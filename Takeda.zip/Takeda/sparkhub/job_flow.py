# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 18:15:15 2019

@author: deloitte
"""

import os
import sys
import sqlite3
import pandas as pd
import logging
import time
import datetime


def main():
    batch_metadata_entry()
    creat_entry_batch_statistics()
    batch=select_job_metadata()
    print(batch)
    #sys.wait(1000)
    fetch_details_job_metadata(batch[0])
   

def db_connection():
    pass

def batch_metadata_entry():
    conn = sqlite3.connect('test.db')
    batch_id='batch_id_1'
    source_system='source_system_1'
    project_name='project_name_1'
    active_flag='Y'
    start_ts=datetime.datetime.now()
    insert_user_id='system'
    update_user_id='system'
    conn.execute('''INSERT INTO batch_metadata
                 (batch_id,source_system,project_name,active_flag,start_ts,insert_user_id,update_user_id)
                 VALUES(?,?,?,?,?,?,?)''', 
                 (batch_id,source_system,project_name,active_flag,start_ts,insert_user_id,update_user_id))
    
    conn.commit()
    conn.close()

def creat_entry_batch_statistics():
    conn = sqlite3.connect('test.db')
    conn.execute('''INSERT INTO batch_statistics (batch_start_ts,insert_user_id,updated_user_id,batch_id) select start_ts,insert_user_id,update_user_id,batch_id from batch_metadata''')
    #conn.execute('''INSERT INTO batch_statistics (batch_start_ts,batch_end_ts,status_code,insert_user_id,updated_user_id,batch_cycle,batch_id) VALUES(?,?,?,?,?,?,?)''', (batch_start_ts,batch_end_ts,status_code,insert_user_id,updated_user_id,batch_cycle,batch_id))
    conn.commit()
    conn.close()
    
def select_job_metadata():
    batch=list()
    conn = sqlite3.connect('test.db')
    cursor=conn.execute('''SELECT distinct(batch_id) FROM batch_statistics''')
    for row in cursor:
        batch.append(row[0])
    conn.close()
    
    return batch
    #entry_job_run_statistics()
    

def fetch_details_job_metadata(batch_id):
    
    conn = sqlite3.connect('test.db')
    print(batch_id)
    cursor=conn.execute('''SELECT * FROM job_metadata WHERE  batch_id=? ''', (batch_id,))
    ## From here call to job execution() 
    print(cursor)
    for row in cursor:
        source_loc_path=row[8]
        target_loc_path=row[12]
        print(source_loc_path)
        print(target_loc_path)
    conn.close()
    entry_job_run_statistics(source_loc_path,target_loc_path)
    
    
def entry_job_run_statistics(source_loc_path,target_loc_path):
    conn = sqlite3.connect('test.db')
    job_run_id='jon_run_id_1'
    batch_run_id='batch_run_id_1'
    job_id='job_id_1'
    start_ts=datetime.datetime.now()
    status_code=0
    job_name='job_name_1'
    insert_user_id='system'
    partition_year_month='jun_2019'
    batch_id='batch_id_1'
    conn.execute('''INSERT INTO job_run_statistics (
                                   job_run_id,
                                   batch_run_id,
                                   job_id,
                                   start_ts,
                                   status_code,
                                   job_name,
                                   insert_user_id,
                                   partition_year_month,
                                   batch_id
                               ) VALUES(?,?,?,?,?,?,?,?,?)''', (
                                   job_run_id,
                                   batch_run_id,
                                   job_id,
                                   start_ts,
                                   status_code,
                                   job_name,
                                   insert_user_id,
                                   partition_year_month,
                                   batch_id))
    conn.commit()
    conn.close()
    end_ts,rows_read,rows_loaded,rows_rejected,status_code,job_id,error_message,error_code,error_file_name=job_execution(job_id,source_loc_path,target_loc_path)
    if(status_code==1):
        job_error_statistics(job_name,error_code,error_message,start_ts,end_ts,insert_user_id,partition_year_month,error_file_name,job_run_id,batch_run_id)
        
    update_job_run_statistics(end_ts,rows_read,rows_loaded,rows_rejected,status_code,job_id)
    
    

def update_job_run_statistics(end_ts,rows_read,rows_loaded,rows_rejected,status_code,job_id):
    #print(values)
    conn = sqlite3.connect('test.db')
    #end_ts=''
    #rows_read=''
    #rows_loaded=''
    #rows_rejected=''
    #status_code=''
    job_run_id='job_run_id_1'
    batch_run_id='batch_run_id_1'
    #job_id=''
    #conn.execute("UPDATE COMPANY set SALARY = 25000.00 where ID = 1")
    conn.execute('''UPDATE job_run_statistics SET 
       end_ts = ?,
       rows_read = ?,
       rows_loaded = ?,
       rows_rejected = ?,
       status_code = ?
       WHERE job_run_id = ? AND 
       batch_run_id = ? AND 
       job_id = ?  ''',(end_ts,rows_read,rows_loaded,rows_rejected,status_code,job_run_id,batch_run_id,job_id,))
    conn.commit()
    conn.close()
    
    print("Tables executed successfully")
    
   
def job_execution(job_id,source_loc_path,target_loc_path):
    end_ts=time.time()
    source_table_count=0
    target_table_count=0
    error_message=""
    error_file_name=''
    error_code=0
    
    try :
        source_table_count=len(pd.read_excel(source_loc_path))
        target_table_count=len(pd.read_excel(target_loc_path))
        status_code=0
        print(source_table_count)
        print(target_table_count)
        if int(source_table_count) == int(target_table_count):
            print("count in source matches with target")
        else:
            print("count in source and target doesnt match")
        rows_read=source_table_count
        rows_loaded=target_table_count
        rows_rejected='none'
    except:
        print("Job failed")
        error_code=1
        error_message='Job failed to execute'
        error_file_name='example_file'
        
    return end_ts,rows_read,rows_loaded,rows_rejected,status_code,job_id,error_message,error_code,error_file_name

def job_error_statistics(job_name,error_code,error_message,start_ts,end_ts,insert_user_id,partition_year_month,error_file_name,job_run_id,batch_run_id):
    conn = sqlite3.connect('test.db')
    conn.execute('''INSERT INTO job_error_statistics (
                                    job_name,
                                    error_code,
                                    error_message,
                                    start_ts,
                                    end_ts,
                                    insert_user_id,
                                    partition_year_month,
                                    error_file_name,
                                    batch_run_id,
                                    job_run_id
                               ) VALUES(?,?,?,?,?,?,?,?,?,?,?)''', (
                                    job_name,
                                    error_code,
                                    error_message,
                                    start_ts,
                                    end_ts,
                                    insert_user_id,
                                    partition_year_month,
                                    error_file_name,
                                    batch_run_id,
                                    job_run_id))
    conn.commit()
    conn.close()

    ##After job execution the return from the job has to be stored in job_run_statistics incase job execution is successfull
    ##Else error code along with error description and other details have to be stored in job_error_statistics
    
#if __name__=="__main__":
    #db_connection()
   # main()
    
    ##Input for fetch_details_job_metadata will be taken from excel sheet