
spark_path = r'/opt/mapr/spark/spark-2.2.1/bin'
app_path = r''
spark_master = r'local[*]'
spark_deploy_mode = 'client'
spark_executor_memory = '4G'
spark_executor_cores = '2'
spark_num_executors = '10'
spark_conf = None
app_archive =  "hub_app.zip,hub_config.py"
application_file = "run.py"
log_path = r''
wait_for_completion = False
#hub_app_config
job_config = 'file:///home/ec2-user/sparkhub/hub_app/configs/job_cfg.csv'
op_config = "file:///home/ec2-user/sparkhub/hub_app/configs/op_cfg.csv"
override_file = "file:///home/ec2-user/sparkhub/hub_app/configs/override_config.csv"
application_id_path = "hdfs:///gpdip/dev/temp/sparkhub_applications"
temp_path = "hdfs:///gpdip/dev/temp/"
debug_mode = True
debug_rows = 2
config_file_format = "csv"

#paths rationalization
raw_hdfs = ''
raw_s3 = ''
curated_hdfs = ''
curated_s3 = ''
conformed_hdfs = ''
conformed_s3 = ''
temp_hdfs = ''
temp_s3 = ''
