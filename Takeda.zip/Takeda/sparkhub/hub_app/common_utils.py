import linecache, sys, re, hashlib


def get_exception(debug=True):
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
    err_obj = {
        'error_code':str(exc_type),
        'error_message':str(exc_obj)
    }
    if debug:
        err_obj['error_at']='EXCEPTION IN ({},LINE {} "{}")'.format(filename,lineno,line.strip())
    return err_obj


def errorify(error_code='',error_message='',error_at=''):
    return {
            'error_code':str(error_code),
            'error_message':str(error_message),
            'error_at':str(error_at)
        }
    
        
def keyfy(inp_str):
       return re.sub(r'[^A-Za-z0-9_-]+','',inp_str).upper()


def glob_to_re(pat):
    """
       taken from: https://stackoverflow.com/a/29820981
       Translate a shell PATTERN to a regular expression.
       There is no way to quote meta-characters.
    """
    i, n = 0, len(pat)
    res = ''
    while i < n:
        c = pat[i]
        i = i+1
        if c == '*':
            #res = res + '.*'
            res = res + '[^/]*'
        elif c == '?':
            #res = res + '.'
            res = res + '[^/]'
        elif c == '[':
            j = i
            if j < n and pat[j] == '!':
                j = j+1
            if j < n and pat[j] == ']':
                j = j+1
            while j < n and pat[j] != ']':
                j = j+1
            if j >= n:
                res = res + '\\['
            else:
                stuff = pat[i:j].replace('\\','\\\\')
                i = j+1
                if stuff[0] == '!':
                    stuff = '^' + stuff[1:]
                elif stuff[0] == '^':
                    stuff = '\\' + stuff
                res = '%s[%s]' % (res, stuff)
        else:
            res = res + re.escape(c)
    return res + '\Z(?ms)'

def glob_filter_keep(l_files,pattern):
    return [f for f in l_files if re.search(glob_to_re(pattern),f.file_path_str)]

def glob_filter_remove(l_files,pattern):
    return [f for f in l_files if not re.search(glob_to_re(pattern),f.file_path_str)]

def make_table_name(name):
    tname = name
    if '/' in name or '\\' in name:
        l_parts = re.split(r'[\/]+',name)
        tname = l_parts[-1]
    if '.' in name:
        l_parts = name.split('.')
        tname = l_parts[-2]
    tname = re.sub(r'[ \t]+','_',tname)
    tname = re.sub(r'[^A-Za-z0-9_]+','',tname)
    tname = tname.lower()
    return tname

def get_md5(name):
    m = hashlib.md5()
    if sys.version_info[0]<3:
        m.update(str(name))
    else:
        m.update(name.encode('utf-8'))
    fkey = m.hexdigest()
    return fkey

def get_file_extension(name):
    ext = None
    if not name:
        return ext
    if name:
        name = name.strip().lower()
        if name == '':
            return ext
    if '.' in name:
        l_parts = name.split('.')
        if l_parts:
            t_ext = l_parts[-1]
            if t_ext in ['csv','avro','asvc','parquet','txt']:
                ext = t_ext
    if not ext:
        ext = ''
    return ext