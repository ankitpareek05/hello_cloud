
from hub_app.common_utils import get_exception, errorify, glob_filter,get_file_extension,get_md5, make_table_name
import hub_app.const as cc
from collections import defaultdict
class SyncOperations:
    def __init__(self,spark,**kwargs):
        sc = spark.sparkContext
        self.app_id = sc.applicationId
        self.sc = sc
        self.URI           = sc._jvm.java.net.URI
        self.Path          = sc._jvm.org.apache.hadoop.fs.Path
        self.FileSystem    = sc._jvm.org.apache.hadoop.fs.FileSystem
        self.FSDIN         = sc._jvm.org.apache.hadoop.fs.FSDataInputStream
        self.Configuration = sc._jvm.org.apache.hadoop.conf.Configuration
        self.FileUtil      = sc._jvm.org.apache.hadoop.fs.FileUtil
        self.conf = self.Configuration()
        
        self.spark = spark
        self.sync_id = kwargs.get('sync_id')
        self.source_dir = kwargs.get('source_dir')
        self.target_dir = kwargs.get('target_dir')
        self.target_sync_dir = self.target_dir+'/'+self.sync_id
        self.reference_dir = kwargs.get('reference_dir')
        self.table_format = kwargs.get('table_format')
        self.schema_name = kwargs.get('schema_name')
        
        self.l_allowed_patterns = ['*']
        self.l_exclude_patterns = []
        self.pattern_delimiter = cc.input_column_delimiter
        
        if 'delimiter' in kwargs:
            delim = kwargs.get('delimiter')
            if delim and delim.strip()!='':
                self.pattern_delimiter = delim
                
        if 'allowed_file_patterns' in kwargs:
            afp = kwargs.get('allowed_file_patterns')
            if afp and afp.strip()!='':
                self.l_allowed_patterns = afp.split(self.pattern_delimiter)
        
        if 'exclude_file_patterns' in kwargs:
            efp = kwargs.get('exclude_file_patterns')
            if efp and efp.strip()!='':
                self.l_exclude_patterns = efp.split(self.pattern_delimiter)
            
        
        self.delete_source = False
        self.overwrite_target = True

        
        self.source_uri = None
        self.target_uri = None
        self.ref_uri = None
        self.source_fs = None
        self.tgt_fs = None
        self.ref_fs = None
        self.d_tasks = {}
        self.d_ref_files={}
#         self.start_path = None
#         self.target_path = None
#         self.check_path = None
        
        
    def set_params(self):
        try:
            print(self.source_dir)
            self.source_uri = self.URI(self.source_dir)
            self.target_uri = self.URI(self.target_dir)
            self.ref_uri = self.URI(self.reference_dir)
            
            self.source_fs = self.FileSystem.get(self.source_uri,self.conf)
            self.tgt_fs = self.FileSystem.get(self.target_uri ,self.conf)
            self.ref_fs = self.FileSystem.get(self.ref_uri,self.conf)
#             self.d_ref_files,e = self.read_reference_files()
#             if e:
#                 print(e)
#             self.start_path = self.Path(self.source_uri.getPath())
#             self.target_path = self.Path(self.target_uri.getPath())
#             self.check_path = self.Path(self.ref_uri.getPath())
            return None
        except:
            e = get_exception()
            print(e)
            return e
    
    def walk_path(self,start_dir):
        """
        implement the ls -R functionality in python using hadoop file utils.
        accepts three parameters
         source_file_path: s3a://bucket_name/dir_path
         l_allowed_format_pattern: ['*.csv','*.avro','*.parquet']
         l_exclude_file_pattern: ['*.xlsx'] 
        returns the list of files
        """
        d_res = {}
        try:
            #get directories
            l_paths = self.source_fs.globStatus(self.Path(start_dir+'/*'))
            l_dirs = []
            l_files = []
            for fp in l_paths:
                if fp.isDirectory():
                    l_dirs.append(fp.getPath().toString())
                elif fp.isFile():
                    l_files.append(fp.getPath().toString())
            #find allowed_files
#             print("Files in dir:",start_dir,l_files)
            l_allowed = []
            for pat in self.l_allowed_patterns:
                l_temp = glob_filter(l_files,pat)
#                 print("Allowed Files returned from glob_filter:",pat,l_temp)
                if l_temp:
                    l_allowed+=l_temp
            l_exclude = []
            #find excluded files
            for pat in self.l_exclude_patterns:
                l_temp = glob_filter(l_files,pat)
#                 print("Exclude Files returned from glob_filter:",pat,l_temp)
                if l_temp:
                    l_exclude+=l_temp
            #remove excluded files from allowed files

            l_final = set(l_allowed) - set(l_exclude)
            l_final = list(l_final)

            d_ext_files = defaultdict(list)    
            if l_final:
                for fl in l_final:
                    ext = get_file_extension(fl)
                    if ext == 'asvc':
                        ext = 'avro'
                    d_ext_files[ext].append(fl)
                    
                d_res[start_dir] = d_ext_files
            #walk the sub directories
            for sub_dir in l_dirs:
                d_sub_res,err = self.walk_path(sub_dir)
                for k,v in d_sub_res.items():
                    d_res[k] = v
            return d_res,None
            
        except:
            e = get_exception()
            return d_res,e
    
    def read_reference_files(self,ref_grp_dir):
        d_res = {}
#         ref_grp_dir = self.reference_dir+'/'+self.sync_id
        try:
            l_files = self.ref_fs.globStatus(self.Path(ref_grp_dir+'/*'))
            print(l_files)
            for fp in l_files:
                check_path = fp.getPath()
                check_file_name = check_path.getName()
                inp_s = self.ref_fs.open(check_path)
                prevmodtime=''
                try:
                    while inp_s.available() > 0:
                        value = inp_s.read()  
                        if value:
                            prevmodtime+=chr(value)
                    
                except:
                    e = get_exception()
                    print(e)
                    prevmodtime=''
                if prevmodtime == '': prevmodtime='0'
                d_res[check_file_name] = prevmodtime
            return d_res,None
        except:
            e = get_exception()
            return d_res,e
        
    def write_reference_file(self,ref_grp_dir,file_name,modification_time):
        try:
            e = None
            check_path = ref_grp_dir+'/'+file_name
            fout = self.ref_fs.create(self.Path(check_path), True)
            fout.writeBytes(str(modification_time))
            fout.close()
            return e
        except:
            e = get_exception()
            return e
        
    def delete_file(self,file_system, file_path):
        try:
            e = None
            path_exists = file_system.exists(file_path)
            if path_exists:
                stat = file_system.delete(file_path,True)
            else:
                stat = True
            return stat,e
        except:
            e = get_exception()
            return False,e
    
    def copy_file_to_sync(self,source_path,target_path):
        try:
            e = None
            res = self.FileUtil.copy(self.source_fs, source_path, self.tgt_fs, target_path, self.delete_source, self.overwrite_target, self.conf)
            
            return res,e
        except:
            e = get_exception()
            return False,e
    
    def write_to_target_dir(self,source_format, source_dir,target_dir,schema_name, table_name,avro_schema_file=None):
        try:
            e = None
            print("Format:",source_format)
            if source_format == "avro":
                return self.write_avro_to_target(source_format, source_dir, target_dir, schema_name, table_name, avro_schema_file)
            spark = self.spark
            result_df = None
            #read_files
            if source_format == 'csv':
                is_multiline = True
                has_header = True
                column_delimiter = ','
                quote_char = '"'
                escape_char = '\\'
                result_df = spark.read.format("csv").option(
                    "multiline",str(is_multiline)).option(
                        "delimiter",column_delimiter).option(
                            'quote',quote_char).option(
                                'escape',escape_char).option(
                                    "header", str(has_header)).load(source_dir)
            
            elif source_format == 'parquet':
                result_df =  spark.read.parquet(source_dir)
            elif source_format == 'avro':
                result_df = spark.avro.read(source_dir)
            else :
                result_df =  spark.read.format(file_format).load(source_dir)
            
            
            if result_df:
                spark.conf.set("spark.sql.parquet.writeLegacyFormat","True")
                temp_table_name = str(table_name+'_{}_temp'.format(self.sync_id))
                result_df.createOrReplaceTempView(temp_table_name)
                q_tbl = table_name
                if schema_name:
                    if schema_name.strip()!='':
                        q_tbl = schema_name+'.'+table_name
                drop_sql_text = 'DROP TABLE IF EXISTS '+q_tbl
                create_sql_text = """CREATE EXTERNAL TABLE {table_name}
                                     STORED AS {format}
                                     LOCATION '{location}'
                                     AS SELECT * FROM {temp_table_name}
                                  """.format(table_name = q_tbl,
                                             format='PARQUET',
                                             location=target_dir,
                                             temp_table_name = temp_table_name
                                            )
                try:
                    drop_res = spark.sql(drop_sql_text)
                except:
                    pass
                create_res = spark.sql(create_sql_text)
                print(create_res)
                return True,None
                
            return True,e
        except:
            e = get_exception()
            return False,e
    def write_avro_to_target(self,source_format, source_dir,target_dir,schema_name, table_name,avro_schema_file = None):
        try:
            q_tbl = table_name
            if schema_name and schema_name.strip()!='':
                q_tbl = schema_name+'.'+table_name
            spark = self.spark
            drop_sql_text = 'DROP TABLE IF EXISTS '+q_tbl
            """
                CREATE EXTERNAL TABLE my_avro_tbl
                  ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.avro.AvroSerDe'
                  STORED as INPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat'
                  OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat'
                  LOCATION '/user/...'
                  TBLPROPERTIES ('avro.schema.url'='hdfs://name-node.fqdn:8020/user/.../schema.avsc');
            """
            create_sql_text = """CREATE EXTERNAL TABLE {table_name}
                                 STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat'
                                 OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat'
                                 LOCATION '{location}'
                                 
                              """.format(table_name = q_tbl,
                                         location=source_dir
                                        )
            if avro_schema_file:
                tbl_properties = "\nTBLPROPERTIES ('avro.schema.url'='hdfs:///{}')".format(avro_schema_file)
                create_sql_text+=tbl_properties
            print(create_sql_text)
            try:
                drop_res = spark.sql(drop_sql_text)
            except:
                pass
            create_res = spark.sql(create_sql_text)
            print(create_res)
            return True,None
            
        except:
            e = get_exception()
            print(e)
            return False,e
        
    def cmp_files(self,start_dir):
        
        pass
    def process(self,start_dir,task):
        """
        start_dir: source directory
        task: {extension : list of files}
        check_grp_dir = self.reference_dir+'/'+sync_id+'/'+md5(start_dir)
        target_grp_dir = self.target_dir+'/'+sync_id+'/'
        The following logic has been implemented:
        for a check_grp_dir get all the file_names  
        compare them to the incoming task file names
        identify new,modified and expired files this way
        """
        try:
            is_root_dir = False
            if self.source_dir == start_dir:
                is_root_dir = True
            start_dir_md5 = get_md5(start_dir)  
            ref_grp_dir = self.reference_dir+'/'+self.sync_id+'/'+start_dir_md5
            d_ref_prevmod,e = self.read_reference_files(ref_grp_dir)
            print(e)
            target_sync_dir = self.target_dir+'/'+self.sync_id 
            
            start_table_name = make_table_name(start_dir)
            #logic for setting hte table name
            # if root_dir then files are tables
            # else folder name is table name
            
                
    
            l_exists = []
            l_tobedeleted = []
            l_copy_failures = []
            l_exts = task.keys()
            d_tables = {}
            if not is_root_dir and len(l_exts)>1:
                print("Multiple file types found in sub folder",start_dir)
            
            for ext,l_files in task.items():
                
                l_final_paths = [self.Path(x) for x in l_files]
                l_final_status = [self.source_fs.getFileStatus(x) for x in l_final_paths]
                avro_schema_file = None
                for lf in l_final_status:
                    
                    file_path = lf.getPath()
                    file_name = file_path.getName()
                    f_ext = get_file_extension(file_name)
                    
                    file_path_str = lf.getPath().toString()
                    modtime = lf.getModificationTime()
                    prevmodtime = '0'
                    
                    if file_name in d_ref_prevmod:
                        l_exists.append(file_name)
                        prevmodtime = d_ref_prevmod.get(file_name)
                    if modtime>int(prevmodtime):
                        
                        target_path_str = target_sync_dir
                        table_name = start_table_name
                         
                        if is_root_dir:
                            table_name = make_table_name(file_name)
                        d_tables[table_name] = (target_path_str+'/'+table_name,self.target_dir+'/'+table_name,ext,avro_schema_file)
                        target_path_str += '/'+table_name +'/'+file_name
                        target_path = self.Path(target_path_str)
                        
                        status,e = self.copy_file_to_sync(file_path, target_path)
                        if e:
                            print(e)
                            l_copy_failures.append((file_path_str,e))
                        elif status:
                            self.write_reference_file(ref_grp_dir,file_name,modtime)
                
                            
                        
                    
            #delete files from ref_grp_dir
            l_prev = d_ref_prevmod.keys()
            
            s_tobedeleted = set(l_prev)-set(l_exists)
            l_tobedeleted = list(s_tobedeleted)
            print("to be deleted:",l_tobedeleted)
            for file_name in l_tobedeleted:
                target_path_str = target_sync_dir
                table_name = start_table_name
                if is_root_dir:
                    table_name = make_table_name(file_name)
                target_path_str += '/'+table_name +'/'+file_name
                self.delete_file(self.ref_fs, self.Path(ref_grp_dir+'/'+file_name))
                self.delete_file(self.tgt_fs, self.Path(target_path_str))
            
            #create hive table
            for table_name, paths in d_tables.items(): 
                source_dir = paths[0]
                target_dir = paths[1]
                source_format = paths[2]
                avro_schema_file = paths[3]
                stat,e = self.write_to_target_dir(source_format=source_format,
                                                   source_dir=source_dir,
                                                   target_dir=target_dir,
                                                   schema_name=self.schema_name,
                                                    table_name = table_name,
                                                    avro_schema_file = avro_schema_file)
                print(e)
            return None
        except:
            e = get_exception()
            return e        
            
                
        
    def run(self):
        try:
            e = None
            e= self.set_params()
            if e:
                return e
            d_res,e = self.walk_path(self.source_dir)
            self.d_tasks = d_res
            for start_dir, d_ext_files in self.d_tasks.items():
                print(start_dir)
                print(d_ext_files)
                e = self.process(start_dir, d_ext_files)
            return e
        except:
            e = get_exception()
            
            return e    