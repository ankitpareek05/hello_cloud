

input_column_delimiter='|'
delimiter_key = "delimiter"
dataframe_name_key = "dataframe_name"
default_timestamp_format = '%Y-%m-%d/%H-%M-%S'
 