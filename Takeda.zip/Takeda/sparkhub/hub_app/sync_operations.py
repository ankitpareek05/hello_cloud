
from hub_app.common_utils import get_exception, errorify, glob_filter_keep, glob_filter_remove, get_file_extension, get_md5, make_table_name
import hub_app.const as cc
from hub_app.sync_file import SFile
from collections import defaultdict

class SyncOperations:
    def __init__(self,spark,**kwargs):
        sc = spark.sparkContext
        self.app_id = sc.applicationId
        self.sc = sc
        self.URI           = sc._jvm.java.net.URI
        self.Path          = sc._jvm.org.apache.hadoop.fs.Path
        self.FileSystem    = sc._jvm.org.apache.hadoop.fs.FileSystem
        self.FSDIN         = sc._jvm.org.apache.hadoop.fs.FSDataInputStream
        self.Configuration = sc._jvm.org.apache.hadoop.conf.Configuration
        self.FileUtil      = sc._jvm.org.apache.hadoop.fs.FileUtil
        self.conf = self.Configuration()
        
        self.spark = spark
        self.sync_id = kwargs.get('sync_id')
        self.source_dir = kwargs.get('source_dir')
        self.target_dir = kwargs.get('target_dir')
        self.target_sync_dir = self.target_dir+'/'+self.sync_id
        self.reference_dir = kwargs.get('reference_dir')
        self.table_format = kwargs.get('table_format')
        self.schema_name = kwargs.get('schema_name')
        
        self.l_allowed_patterns = ['*']
        self.l_exclude_patterns = []
        self.pattern_delimiter = cc.input_column_delimiter
        
        
        if 'delimiter' in kwargs:
            delim = kwargs.get('delimiter')
            if delim and delim.strip()!='':
                self.pattern_delimiter = delim
                
        if 'allowed_file_patterns' in kwargs:
            afp = kwargs.get('allowed_file_patterns')
            if afp and afp.strip()!='':
                self.l_allowed_patterns = afp.split(self.pattern_delimiter)
        
        if 'exclude_file_patterns' in kwargs:
            efp = kwargs.get('exclude_file_patterns')
            if efp and efp.strip()!='':
                self.l_exclude_patterns = efp.split(self.pattern_delimiter)
            
        
        self.delete_source = False
        self.overwrite_target = True

        
        self.source_uri = None
        self.target_uri = None
        self.ref_uri = None
        self.source_fs = None
        self.tgt_fs = None
        self.ref_fs = None
        self.d_tasks = {}
        self.d_ref_files={}
        self.s_ref_exists = set()
#         self.start_path = None
#         self.target_path = None
#         self.check_path = None
        
        
    def set_params(self):
        try:
            print(self.source_dir)
            self.source_uri = self.URI(self.source_dir)
            self.target_uri = self.URI(self.target_dir)
            self.ref_uri = self.URI(self.reference_dir)
            
            self.source_fs = self.FileSystem.get(self.source_uri,self.conf)
            self.tgt_fs = self.FileSystem.get(self.target_uri ,self.conf)
            self.ref_fs = self.FileSystem.get(self.ref_uri,self.conf)
#             self.d_ref_files,e = self.read_reference_files()
#             if e:
#                 print(e)
#             self.start_path = self.Path(self.source_uri.getPath())
#             self.target_path = self.Path(self.target_uri.getPath())
#             self.check_path = self.Path(self.ref_uri.getPath())
            return None
        except:
            e = get_exception()
            print(e)
            return e
    
    
    
    
    
    def walk_source_path(self,start_dir):
        """
        implement the ls -R functionality in python using hadoop file utils.
        accepts three parameters
         source_file_path: s3a://bucket_name/dir_path
         l_allowed_format_pattern: ['*.csv','*.avro','*.parquet']
         l_exclude_file_pattern: ['*.xlsx'] 
        returns the list of files
        """
        d_res = {}
        try:
            #get directories
            l_paths = self.source_fs.globStatus(self.Path(start_dir+'/*'))
            l_dirs = []
            l_files = []
            
            for fs in l_paths:
                fp = fs.getPath()
                if fs.isDirectory():
                    l_dirs.append(fp.toString())
                elif fs.isFile():

                    sf = SFile()
                    
                    e = sf.set_params(file_status = fs, root_dir = self.source_dir)
                    if e:
                        print(e)
                        return None,e
                    ref_path_key = sf.get_ref_path()
                    print("Expected ref_path_key:",ref_path_key)
                    prevmodtime = '0'
                    #check if ref_path exists in d_ref_files
                    if ref_path_key in self.d_ref_files:
                        prevmodtime = self.d_ref_files.get(ref_path_key)
                        self.s_ref_exists.add(ref_path_key)
                    is_new_or_changed = sf.is_new_or_changed(prevmodtime)
                    if is_new_or_changed: 
                        l_files.append(sf)

            #Filter allowed patterns
            l_allowed = []
            if self.l_allowed_patterns:
                for pat in self.l_allowed_patterns:
                    l_temp = glob_filter_keep(l_files,pat)
                    print("Allowed Files returned from glob_filter:",pat,l_temp)
                    if l_temp:
                        l_allowed+=l_temp
            else:
                l_allowed = l_files
            
            #remove exclude patterns
            if l_allowed and self.l_exclude_patterns:
                for pat in self.l_exclude_patterns:
                    l_final = glob_filter_remove(l_allowed,pat)
    #                 
            else:
                l_final = l_allowed
            
                
            if l_final:
#                 for fl in l_final:
#                     ext = get_file_extension(fl)
#                     if ext == 'asvc':
#                         ext = 'avro'
#                     d_ext_files[ext].append(fl)
                     
                d_res[start_dir] = l_final
            
            #walk the sub directories
            for sub_dir in l_dirs:
                d_sub_res,err = self.walk_source_path(sub_dir)
                for k,v in d_sub_res.items():
                    d_res[k] = v
            return d_res,None
            
        except:
            e = get_exception()
            return d_res,e
    
    
    def find_delete_files(self):
        try:
            s_all_refs = set(self.d_ref_files.keys())
            s_exists = self.s_ref_exists
            s_to_be_deleted = s_all_refs - s_exists
            l_to_be_deleted = list(s_to_be_deleted)
            print ("To be deleted:",l_to_be_deleted)
            return l_to_be_deleted
        except:
            e = get_exception()
            return e
        
    def write_reference_file(self,sfile):
        try:
            e = None
            ref_grp_dir = self.reference_dir+'/'+self.sync_id
            ref_path = sfile.get_ref_path()
            modification_time = sfile.last_modified_at
            if e:
                return e
            
            check_path = ref_grp_dir+'/'+ref_path
        
            fout = self.ref_fs.create(self.Path(check_path), True)
            fout.writeBytes(str(modification_time))
            fout.close()
            return e
        except:
            e = get_exception()
            return e
    
    
    def read_reference_dir(self):
        d_res = {}
        ref_grp_dir = self.reference_dir+'/'+self.sync_id
        e = None
        try:
            ref_path = self.Path(ref_grp_dir+'/')
            if not self.ref_fs.exists(ref_path):
                return d_res,None
            l_files = self.ref_fs.listFiles(self.Path(ref_grp_dir+'/'),True)
            
            #for fp in l_files:
            while l_files.hasNext():
                fp = l_files.next()
            
                if fp.isDirectory():
                    continue
                check_path = fp.getPath()
                check_path_str = check_path.toString()
                
                check_path_key = check_path_str.replace(ref_grp_dir,'')
                print(check_path_key, ref_grp_dir)
                check_file_name = check_path.getName()
                inp_s = self.ref_fs.open(check_path)
                prevmodtime=''
                try:
                    while inp_s.available() > 0:
                        value = inp_s.read()  
                        if value:
                            prevmodtime+=chr(value)
                    
                except:
                    e = get_exception()
                    prevmodtime=''
                if prevmodtime == '': prevmodtime='0'
                d_res[check_path_key] = prevmodtime
            return d_res,None
        except:
            e = get_exception()            
            return d_res,e
    
    
    def find_groups(self,l_files):
        d_res = defaultdict(list)
        try:
            for sf in l_files:
                ext = sf.ext
                if ext == 'asvc':
                    ext = 'avro'
                table_name = sf.table_name
                ref_grp_name = sf.ref_path_grp
                d_res[ref_grp_name].append(sf)
            return d_res,None
        except:
            return None,get_exception()
    
    def parse_groups(self,d_src):
        e = None
        try:
            for dir_name, l_files in d_src.items():
                d_grps,e = self.find_groups(l_files)
                if e:
                    return e
                for grp_name, l_sf in d_grps.items():
                    e = self.process_group(dir_name, grp_name, l_sf)
                    if e:
                        return e
                    
            return e
        except:
            e = get_exception()
            return e
    
    def copy_file_to_sync(self,source_path,target_path):
        try:
            e = None
            res = self.FileUtil.copy(self.source_fs, source_path, self.tgt_fs, target_path, self.delete_source, self.overwrite_target, self.conf)
            
            return res,e
        except:
            e = get_exception()
            return False,e
        
    def delete_file(self,file_system, file_path):
        try:
            e = None
            path_exists = file_system.exists(file_path)
            if path_exists:
                stat = file_system.delete(file_path,True)
            else:
                stat = True
            return stat,e
        except:
            e = get_exception()
            return False,e    
    
    def process_group(self,dir_path,grp_name,l_files):
        l_copied = []
        l_failed = []
        try:
            #for each table do the following:
            # 1. if files are of csv format, then write them to staging location, and convert them to parquet into the target table
            # 2. if files are of type avro, then write them to target location directly 
            target_sync_dir = self.target_dir+'/'+self.sync_id
            print(dir_path,grp_name,str(l_files))
            l_grp = grp_name.split('#')
            table_name = l_grp[0]
            ext = l_grp[1]
            target_dir_path = target_sync_dir+'/'+grp_name
            target_table_path = self.target_dir+'/'+table_name
            for sf in l_files:
                source_path = self.Path(sf.file_path_str)
                target_path = self.Path(target_dir_path+'/'+sf.file_name)
                res,e = self.copy_file_to_sync(source_path, target_path)
                if e:
                    print(e)
                    sf.error.append(e)
                    l_failed.append(sf)
                l_copied.append(sf)
            
            #create table
            l_tabled = []
            stat,e = self.create_table(self.schema_name, table_name, ext, target_dir_path,target_table_path )
            if not stat:
                if e:
                    print(e)
                    return e
            
            
            #write_reference_files
            for sf in l_copied:
                e = self.write_reference_file(sf)
                if e:
                    print(e)
                    sf.error.append(e)
            return None
        except:
            return get_exception()
        
    def create_table(self,schema_name, table_name, file_type,source_path_str, target_path_str):
        e = None
        try:
            #1. Read csv files from source dir path
            spark = self.spark
            result_df = None
            #read_files
            if file_type == 'csv':
                is_multiline = True
                has_header = True
                column_delimiter = ','
                quote_char = '"'
                escape_char = '\\'
                result_df = spark.read.format("csv").option(
                    "multiline",str(is_multiline)).option(
                        "delimiter",column_delimiter).option(
                            'quote',quote_char).option(
                                'escape',escape_char).option(
                                    "header", str(has_header)).load(source_path_str)
                                    
            
            else:
                e = errorify('INVALID FILE FORMAT','Files encountered with an invalid type,<{}>,Skipping.. '.format(file_type))
                return True,e
            
            #create a temp table on the dataframe
            if result_df:
                spark.conf.set("spark.sql.parquet.writeLegacyFormat","True")
                temp_table_name = str(table_name+'_{}_temp'.format(self.sync_id))
                result_df.createOrReplaceTempView(temp_table_name)
                
                #create target external hive table
                q_tbl = table_name
                if schema_name:
                    if schema_name.strip()!='':
                        q_tbl = schema_name+'.'+table_name
                drop_sql_text = 'DROP TABLE IF EXISTS '+q_tbl
                create_sql_text = """CREATE EXTERNAL TABLE {table_name}
                                     STORED AS {format}
                                     LOCATION '{location}'
                                     AS SELECT * FROM {temp_table_name}
                                  """.format(table_name = q_tbl,
                                             format='PARQUET',
                                             location=target_path_str,
                                             temp_table_name = temp_table_name
                                            )
#                 try:
#                     drop_res = spark.sql(drop_sql_text)
#                 except:
#                     pass
#                 create_res = spark.sql(create_sql_text)
                print(drop_sql_text)
                print(create_sql_text)
                return True,None
            return True,e
        except:
            e = get_exception()
            return False, e
        
    def run(self):
        try:
            e = None
            e= self.set_params()
            if e:
                return e
            #read reference files
            d_ref,e = self.read_reference_dir()
            if e:
                return e
            #debug reference files
            for ref_path, modtime in d_ref.items():
                print("ref_path: {}, prevmodtime:{}".format(ref_path,modtime))
            
            self.d_ref_files = d_ref
            
            #check source files
            d_src,e = self.walk_source_path(self.source_dir)
            if e:
                return e
            
            #delete non existent files
            self.find_delete_files()
            #debug what's getting returned from source
#             for dir_name, l_files in d_src.items():
#                 for f in l_files:
#                     print( dir_name, str(f))
            e = self.parse_groups(d_src)
            if e:
                return e
#             self.d_tasks = d_res
#             for start_dir, d_ext_files in self.d_tasks.items():
#                 print(start_dir)
#                 print(d_ext_files)
#                 e = self.process(start_dir, d_ext_files)
            return e
        except:
            e = get_exception()
            
            return e    