import re
from hub_app.func_utils import get_exception, errorify
from pyspark.sql.types import *
from datetime import datetime
from collections import OrderedDict
import pyspark.sql.functions as pyfunc
from hub_app.schema_operations import make_schema


        
def read_file(spark,**kwargs):
    try:
        file_path = kwargs.get('file_path')
        file_format = kwargs.get('file_format')
        result_dataframe_name = kwargs.get('result_dataframe')
        validate = False
        result_df = None
        e = None
        schema_file = None
        has_header = True
        is_multiline = True
        column_delimiter = ','
        quote_char = '"'
        escape_char = '\\'
        sch_obj = None
        schema = None
        if "validate" in kwargs:
            vld = kwargs.get("validate")
            if vld:
                vld = vld.strip().upper()
                if vld == 'TRUE':
                    validate = True
        if "schema_file" in kwargs:
            schema_file = kwargs.get("schema_file")
        if "has_header" in kwargs:
            hh = kwargs.get('has_header')
            if hh.strip().upper() == 'FALSE':
                has_header = False
            
        if "is_multiline" in kwargs:
            im = kwargs.get("is_multiline")
            im_key = im.strip().upper()
            if im_key == 'FALSE':
                is_multiline = False
            
        if "column_delimiter" in kwargs:
            cd = kwargs.get("column_delimiter")
            if cd and cd.strip() != '':
                column_delimiter = cd
        if "quote_char" in kwargs:
            qc = kwargs.get('quote_char')
            if qc and qc.strip()!='':
                quote_char = qc
        if "escape_char" in kwargs:
            ec = kwargs.get('escape_char')
            if ec and ec.strip() != '':
                escape_char = ec
        
                
        if file_format == 'csv':
#              
            result_df = spark.read.format("csv").option(
                "multiline",str(is_multiline)).option(
                    "delimiter",column_delimiter).option(
                        'quote',quote_char).option(
                            'escape',escape_char).option(
                                "header", str(has_header)).load(file_path)
#             result_df = spark.read.csv(file_path,header=hasHeader, schema = None).alias(result_dataframe_name)
            
        elif file_format == 'parquet':
            result_df =  spark.read.parquet(file_path).alias(result_dataframe_name)
        else :
            result_df =  spark.read.format(file_format).load(file_path).alias(result_dataframe_name)
        if validate and schema_file:
            file_count = result_df.count()
            if file_count > 0:
                return validate_dataframe(spark,result_df,**kwargs)


        return result_df , None,None
    except:
        e = get_exception()
        return None,None, e



def cmp_columns(file_cols, schema_cols):
    """
    to compare the columns actually there in file and the columns provided in the schema file
    1.if column is there in file but not in schema
    2.if column in schema but not in file
    Here schema will be treated as the source of truth, and columns will be mapped based on the schema file
    return intersect of both and index of column from file and index of column in schema
    """
    f_set = set(file_cols)
    s_set = set(schema_cols)
#     l_matched_cols = f_set & s_set
    #columns in file but not in schema
    l_unmatch_in_file = f_set - s_set
    #columns in schema but not in file
    l_unmatch_in_schema = s_set - f_set
    
    return l_unmatch_in_file, l_unmatch_in_schema
    
    
    
    
   
def validate_dataframe(spark,df,**kwargs):
    """
    function to clean specific columns in the dataframe
    return: dataframe
    """
    try:
        d_cols = OrderedDict()
        schema_file = kwargs.get('schema_file')
        remove_newline = False
        if 'remove_newline' in kwargs:
            rn = kwargs.get('remove_newline')
            if rn and rn.strip().upper() == 'TRUE':
                remove_newline = True
                
        sch_obj =  make_schema(spark,schema_file)
        file_cols = df.columns
        schema_cols = sch_obj.get_column_names()
        if len(file_cols) != len(schema_cols):
            l_file,l_sch = cmp_columns(file_cols, schema_cols)
            err_msg = 'There is a mismatch between the columns in the data file and the schema file.\n'
            if l_file:
                err_msg += " Columns present in file but not in schema : <{}>\n".format(','.join(l_file))
            if l_sch:
                err_msg += " Columns present in schema but not in file : <{}>\n".format(','.join(l_sch))
                
            e = errorify('INVALID_SCHEMA', err_msg,'Validate DataFrame Operation')
            return None, None, e
        valid_schema = sch_obj.get_dataframe_schema().add("ERROR_MESSAGE",StringType(), True)
        valid_schema_cols = sch_obj.get_dataframe_column_types()
        valid_schema_cols.append(StringType())
        d_cols = sch_obj.get_validateable_column_datatypes()
        l_exprs = []


        for r_col,dtypes in d_cols.items():
            dtype = dtypes[0]
            is_nullable = dtypes[1]
            if dtype != 'STRING':
                v_expr = "pyfunc.col('{}').validate_datatype('{}',name='{}')".format(r_col,dtype,r_col)
                l_exprs.append(v_expr)
            if not is_nullable:
                v_expr = "pyfunc.col('{}').validate_not_null(name='{}')".format(r_col,r_col)
                l_exprs.append(v_expr)
            
        v_l_expr = "pyfunc.concat_ws('{delim}',{list_of_cols})".format(delim = '|',
                                                            list_of_cols = ','.join(l_exprs)
                                                            )
        f_v_expr = "df.withColumn('{}',{})".format('ERROR_MESSAGE',v_l_expr)
#         print (f_v_expr)
        df = eval(f_v_expr)

        df = df.withColumn('ERROR_MESSAGE',pyfunc.regexp_replace(df['ERROR_MESSAGE'],'[\|]+','|'))
        
        valid_df = df.filter(df['ERROR_MESSAGE'].isin('|',''))
        
        d_col_type = sch_obj.get_columns_spark_types()
        for d_col,s_type_t in d_col_type.items():
            h_type = s_type_t[1]
            s_type = s_type_t[0]

            if h_type in ['DATE','DATETIME','TIMESTAMP']:
                
                valid_df = valid_df.withColumn(d_col,valid_df[d_col].rationalize_year().cast(TimestampType()))
            else:
                valid_df = valid_df.withColumn(d_col,valid_df[d_col].cast(s_type))
            
        if remove_newline:
            d_str_col_type = sch_obj.get_string_columns()
            for d_col,s_type in d_str_col_type.items():
                valid_df = valid_df.withColumn(d_col,pyfunc.col(d_col).remove_newline()) 
        
        invalid_df = df.filter(~df['ERROR_MESSAGE'].isin('|',''))
        valid_df = valid_df.drop('ERROR_MESSAGE')


        return valid_df,invalid_df,None
    except:
        e = get_exception()
        return None,None,e


