from collections import defaultdict
from hub_app.func_utils import get_exception
from pyspark.sql.types import *
"""
entity
    --override_column,val
        --key_column,val
    
"""
class Override(object):
    def __init__(self):
        try:
            self.configs = defaultdict(
                                                           #entity
                            lambda: defaultdict(            #lkp_col_name
#                                 lambda: defaultdict(        #lkp_col_val
                                    lambda: defaultdict(    #key_col_name
#                                         lambda: defaultdict(#key_column_val
                                            list
                                        )
#                                     )
                                )
#                             )
                        )
            self.d_entity_df= defaultdict(
                                lambda: defaultdict(
                                        lambda: defaultdict(
                                            list
                                            )
                                    )
                            )
        except:
          e = get_exception()
          print(e)  
    
    def add_to_config(self):
        pass   
    def parse_row(self,**kwargs):
        entity_key = kwargs.get('entity_key')
        key_col = kwargs.get('key_column_name')
        key_val = kwargs.get('key_column_value')
        lkp_col = kwargs.get('override_column_name')
        lkp_val = kwargs.get('override_column_value')
        okv = override_key_val()
        okv.set_params(key_col, key_val, lkp_col, lkp_val)
        ky = '{}#{}#{}'.format(entity_key,lkp_col,key_col)
#         self.configs[ky].append(okv)
#         self.configs[entity_key][lkp_col][lkp_val][key_col][key_val].append(okv)
        self.configs[entity_key][lkp_col][key_col].append(okv)
    
    def process_rows(self,spark):
        try: 
            d = self.configs
            for entity_key, d_ek in d.items():
                    for lkp_col , d_lc in d_ek.items():
                        for key_col, l_kc in d_lc.items():
                            
                            df = []
                            for okv in l_kc:
                                df.append((okv.key_val,okv.lkp_val))
                                
                            df_schema =StructType([
                                StructField(key_col,StringType(),False),
                                StructField(lkp_col,StringType(),False)
                                ])
                            sdf = spark.createDataFrame(df,df_schema)
                            self.d_entity_df[entity_key][lkp_col][key_col].append(sdf)    
        except:
            e = get_exception()
            print(e)
    def get_by_entity(self,entity_key):
        res = {}
        if entity_key in self.configs:
            res = self.configs.get(entity_key)
        return res
    
    def get_all_configs(self):
        return self.d_entity_df
    
    
class override_key_val:
    def __init__(self):
        self.key_col = None
        self.key_val = None
        self.lkp_col = None
        self.lkp_val = None
    
    def set_params(self,key_col, key_val, lkp_col, lkp_val):
        self.key_col = key_col
        self.key_val = key_val
        self.lkp_col = lkp_col
        self.lkp_val = lkp_val
    
    def __str__(self):
        return 'key_col:{}, key_val:{}, lkp_col:{}, lkp_val:{} '.format(self.key_col,
                                                                       self.key_val,
                                                                       self.lkp_col,
                                                                       self.lkp_val
                                                                       )
        