from collections import OrderedDict
from pyspark.sql.types import *
from pyspark.sql.functions import isnull
from hub_app.schema_objects import Sch, SchColumn
import re

def get_datatype(inp_dtype):
    d_map = {
            'VARCHAR':'STRING',
            'STRING':'STRING',
            'CHAR':'STRING',
            'NCHAR':'STRING',
            'NCHARVARYING':'STRING',
            'CHARVARYING':'STRING',
            'VARCHAR2':'STRING',
            'NVARCHAR2':'STRING',
            'NVARCHAR':'STRING',
            'CHARACTER':'STRING',
            
            
            'LONG':'NUMBER',
            'INT':'NUMBER',
            'INTEGER':'NUMBER',
            'PLSINTEGER':'NUMBER',
            'BIGINT':'NUMBER',
            'TINYINT':'NUMBER',
            'SMALLINT':'NUMBER',
            'SIGNEDLARGEINT':'NUMBER',
            'SIGNEDSMALLINT':'NUMBER',
            'SIGNEDINTEGER':'NUMBER',
            'UNSIGNEDLARGEINT':'NUMBER',
            'UNSIGNEDSMALLINT':'NUMBER',
            'UNSIGNEDINTEGER':'NUMBER',
            
            'FLOAT':'DECIMAL',
            'DOUBLE':'DOUBLE',
            'DOUBLEFLOAT':'FLOAT',
            'DOUBLEPRECISION':'DECIMAL',
            'BINARYDOUBLE':'DECIMAL',
            'NUMBER':'DECIMAL',
            'NUMERIC':'DECIMAL',
            'DECIMAL':'DECIMAL',
            'SIGNEDNUMERIC':'DECIMAL',
            'SIGNEDINTEGER':'DECIMAL',
            'SIGNEDDECIMAL':'DECIMAL',
            'UNSIGNEDNUMERIC':'DECIMAL',
            'UNSIGNEDDECIMAL':'DECIMAL',
            
            'DATE':'DATETIME',
            'TIME':'TIMESTAMP',
            'DATETIME':'DATETIME',
            'TIMESTAMP':'TIMESTAMP',
            'TIMESTAMPWITHTIMEZONE':'TIMESTAMP',
            
            'BINARY':'BINARY',
            'BOOLEAN':'BOOLEAN',
            'BOOL':'BOOLEAN',
            'BYTE':'BYTE',
            'BYTEARRAY':'BYTE',
            
            
        }
    
    dtype_key = inp_dtype.strip().upper()
    dtype_r = None
    
    if dtype_key in d_map:
        dtype_r = d_map.get(dtype_key)
    if dtype_r =='STRING':
        return dtype_r, StringType()
    elif dtype_r == 'NUMBER':
        return dtype_r, IntegerType()
    elif dtype_r == 'DECIMAL':
        return dtype_r, DecimalType()
    elif dtype_r == 'FLOAT':
        return 'DECIMAL', FloatType()
    elif dtype_r == 'DOUBLE':
        return 'DECIMAL', DoubleType()
    elif dtype_r == 'BOOLEAN':
        return dtype_r, BooleanType()
    elif dtype_r == 'DATE':
        return dtype_r, DateType()
    elif dtype_r == 'DATETIME':
        return 'DATETIME', DateType()
    elif dtype_r == 'TIMESTAMP':
        return dtype_r, TimestampType()
    elif dtype_r == 'BINARY':
        return dtype_r, BinaryType()
    elif dtype_r == 'BYTE':
        return dtype_r, ByteType()
    else:
        return 'STRING', StringType()

def make_schema(spark,schema_file_path):
    
#     TableName    ColumnName    DataType    Size    Is_Nullable
    meta_schema = StructType([
                    StructField("table_name",StringType()),
                    StructField("column_name",StringType()),
                    StructField("datatype",StringType()),
                    StructField("length",StringType()),
                    StructField("is_nullable",StringType())
                ])
    l_res = []
    meta_df = spark.read.csv(schema_file_path,header = True,schema=meta_schema)
    meta_df = meta_df.filter(~isnull(meta_df['column_name'])).collect()
    sch = Sch()
    for rw in meta_df:
        col_name = rw.column_name
        inp_dtype = rw.datatype
        length = rw.length
        is_nullable = True
        if length:
            length = re.sub('[^0-9]+','',length)
            if length != '':
                length = int(length)
            else:
                length = -1
        else:
            length = -1
        is_nullable_str = rw.is_nullable
        if is_nullable_str:
            ink = is_nullable_str.strip().upper()
            if ink == 'FALSE' or ink == 'NO':
                is_nullable = False
        
        hive_datatype, spark_datatype = get_datatype(inp_dtype)
        sch_col = SchColumn()
        sch_col.set_params(col_name, inp_dtype, spark_datatype, hive_datatype, length, is_nullable)
        sch.add_column(sch_col)
    
    return sch


    