import re
from hub_app.func_utils import get_exception, errorify
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import isnull,udf
from collections import OrderedDict
from pyspark.sql import Row
def get_datatype(inp_dtype):
    d_map = {
            'VARCHAR':'STRING',
            'STRING':'STRING',
            'CHAR':'STRING',
            'NCHAR':'STRING',
            'NCHARVARYING':'STRING',
            'CHARVARYING':'STRING',
            'VARCHAR2':'STRING',
            'NVARCHAR2':'STRING',
            'NVARCHAR':'STRING',
            'CHARACTER':'STRING',
            
            'LONG':'NUMBER',
            'INT':'NUMBER',
            'INTEGER':'NUMBER',
            'PLSINTEGER':'NUMBER',
            'BIGINT':'NUMBER',
            'TINYINT':'NUMBER',
            'SMALLINT':'NUMBER',
            'SIGNEDLARGEINT':'NUMBER',
            'SIGNEDSMALLINT':'NUMBER',
            'SIGNEDINTEGER':'NUMBER',
            'UNSIGNEDLARGEINT':'NUMBER',
            'UNSIGNEDSMALLINT':'NUMBER',
            'UNSIGNEDINTEGER':'NUMBER',
            
            'FLOAT':'DECIMAL',
            'DOUBLE':'DOUBLE',
            'DOUBLEFLOAT':'FLOAT',
            'DOUBLEPRECISION':'DECIMAL',
            'BINARYDOUBLE':'DECIMAL',
            'NUMERIC':'DECIMAL',
            'DECIMAL':'DECIMAL',
            'SIGNEDNUMERIC':'DECIMAL',
            'SIGNEDINTEGER':'DECIMAL',
            'SIGNEDDECIMAL':'DECIMAL',
            'UNSIGNEDNUMERIC':'DECIMAL',
            'UNSIGNEDDECIMAL':'DECIMAL',
            
            'DATE':'DATE',
            'TIME':'TIMESTAMP',
            'DATETIME':'TIMESTAMP',
            'TIMESTAMP':'TIMESTAMP',
            'TIMESTAMPWITHTIMEZONE':'TIMESTAMP',
            
            'BINARY':'BINARY',
            'BOOLEAN':'BOOLEAN',
            'BOOL':'BOOLEAN',
            'BYTE':'BYTE',
            'BYTEARRAY':'BYTE',
            
            
        }
    dtype_key = inp_dtype.strip().upper()
    dtype_r = None
    if dtype_key in d_map:
        dtype_r = d_map.get(dtype_key)
    if dtype_r =='STRING':
        return dtype_r, StringType()
    elif dtype_r == 'NUMBER':
        return dtype_r, IntegerType()
    elif dtype_r == 'DECIMAL':
        return dtype_r, DecimalType()
    elif dtype_r == 'FLOAT':
        return 'DECIMAL', FloatType()
    elif dtype_r == 'DOUBLE':
        return 'DECIMAL', DoubleType()
    elif dtype_r == 'BOOLEAN':
        return dtype_r, BooleanType()
    elif dtype_r == 'DATE':
        return dtype_r, DateType()
    elif dtype_r == 'TIMESTAMP':
        return dtype_r, TimestampType()
    elif dtype_r == 'BINARY':
        return dtype_r, BinaryType()
    elif dtype_r == 'BYTE':
        return dtype_r, ByteType()
    else:
        return 'STRING', StringType()

def make_schema(spark,schema_file_path):
    
#     TableName    ColumnName    DataType    Size    Is_Nullable
    meta_schema = StructType([
                    StructField("table_name",StringType()),
                    StructField("column_name",StringType()),
                    StructField("datatype",StringType()),
                    StructField("length",StringType()),
                    StructField("is_nullable",StringType())
                ])
    l_res = []
    meta_df = spark.read.csv(schema_file_path,header = True,schema=meta_schema)
    meta_df = meta_df.filter(~isnull(meta_df['column_name'])).collect()
    sch = Sch()
    for rw in meta_df:
        col_name = rw.column_name
        inp_dtype = rw.datatype
        length = rw.length
        is_nullable = True
        if length:
            length = re.sub('[^0-9]+','',length)
            if length != '':
                length = int(length)
            else:
                length = -1
        else:
            length = -1
        is_nullable_str = rw.is_nullable
        if is_nullable_str:
            ink = is_nullable_str.strip().upper()
            if ink == 'FALSE' or ink == 'NO':
                is_nullable = False
        
        hive_datatype, spark_datatype = get_datatype(inp_dtype)
        sch_col = SchColumn()
        sch_col.set_params(col_name, inp_dtype, spark_datatype, hive_datatype, length, is_nullable)
        sch.add_column(sch_col)
    
    return sch
        
def read_file(spark,**kwargs):
    try:
        file_path = kwargs.get('file_path')
        file_format = kwargs.get('file_format')
        result_dataframe_name = kwargs.get('result_dataframe')
        validate = False
        result_df = None
        e = None
        file_schema = None
        hasHeader = True
        isMultiline = True
        column_delimiter = ','
        quote_char = '"'
        escape_char = '"'
        sch_obj = None
        schema = None
        if "validate" in kwargs:
            vld = kwargs.get("validate")
            if vld:
                vld = vld.strip().upper()
                if vld == 'TRUE':
                    validate = True
        if "file_schema" in kwargs:
            file_schema = kwargs.get("file_schema")
        if "has_header" in kwargs:
            hh = kwargs.get('has_header')
            if hh.strip().upper() == 'FALSE':
                hasHeader = False
            elif hh.strip().upper() == 'TRUE':
                hasHeader = True
        if "is_multiline" in kwargs:
            im = kwargs.get("is_multiline")
            im_key = im.strip().upper()
            if im_key == 'FALSE':
                isMultiline = False
            elif im_key == 'TRUE':
                isMultiline = True
        if "column_delimiter" in kwargs:
            cd = kwargs.get("column_delimiter")
            if cd and cd.strip() != '':
                column_delimiter = cd
        if "quote_char" in kwargs:
            qc = kwargs.get('quote_char')
            if qc and qc.strip()!='':
                quote_char = qc
        if "escape_char" in kwargs:
            ec = kwargs.get('escape_char')
            if ec and ec.strip() != '':
                escape_char = ec
        
#         if file_schema:
#                 sch_obj =  make_schema(file_schema)
#                 schema = sch_obj.get_dataframe_schema()
                
        if file_format == 'csv':
#               result_df =  spark.read.csv(file_path,header=hasHeader,schema=schema).alias(df_name)
#             result_df = spark.read.format("csv").option("schema",schema).option("multiline",isMultiline).option("delimiter",column_delimiter) \
#                         .option("quote",quote_char).option('escape',escape_char).option("header", hasHeader) \
            result_df = spark.read.csv(file_path,header=hasHeader, schema = None).alias(result_dataframe_name)
        elif file_format == 'parquet':
            result_df =  spark.read.parquet(file_path).alias(result_dataframe_name)
        else :
            result_df =  spark.read.format(file_format).alias(result_dataframe_name)
        if validate and file_schema:
            print ("In Validate")
            threshold_in_percent = 10
            print(kwargs.get('reject_threshold'))
            return validate_df(spark,result_df,file_schema,threshold_in_percent)
        return result_df , None,None
    except:
        e = get_exception()
        return None,None, e


def cmp_columns(file_cols, schema_cols):
    """
    to compare the columns actually there in file and the columns provided in the schema file
    1.if column is there in file but not in schema
    2.if column in schema but not in file
    Here schema will be treated as the source of truth, and columns will be mapped based on the schema file
    return intersect of both and index of column from file and index of column in schema
    """
    d_file_cols = OrderedDict()
    d_schema_cols = OrderedDict()
    for i,col in enumerate(schema_cols):
        d_schema_cols[col] = i
    for i,col in enumerate(file_cols):
        d_file_cols[col]=i
    d_res = OrderedDict()
    for schema_col,schema_ord in d_schema_cols.items():
        file_schema_ord= -1
        if schema_col in d_file_cols:
            file_schema_ord = d_file_cols.get(schema_col)
        d_res[schema_col]=file_schema_ord
    return d_res
    
    
# def validate(spark, data_df, metadata_df, datatype_map):
def validate_df(spark,data_df,file_schema,threshold):
    try:
        
        sch_obj =  make_schema(spark,file_schema)
        schema = sch_obj.get_dataframe_schema()
        df_columns = data_df.columns
        schema_columns = sch_obj.get_column_names()
        d_relevant_columns = cmp_columns(df_columns,schema_columns)
        

        
        df_schema = data_df.schema
        reject_schema = df_schema.add("error_flag",BooleanType(), True).add("validation_messages",StringType(), True)
        valid_schema = sch_obj.get_dataframe_schema()
        
#         valid_row_struct = ArrayType(reject_schema, valid_schema, BooleanType())
#         valid_row_struct = reject_schema
#         validate_row_udf = udf(validate_row,valid_row_struct)
#         check_df = data_df.rdd.map(lambda row: validate_row_udf(row,sch_obj,d_relevant_columns,df_columns))
        check_df = data_df.rdd.map(lambda row: validate_row(row,sch_obj,d_relevant_columns,df_columns))
        orig_row_pos = 0
        new_row_pos = 1
        error_flag_pos = 2
        
        
        
#         res.filter(lambda x: x[1] is False).map(lambda x: x[0]), schema=s_schema
        valid_df = spark.createDataFrame(check_df.filter(lambda res: res[error_flag_pos] is False).map(lambda res:res[new_row_pos]),schema = valid_schema)
        
        invalid_df = spark.createDataFrame(check_df.filter(lambda res: res[error_flag_pos] is True).map(lambda res:res[orig_row_pos]),schema = reject_schema)

#         invalid_df = spark.createDataFrame(check_df.filter(lambda row: row['error_flag'] == True),schema = reject_schema)
#         valid_df = spark.createDataFrame(check_df.filter(lambda row: row['error_flag'] == False),schema = reject_schema)
        
        valid_count = valid_df.count()
        invalid_count = invalid_df.count()
        print(valid_df.columns)
        print(invalid_df.columns)
        print(valid_df.take(10))
        print(invalid_df.take(10))
        print('valid_records:{}, invalid_records:{}'.format(str(valid_count),str(invalid_count)))
        return valid_df,invalid_df,None
#         metadata = metadata_df.filter(~isnull(metadata_df['ColumnName'])).collect()
#         res = data_df.rdd.map(lambda x: validate_record(x, sch_obj))
#         valid_df = spark.createDataFrame(res.filter(lambda x: x[1] is False).map(lambda x: x[0]), schema=s_schema)
#         s_schema.add('DQ_Error_Message', StringType(), False)
#         invalid_df = spark.createDataFrame(res.filter(lambda x: x[1] is True).map(lambda x: x[0]), schema=s_schema)
#         invalid_count = invalid_df.count()
#         if invalid_count <= threshold:
#             return valid_df.alias(validated_dataframe_name), invalid_df.alias(rejected_dataframe_name)
#         else:
#             return None,errorify(error_code='THRESHOLD CROSSED', error_message='The count for invalid records exceeds the threshold')
    except:
        e = get_exception()
        print(e)
        return None,None,e
def make_error(error_column,error_code,error_message):
    return error_column+'-'+error_code+':'+error_message

def make_datatype_error(column_index,column_name,column_datatype,column_value):
    err_col = column_name
    err_code = 'DATATYPE_MISMATCH'
    err_msg = 'Column <{}> at position <{}> with <{}> datatype, has an invalid value <{}>.'.format(column_name,
                                                                                                   column_index,
                                                                                                   column_datatype,
                                                                                                   column_value
                                                                                                   )
    return make_error(err_col,err_code,err_msg)

def is_not_null(col_value):
    if not col_value:
        return False
    elif col_value.strip()!='':
        return True
    return False

def is_valid_number(col_value):
    try:
        is_valid = True
        valid_value = col_value
        col_value_key = re.sub('[ \t\r\n]+','',col_value)
        if re.sub('[0-9]+','',col_value_key)!='':
            is_valid = False
        else:
            valid_value = col_value_key
        return is_valid,valid_value,None
    except:
        e = get_exception()
        return False,col_value,e
    
def is_valid_decimal(col_value):
    try:
        is_valid = True
        valid_value = col_value
        col_value_key = re.sub('[ \t\r\n]+','',col_value)
        if re.sub('[0-9\.]+','',col_value_key)!='':
            is_valid = False
        else:
            valid_value = col_value_key
        return is_valid,valid_value,None
    except:
        e = get_exception()
        return False,col_value,e

def is_valid_boolean(col_value):
    try:
        is_valid = True
        valid_value = col_value
        col_value_key = re.sub('[ \t\r\n]+','',col_value)
        if col_value_key.upper() in ['TRUE','YES','1']:
            valid_value = True
        elif col_value_key.upper() in ['FALSE','NO','0']:
            valid_value = False
        else:
            is_valid = False
        return is_valid,valid_value,None
    except:
        e = get_exception()
        return False,col_value,e

def is_valid_date(col_value,pattern=None):
    try:
        is_valid = True
        valid_value = col_value
        
        date_pattern_1 = r'([0-9]{4})[ \./\-]*([0-9]{1,2})[ \./\-]*([0-9]{1,2})'
#         date_pattern_2 = r'([0-9]{1,2})[ \./\-]*([0-9]{1,2)[ \./\-]*([0-9]{4})'
        col_value_key = col_value.strip()
        srch = re.search(date_pattern_1, col_value_key)
        if srch:
            year = srch.group(1)
            month = srch.group(2)
            day = srch.group(3)
            col_value_key = '{year}/{month}/{day}'.format(year,month,day)
            valid_value = datetime.strptime(col_value_key,'%Y/%M/%d')
        else:
            is_valid = False
        
        return is_valid,valid_value,None
    except:
        e = get_exception()
        return False,col_value,e

def is_valid_time(col_value, pattern=None):
    v_err = None
    try:
        is_valid = False
        valid_value = col_value
        
        col_value_key = col_value.strip()
        time_separator = r'[ :\./\-]*'
        fract_seconds = r'([0-9]*)'
        time_pattern = r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+fract_seconds
        tsrch = re.search(time_pattern,col_value_key)
        if tsrch:
            year = '0000'
            month = '00'
            date = '00'
            hour = tsrch.group(1)
            minute = tsrch.group(2)
            second = tsrch.group(3)
            frac_secs ='000' 
            if len(tsrch.groups)>3:
                frac_secs = tsrch.group(4)
            col_value_key = '{year}/{month}/{date} {hour}:{minute}:{second}.{frac_secs}'.format(
                year, month, date, hour, minute,second, frac_secs
                )
            valid_value = datetime.strptime(col_value_key,'%Y/%m/%d %H:%M:%S.%f')
            is_valid = True
        return is_valid, valid_value, v_err
    except:
        v_err = get_exception()
        return False, col_value, v_err

def is_valid_timestamp(col_value,pattern=None):
    v_err = None
    try:
        is_valid = False
        valid_value = col_value
        
        col_value_key = col_value.strip()
        date_separator = r'[ \./\-]*'
        time_separator = r'[ :\./\-]*'
        date_pattern = r'([0-9]{4})'+date_separator+r'([0-9]{2})'+date_separator+r'([0-9]{2})'
        fract_seconds = r'([0-9]*)'
        time_pattern = r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+fract_seconds
        timestamp_pattern = date_pattern+date_separator+time_pattern
        
        #checking for timestamp
        tsrch = re.search(timestamp_pattern,col_value_key)
        if tsrch:
            year = tsrch.group(1)
            month = tsrch.group(2)
            date = tsrch.group(3)
            hour = tsrch.group(4)
            minute = tsrch.group(5)
            second = tsrch.group(6)
            frac_secs ='000' 
            if len(tsrch.groups)>6:
                frac_secs = tsrch.group(7)
            col_value_key = '{year}/{month}/{date} {hour}:{minute}:{second}.{frac_secs}'.format(
                year, month, date, hour, minute,second, frac_secs
                )
            valid_value = datetime.strptime(col_value_key,'%Y/%m/%d %H:%M:%S.%f')
            is_valid = True
        #checking for date
        if not is_valid:
            is_valid,valid_value,v_err = is_valid_date(col_value)
        #checking for time
        if not is_valid:
            is_valid, valid_value, v_err = is_valid_time(col_value)
            
        return is_valid,valid_value,v_err
    except:
        e = get_exception()
        return False,col_value,e

def validate_row(row, sch_obj,d_relevant_columns,file_cols):
    try:
        
        print ("ROW:",row)
        l_errors = []
        error_flag = False
        l_orig_cols = row.asDict().keys()
        print (l_orig_cols)
        
        new_row = OrderedDict()
        
        for i,col_name in enumerate(file_cols):
            file_column_index = d_relevant_columns.get(col_name)
            sch_col = sch_obj.get_column(col_name)
            if sch_col is None:
                print("Column <{}> was not found in file but not in the defined schema file. This column will be ignored".format(col_name))
                continue
            col_datatype = sch_col.datatype
            hive_datatype = sch_col.hive_datatype
            
            is_nullable = str(sch_col.is_nullable)
            
            col_value = None
            valid_status = True
            valid_value = col_value
            l_v_err = None
            col_validated_value = None
            
            # get the column value
            if file_column_index == -1:
                col_value = None
            else:
                col_value = row[file_column_index]
            
            # validate if column value is nullable
            if col_value is None or col_value.strip()=='':
                if not is_nullable:
                    valid_status = False
                    error_flag = True
                    l_errors.append(make_error(col_name,'NOT_NULLABLE','Null or empty value found for NOT NULL Column.'))
            else:    
                if hive_datatype == 'STRING':
                    valid_status = True
                    valid_value = col_value
                    v_err = None
                elif hive_datatype == 'NUMBER':
                    valid_status,valid_value,v_error = is_valid_number(col_value)
                elif hive_datatype == 'DECIMAL':
                    valid_status,valid_value,v_error = is_valid_decimal(col_value)
                elif hive_datatype == 'BOOLEAN':
                    valid_status,valid_value,v_error = is_valid_boolean(col_value)
                    
                elif hive_datatype == 'DATE':
                    valid_status,valid_value,v_error = is_valid_date(col_value)
                elif hive_datatype == 'TIMESTAMP':
                    valid_status,valid_value,v_error = is_valid_timestamp(col_value)
                else:
                    valid_status = True
                    valid_value = col_value
                    l_errors.append(make_error(col_name,'DATATYPE_UNDEF_WARN',' Warning: Validation Method for datatype <{}> is undefined'.format(
                            col_datatype
                            )))
                    
                if not valid_status:
                    error_flag = True
                    err = make_datatype_error(file_column_index,col_name,col_datatype,col_value)
                    l_errors.append(err)
                    col_validated_value = col_value
                
            new_row[col_name] = valid_value
            
#             print("Column_{} - Name :<{}>, Datatype:<{}> , Value:<{}>, validated_value:<{}>".format(str(i),col_name,col_datatype,col_value,valid_value))
            
        #end of for loop
        record = row.asDict()
        record["error_flag"] = error_flag
        record["validation_messages"] = '|'.join(l_errors)
        return Row(**record),Row(**new_row),error_flag
#         return Row(**record)
    except:
        e = get_exception()
        print(e)
        orig_record = record = row.asDict()
        record["error_flag"] = True
        e = make_error('', e.get(error_code), e.get(error_message))
        record["validation_messages"] = e
        return Row(**record),None,error_flag
#         return Row(**record)

class Sch(object):
    def __init__(self):
        self.column_names = []
        self.d_columns = OrderedDict()
        
    def add_column(self,schCol):
        self.d_columns[schCol.name]=schCol
        self.column_names.append(schCol.name)
        
    def get_columns(self):
        return self.d_columns
    
    def get_column(self,column_name):
        if column_name in self.d_columns:
            return self.d_columns.get(column_name)
        else:
            return None
    
    def get_column_names(self):
        return self.column_names
        
        
    def get_dataframe_schema(self):
        l_cols = []
        for col_name in self.column_names:
            col = self.get_column(col_name)
            if col:
                spark_datatype = col.spark_datatype
                is_nullable = col.is_nullable
                l_cols.append(StructField(col_name, spark_datatype))
            else:
                spark_datatype = StringType()
                is_nullable = True
                l_cols.append(StructField(col_name, spark_datatype))
                
        return StructType(l_cols)

class SchColumn(object):
    def __init__(self):
        self.name = ''
        self.datatype = ''
        self.spark_datatype = None
        self.hive_datatype = ''
        self.length = 0
        self.is_nullable = True
    
    def set_params(self,name, datatype, spark_datatype, hive_datatype, length, is_nullable):
        self.name = name
        self.datatype = datatype
        self.spark_datatype = spark_datatype
        self.hive_datatype = hive_datatype
        self.length = length
        self.is_nullable = is_nullable
        
    