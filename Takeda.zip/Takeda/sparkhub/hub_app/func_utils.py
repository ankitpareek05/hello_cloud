import re
from collections import OrderedDict
from datetime import datetime
import hub_app.const as cc
import pyspark.sql.functions as pyfunc
from pyspark.sql.functions import *
import sys, linecache, hashlib
from hub_app.sync_file import SFile
from hub_app.sync_operations import SyncOperations

def get_exception(debug=True):
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
    err_obj = {
        'error_code':str(exc_type),
        'error_message':str(exc_obj)
    }
    if debug:
        err_obj['error_at']='EXCEPTION IN ({},LINE {} "{}")'.format(filename,lineno,line.strip())
    return err_obj


def errorify(error_code='',error_message='',error_at=''):
    return {
            'error_code':str(error_code),
            'error_message':str(error_message),
            'error_at':str(error_at)
        }
    
        
def keyfy(inp_str):
       return re.sub(r'[^A-Za-z0-9_-]+','',inp_str).upper()

# function to compare and select those input columns 
# that exist in dataframe columns 
def cmp(df_cols,inp_cols):
    l_df_cols = [keyfy(x) for x in df_cols]
    l_inp_cols = [keyfy(x) for x in inp_cols]
    d_out_cols = OrderedDict()
    for i,k_df_col in enumerate(l_df_cols):
        for j,k_inp_col in enumerate(l_inp_cols):
            if k_df_col == k_inp_col:
                df_col = df_cols[i]
                inp_col = inp_cols[j]
                d_out_cols[df_col]=inp_col
    return d_out_cols

def cmp_rep(df_cols,inp_cols,new_cols):
    l_df_cols = [keyfy(x) for x in df_cols]
    l_inp_cols = [keyfy(x) for x in inp_cols]
    d_out_cols = OrderedDict()
    for i,k_df_col in enumerate(l_df_cols):
        for j,k_inp_col in enumerate(l_inp_cols):
            if k_df_col == k_inp_col:
                df_col = df_cols[i]
                inp_col = inp_cols[j]
                new_col = new_cols[j]
                d_out_cols[df_col]=new_col
                
    return d_out_cols

def cmp_intersect(df_cols,inp_cols):
    l_df_cols = [keyfy(x) for x in df_cols]
    l_inp_cols = [keyfy(x) for x in inp_cols]
    res = OrderedDict()
    for i,k_df_col in enumerate(l_df_cols):
        for j,k_inp_col in enumerate(l_inp_cols):
            if k_df_col == k_inp_col:
                df_col = df_cols[i]
                res[df_col]=""
    return res

def select_columns(df,**kwargs):
    """
    function to select specific columns from a dataframe
    return: dataframe
    """
    try:
        delimiter =cc.input_column_delimiter
        df_name = kwargs.get('dataframe_name')
        columns = kwargs.get('columns')
        if "delimiter" in kwargs:
            delimiter = kwargs.get('delimiter')
        if columns == '':
            return df,None
        inp_columns = columns.split(delimiter)
        d_out_cols = cmp(df.columns,inp_columns)
        if d_out_cols:
            l_select = d_out_cols.keys()
            l_rename = d_out_cols.values()
            return df.select(*l_select).toDF(*l_rename),None
        else :
            return df,None
    except:
        e = get_exception()
        return None,e

def rename_columns(df,**kwargs):
    """
    function to rename columns in a dataframe
    return: dataframe
    """
    try:
        old_columns = kwargs.get("old_columns")
        new_columns = kwargs.get("new_columns")
        delimiter=cc.input_column_delimiter
        if not old_columns or not new_columns:
            return df
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
        
        l_old_cols = old_columns.split(delimiter)
        l_new_cols = new_columns.split(delimiter)
        d_out_cols = cmp_rep(df.columns,l_old_cols,l_new_cols)
        if d_out_cols:
            for old_col,new_col in d_out_cols.items():
                df = df.withColumnRenamed(old_col,new_col)
        return df,None
    except:
        e = get_exception()
        return None,e
    
def drop_columns(df,**kwargs):
    """
    function to drop specific columns from the dataframe
    return: dataframe
    """
    try:
        delimiter = cc.input_column_delimiter
        drop_cols = kwargs.get("columns")
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
        if drop_cols.strip()== '':
            e = errorify("INVALID_PARAMS","Param columns:<{}> has been incorrectly specified".format(drop_cols))
            return None,e
        l_drop_cols = drop_cols.split(delimiter)
        d_out_cols = cmp_intersect(df.columns,l_drop_cols)
        if d_out_cols:
            revised_drop_cols = d_out_cols.keys()
            if len(l_drop_cols) != len(revised_drop_cols):
                e = errorify("INVALID_PARAMS","Some of the drop columns we not found in the dataframe columns.")
                return None,e
            df = df.drop(*revised_drop_cols)
        else:
            e = errorify("INVALID_PARAMS","Param columns:<{}> has been incorrectly specified".format(drop_cols))
            return None,e
        return df,None
    except:
        e = get_exception()
        return None,e
    
def cleanup_columns(df,**kwargs):
    """
    function to clean specific columns in the dataframe
    return: dataframe
    """
    try:
        delimiter = cc.input_column_delimiter
        columns = kwargs.get("columns")
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
    
        l_cols = columns.split(delimiter) 
        d_out_cols = cmp_intersect(df.columns,l_cols)
        if d_out_cols:
            revised_cols = d_out_cols.keys()
            for r_col in revised_cols:
                df = df.withColumn(r_col,pyfunc.col(r_col).cleanup())
        return df,None
    except:
        e = get_exception()
        return None,e


def add_column(df,**kwargs):
    return modify_column(df,**kwargs)

def modify_column(df,**kwargs):
    try:
        delimiter = cc.input_column_delimiter
        mod_column = kwargs.get("column_name")
        function = None
        params = None
        options = None
        expression = None
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
        
        if "expression" in kwargs:
            expression = kwargs.get("expression").strip()
            
        else:
            e = errorify("INVALID_PARAMS"," <expression> for the new column has not been defined ")
            return None,e
        
        eval_expr = 'df.withColumn(\'{}\',{})'.format(mod_column,expression)
        df = eval(eval_expr)
        
        return df,None
    except:
        e = get_exception()
        return None,e      

def transform_columns(df,**kwargs):
    
    """
    function to transform specific columns in the dataframe
    return: dataframe
    """
    try:
        delimiter = cc.input_column_delimiter
        columns = kwargs.get("columns")
        function = None
        params = None
        options = None
        expression = None
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
            
        if "function" in kwargs:
            func = kwargs.get("function").strip()
            if func in dir(pyfunc):
                function = getattr(pyfunc,func)
            else:
                e = errorify("INVALID_FUNCTION","Specified function <{}> does not seem to be a part of pyspark.sql.function module")
                #log_error pyspark sql function not found
                return None,e
        
            if "params" in kwargs:
                p = kwargs.get("params")
                if p:
                    params = tuple(p.split(delimiter))
            if "options" in kwargs:
                options = kwargs.get("options")
        
        elif "expression" in kwargs:
            expression = kwargs.get("expression").strip()
            
        else:
            e = errorify("INVALID_PARAMS","Neither of params, <function> or <expression> have not been defined ")
            return None,e
        
        l_cols = columns.split(delimiter)
        d_out_cols = cmp_intersect(df.columns,l_cols)
        if d_out_cols:
            revised_cols = d_out_cols.keys()
            if function:
                for r_col in revised_cols:
                    if params:
                        
                        df = df.withColumn(r_col,function(pyfunc.col(r_col),*params))
                    else:
                        df = df.withColumn(r_col,function(pyfunc.col(r_col)))
            elif expression:
                for r_col in revised_cols:
                    f_expr = expression.format('pyfunc.col(\'{}\')'.format(r_col))
                    eval_expr = 'df.withColumn(\'{}\',{})'.format(r_col,f_expr)
                    df = eval(eval_expr)
            else:
                print("falsehood")
                pass
        return df,None
    except:
        e = get_exception()
        return None,e      

def filter_rows(df,**kwargs):
    try:
        filter_clause = kwargs.get("filter_clause")
        return df.filter(filter_clause),None
    except:
        e = get_exception()
        return None,e




def cmp_duplicates(left_cols,right_cols,left_name,right_name,left_rename_cols,right_rename_cols):
    common_cols = set(left_cols) & set(right_cols)
    select_cols = [col('A.{}'.format(x)) for x in left_cols]+[col('B.{}'.format(x)) for x in right_cols]
    
    rename_left_cols = []
    len_lrcols = len(left_rename_cols)
    for i,left_col in enumerate(left_cols):
        lrc = left_col
        if i<len_lrcols:
            lrc = left_rename_cols[i]
        rename_left_cols.append(lrc)
        
    rename_right_cols = []
    len_rrcols = len(right_rename_cols) 
    for j, right_col in enumerate(right_cols):
        rrc = right_col
        if j<len_rrcols:
            rrc = right_rename_cols[j]
        elif right_col in common_cols:
            rrc = '{}_{}'.format(right_name,right_col)
        rename_right_cols.append(rrc)
            
#     rename_cols =left_cols+[ '{}_{}'.format(right_name,x) if x in common_cols else x for x in right_cols]
    rename_cols = rename_left_cols + rename_right_cols
    return select_cols,rename_cols

def join_dataset(primary_df,join_df,**kwargs):
    try:
        #init
        result_df = None
        filter_clause = None
        delimiter = cc.input_column_delimiter
        all_cols_from_left = False
        all_cols_from_right = False
        join_type = "inner"
        l_df_cols = []
        l_join_df_cols = []
        l_rename_df_cols = []
        l_rename_join_df_cols = []
        #mandatory tags
        df_name = kwargs.get("dataframe_name")
        join_df_name = kwargs.get("join_dataframe_name")
        result_df_name = kwargs.get("result_dataframe")
        df_key_cols = kwargs.get("dataframe_keys")
        join_df_key_cols = kwargs.get("join_dataframe_keys")
        result_df_name = kwargs.get("result_dataframe")
        df_cols = kwargs.get("dataframe_columns")
        join_df_cols = kwargs.get("join_dataframe_columns")
        
        #check and set optional tags, if present
        # setting delimiter
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
        if "rename_dataframe_columns" in kwargs:
            rdc = kwargs.get('rename_dataframe_columns')
            if rdc and rdc.strip()!='':
                l_rename_df_cols = rdc.strip().split(delimiter)
        if "rename_join_dataframe_columns" in kwargs:
            rjdc = kwargs.get('rename_join_dataframe_columns')
            if rjdc and rjdc.strip()!='':
                l_rename_join_df_cols = rjdc.strip().split(delimiter)
        
        #Added Logic to exclude columns from dataframe or join dataframe
        #setting df_columns
        if not df_cols or df_cols.strip() == '':
            pass
        elif df_cols.strip() == '*':
            all_cols_from_left = True
            l_df_cols = primary_df.columns
        else:
            l_df_cols = df_cols.split(delimiter)
            
        #setting join_df columns
        if not join_df_cols or join_df_cols.strip() == '':
            pass
        elif join_df_cols.strip() == '*':
            all_cols_from_right = True
            l_join_df_cols = join_df.columns
        else:
            l_join_df_cols = join_df_cols.split(delimiter)
        #setting join_type
        if "join_type" in kwargs:
            jt = kwargs.get('join_type')
            if jt:
                jt = jt.strip().lower()
            if jt in ['inner','outer','left_outer','right_outer','leftsemi']:
                join_type = jt
            
        else:
            print("Join Type was not found in kwargs")
        if "filter_clause" in kwargs:
            fcls = kwargs.get("filter_clause")
            if fcls and fcls.strip()!='':
                filter_clause = fcls
        
        filter_join_clause = None
        if "filter_join_dataframe" in kwargs:
            fcls = kwargs.get("filter_join_dataframe")
            if fcls and fcls.strip() != '':
                filter_join_clause = fcls
        if filter_join_clause:
            join_df = join_df.filter(filter_join_clause)
            
        check_df_key_cols = df_key_cols.strip()
        check_join_df_key_cols = join_df_key_cols.strip()
        if check_df_key_cols == ''  or check_join_df_key_cols == '':
            e = errorify("INVALID_PARAMS"," Insuffucient key columns provided in params, dataframe_keys:<{}> v/s join_dataframe_keys:<{}> to formulate a join".format(df_key_cols,join_df_key_cols))
            return None,e
        
        l_df_keys = df_key_cols.split(delimiter)
        l_join_df_keys = join_df_key_cols.split(delimiter)
        if len(l_df_keys) != len(l_join_df_keys):
            e = errorify("INVALID_PARAMS","There seems to be a mismatch between the number"+     
            "of keys provided in dataframe_keys<{} v/s join_dataframe_keys<{}.".format(len(l_df_keys),len(l_join_df_keys)))
            return None,e
        
        
        l_key_set = zip(l_df_keys,l_join_df_keys)
        cond_set = []
        common_cols =OrderedDict()
        all_join_cols_match = True
        for s in l_key_set:
#             print(s[0],s[1])
            left_expr = s[0]
            right_expr = s[1]
            if left_expr != right_expr:
                all_join_cols_match = False
            elif left_expr == right_expr:
                common_cols[left_expr] =0
            
            cond_set.append(primary_df[left_expr]==join_df[right_expr])
        if all_join_cols_match:
            cond_set = list(common_cols.keys())
#         print("COND_SET:",cond_set)
        
        if all_cols_from_left and all_cols_from_right:   
            result_df = primary_df.join(join_df,cond_set,join_type).alias(result_df_name)
        else:
            select_cols, rename_cols = cmp_duplicates(l_df_cols,l_join_df_cols,df_name,join_df_name,l_rename_df_cols,l_rename_join_df_cols)
#             select_cols = [col("A.{}".format(x)) for x in l_df_cols]+[col("B.{}".format(x)) for x in l_join_df_cols]
#             print("SELECT COLS:",select_cols)
#             print("Rename Cols:",rename_cols)
            result_df = primary_df.alias("A").join(join_df.alias("B"),cond_set,join_type).select(*select_cols).toDF(*rename_cols).alias(result_df_name)
            
        #implementing filter
        if filter_clause:
            result_df = result_df.filter(filter_clause)
        return result_df,None
    except:
        e = get_exception()
        print(e)
        return None,e

def register_temp_table(d_dfs,**kwargs):
    try:
        delimiter = cc.input_column_delimiter
        df_names = kwargs.get('dataframe_name')
        table_names = kwargs.get('table_name')
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
        l_df_names = df_names.split(delimiter)
        l_table_names = table_names.split(delimiter)
        if len(l_df_names)!= len(l_table_names):
            #log error 
            return False,errorify("INVALID_PARAMS","Param List provided for operation is incorrect.")
        res_set = zip(l_df_names,l_table_names)
        for item in res_set:
            df_name = item[0]
            table_name = item[1]
            print (df_name,table_name)
            if df_name in d_dfs:
                df = d_dfs.get(df_name)
                df.createOrReplaceTempView(table_name)
            else:
                return False,errorify("INVALID_DATAFRAME_NAME","Dataframe <{}> has not been initialised".format(df_name))
        return True,None
    except:
        e = get_exception()
        return False,e



def run_sql(spark,**kwargs):
    try:
        sql_text = None
        result_df_name = kwargs.get("result_dataframe")
        if "sql_file" in kwargs:
            sql_file = kwargs.get("sql_file")
            read_file = spark.sparkContext.wholeTextFiles(sql_file).collect()
            if read_file:
                rd_temp = read_file[0][1]
                if rd_temp:
                    sql_text = rd_temp
        elif "sql_text" in kwargs:
            sq_temp = kwargs.get("sql_text")
            if sq_temp and sq_temp.strip() != '':
                sql_text = sq_temp
        
        if not sql_text:
            return None,errorify("INVALID_PARAMS","Param List provided for operation is incorrect.")
        else:
            result_df = spark.sql(sql_text).alias(result_df_name)
            return result_df,None    
    except:
        e = get_exception()
        return None, e

def aggregate_dataset(df,**kwargs):
    try:
        delimiter = cc.input_column_delimiter
        result_dataframe_name = None
        group_by_cols = kwargs.get("group_by_columns")
        agg_func_ops = kwargs.get("aggregate_output")
        if ("result_dataframe") in kwargs:
            rd = kwargs.get("result_dataframe")
            if rd and rd.strip() != '':
                result_dataframe_name = rd
        l_grp_by_cols = group_by_cols.split(delimiter)
        l_agg_func = agg_func_ops.split(delimiter)
        l_agg_func = ["pyfunc."+x for x in l_agg_func]
        l_agg_func = [eval(x) for x in l_agg_func]
        result_df = df.groupBy(l_grp_by_cols).agg(*l_agg_func)
        if result_dataframe_name:
            result_df.alias(result_dataframe_name)
        return result_df,None
    except:
        e = get_exception()
        return None, e
    
def pivot_dataset(df,**kwargs):
    try:
        delimiter = cc.input_column_delimiter
        
        p_col_vals = None
        l_p_col_vals = [] 
        group_by_columns = kwargs.get("group_by_columns")
        pivot_col = kwargs.get('pivot_column')
        agg_columns = None
        agg_function = 'pyfunc.first'
        agg_expression = None
        
        if 'aggregate_expression' in kwargs:
            ae = kwargs.get('aggregate_expression')
            if ae and ae.strip()!='':
                agg_expression = ae
        
        if 'aggregate_columns' in kwargs:
            ac = kwargs.get('aggregate_columns')
            if ac and ac.strip()!='':
                agg_columns = ac
        
        if 'aggregate_function' in kwargs:
            af = kwargs.get('aggregate_function')
            if af and af.strip()!='':
                agg_function = af
        
        if "delimiter" in kwargs:
            delimiter = kwargs.get("delimiter")
        
        if 'pivot_column_values' in kwargs:
            pcv = kwargs.get('pivot_column_values')
            if pcv and pcv.strip()!='':
                p_col_vals = pcv
        
        
        
        l_grp_by_cols = group_by_columns.split(delimiter)
        l_agg_expr = []
        if agg_expression:
            l_agg_expr = agg_expression.split(delimiter)
        elif agg_columns:
            l_agg_cols = agg_columns.split(delimiter)
            l_agg_func = agg_function.split(delimiter)
            len_agg_func = len(l_agg_func)
            
            for i,agg_col in enumerate(l_agg_cols):
                fc = 'first'
                if i<len_agg_func:
                    fc = l_agg_func[i]
                else:
                    fc = l_agg_func[-1]
                alias_name = fc.upper()+'_'+agg_col.upper()
                fc_f = fc+"('"+agg_col+"').alias('"+alias_name+"')"
                l_agg_expr.append(fc_f)
                        
        if not l_agg_expr:
            return None,errorify('INVALID_PARAMS', 'Either of params, <aggregate_expression> or <aggregate_columns> not found')
        
        l_agg_expr = [eval('pyfunc.'+x) for x in l_agg_expr]
        
        pivot_df = None
        if p_col_vals:
            l_p_col_vals = p_col_vals.split(delimiter)
            pivot_df = df.groupBy(l_grp_by_cols).pivot(pivot_col,l_p_col_vals).agg(*l_agg_expr)
        else:
            pivot_df = df.groupBy(l_grp_by_cols).pivot(pivot_col).agg(*l_agg_expr)
        return pivot_df,None
        
    except:
        e = get_exception()
        return None,e

    
def format_path(fpath,**kwargs):
    try:
         
        timestamp_format = cc.default_timestamp_format  
        if 'timestamp_format' in kwargs:
            tf = kwargs.get('timestamp_format')
            if tf and tf.strip()!='':
                timestamp_format = tf
        
        current_dtm = datetime.now()
        yyyy = current_dtm.strftime('%Y')
        MM = current_dtm.strftime('%m')
        dd = current_dtm.strftime('%d')
        HH=current_dtm.strftime('%H')
        mm = current_dtm.strftime('%M')
        ss = current_dtm.strftime('%S')
        ts = current_dtm.strftime(timestamp_format)
        fpath = fpath.format(timestamp = ts,
                         year = yyyy,
                         yyyy = yyyy,
                         month = MM,
                         MM=MM,
                         date = dd,
                         dd=dd,
                         hour = HH,
                         HH = HH,
                         minute = mm,
                         mm = mm,
                         second = ss,
                         ss = ss
                         )
        return fpath, None
    except:
        e = get_exception()
        return None,e
    
def write_file(spark,df,**kwargs):
    try:
        
        df_name = kwargs.get('dataframe_name')
        file_path = kwargs.get('file_path')
        fpath,e = format_path(file_path,**kwargs)
        if e:
            return False,e 
        else:
            file_path = fpath
        file_format = kwargs.get('file_format')
        write_mode = 'append'
        distinct = False
        single_file = False
        save_as_table = False
        database_name = None
        table_name = None
        if 'save_as_table' in kwargs:
            sat = kwargs.get('save_as_table')
            if sat:
                if sat.strip().upper() == 'TRUE':
                    save_as_table = True
        
        if save_as_table:
            database_name = 'default'
            table_name = df_name
            if 'database_name' in kwargs:
                dn = kwargs.get('database_name')
                if dn and dn.strip()!='':
                    database_name = dn
                
            if 'table_name' in kwargs:
                tn = kwargs.get('table_name')
                if tn and tn.strip()!='':
                    table_name = tn
            
                
        if 'write_mode' in kwargs:
            wm = kwargs.get('write_mode')
            if wm in ['append','overwrite','ignore','error']:
                write_mode = wm
        if 'distinct' in kwargs:
            v = kwargs.get('distinct')
            if v and v.strip().upper() == 'TRUE':
                distinct = True
        if 'single_file' in kwargs:
            sf = kwargs.get('single_file')
            if sf:
                sf = sf.strip().upper()
                if sf == 'TRUE':
                    single_file = True
                
        if distinct:
            df = df.distinct()
        if single_file:
            df = df.coalesce(1)
        
        if save_as_table:
            spark.conf.set("spark.sql.parquet.writeLegacyFormat","True")
            cht_tags = {'table_name': table_name, 'database_name': database_name, 'file_format': 'parquet', 'file_path': file_path,
                        }
            return create_hive_table(spark,df,**cht_tags)
        else:
            if file_format == 'csv':
                df.write.option('header',True).option("multiline","True").option("delimiter",",") \
                            .option("quote",'"').option('escape','\\') \
                .mode(write_mode).csv(file_path)
            else:
                if file_format == 'parquet':
                    spark.conf.set("spark.sql.parquet.writeLegacyFormat","True")
                df.write.format(file_format).mode(write_mode).save(file_path)
        
        return True,None
    except:
        e = get_exception()
        return False,e


def move_file(spark,**kwargs):
    try:
        sc = spark.sparkContext
        
        src = kwargs.get('source_file_path')
        dest = kwargs.get('target_file_path')
        fpath,e = format_path(dest,**kwargs)
        if e:
            return False,e 
        else:
            dest = fpath
             
        delete_source = False
        overwrite=True
        if 'delete_source' in kwargs:
            ds = kwargs.get('delete_source')
            ds = ds.strip().upper()
            if ds == 'TRUE':
                delete_source = True
        
        if 'overwrite_target' in kwargs:
            ot = kwargs.get('overwrite_target')
            ot = ot.strip().upper()
            if ot == 'FALSE':
                overwrite = False
       
        
            
        URI           = sc._jvm.java.net.URI
        Path          = sc._jvm.org.apache.hadoop.fs.Path
        FileSystem    = sc._jvm.org.apache.hadoop.fs.FileSystem
        Configuration = sc._jvm.org.apache.hadoop.conf.Configuration
        FileUtil      = sc._jvm.org.apache.hadoop.fs.FileUtil
    
        conf = Configuration()
        if 'aws_access_key' in kwargs:
            aws_access_key = kwargs.get('aws_access_key')
            conf.set("fs.s3a.access.key",aws_access_key)
        if 'aws_secret_key' in kwargs:
            aws_secret_key = kwargs.get('aws_secret_key')
            conf.set("fs.s3a.secret.key",aws_secret_key)
#         conf.set("fs.s3a.impl","org.apache.hadoop.fs.s3a.S3AFileSystem")
#         
#         
        src_uri = URI(src)
        dest_uri = URI(dest)
        
        src_fs = FileSystem.get(src_uri, conf)
        dest_fs = FileSystem.get(dest_uri ,conf)
        
        src_path = Path(src_uri.getPath())
        dest_path = Path(dest_uri.getPath())
    
        res = FileUtil.copy(src_fs, src_path, dest_fs, dest_path, delete_source, overwrite, conf)
        return res,None
    except:
        e = get_exception()
        return False, e

def create_hive_table(spark,df,**kwargs):
    try:

        file_path = kwargs.get('file_path')
        file_format = kwargs.get('file_format').strip().upper()
        db_name = kwargs.get('database_name')
        table_name = kwargs.get('table_name')
        
        temp_table_name = table_name+'_temp'
        q_tbl = table_name
        if db_name:
            if db_name.strip()!='':
                q_tbl = db_name+'.'+table_name
        
        
        df.createOrReplaceTempView(temp_table_name)
        demo_text = "show databases"
        drop_sql_text = 'DROP TABLE IF EXISTS '+q_tbl
#         create_sql_text = 'create external table '+q_tbl+' like '+temp_table_name+' location \''+file_path+'\''
        create_sql_text = """CREATE EXTERNAL TABLE {table_name}
                 STORED AS {format}
                 LOCATION '{location}'
                 AS SELECT * FROM {temp_table_name}
              """.format(table_name = q_tbl,
                         format='PARQUET',
                         location=file_path,
                         temp_table_name = temp_table_name
                         )
        
#         df = spark.sql(demo_text)
#         df.show()
        try:
            drop_res = spark.sql(drop_sql_text)
        except:
            pass
        create_res = spark.sql(create_sql_text)
        return True,None
    except:
        e = get_exception()
        return False, e

def get_redshift_dtype(dtype):
    
    """
    https://spark.apache.org/docs/2.1.2/api/python/_modules/pyspark/sql/types.html
    Spark Datatypes:
    ########################################################################################
    "DataType", "NullType", "StringType", "BinaryType", "BooleanType", "DateType",
    "TimestampType", "DecimalType", "DoubleType", "FloatType", "ByteType", "IntegerType",
    "LongType", "ShortType", "ArrayType", "MapType", "StructField", "StructType"
    ########################################################################################
    https://docs.aws.amazon.com/redshift/latest/dg/c_Supported_data_types.html
    Redshift Datatypes:
    Data Type    Aliases    Description
    SMALLINT    INT2    Signed two-byte integer
    INTEGER    INT, INT4    Signed four-byte integer
    BIGINT    INT8    Signed eight-byte integer
    DECIMAL    NUMERIC    Exact numeric of selectable precision
    REAL    FLOAT4    Single precision floating-point number
    DOUBLE PRECISION    FLOAT8, FLOAT    Double precision floating-point number
    BOOLEAN    BOOL    Logical Boolean (true/false)
    CHAR    CHARACTER, NCHAR, BPCHAR    Fixed-length character string
    VARCHAR    CHARACTER VARYING, NVARCHAR, TEXT    Variable-length character string with a user-defined limit
    DATE        Calendar date (year, month, day)
    TIMESTAMP    TIMESTAMP WITHOUT TIME ZONE    Date and time (without time zone)
    TIMESTAMPTZ    TIMESTAMP WITH TIME ZONE    Date and time (with time zone)
    """
    dtype_key = dtype
    precision = ''
    m = re.search('([a-zA-Z]+)[ ]*(\([0-9 ,]+\))*',dtype)
    if m:
        len_m = len(m.groups())
        dtype_key = m.group(1).strip().lower()
        if len_m>1:
            if m.group(2):
                precision = m.group(2)
        
        
    d_types = {
            "data":"VARCHAR(MAX)",
            "null":"VARCHAR(MAX)",
            "string":"VARCHAR(MAX)",
            "binary":"VARCHAR(MAX)",
            "boolean":"BOOLEAN",
            "date":"DATE",
            "timestamp":"TIMESTAMP",
            "double":"DOUBLE PRECISION",
            "float":"DECIMAL",
            "byte":"byte",
            "integer":"INTEGER",
            "long":"BIGINT",
            "short":"SMALLINT",
            "array":"VARCHAR(MAX)",
            "map":"VARCHAR(MAX)",
            "decimal":"DECIMAL",
            "tinyint":"SMALLINT",
            "int":"INTEGER",
            "bigint":"BIGINT",
            "smallint":"SMALLINT",
            
    
        }
    
    if dtype_key in d_types:
        res =  d_types.get(dtype_key)
        if res != 'VARCHAR(MAX)':
            if precision!='':
                res = res+' '+precision
        return res
    else:
        return 'VARCHAR(MAX)'


def write_string_to_file(spark,**kwargs):
    try:
        sc = spark.sparkContext
        data = kwargs.get('string_data')
        file_path = kwargs.get('file_path')
        file_name = kwargs.get('file_name')
        final_rdd = sc.parallelize([data])
        #deleting previous file path
        res,e = delete_file(spark,**kwargs)
        if e :
            return False,e
        
        final_rdd.coalesce(1).saveAsTextFile(file_path)
        return rename_file(spark,**kwargs)
    except:
        e = get_exception()
        return False,e
    
def write_redshift_ddl(spark,df,**kwargs):
    try:
        file_path = kwargs.get('file_path')
        file_path,e = format_path(file_path,**kwargs)
        if e:
            return False,e
        sc = spark.sparkContext
        database_name = kwargs.get('database_name')
        table_name = kwargs.get('table_name')
        exclude_drop_table = False
        exclude_grant_previleges = False
        exclude_audit_columns = False
        drop_statement = ''
        grant_statement = ''
        
        if 'exclude_drop_table' in kwargs:
            edt = kwargs.get('exclude_drop_table')
            if edt:
                if edt.strip() == 'TRUE':
                    exclude_drop_table = True
        
        if 'exclude_grant_previleges' in kwargs:
            egp = kwargs.get('exclude_grant_previleges')
            if egp:
                if egp.strip() == 'TRUE':
                    exclude_grant_previleges = True
        
        if 'exclude_audit_columns' in kwargs:
            eac = kwargs.get('exclude_audit_columns')
            if eac:
                if eac.strip() == 'TRUE':
                    exclude_audit_columns = True
        if not exclude_drop_table:
            drop_statement = 'drop table if exists {}.{};\n\n'.format(database_name,table_name)
        if not exclude_grant_previleges:
            grant_statement = 'grant all privileges on {}.{} to PUBLIC;\n\n'.format(database_name,table_name)
        create_statement = 'create table {}.{} (\n'.format(database_name,table_name) 
        sch_dtypes = df.dtypes
        
        for i,rw in enumerate(sch_dtypes):
            column_name = str(rw[0]).strip()
            dtype = rw[1]
            
            red_dtype = get_redshift_dtype(dtype)
#             print(column_name, dtype,red_dtype)
            column_statement =  '{column_name} {datatype}\n'.format(column_name = column_name,
                                                                     datatype = red_dtype
                                                                     )
            if i==0:
                column_statement = '  '+column_statement
            else:
                column_statement = ', '+column_statement
            create_statement+=column_statement
        #end of for
#         if not exclude_audit_columns:
#             create_statement += ', SNAPSHOT_DATE TIMESTAMP'
        create_statement+='\n);\n\n'
        final_ddl = drop_statement + create_statement + grant_statement
        final_rdd = sc.parallelize([final_ddl])
        #deleting previous file path
        res,e = delete_file(spark,**kwargs)
        if e :
            return False,e
#         print(file_path)
        final_rdd.coalesce(1).saveAsTextFile(file_path)
        return rename_file(spark,**kwargs)
        
    except:
        e = get_exception()
        return False,e

def delete_file(spark,**kwargs):
    """
    using hadoop fileutils
    https://hadoop.apache.org/docs/r2.7.1/api/org/apache/hadoop/fs/FileSystem.html
    """
    try:
        res = False
        sc = spark.sparkContext
        src = kwargs.get('file_path')
        URI           = sc._jvm.java.net.URI
        Path          = sc._jvm.org.apache.hadoop.fs.Path
        FileSystem    = sc._jvm.org.apache.hadoop.fs.FileSystem
        Configuration = sc._jvm.org.apache.hadoop.conf.Configuration
        FileUtil      = sc._jvm.org.apache.hadoop.fs.FileUtil
        conf = Configuration()
        if 'aws_access_key' in kwargs:
            aws_access_key = kwargs.get('aws_access_key')
            conf.set("fs.s3a.access.key",aws_access_key)
        if 'aws_secret_key' in kwargs:
            aws_secret_key = kwargs.get('aws_secret_key')
            conf.set("fs.s3a.secret.key",aws_secret_key)
        src_uri = URI(src)
        src_fs = FileSystem.get(src_uri, conf)
        src_path =  Path(src_uri.getPath())
        path_exists = src_fs.exists(src_path)
        if path_exists:
            res = src_fs.delete(src_path,True)
        else:
            res = True
        return res,None
    except:
        e = get_exception()
        return False,e




def sync_files(spark,**kwargs):
    try:
        sop = SyncOperations(spark,**kwargs)
        e = sop.run()
        return True,e
    except:
        e = get_exception()
        return False,e
    
def rename_file(spark,**kwargs):
    """
    using hadoop fileutils
    https://hadoop.apache.org/docs/r2.7.1/api/org/apache/hadoop/fs/FileSystem.html
    """
    try:
        res = False
        sc = spark.sparkContext
        src = kwargs.get('file_path')
        file_name = kwargs.get('file_name')
        URI           = sc._jvm.java.net.URI
        Path          = sc._jvm.org.apache.hadoop.fs.Path
        FileSystem    = sc._jvm.org.apache.hadoop.fs.FileSystem
        Configuration = sc._jvm.org.apache.hadoop.conf.Configuration
        FileUtil      = sc._jvm.org.apache.hadoop.fs.FileUtil
        conf = Configuration()
        if 'aws_access_key' in kwargs:
            aws_access_key = kwargs.get('aws_access_key')
            conf.set("fs.s3a.access.key",aws_access_key)
        if 'aws_secret_key' in kwargs:
            aws_secret_key = kwargs.get('aws_secret_key')
            conf.set("fs.s3a.secret.key",aws_secret_key)
        src_uri = URI(src)
        src_fs = FileSystem.get(src_uri, conf)
        src_path =  Path(src_uri.getPath())
        if src[-1] == '/':
            src = src[:-1]
#         print (src)
        l_files = src_fs.globStatus(Path(src+'/part*')) 
        f = l_files[0] #CopyMerge all part files into one 
        res = src_fs.rename(f.getPath(),Path(src+'/'+file_name))
        return res,None
    except:
        e = get_exception()
        return False,e

def cmp_override(df_columns,lkp_key_cols):
    valid_lkp_key_cols = []
    invalid_lkp_key_cols = []
    d_valid = {}
    for t in lkp_key_cols:
        lc = t[0]
        kc = t[1]
        lc_valid = False
        kc_valid = False
        if lc in d_valid:
            lc_valid = True
        if kc in d_valid:
            kc_valid = True
        if not lc_valid and lc in df_columns:
            lc_valid = True
            d_valid[lc] = ""
        if not kc_valid and kc in df_columns:
            kc_valid = True
            d_valid[kc]=""
        if lc_valid and kc_valid:
            valid_lkp_key_cols.append(t)
    return valid_lkp_key_cols
    
def override_columns(df,d_override_dfs,**kwargs):
    try:
        df_res = None
        d_lc_kc = {}
        l_lc_kc = []
        entity_name = kwargs.get('entity_name')
        if entity_name in d_override_dfs:
            d_lc_kc = d_override_dfs.get(entity_name)
        if d_lc_kc:
            for lc, d_kc in d_lc_kc.items():
                for kc in d_kc.keys():
                  l_lc_kc.append((lc,kc))
        valid_lkp_key_cols = cmp_override(df.columns, l_lc_kc)
#         print(valid_lkp_key_cols)
        
        df_res = df
        df_res = df_res.withColumn("OVERRIDE_COLUMNS",lit("None"))
        select_cols = df_res.columns
        rename_cols = df_res.columns
        
        for t in valid_lkp_key_cols:
            lookup_col = t[0]
            override_lkp_col = 'override_'+lookup_col
            key_col = t[1]
            l_df_lkp = d_lc_kc.get(lookup_col).get(key_col)
#             print(t,l_df_lkp)
           
            for df_lkp in l_df_lkp:                
                select_columns = [col('A.{}'.format(x)) for x in select_cols]+[col('B.{}'.format(lookup_col))]
                rename_columns = rename_cols+[override_lkp_col]
                df_res = df_res.alias("A").join(df_lkp.alias("B"),[key_col],'left_outer').select(*select_columns).toDF(*rename_columns)
                df_res = df_res.withColumn(lookup_col,when(isnull(col(override_lkp_col)),col(lookup_col)).otherwise(col(override_lkp_col)))
                
                df_res = df_res.withColumn("OVERRIDE_COLUMNS"
                                           ,when(
                                               isnull(col(override_lkp_col))
                                               ,col("OVERRIDE_COLUMNS")
                                            ).otherwise(
                                                when(col("OVERRIDE_COLUMNS")==lit('None'),lit(lookup_col))
                                                .otherwise(concat_ws(';',col("OVERRIDE_COLUMNS"),lit(lookup_col)))
                                            )
                                        )
                
                df_res = df_res.drop(override_lkp_col)
            
           
        return df_res,None
    except:
        e = get_exception()
        return None,e