from pyspark.sql import SparkSession


spark = SparkSession.builder.enableHiveSupport().getOrCreate()
#          \
#         .enableHiveSupport() \
#         .getOrCreate()

