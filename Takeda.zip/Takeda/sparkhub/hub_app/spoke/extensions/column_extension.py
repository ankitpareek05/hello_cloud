import pyspark.sql.functions as pyfunc
from pyspark.sql.functions import when, regexp_replace, trim, lit,concat,regexp_extract
from pyspark.sql.column import Column
from hub_app.func_utils import get_exception
def cleanup(self):
#     if type(self) != 'StringType':
#         return self
    #trims and removes all non word characters from the column string
    return pyfunc.trim(pyfunc.regexp_replace(self,"[^\x20-\x7f]+" , ''))


def remove_newline(self):
    return regexp_replace(self,"[\r\n]+","\t")


def get_pattern(datatype):
    if datatype == 'NUMBER':
        return '[0-9-]+'
    elif datatype == 'DECIMAL':
        return '[0-9\.-]+'
    elif datatype == 'DATE':
        return '([0-9]{4})[ \./\-]*([0-9]{2})[ \./\-]*([0-9]{2})'
    elif datatype == 'DATETIME':
        date_separator = r'[ \./\-]*'
        time_separator = r'[ :\./\-]*'
        date_pattern = r'([0-9]{4})'+date_separator+r'([0-9]{2})'+date_separator+r'([0-9]{2})'
        time_pattern = r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+r'([0-9]{2})'
        time_pattern_optional = r'('+time_pattern+')*'
        fractional_seconds_optional = r'([0-9]*)'
        datetime_pattern = date_pattern+date_separator+time_pattern_optional+time_separator+fractional_seconds_optional
        return datetime_pattern
    elif datatype == 'TIMESTAMP':
        date_separator = r'[ \./\-]*'
        time_separator = r'[ :\./\-]*'
        date_pattern = r'([0-9]{4})'+date_separator+r'([0-9]{2})'+date_separator+r'([0-9]{2})'
        fract_seconds = r'([0-9]*)'
        time_pattern = r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+r'([0-9]{2})'+time_separator+fract_seconds
        timestamp_pattern = date_pattern+date_separator+time_pattern
        return timestamp_pattern
    else:
        return r'.*'

def is_null_or_blank(self):
        return self.isNull() | (pyfunc.trim(self) == '')

def validate_not_null(self,name):
    
    err_msg = " - Not Null column has null or blank values."
    return when (self.isNull(),concat(lit(name),lit(err_msg))).otherwise("")
   
   
def validate_datatype(self,datatype,name=''):
    try:
        
        pattern = get_pattern(datatype)
        datatype_err_msg = name+" - Column of datatype <"+datatype+"> has invalid values <"+self.cast("string")+">."
        err_msg_1 = " - Column of datatype <"
        err_msg_2 = "> has invalid value <"
        err_msg_3 = ">."
        return when (~(self.is_null_or_blank()) & (~(regexp_replace(trim(self),pattern,'')=='')),concat(lit(name),lit(err_msg_1),lit(datatype),lit(err_msg_2),self.cast("string"),lit(err_msg_3))).otherwise("")
    
    except:
        e = get_exception()
        print(e)
        return None
    

def rationalize_year(self):
    try:
        check_pattern = '^([0-9]{4})'
#         replace_pattern = '^([0-9]{4})([ \./\-]*[0-9]{2}[ \./\-]*[0-9]{2}[ :\./\-]*[0-9]{2}[ :\./\-]*[0-9]{2}[ :\./\-]*[0-9]{2}[ :\./\-]*[0-9]*)'
        
        return when (~(self.is_null_or_blank()) &  (regexp_extract(trim(self),check_pattern,1)<lit('1900')),
                                     regexp_replace(trim(self),check_pattern,'1900')
                                     ).otherwise(trim(self))
        
    
    except:
        e = get_exception()
        print(e)
        return None
        
       
Column.is_null_or_blank = is_null_or_blank    
Column.cleanup = cleanup
Column.validate_datatype = validate_datatype
Column.remove_newline = remove_newline
Column.validate_not_null = validate_not_null
Column.rationalize_year = rationalize_year

