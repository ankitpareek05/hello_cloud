from pyspark.sql import SparkSession
from hub_app.spoke.spark import *
from pyspark.sql.types import StructField, StructType
# from hub_app.func_utils import get_exception, errorify
# from pyspark.sql.types import *
# from datetime import datetime
# from pyspark.sql.column import Column
# from pyspark.sql.functions import isnull
# import re
# from collections import OrderedDict


def create_df(self,rows_data,columns):
    struct_fields = list(map(lambda x:StructField(*x),columns))
    return spark.createDataFrame(rows_data,StructType(struct_fields))

def create_dataframe(self,**kwargs):

    df_name = kwargs.get('dataframe_name')
    file_path = kwargs.get('file_path')
    file_schema = kwargs.get('file_schema')
    file_format = kwargs.get('file_format')
    schema = None
    hasHeader = True
    if 'has_header' in kwargs:
        temp = kwargs.get('has_header')
        temp = temp.strip().upper()
        if temp == 'TRUE':
            hasHeader = True
        elif temp == 'FALSE':
            hasHeader = False 
    if file_schema:
        pass
    result_df = None
    if file_format == 'csv':
        return spark.read.csv(file_path,header=hasHeader,schema=schema).alias(df_name)
    elif file_format == 'parquet':
        return spark.read.parquet(file_path).alias(df_name)
    else :
        return spark.read.format(file_format).load(file_path).alias(df_name)


     
SparkSession.create_dataframe = create_dataframe
SparkSession.create_df = create_df