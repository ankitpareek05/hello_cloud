
from hub_app.common_utils import get_exception, errorify, glob_filter_keep, glob_filter_remove, get_file_extension, get_md5, make_table_name

class SFile:
    def __init__(self):
        self.fso=None # to store the file status object
        self.fpo = None #to store the file path object
        self.file_name=''
        self.file_path_str = ''
        self.last_modified_at = ''
        self.ext = ''
        self.parent_folder_name = ''
        self.is_schema_required = False
        self. ref_path = ''
        self.table_name = ''
        self.error = []
        self.ref_path_grp = ''
    
    def set_params(self,file_status=None, root_dir = None):
        try:
            self.fso = file_status
            self.fpo = file_status.getPath()
            self.file_path_str = self.fpo.toString()
            self.file_name = self.fpo.getName()
            self.parent_folder_name = self.fpo.getParent().getName()
            self.ext = get_file_extension(self.file_name)
            self.last_modified_at=self.fso.getModificationTime()
            self.ref_path = self.file_path_str.replace(root_dir,'')
            tb_key = self.ref_path.replace('/'+self.file_name,'')
            if self.ref_path == '':
                self.ref_path = self.file_name
                tb_key = self.file_name
            
            self.table_name = make_table_name(tb_key)
            self.ref_path_grp = self.table_name+'#'+self.ext
            print(self.ref_path,self.table_name)
            return None
        except:
            e = get_exception()
            return e
        
    def get_ref_path(self):
        return self.ref_path
    
    def is_new_or_changed(self,prevmodtime):
        if self.last_modified_at>int(prevmodtime):
            return True
        else:
            return False
    
    def __str__(self):
        return "file_path_str: {}, file_name: {}, parent_folder_name: {}, ext: {}, last_modified_at: {}".format(
                self.file_path_str,self.file_name, self.parent_folder_name, self.ext, self.last_modified_at
            )
#     def set_params(self,file_name, file_path_str,parent_folder_name, last_modified):
#         self.file_name = file_name
#         self.file_path_str = file_path_str
#         self.parent_folder_name = parent_folder_name
#         self.last_modified_at = last_modified