from collections import OrderedDict
from pyspark.sql.types import StructType, StructField, StringType

class Sch(object):
    def __init__(self):
        self.column_names = []
        self.d_columns = OrderedDict()
        self.l_validateable_types = ['DATE','TIMESTAMP','NUMBER','DECIMAL']
    def add_column(self,schCol):
        self.d_columns[schCol.name]=schCol
        self.column_names.append(schCol.name)
        
    def get_columns(self):
        return self.d_columns
    
    def get_column(self,column_name):
        if column_name in self.d_columns:
            return self.d_columns.get(column_name)
        else:
            return None
    
    def get_column_names(self):
        return self.column_names
        
    def get_column_datatypes(self):
        d_res = OrderedDict()
        for col_name in self.column_names:
            col = self.get_column(col_name)
            
            if col:
                d_res[col_name] = col.hive_datatype
            else:
                d_res[col_name] = "STRING"
        return d_res
    
    def get_validateable_column_datatypes(self):
        d_res = OrderedDict()
        for col_name in self.column_names:
            col = self.get_column(col_name)
            
            if col:
                dtype = col.hive_datatype
                if dtype in self.l_validateable_types or not col.is_nullable:
                    d_res[col_name] = (col.hive_datatype,col.is_nullable)
            
                
        return d_res
    
    
    
    def get_dataframe_schema(self):
        l_cols = []
        for col_name in self.column_names:
            col = self.get_column(col_name)
            if col:
                spark_datatype = col.spark_datatype
                is_nullable = col.is_nullable
                l_cols.append(StructField(col_name, spark_datatype))
            else:
                spark_datatype = StringType()
                is_nullable = True
                l_cols.append(StructField(col_name, spark_datatype))
                
        return StructType(l_cols)
    
    def get_dataframe_column_types(self):
        l_cols = []
        for col_name in self.column_names:
            col = self.get_column(col_name)
            if col:
                spark_datatype = col.spark_datatype
                is_nullable = col.is_nullable
                l_cols.append(StructField(col_name, spark_datatype))
            else:
                spark_datatype = StringType()
                is_nullable = True
                l_cols.append(StructField(col_name, spark_datatype))
                
        return l_cols
    
    def get_columns_spark_types(self):
        d_cols = {}
        for col_name in self.column_names:
            col = self.get_column(col_name)
            if col:
                spark_datatype = col.spark_datatype
                hive_datatype = col.hive_datatype
                if hive_datatype != 'STRING':
                    d_cols[col_name] = (spark_datatype,hive_datatype)
                    
        return d_cols
    
    def get_string_columns(self):
        d_cols = {}
        for col_name in self.column_names:
            col = self.get_column(col_name)
            if col:
                spark_datatype = col.spark_datatype
                hive_datatype = col.hive_datatype
                if hive_datatype == 'STRING':
                    d_cols[col_name] = spark_datatype
                    
        return d_cols
    def get_column_by_types(self):
        d_type_cols = {}
        for col_name in self.column_names:
            col = self.get_column(col_name)
            if col:
                hive_datatype = col.hive_datatype
                spark_datatype = col.spark_datatype
                l_cols = []
                if hive_datatype in d_type_cols:
                    l_cols = d_type_cols.get(hive_datatype)
                l_cols.append((col_name,spark_datatype))
                d_type_cols[hive_datatype] = l_cols    
        return d_type_cols
    
class SchColumn(object):
    def __init__(self):
        self.name = ''
        self.datatype = ''
        self.spark_datatype = None
        self.hive_datatype = ''
        self.length = 0
        self.is_nullable = True
    
    def set_params(self,name, datatype, spark_datatype, hive_datatype, length, is_nullable):
        self.name = name
        self.datatype = datatype
        self.spark_datatype = spark_datatype
        self.hive_datatype = hive_datatype
        self.length = length
        self.is_nullable = is_nullable
        
    