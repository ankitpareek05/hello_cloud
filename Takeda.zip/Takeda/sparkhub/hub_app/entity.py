from hub_app.spoke import *
from hub_app.func_utils import get_exception,errorify
import hub_app.func_utils as func
import hub_app.validation_df as vld
from collections import OrderedDict
from hub_app.override_objects import Override as Over

import sys
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql.functions import col,collect_list
from hub_app.operation import Operation

log4jlogger = spark._jvm.org.apache.log4j
log = log4jlogger.LogManager.getLogger(__name__)
log.warn("spark_application_id:<{}>".format(spark.sparkContext.applicationId))
         
class Entity:
    #job_id,job_config,op_config,config_format,debug= True,num_debug_rows = 10,override_file= None
    def __init__(self,**kwargs):
        self.job_id = None
        self.job_run_id = None
        self.f_job_config = None
        self.f_op_config = None
        self.application_id_path = None
        self.f_cfg_format = "csv"
        self.debug = False
        self.take = 10
        self.f_override = None
        self.operations = OrderedDict()
        self.distinct_operations = {}
        self.d_override_dfs = {}
        self.d_ops = {}
        self.dataframes = {}
        self.df_paths ={}
        
        
        self.params_set = self.set_params(**kwargs)
        if self.params_set:
            if self.job_id and self.f_job_config and self.f_op_config:
                self.read_config()
            if self.f_override:
                self.d_override_dfs = self.read_override(override_file = self.f_override)
            if self.application_id_path and self.job_run_id:
                self.write_application_id()
            else:
                if not self.application_id_path:
                    log.warn('application_id_path has not been defined')
                if not self.job_run_id:
                    log.warn('job_run_id is not defined')   
    def set_params(self,**kwargs):
        try:
            self.job_id = kwargs.get('job_id')
            self.f_job_config = kwargs.get('job_config')
            self.f_op_config = kwargs.get('op_config')
            self.f_cfg_format = kwargs.get('config_file_format')
            self.debug = kwargs.get('debug_mode')
            self.take = kwargs.get('num_debug_rows')
            self.f_override = kwargs.get('override_file')
            if 'job_run_id' in kwargs:
                self.job_run_id = kwargs.get('job_run_id')
            if 'application_id_path' in kwargs:
                self.application_id_path = kwargs.get('application_id_path')
        except:
            return False
        return True
    def read_override(self,override_file):
        """
        Function to read the override file
        """
        try:
            override_schema = StructType([
                StructField("entity_key",StringType(), False),
                StructField("key_column_name",StringType(),False),
                StructField("key_column_value",StringType(),False),
                StructField("override_column_name",StringType(),False),
                StructField("override_column_value",StringType(),False)
            ])
            override_df = spark.read.format(self.f_cfg_format)            \
                            .option('header','true')                    \
                            .schema(override_schema)                      \
                            .load(override_file)    

            ov = Over()
            for row in override_df.collect():
                ov.parse_row(**row.asDict())
            ov.process_rows(spark)
            res =  ov.get_all_configs()
            
#             for entity_key,d_ek in res.items():
#                 for lkp_col, d_lc in d_ek.items():
#                     for key_col, l_kc in d_lc.items():
#                         for i,df in enumerate(l_kc):
#                             print(i,key_col,lkp_col)
#                             df.show()
            return res
        except:
            e = get_exception()
            log.error(e)
            return None
    
    
    def write_application_id(self):
        try:
            file_path = self.application_id_path+'/'+self.job_run_id
            file_name = 'application_id'
            string_data = spark.sparkContext.applicationId
            op_tags = {'string_data':string_data,
                       'file_path':file_path,
                       'file_name':file_name
                       }
            stat,e = func.write_string_to_file(spark,**op_tags)
            if e:
                log.error(e)
        except:
            log.error(get_exception())
    def read_config(self):
        """
        Function 
        """
        try:
            job_op_schema = StructType([
                    StructField("job_id",StringType()),
                    StructField("job_name",StringType()),
                    StructField("op_id",StringType()),
                    StructField("op_order",IntegerType()),
                    StructField("active_flag",StringType())
                ])
            op_schema = StructType([
                    StructField("job_id",StringType()),
                    StructField("op_id",StringType()),
                    StructField("op_class",StringType()),
                    StructField("op_type",StringType()),
                    StructField("op_tag",StringType()),
                    StructField("op_value",StringType())
                ])
            
            job_op_df = spark.read.format(self.f_cfg_format)            \
                            .option('header','true')                    \
                            .schema(job_op_schema)                      \
                            .load(self.f_job_config)          
            job_op_df = job_op_df                                       \
                        .filter(job_op_df["job_id"] == self.job_id)     \
                        .filter(job_op_df["active_flag"] == 'Y')        \
                        .orderBy("op_order",ascending=True)             \
                        .collect()
                            
            for rw in job_op_df:
                k = rw.op_order #1
                v = rw.op_id # 
                self.distinct_operations[v]='' #meaning 4401-- ""
                if k in self.operations:
                    l_v = self.operations.get(k)
                    l_v.append(v)
                    self.operations[k] = l_v
                else:
                    self.operations[k] = [v] #key, list[] 1,4401
            l_ops = set(self.distinct_operations.keys())
            op_cfg_df = spark.read.format(self.f_cfg_format)            \
                            .option('header','true')                    \
                            .schema(op_schema)                          \
                            .load(self.f_op_config) 
            op_cfg_df = op_cfg_df                                       \
                            .filter(op_cfg_df.job_id == self.job_id)    \
                            .filter(op_cfg_df.op_id.isin(l_ops))        \
                            .orderBy("op_id")                           \
                            .collect()
            
            
            #looping over the operations and converting them to operation objects
            prev_op_id = ''
            op = None
            for rw in op_cfg_df:
                if rw.op_id != prev_op_id:
                    if op and prev_op_id != '':
                        self.d_ops[prev_op_id] = op 
                        
                    op = Operation()
                    op.set_params(rw.op_id,rw.op_class,rw.op_type)
                
                op.add_tag(rw.op_tag,rw.op_value)
                prev_op_id = rw.op_id
            if op and prev_op_id!='':
                self.d_ops[prev_op_id] = op
#             for k,v in self.d_ops.items():
#                 print(k,str(v))
#             
            
        except:
            e = get_exception()
            log.error(e)
#             sys.stderr(e)
    
    def run_operations(self):
        try:
            if not self.operations:
                log.warn("No operations found to run")
                return True
            
            for op_order,l_v in self.operations.items():
                for op_id in l_v:
                    if op_id in self.d_ops:
                        op_obj = self.d_ops.get(op_id)
                        
                        if self.debug:
                            log.warn(str(op_obj))
                        res = self.run_operation(op_obj)
                        if not res:
                            log.error("Error encountered during run of operation:<{}>,<{}>".format(op_id,op_obj.operation_class))
                            return False
                    else:
                        log.warn("Operation <{}> is not defined, skipping".format(op_id))
                        continue
            return True
        except:
            e = get_exception()
            log.error(e)
            return False
    
    def dataframe_default_operations(self,name, df):
        log.warn("{} dataframe , Count:{}".format(name, str(df.count())))
    
    def dataframe_debug(self,df_name,df):
        try:
            log.warn("Dataframe: <{}> ".format(df_name))
            log.warn("Columns: {} ".format(','.join(df.columns)))
            log.warn("Datatypes:{}".format(str(df.dtypes)))
            log.warn(df.show(self.take,False))
        except:
            e = get_exception()
            log.warn(e)
            return
    
    
    def add_dataframe(self,name,df):
        try:
            if df and type(df).__name__.endswith('DataFrame'):
                self.dataframes[name] = df
                if self.debug:
                    self.dataframe_debug(name,df)
                self.dataframe_default_operations(name,df)
                return True
            return False
        except:
            e = get_exception()
            print(e)
            return False
    def get_dataframe(self,name):
        if name in self.dataframes:
            return self.dataframes.get(name)
        else:
            return None
        
    def run_operation(self,op_obj):
        try:
            avl_funcs = dir(func)
#             assert(type(op_obj).__name__ == "Operation")
            op_id = op_obj.operation_id
            op_class = op_obj.operation_class
            op_type = op_obj.operation_type
            op_tags = op_obj.operation_tags
            log.warn('Running operation {},{}'.format(op_id,op_class))
            if op_type=='entity':
                if op_class == 'sync_files':
                    status,error = func.sync_files(spark,**op_tags)
                    if error:
                        log.error(error)
                        return False
                elif op_class == 'register_temp_table':
                    status,error = func.register_temp_table(self.dataframes,**op_tags)
                    if error:
                        log.error(error)
                        return False
                    return True
                elif op_class == 'run_sql':
                    result_df_name = op_tags.get("result_dataframe")
                    result_df,error = func.run_sql(spark,**op_tags)
                    if error:
                        log.error(error)
                        return False
                    if result_df and type(result_df).__name__.endswith('DataFrame'):
                        self.dataframes[result_df_name] = result_df
                        if self.debug:
                            log.warn("columns:"+str(result_df.columns))
                            log.warn(result_df.take(self.take))
                    return True
                elif op_class == 'read_file':
                    result_df_name = op_tags.get("result_dataframe")
                    reject_df_name = result_df_name+'_rejected'
                    if 'reject_dataframe' in op_tags:
                        reject_df_name = op_tags.get('reject_dataframe')
                    result_df,reject_df,error = vld.read_file(spark,**op_tags)
                    if error:
                        log.error(error)
                        return False
                    if result_df:
                        stat = self.add_dataframe(result_df_name,result_df)
                        if not stat:
                            log.warn("Unable to persist dataframe <{}>".format(result_df_name))
                            return False
                    if reject_df:
                        stat = self.add_dataframe(reject_df_name,reject_df)
                        if not stat:
                            log.warn("Unable to persist dataframe <{}>".format(result_df_name))
                            return False
                    return True
                elif op_class == 'move_file':
                    status,error = func.move_file(spark,**op_tags)
                    if error:
                        log.error(error)
                        return False
                    if not status:
                        log.error("File Move operation was unsuccessful")
                        return False
                    return True
                
            elif op_type == 'dataframe':
                df_name = op_tags.get('dataframe_name')
                result_df_name = df_name
                
                if 'result_dataframe' in op_tags:
                    result_df_name = op_tags.get("result_dataframe")
                
                

                if op_class == 'create_dataframe':
                    #block for creating a dataframe
                    result_df = spark.create_dataframe(**op_tags)
                    if result_df:
                        stat = self.add_dataframe(result_df_name,result_df)
                        if not stat:
                            log.warn("Unable to persist dataframe <{}>".format(result_df_name))
                            return False                        
                elif df_name in self.dataframes:
                    inp_df = self.dataframes.get(df_name)
                    if op_class == 'override_columns':
                        result_df,error = func.override_columns(inp_df,self.d_override_dfs,**op_tags)
                        if error:
                            log.error(error)
                            return False
                        if result_df:
                            stat = self.add_dataframe(result_df_name,result_df)
                            if stat:
                                return True
                            else:
                                log.warn("Unable to persist dataframe <{}>".format(result_df_name))
                                return False
                    elif op_class == 'create_hive_table':
                        status,error = func.create_hive_table(spark,inp_df,**op_tags)
                        if error:
                            log.error(error)
                            return False
                        if not status:
                            log.error("Create hive table operation was unsuccessful")
                            return False
                    elif op_class == 'write_file':
                        status,error = func.write_file(spark,inp_df,**op_tags)
                        if error:
                            log.error(error)
                            return False
                        if not status:
                            log.error('Operation write file was unsuccessful.')
                            return False
                    elif op_class == 'write_redshift_ddl':
                        status,error = func.write_redshift_ddl(spark,inp_df,**op_tags)
                        if error:
                            log.error(error)
                            return False
                        if not status:
                            log.error('Operation write file was unsuccessful.')
                            return False       
                    elif op_class == 'join_dataset':
                        inp_df = self.dataframes.get(df_name)
                        join_df_name = op_tags.get('join_dataframe_name')
                        
                        if join_df_name in self.dataframes:
                            join_df = self.dataframes.get(join_df_name)
                            result_df,error = func.join_dataset(inp_df,join_df,**op_tags)
                            if error:
                                log.error(error)
                                return False
                            if result_df:
                                stat = self.add_dataframe(result_df_name,result_df)
                                if stat:
                                    return True
                                else:
                                    log.warn("Unable to persist dataframe <{}>".format(result_df_name))
                                    return False
                        else:
                            log.warn("Dataframe: {} was not found in created dataframes.".format(join_df_name))
                            return False
                    elif op_class in avl_funcs:
                        df_function = getattr(func,op_class)
                        inp_df = self.dataframes.get(df_name)
#                         inp_df = inp_df.transform(lambda df:df_function(df,**op_tags))
                        result_df,error = df_function(inp_df,**op_tags)
                        if error:
                            log.error(error)
                            return False
                        if result_df:
                            stat = self.add_dataframe(result_df_name,result_df)
                            
                            if stat:
                                return True
                            else:
                                log.warn("Unable to persist dataframe <{}>".format(result_df_name))
                                return False
                    else:
                        e = errorify(error_code="INVALID_OP_CLASS",error_message="Operation class <{}> is invalid.".format(op_class))
                        #log error as operation class is invalid
                        log.error(e)
                        return False
                    
                else:
                    e = errorify(error_code="INVALID_DATAFRAME",
                                 error_message="Input dataframe <{}> has not been created before invocation".format(df_name))
                    log.error(e)
                    # log error as input dataframe has not been initialised for a dataframe operation
                    return False
                log.warn('Completed operation {},{}'.format(op_id,op_class))
                return True
            else:
                e = errorify(error_code="INVALID_OP_TYPE",
                             error_message=" Operation type <{}> is invalid/undefined.".format(op_type))
                log.error(e)
                return False
            
        except:
            e = get_exception()
            log.error(e)
            return False
    
    def run(self):
        status = self.run_operations()
        if not status:
            log.error("Application run has ended with errors")
            return False
        else:
            log.warn("All steps have been executed successfully")
            return True
# if __name__  == '__main__':
#     job_op_cfg = r"D:/Users/KONDAG/git/gpdip-spark/src/app/configs/job_cfg.csv"
#     op_cfg = r"D:/Users/KONDAG/git/gpdip-spark/src/app/configs/op_cfg.csv"
#     e = Entity("101","file:///{}".format(job_op_cfg),"file:///{}".format(op_cfg),"csv")
#     e.run()