Select
   Study_Number_Cal,
   INDICATION_PREFERRED_TERM,
   COMMERCIAL_BU,
   CASE
      WHEN
         DER_BU_RU IS NULL 
         AND STUDY_ZONE = 'GLOBAL RESEARCH'
         AND STUDY_UNIT = 'NEURO' 
      THEN
         'BTx Research' 
      ELSE
         DER_BU_RU 
   END
   AS COMMERCIAL_BU_RU 
FROM
   (
      Select
         CV_STUDY_DATA_TMP.Study_Number_Cal,
         CV_STUDY_DATA_TMP.STUDY_ZONE,
         CV_STUDY_DATA_TMP.STUDY_UNIT,
         CASE
            WHEN
               UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE) = 'VACCINE RESEARCH' 
               OR UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE) = 'VACCINES' 
            then
               'Vaccines'           --1.
            WHEN
               UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE) = 'BIOSIMILARS' 
               OR UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE) = 'BRDU' 
            then
               'Biosimilars'          --2
            WHEN
               UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE) = 'CONSUMER HEALTHCARE' 
               OR UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE) = 'PCH' 
            then
               'Consumer Healthcare' 
            WHEN
               CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_DIVISION = 'WRD' 
            THEN
               CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE 
            WHEN
               UPPER (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_DIVISION) = 'PIH' 
            then
               'GPD' 
            WHEN
               UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'VACCINE RESEARCH' 
               OR UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'VACCINES' 
            then
               'Vaccines'           --1.
            WHEN
               UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'BIOSIMILARS' 
               OR UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'BRDU' 
            then
               'Biosimilars'          --2
            WHEN
               UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'CONSUMER HEALTHCARE' 
               OR UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'PCH' 
            then
               'Consumer Healthcare' 
            WHEN
               CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_DIVISION = 'WRD' 
            THEN
               PRODUCTGROUP_ZONE 
            WHEN
               UPPER (CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE) = 'PIH' 
            then
               'GPD' 
            ELSE
               NVL(CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_DIVISION, CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_DIVISION) 
         END
         as DER_BU_RU, 
         CASE
            WHEN
               NVL ( NVL (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE, CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE), CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_DIVISION) IS NULL 
               AND CV_STUDY_DATA_TMP.STUDY_ZONE = 'GLOBAL RESEARCH' 
               AND CV_STUDY_DATA_TMP.STUDY_UNIT = 'NEURO' 
            THEN
               'WRD' 
            ELSE
               NVL ( NVL (CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_ZONE, CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_ZONE), CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_DIVISION) 
         END
         AS COMMERCIAL_BU 
      FROM
         CV_STUDY_DATA_TMP 
         Left Outer Join
            CV_CANDIDATE_PORTFOLIO_TMP 
            on CV_STUDY_DATA_TMP.CANDIDATE_CODE = CV_CANDIDATE_PORTFOLIO_TMP.CANDIDATE_CODE 
         Left Outer Join
            CV_PRODUCT_GROUP_TMP 
            on CV_STUDY_DATA_TMP.CANDIDATE_CODE = CV_PRODUCT_GROUP_TMP.PRODUCTGROUP_Code 
   )
   STUDY_DER_Q1 
   left join
      (
         Select
            Study_Id,
            concat_ws(',',collect_list(IND_PREFERRED_TERM)) INDICATION_PREFERRED_TERM 
         From
            PODS_ODS_STUDY_INDICATION_V_TMP 
         WHERE
            PODS_ODS_STUDY_INDICATION_V_TMP.DELETE_FLAG = 'N' 
         GROUP BY
            PODS_ODS_STUDY_INDICATION_V_TMP.STUDY_ID 
      )
      STUDY_DER 
      on STUDY_DER_Q1.Study_Number_Cal = STUDY_DER.Study_Id