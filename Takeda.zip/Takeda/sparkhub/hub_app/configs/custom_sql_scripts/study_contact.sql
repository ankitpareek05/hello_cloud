select t1.study_id, t1.Person_full_names as S_RCSL,
t7.Person_full_names as CLINICIAN, 
t2.Person_full_names as CLINICAL_PROJECT_MANAGER, 
t3.Person_full_names as RT2_CPM_PARTNER,
t4.Person_full_names as STUDY_TEAM_LEAD,
t5.Person_full_names as PROGRAM_LEAD,
t6.Person_full_names as STUDY_PROJECT_PLANNER,
t8.CDO_TA_LEAD as CDO_TA_LEAD,
t8.CLIN_OPS_GROUP_LEAD as CLIN_OPS_GROUP_LEAD,
t8.SM_GROUP_LEAD as SM_GROUP_LEAD  from 
((
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id
from STUDY_CONTACT_PERSON_TMP 
where contact_role = 'S-RCSL-STUDY REGIONAL CLINICAL SITE LEAD' 
AND PODS_STUDY_PERSON_V_contact_role = 'S-RCSL-STUDY REGIONAL CLINICAL SITE LEAD' group by study_id) t1
left join (
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id
from STUDY_CONTACT_PERSON_TMP 
where contact_role = 'CLINICAL PROJECT MANAGER' 
AND PODS_STUDY_PERSON_V_contact_role = 'CLINICAL PROJECT MANAGER' group by study_id) t2 on t1.study_id = t2.study_id
left join (
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id
from STUDY_CONTACT_PERSON_TMP 
where  (   contact_role =
'PAREXEL PROJECT LEADER' OR contact_role = 'ICON PROJECT MANAGER') AND  (   PODS_STUDY_PERSON_V_contact_role = 'PAREXEL PROJECT LEADER' 
OR PODS_STUDY_PERSON_V_contact_role = 'ICON PROJECT MANAGER') group by study_id) t3 on t2.study_id = t3.study_id
left join (
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id
from STUDY_CONTACT_PERSON_TMP
where contact_role like '%COSTL%'
AND PODS_STUDY_PERSON_V_contact_role like '%COSTL%' group by study_id) t4 on t3.study_id = t4.study_id
left join (
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id 
from STUDY_CONTACT_PERSON_TMP 
where contact_role like '%COPL%'
AND PODS_STUDY_PERSON_V_contact_role like '%COPL%' group by study_id) t5 on t4.study_id = t5.study_id
left join (
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id
from STUDY_CONTACT_PERSON_TMP 
where PODS_STUDY_PERSON_V_contact_role = 'STUDY PLANNER' group by study_id) t6 on t5.study_id = t6.study_id
left join (
select concat_ws(';', collect_list(Person_full_name)) as person_full_names,Study_Id
from STUDY_CONTACT_PERSON_TMP 
where PODS_STUDY_PERSON_V_contact_role = 'LEAD CLINICIAN' group by study_id) t7 on t7.study_id = t6.study_id
left join (
select concat_ws(';', collect_list(CDO_TA_LEAD)) as CDO_TA_LEAD,
concat_ws(';', collect_list(CLIN_OPS_GROUP_LEAD)) as CLIN_OPS_GROUP_LEAD,
concat_ws(';', collect_list(SM_GROUP_LEAD)) as SM_GROUP_LEAD,
id
from T_STUDY_MGMT_ROLES_TMP group by id) t8 on t7.study_id = t8.id
)