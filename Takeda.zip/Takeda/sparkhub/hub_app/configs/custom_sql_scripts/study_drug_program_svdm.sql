select
S.*,
   TRIM(NVL(PRODUCTGROUP_NAME,COMPOUND_NAME)) AS PRODUCT_DER,
   CASE
      WHEN
        CANDIDATE_ZONE IN 
         (
            'BRDU',
            'Biosimilars' 
         )
      THEN
         'Biosimilars'
      ELSE
         COMPOUND_TYPE_BINNED
   END
   AS COMPOUND_TYPE_DER, 
   CASE
      when
         CV_COMP_COMPOUND_MECHANISM_OF_ACTION is Null 
      then
         TRIM(COMPOUND_MECHANISM_OF_ACTION)
      Else
         TRIM(CV_COMP_COMPOUND_MECHANISM_OF_ACTION)
   END
   as MECHANISM_OF_ACTION, 
   CASE
      when
         TRIM(PRODUCTGROUP_NAME) is Null 
      then
(
         CASE
                  
            WHEN
               TRIM(CANDIDATE_SHORT_DESC) is Null               
            THEN
               TRIM(COMPOUND_NAME)               
            ELSE
               TRIM(CANDIDATE_SHORT_DESC)            
         END
) 
         Else
            TRIM(PRODUCTGROUP_NAME) 
   END
   as ASSET 
from
STUDY_DRUG_PROGRAM_ENTITY_TMP S