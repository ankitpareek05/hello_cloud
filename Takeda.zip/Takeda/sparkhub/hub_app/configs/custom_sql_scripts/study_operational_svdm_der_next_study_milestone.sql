SELECT STUDY_MILESTONE_PVT.STUDY_ID,
CASE WHEN MAX_DATE.NEXT_MILESTONE_DATE <> cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
THEN
	CASE 
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.FAP_PLANNED_DATE THEN 'FAP'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.FSFV_PLANNED_DATE THEN 'FSFV'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.LSFV_PLANNED_DATE THEN 'LSFV'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.PCD_PLANNED_DATE THEN 'PCD'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.DBR_PLANNED_DATE THEN 'DBR'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.CSR_MIN_DATE THEN 'CSR_MIN'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.LSLV_SUPPLEMENTAL_PLANNED_DATE THEN 'SUPP_LSLV'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.DBR_SUPPLEMENTAL_PLANNED_DATE THEN 'SUPP_DBR'
	WHEN MAX_DATE.NEXT_MILESTONE_DATE = STUDY_MILESTONE_PVT.CSR_SUPPLEMENTAL_PLANNED_DATE THEN 'SUPP_CSR'
	END
ELSE NULL
END AS DER_NEXT_STUDY_MILESTONE,
CASE WHEN MAX_DATE.NEXT_MILESTONE_DATE == from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))
THEN NULL
ELSE MAX_DATE.NEXT_MILESTONE_DATE
END AS DER_NEXT_STUDY_MILESTONE_DATE 
FROM STUDY_MILESTONE_PVT INNER JOIN (SELECT STUDY_MILESTONE_PVT.STUDY_ID,
LEAST (
      CASE WHEN FAP_PLANNED_DATE > MAX_ACTUAL_DATE and FAP_ACTUAL_DATE is null
         THEN COALESCE(FAP_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN FSFV_PLANNED_DATE > MAX_ACTUAL_DATE and FSFV_ACTUAL_DATE is null
         THEN COALESCE(FSFV_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN LSFV_PLANNED_DATE > MAX_ACTUAL_DATE and LSFV_ACTUAL_DATE is null
         THEN COALESCE(LSFV_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN PCD_PLANNED_DATE > MAX_ACTUAL_DATE and PCD_ACTUAL_DATE is null
         THEN COALESCE(PCD_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN DBR_PLANNED_DATE > MAX_ACTUAL_DATE and DBR_ACTUAL_DATE is null
         THEN COALESCE(DBR_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN LSLV_SUPPLEMENTAL_PLANNED_DATE > MAX_ACTUAL_DATE and LSLV_SUPPLEMENTAL_ACTUAL_DATE is null
         THEN COALESCE(LSLV_SUPPLEMENTAL_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN DBR_SUPPLEMENTAL_PLANNED_DATE > MAX_ACTUAL_DATE and DBR_SUPPLEMENTAL_ACTUAL_DATE is null
         THEN COALESCE(DBR_SUPPLEMENTAL_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END,
      CASE
         WHEN CSR_SUPPLEMENTAL_PLANNED_DATE > MAX_ACTUAL_DATE and CSR_SUPPLEMENTAL_ACTUAL_DATE is null
         THEN COALESCE(CSR_SUPPLEMENTAL_PLANNED_DATE,cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date))
         ELSE cast(to_date(from_unixtime(unix_timestamp('01-01-5012' , 'dd-MM-yyyy'))) as date)
      END)
    AS NEXT_MILESTONE_DATE
    FROM STUDY_MILESTONE_PVT INNER JOIN 
    (Select COALESCE(GREATEST(FAP_ACTUAL_DATE,FSFV_ACTUAL_DATE, LSFV_ACTUAL_DATE,PCD_ACTUAL_DATE,DBR_ACTUAL_DATE, LSLV_SUPPLEMENTAL_ACTUAL_DATE,DBR_SUPPLEMENTAL_ACTUAL_DATE, CSR_MIN_DATE,CSR_MAX_DATE),cast(to_date(from_unixtime(unix_timestamp('01-01-1400' , 'dd-MM-yyyy'))) as date)) as MAX_ACTUAL_DATE,STUDY_ID from STUDY_MILESTONE_PVT)MAXIMIUM 
    ON STUDY_MILESTONE_PVT.STUDY_ID = MAXIMIUM.STUDY_ID)MAX_DATE ON STUDY_MILESTONE_PVT.STUDY_ID = MAX_DATE.STUDY_ID