with gd as 
(
   select
      id,
      goal,
      goal_status,
      year,
      psi_tracked_asset,
      row_number() over (partition by id 
   order by
      case
         when
            goal = 'FIH' 
         then
            1 
         when
            GOAL = 'POM' 
         then
            2 
         when
            GOAL = 'ESS' 
         then
            3 
         when
            GOAL = 'ESOE' 
         then
            4 
         when
            GOAL = 'SOCA' 
         then
            5 
         when
            GOAL = 'PSS' 
         then
            6 
         when
            GOAL = 'POC' 
         then
            7 
         when
            GOAL = 'PHASE 3' 
         then
            8 
         else
            9 
      END
) as rnk_order 
   from
      T_STUDY_VOLUME_GOAL_TRACK_LKP_TMP 
   order by
      rnk_order 
)
, con as 
(
   select
      concat_ws(';', collect_list(psi_tracked_asset)) as psi,
      concat_ws(';', collect_list(major_ongoing_study_flag)) as mos,
      id 
   from
      T_STUDY_VOLUME_GOAL_TRACK_LKP_TMP 
   group by
      id 
)
select distinct
   GY_GS.*,
   PSI_ASSET.PSI_TRACKED_ASSET,
   GOAL_DETAIL.GOAL_DETAIL,
   CASE
      WHEN
         (
            UPPER (GOAL_MAIN.PSI_TRACKED_ASSET) 
         )
         LIKE '%HISTORICAL%' 
      THEN
         'Yes PSI Historical' 
      ELSE
         NULL 
   END
   AS PSI_HISTORICAL_FLAG, PHASE3_POM.PHASE3_GS, PHASE3_POM.PHASE3_GY, PHASE3_POM.POM_GY, PHASE3_POM.POM_GS, OPCO_DATE.OPCO_AGMT_MIN_DT, OPCO_DATE.OPCO_AGMT_MAX_DT 
from
   T_STUDY_VOLUME_GOAL_TRACK_LKP_TMP GOAL_MAIN 
   left join
      (
         SELECT
            ID,
            NVL (regexp_replace (regexp_replace ( concat_ws(',', collect_list (TRIM (CONCAT( 
            CASE
               WHEN
                  UPPER (GOAL_STATUS) LIKE 'ACHIEVED' 
               THEN
                  CONCAT( 
                  CASE
                     WHEN
                        regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') LIKE '%US/EU' 
                     THEN
                        regexp_replace (regexp_replace (GOAL, 'Submission - US/EU', concat(CONCAT ('Sub EU ', YEAR), ' (A)~Sub US')), 'Phase 3', 'P3') 
                     ELSE
                        regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') 
                  END
, ' ', YEAR, ' ', '(A)') 
                  ELSE
                     CONCAT( 
                     CASE
                        WHEN
                           regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') LIKE '%US/EU' 
                        THEN
                           regexp_replace (regexp_replace (GOAL, 'Submission - US/EU', CONCAT( CONCAT ('Sub EU ', YEAR), '~ Sub US')), 'Phase 3', 'P3') 
                        ELSE
                           regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') 
                     END
, ' ', YEAR) 
            END
) ))), ';', ','), '~', ','), 'NA') AS GOAL_DETAIL 
         FROM
            gd 
         group by
            id 
      )
      GOAL_DETAIL 
      on GOAL_DETAIL.ID = GOAL_MAIN.ID 
   left join
      (
         SELECT
            sa.ID,
            CASE
               WHEN
                  UPPER(psi) LIKE '%PSI CURRENT%' 
               THEN
                  'PSI Current' 
               WHEN
                  UPPER(mos) LIKE '%MAJOR ONGOING STUDY%' 
               THEN
                  'Major Ongoing Study' 
               ELSE
                  SUBSTR(psi, 0, INSTR(psi, ';') - 1) 
            END
            AS PSI_TRACKED_ASSET 
         FROM
            T_STUDY_VOLUME_GOAL_TRACK_LKP_TMP Sa 
            left outer join
               con c 
               on sa.id = c.id 
         where
            (
               UPPER(psi) NOT LIKE '%HISTORICAL%' 
               OR PSI_TRACKED_ASSET IS NULL 
            )
      )
      PSI_ASSET 
      on PSI_ASSET.ID = GOAL_MAIN.ID 
   left join
      (
         select distinct
            ID,
            PHASE3_GS,
            PHASE3_GY,
            POM_GY,
            POM_GS 
         from
            (
               select
                  Sa.ID,
                  Sa.Binned_Goal,
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'PHASE 3' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS PHASE3_GS, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'PHASE 3' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS PHASE3_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'POM' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS POM_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'POM' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS POM_GS 
               from
                  T_STUDY_VOLUME_GOAL_TRACK_LKP_TMP Sa 
            )
      )
      PHASE3_POM 
      on PHASE3_POM.id = GOAL_MAIN.ID 
   left join
      (
         select
            ID,
            MIN (FIH_GY) FIH_GY,
            MIN (FIH_GS) FIH_GS,
            MIN (PSS_GY) PSS_GY,
            MIN (PSS_GS) PSS_GS,
            MIN (POS_GY) POS_GY,
            MIN(POS_GS) POS_GS,
            MIN (ESS_GY) ESS_GY,
            MIN (ESS_GS) ESS_GS,
            MIN (ESOE_GY) ESOE_GY,
            MIN (ESOE_GS) ESOE_GS,
            MIN (SOCA_GY) SOCA_GY,
            MIN (SOCA_GS) SOCA_GS 
         from
            (
               select
                  Sa.ID,
                  Sa.Binned_Goal,
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'FIH' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS FIH_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'FIH' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS FIH_GS, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'PSS' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS PSS_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'PSS' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS PSS_GS, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'POS' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS POS_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'POC' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS POS_GS, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'ESS' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS ESS_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'ESS' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS ESS_GS, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'ESOE' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS ESOE_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'ESOE' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS ESOE_GS, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'SOCA' 
                     THEN
                        Sa.YEAR 
                     ELSE
                        NULL 
                  END
                  AS SOCA_GY, 
                  CASE
                     WHEN
                        UPPER (Sa.BINNED_GOAL) = 'SOCA' 
                     THEN
                        Sa.GOAL_STATUS 
                     ELSE
                        NULL 
                  END
                  AS SOCA_GS 
               from
                  T_STUDY_VOLUME_GOAL_TRACK_LKP_TMP Sa 
            )
         GROUP BY
            ID 
      )
      GY_GS 
      on GOAL_MAIN.ID = GY_GS.ID 
   left join
      (
         SELECT
            MIN (OPCO_LOCK_AGREEMENT_DATE) OPCO_AGMT_MIN_DT,
            MAX (OPCO_LOCK_AGREEMENT_DATE) OPCO_AGMT_MAX_DT,
            ID 
         FROM
            T_STUDY_VOLUME_OPCO_LKP_TMP 
         WHERE
            OPCO_LOCK_AGREEMENT_DATE IS NOT NULL 
         GROUP BY
            ID 
      )
      OPCO_DATE 
      on GOAL_MAIN.ID = OPCO_DATE.ID