with gd as 
(
   select
      Study_ID,
      goal,
      goal_status,
      goal_year,
      
      row_number() over (partition by Study_ID 
   order by
      case
         when
            goal = 'FIH' 
         then
            1 
         when
            GOAL = 'POM' 
         then
            2 
         when
            GOAL = 'ESS' 
         then
            3 
         when
            GOAL = 'ESOE' 
         then
            4 
         when
            GOAL = 'SOCA' 
         then
            5 
         when
            GOAL = 'PSS' 
         then
            6 
         when
            GOAL = 'POC' 
         then
            7 
         when
            GOAL = 'PHASE 3' 
         then
            8 
         else
            9 
      END
) as rnk_order 
   from
      STUDY_GOAL 
   order by
      rnk_order 
)
, con as 
(
   select
      concat_ws(';', collect_list(psi_tracked_asset)) as psi,
      concat_ws(';', collect_list(MAJOR_ONGOING_STUDIES)) as mos,
      study_id 
   from
      STUDY_GOAL 
   group by
      study_id 
)

Select 
B.*,
X.GOAL_DETAIL_LIST,Z.PSI_TRACKED_ASSET,CASE WHEN H.PSI_TRACKED_ASSET IS NOT NULL THEN 'Yes PSI Historical' ELSE NULL   END AS PSI_HISTORICAL_FLAG
from STUDY_GOAL_PIVOT B
LEFT JOIN 
(
 SELECT DISTINCT STUDY_ID,PSI_TRACKED_ASSET FROM STUDY_GOAL WHERE  UPPER (PSI_TRACKED_ASSET) LIKE '%HISTORICAL%' 
			
)H ON H.STUDY_ID=B.STUDY_ID
LEFT JOIN
(
SELECT
            Study_ID,
            NVL (regexp_replace (regexp_replace ( concat_ws(',', collect_list (TRIM (CONCAT( 
            CASE
               WHEN
                  UPPER (GOAL_STATUS) LIKE 'ACHIEVED' 
               THEN
                  CONCAT( 
                  CASE
                     WHEN
                        regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') LIKE '%US/EU' 
                     THEN
                        regexp_replace (regexp_replace (GOAL, 'Submission - US/EU', concat(CONCAT ('Sub EU ', GOAL_YEAR), ' (A)~Sub US')), 'Phase 3', 'P3') 
                     ELSE
                        regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') 
                  END
, ' ', GOAL_YEAR, ' ', '(A)') 
                  ELSE
                     CONCAT( 
                     CASE
                        WHEN
                           regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') LIKE '%US/EU' 
                        THEN
                           regexp_replace (regexp_replace (GOAL, 'Submission - US/EU', CONCAT( CONCAT ('Sub EU ', GOAL_YEAR), '~ Sub US')), 'Phase 3', 'P3') 
                        ELSE
                           regexp_replace (regexp_replace (GOAL, 'Submission -', 'Sub'), 'Phase 3', 'P3') 
                     END
, ' ', GOAL_YEAR) 
            END
) ))), ';', ','), '~', ','), 'NA') AS GOAL_DETAIL_LIST
         FROM gd group by Study_ID 
)X ON B.STUDY_ID = X.STUDY_ID	
left join
      (
	  
	  Select distinct STUDY_ID,PSI_TRACKED_ASSET FROM
	  (
         SELECT
            Sa.STUDY_ID,
            CASE
         WHEN mos IS NOT NULL
         THEN
            CASE
               WHEN UPPER (psi) LIKE '%PSI CURRENT%'
               THEN
                  'PSI Current'
               WHEN (UPPER (mos) LIKE '%MAJOR ONGOING STUDY%' AND UPPER (TRIM (psi)) NOT LIKE ('%PSI CURRENT%')) OR TRIM (psi) IS NULL
               THEN
                  'Major Ongoing Study'
            END
         WHEN mos IS NULL
         THEN
            CASE
               WHEN UPPER (psi) LIKE '%PSI CURRENT%'
               THEN
                  'PSI Current'
               WHEN UPPER (psi) LIKE '%MAJOR ONGOING STUDY%'AND UPPER (psi) NOT LIKE '%PSI CURRENT%'
               THEN
                  'Major Ongoing Study'
               ELSE
                  SUBSTR(psi,0,INSTR(psi, ';') - 1)
            END
      END
            AS PSI_TRACKED_ASSET 
         FROM
            STUDY_GOAL Sa 
            left outer join
               con c 
               on sa.study_id = c.study_id 
         where
            (
               UPPER(PSI_TRACKED_ASSET) NOT LIKE '%HISTORICAL%' 
               OR PSI_TRACKED_ASSET IS NULL 
            )
			
      )
	)  
      Z on Z.STUDY_ID = B.STUDY_ID