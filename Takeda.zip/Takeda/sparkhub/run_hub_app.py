import argparse, re
import hub_config as cc
from subprocess import Popen, PIPE
import sys, linecache,os
import uuid, time

main_parser = argparse.ArgumentParser(description="SparkHub Application")

main_parser.add_argument('--app_name',action="store",dest="app_name",default="sparkhub",help="name of the spark application.")
main_parser.add_argument('--master', action="store", dest="master", default=cc.spark_master, help="is one of local,yarn")
main_parser.add_argument('--deploy_mode', action ="store", dest="deploy_mode", default=cc.spark_deploy_mode,help="is one of client,cluster")
main_parser.add_argument('--executor_memory', action="store", dest="executor_memory", default=cc.spark_executor_memory, help="memory utilized by each executor, default is '4G'")
main_parser.add_argument('--executor_cores', action="store", dest="executor_cores", default=cc.spark_executor_cores, help="core cpus utilized for each executor")
main_parser.add_argument('--num_executors', action="store", dest="num_executors", default= cc.spark_num_executors, help="number of executors, default is 6")
main_parser.add_argument('--conf', action = "store", dest = "conf", default = cc.spark_conf,help="additional spark configurations")
main_parser.add_argument('--app_path', action = "store", dest = "app_path", default = cc.app_path,help="additional spark configurations")
main_parser.add_argument('--app_archive', action="store", dest="app_archive", default=cc.app_archive, help = "egg or zip of the pyspark application")
main_parser.add_argument('--application_file',action="store",dest="application_file",default=cc.application_file, help="name of the application file")
#metavar="N", nargs="+",
main_parser.add_argument('--job_id', action="store",dest="job_id", default=None,required=True, help="job_id of the job for which the pyspark code will run")
main_parser.add_argument('--job_run_id', action="store",dest="job_run_id", default=None, help="job_run_id of the job for which the pyspark code will run")
main_parser.add_argument('--wait', action="store_true", default=cc.wait_for_completion, help ="wait for completion of all subprocesses")
main_parser.add_argument('--job_config', action="store",dest="job_config", default=cc.job_config, help="Job Config file")
main_parser.add_argument('--op_config', action="store",dest="op_config", default=cc.op_config, help="Op Config file")
main_parser.add_argument('--config_file_format', action="store",dest="config_file_format", default=cc.config_file_format, help="Config File Format (csv, json etc..)")
main_parser.add_argument('--debug_mode','-d',action="store_true",default=False, help="run application in debug mode")
main_parser.add_argument('--debug_rows',action="store",default=cc.debug_rows, type=int, help="Number of rows to show from dataframe in debug mode.")
main_parser.add_argument('--override_file', action="store",dest="override_file", default=cc.override_file, help="Override File")
main_parser.add_argument('--log_path',action="store",dest="log_path",default=cc.log_path,help="log path for the application logs.")
main_parser.add_argument('--application_id_path',action="store",dest="application_id_path",default=cc.application_id_path,help="application_id path on hdfs or s3 to store the spark application id.")



def get_exception(debug=True):
    exc_type, exc_obj, tb = sys.exc_info()
    f = tb.tb_frame
    lineno = tb.tb_lineno
    filename = f.f_code.co_filename
    linecache.checkcache(filename)
    line = linecache.getline(filename, lineno, f.f_globals)
    err_obj = {
        'error_code':str(exc_type),
        'error_message':str(exc_obj)
    }
    if debug:
        err_obj['error_at']='EXCEPTION IN ({},LINE {} "{}")'.format(filename,lineno,line.strip())
    return err_obj

def main():
    try:
        args = main_parser.parse_args()
        if not args.job_run_id:
            args.job_run_id = uuid.uuid4().hex
        current_path = os.path.dirname(__file__)
        if args.app_path == '':
            args.app_path = current_path
        debug_mode = ''
        if args.debug_mode:
            debug_mode = '--debug_mode'
        
        
            
        application_args = """ --job_id {job_id}
                               --job_run_id {job_run_id}
                               --job_config {job_config}
                               --op_config {op_config}
                               --config_file_format {config_file_format} 
                               --debug_rows {debug_rows}
                               --override_file {override_file}
                               --application_id_path {application_id_path}
                        """.format(job_id = args.job_id,
                                   job_run_id = args.job_run_id,
                                   job_config = args.job_config,
                                   op_config = args.op_config,
                                   config_file_format = args.config_file_format,
                                   debug_mode = args.debug_mode,
                                   debug_rows = args.debug_rows,
                                   override_file = args.override_file,
                                   application_id_path = args.application_id_path
                                   
                                   )
        cmd = """
            {spark_path}/spark-submit --name {app_name} --master {spark_master} --deploy-mode {spark_deploy_mode}
            --executor-memory {spark_executor_memory} 
            --py-files {app_archive}
            {application_file} {application_args} {debug_mode}
            
        """.format(spark_path = cc.spark_path,
                   app_name = args.app_name,
                   spark_master = args.master,
                   spark_deploy_mode = args.deploy_mode,
                   spark_executor_memory = args.executor_memory,
                   app_archive = os.path.join(args.app_path, args.app_archive),
                   application_file = os.path.join(args.app_path,args.application_file),
                   application_args = application_args,
                   debug_mode = debug_mode
                   
                   )
        cwd = '.'
        cmd = cmd.strip()
        exitcode = None
        cmd_args = re.split('[\r\n\t ]+', cmd)
        print(cmd_args)
        proc = Popen(cmd_args, stdout=PIPE, stderr=PIPE)
        std_op,std_err = proc.communicate()
        if args.wait:
            time.sleep(10)
            exitcode = proc.wait()
#         exitcode = proc.returncode
        std_op = std_op.decode('utf-8')
        std_err = std_err.decode('utf-8')
        print('Exitcode: {}'.format(str(exitcode))) 
        print(std_op)
        print('&*******************************************************>')
        print(std_err)
    #     cmd_output = subprocess.call(cmd, shell=True, stderr=subprocess.PIPE)
    #     cmd_output = cmd_output.stderr.decode("utf-8")
        
        yarn_application_id = None
        yarn_application_ids = re.findall(r"application_\d{13}_\d{4}", std_err)
        if len(yarn_application_ids):
            yarn_application_id = yarn_application_ids[0]
            
        else:
            app_id_path = args.application_id_path+'/'+args.job_run_id+'/application_id'
            print(app_id_path)
            cat = Popen(["hadoop","fs","-cat",app_id_path],stdout=PIPE,stderr=PIPE)
            cat_out,cat_err = cat.communicate()
            print(cat_out)
            print(cat_err)
            yarn_application_ids = re.findall(r"application_\d{13}_\d{4}", cat_out)
            if len(yarn_application_ids):
                yarn_application_id = yarn_application_ids[0]
        if yarn_application_id:
            yarn_log_command = "yarn logs -applicationId " + yarn_application_id
            print(yarn_log_command)
            yarn_log_args = ["yarn","logs","-applicationId",yarn_application_id]
            yarn_status_args = ["yarn","application",'-status',yarn_application_id]
            if args.wait and args.deploy_mode == 'cluster' and args.master == 'yarn':
                proc_complete = False
                while not proc_complete:
                    yarn_cmd = Popen(yarn_status_args,stdout=PIPE, stderr=PIPE)
                    yarn_out,yarn_err = yarn_cmd.communicate()
                    if yarn_err:
                        print('Unable to determine yarn status for application_id: {}'.format(yarn_application_id))
                        print(yarn_err)
                        proc_complete = True
                    if not yarn_out:
                        print('Unable to determine yarn status for application_id: {}'.format(yarn_application_id))
                        proc_complete = True
                        
                    l_proc_status = re.findall(r'State : [A-Za-z]+',yarn_out)
                    if len(proc_status):
                      proc_status = l_proc_status[0]
                      proc_status = str(proc_status).replace('State : ','').strip().upper()
#                       print ('process status : {}'.format(proc_status))
                      if not proc_status in ['RUNNING','STARTING']:
                            proc_complete = True
                
                if args.debug_mode:
                    yarn_cmd = Popen(yarn_log_args,stdout=PIPE, stderr=PIPE)
                    yarn_out,yarn_err = yarn_cmd.communicate()
                    print(yarn_out)
    except:
        e = get_exception()
        print(e)

if __name__ == '__main__':
    main()