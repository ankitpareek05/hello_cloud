from hub_app import *
import hub_config as cc
import argparse

hub_parser = argparse.ArgumentParser(description="Hub App")
hub_parser.add_argument('--job_id',help='job_id of the job to run', required=True)
hub_parser.add_argument('--job_run_id',help='job_run_id from an external system for tracking purposes')
hub_parser.add_argument('--job_config', default=cc.job_config)
hub_parser.add_argument('--op_config', default = cc.op_config)
hub_parser.add_argument('--config_file_format',default=cc.config_file_format)

hub_parser.add_argument('--debug_mode',action="store_true",default=False)
hub_parser.add_argument('--debug_rows',type=int ,default=cc.debug_rows)
hub_parser.add_argument('--override_file',default=cc.override_file)
hub_parser.add_argument('--application_id_path',default=cc.application_id_path)

def main():
    
    args = hub_parser.parse_args()
    op_tags = {"job_id":args.job_id,
               "job_run_id":args.job_run_id,
               "job_config":args.job_config,
               "op_config":args.op_config,
               "config_file_format":args.config_file_format,
               "debug_mode":args.debug_mode,
               "num_debug_rows":args.debug_rows,
               "override_file":args.override_file,
               "application_id_path":args.application_id_path
               }
    e = Entity(**op_tags)
    e.run()
    

if __name__ == '__main__':
    main()