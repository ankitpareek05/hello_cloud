from hub_app import *
import hub_config as cc
import argparse

hub_parser = argparse.ArgumentParser(description="Hub App")
hub_parser.add_argument('--job_id',help='job_id of the job to run', required=True)
hub_parser.add_argument('--job_config', default=cc.job_config)
hub_parser.add_argument('--op_config', default = cc.op_config)
hub_parser.add_argument('--config_file_format',default=cc.config_file_format)

hub_parser.add_argument('--debug_mode',action="store_true",default=False)
hub_parser.add_argument('--debug_rows',type=int ,default=cc.debug_rows)
hub_parser.add_argument('--override_file',default=cc.override_file)

def main(passed_args = None):
    args = None
    if passed_args:
        args = hub_parser.parse_args(passed_args.split())
        print(args)
    else:
        args = hub_parser.parse_args()
    op_tags = {"job_id":"v_110",
               "job_config": r"file:///D:/sparkhub_input/validation_job_cfg.csv",
               "op_config":r"file:///D:/sparkhub_input/validation_op_cfg.csv",
               "config_file_format":args.config_file_format,
               "debug_mode":args.debug_mode,
               "num_debug_rows":args.debug_rows,
               "override_file":None
               }
    e = Entity(**op_tags)
    e.run()
    

if __name__ == '__main__':
    job_config = r"file:///D:/sparkhub_input/validation_job_cfg.csv"
    op_config = r"file:///D:/sparkhub_input/validation_op_cfg.csv"
    job_id = 'v_110'
    passed_args = " --job_id {} --job_config '{}' --op_config '' --debug_mode".format(job_id,job_config,op_config)
    main(passed_args)