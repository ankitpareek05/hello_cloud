mkdir /tmp/sparkhub
chmod 777 /tmp/sparkhub
rm /tmp/sparkhub/*.py
cp build/* /tmp/sparkhub/
chmod -R 777 /tmp/sparkhub/*.py