
import os,shutil
from glob import glob


def get_validated_file_path(in_path):
    curr_dir = os.getcwd()
    if os.path.exists(in_path):
        return in_path
    elif os.path.exists(os.path.join(curr_dir,in_path)):
        return os.path.join(curr_dir,in_path)
    else:
        app_home = get_app_home()
        if app_home and os.path.exists(os.path.join(app_home, in_path)):
            return os.path.join(app_home, in_path)

        app_path = get_app_path()
        if app_path and os.path.exists(os.path.join(app_path,in_path)):
            return os.path.join(app_path,in_path)
    return None

def get_glob_files(in_dir,pattern):
    res = []
    for y in glob(os.path.join(in_dir,pattern)):
        if os.path.isdir(y):
            pass
        else:
            res.append(y)
    return res

def get_files(in_dir,recursive=False,patterns=['*.*'],exclude_patterns=[],validated=False):
    if not validated:
        in_dir = get_validated_file_path(in_dir)
    if not in_dir:
        return None

    file_list=[]
    exclude_list = []
    if recursive:
        for x in os.walk(in_dir):
            for pat in patterns:
                l_f = get_glob_files(x[0],pat)
                file_list += l_f
            for pat in exclude_patterns:
                l_f = get_glob_files(x[0],pat)    
                exclude_list+=l_f
            
    else:
        for pat in patterns:
            l_f = get_glob_files(in_dir,pat)
            file_list += l_f
            
        for pat in exclude_patterns:
                l_f = get_glob_files(in_dir,pat)    
                exclude_list+=l_f

    final_set = set(file_list)-set(exclude_list)            
    return list(final_set)


def make(build_path = None, app_path = None, app_module_name = 'hub_app', l_req_files = None, exclude_files = None):
    if not app_path:
        app_path = os.path.abspath(os.path.dirname(__file__))
        
    if not build_path:
        build_path = app_path+r'/build'
    
    if not l_req_files:
        l_req_files = ['*.py'] 
    if not exclude_files:
        exclude_files = ['*__init__*'] 
           
    app_dir = app_path+'/'+app_module_name
    app_zip = build_path + '/'+app_module_name
    
    if not os.path.exists(app_dir):
        print("Application Directory not found at :{} ".format(app_dir))
        return False
    
    if os.path.exists(build_path):
        print("Cleaning build path")
        shutil.rmtree(build_path)
        os.makedirs(build_path,0o777)
     
    if not os.path.exists(build_path):
        os.makedirs(build_path,0o777)
            
    print("App Path:{}\nModule_Dir:{}\nBuildPath:{}".format(app_path, app_dir,build_path))
    
    shutil.make_archive(app_zip, 'zip', app_path,app_module_name)
    l_files = get_files(app_path,patterns = l_req_files,exclude_patterns=exclude_files,validated=True)
    
    for f in l_files:
        fname = os.path.basename(f)
        shutil.copy(f,build_path+'/'+fname)
        
if __name__ == '__main__':
    make()