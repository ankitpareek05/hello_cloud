import pytest

from hub_app import *
import uuid
from pyspark.sql.types import *
from pyspark.sql.functions import regexp_extract
class TestDataframeFunctions:
    def __init__(self,l_file_names=[]):
        self.id =uuid.uuid4().hex
    
    
    def test_create_dataframe(self):
        pass
    
    def test_filter_rows(self):
        try:
            test_df = spark.createDataFrame(
                [   
                    ("Bob",10),
                    ("Jim",21),
                    ("Caroline",32)
                    ],
                StructType([
                    StructField("name",StringType(),True),
                    StructField("age", IntegerType(), True)
                    ])
                )
            expected_df = spark.createDataFrame(
                [
                    ("Jim",21),
                    ("Caroline",32)
                    ],
                StructType([
                    StructField("name",StringType(),True),
                    StructField("age", IntegerType(), True)
                    ])
                )
            op_tags = {"filter_clause":"age > 10"}
            actual_df,errors = func.filter_rows(test_df,**op_tags)
            if errors:
                log.error(errors)
                return False
            assert actual_df.collect() == expected_df.collect()
            return True

        except:
            e = get_exception()
            log.error(e)
            return False
        
    def test_join_dataset(self):
        try:
            res1 = res2 = False
            emp_df = spark.createDataFrame(
                [   
                    ("Bob",100),
                    ("Jim",2001),
                    ("Caroline",300)
                    ],
                StructType([
                    StructField("name",StringType(),True),
                    StructField("dept_id", IntegerType(), True)
                    ])
            )
            
            dept_df = spark.createDataFrame(
                [   
                    (100,"ACCOUNTING"),
                    (200,"IT"),
                    (300,"HR")
                    ],
                StructType([
                    StructField("dept_id",IntegerType(),True),
                    StructField("dept_name", StringType(), True)
                    ])
            )
            
            #testing for inner join
            expected_join_df = spark.createDataFrame(
                    [
                        
                        ("Bob","ACCOUNTING"),
                        ("Caroline","HR")
                        
                    ],
                    StructType(
                        [
                            StructField("name",StringType(),True),
                            StructField("dept_name",StringType(),True)
                        ]
                    )
                )
            
            op_tags = {
                "dataframe_keys":"dept_id",
                "join_dataframe_keys":"dept_id",
                "dataframe_columns":"name",
                "join_dataframe_columns":"dept_name",
                "join_type":"inner",
                "result_dataframe":"join_res"
            }
            actual_join_df,errors = func.join_dataset(emp_df,dept_df,**op_tags)
            
            
            assert expected_join_df.orderBy(["name"]).collect() == actual_join_df.orderBy(["name"]).collect()
            
            #testing for left outer join
            
            expected_lookup_df = spark.createDataFrame(
                    [
                        ("Bob","ACCOUNTING"),
                        ("Jim",None),
                        ("Caroline","HR")
                    ],
                    StructType(
                        [
                            StructField("name",StringType(),True),
                            StructField("dept_name",StringType(),True)
                        ]
                    )
                )
            op_tags = {
                "dataframe_keys":"dept_id",
                "join_dataframe_keys":"dept_id",
                "dataframe_columns":"name",
                "join_dataframe_columns":"dept_name",
                "join_type":"left_outer",
                "result_dataframe":"join_res"
            }            
            actual_lookup_df,errors = func.join_dataset(emp_df,dept_df,**op_tags)
            actual_lookup_df.show()
            expected_lookup_df.show()
            assert expected_lookup_df.orderBy(["name"]).collect() == actual_lookup_df.orderBy(["name"]).collect() 
            return True

        except:
            e = get_exception()
            log.error(e)
            return False
    def test_add_column(self):
        pass
    def test_modify_column(self):
        pass
    def test_aggregate_dataset(self):
        pass
    def test_register_temp_table(self):
        pass
    def test_run_sql(self):
        pass
    def test_move_file(self):
        pass
    def test_write_file(self):
        pass
    def test_read_file(self):
        pass
    def test_validate_dataframe(self):
        pass
    def test_pivot_dataframe(self):
        pass
    
    def test_date_from_timestamp(self):
        try:
            pass
        except:
            e = get_exception()
            log.error(e)
    
    def test_sync_files(self):
        try:
            source_dir = 's3a://gpdipamrasp32394/shared_sync'
            destination_dir = 'hdfs:///gpdip/dev/temp/shared_sync_copy'
            sync_id='gpdipamrasp32394_username'
            reference_dir = 'hdfs:///gpdip/dev/temp/sync_reference'
            table_format = 'parquet'
            schema_name = 'default'
            op_tags={
                    'source_dir':source_dir,
                    'target_dir':destination_dir,
                    'reference_dir':reference_dir,
                    'sync_id':sync_id,
                    'schema_name':schema_name,
                    'table_format':table_format,
                    'allowed_file_patterns':'*.csv',
                    'excluded_file_patterns':'',
                }
            status,error = func.sync_files(spark,**op_tags)
            if error:
                log.error(error)
                return False
            return status
        except:
            e = get_exception()
            log.error(e)
            return False   
        
    def test_validate_timestamp(self):
        try:
            check_pattern = '^([0-9]{4})'
            replace_pattern = '^([0-9]{4})([ \./\-]*[0-9]{2}[ \./\-]*[0-9]{2}[ :\./\-]*[0-9]{2}[ :\./\-]*[0-9]{2}[ :\./\-]*[0-9]{2}[ :\./\-]*[0-9]*)'
            test_df = spark.createDataFrame(
                [   
                    ("A4091064","0004-11-01 13:12:23.000","0001-11-01 13:12:23.000"),
                    ("C3241001","1870-11-01 13:12:23.020","0001-11-01 13:12:23.000"),
#                     ("B2411153","0001-11-01 13:12:23.000","0001-11-01 13:12:23.000"),
#                     ("B1261022","0001-11-01 13:12:23.000","0001-11-01 13:12:23.000")
                    ],
                StructType([
                    StructField("STUDY_ID",StringType(),True),
                    StructField("START_TS", StringType(), True),
                    StructField("END_TS", StringType(), True)
                    
                    ])
            )
            d_col = 'START_TS'
            test_df = test_df.withColumn(d_col,test_df[d_col].rationalize_year().cast(TimestampType())
                               
                               )
            test_df.show(test_df.count(),False)
            print(test_df.schema)
            return True
        except:
            e = get_exception()
            log.error(e)
            return False
    def test_override_columns(self):
        try:
            op_tags = {"override_file" :"file:///D:/sparkhub_input/PFEInternal_Override_Mapping_LKP_Sample.csv",
                       "config_file_format":"csv"}
            e = Entity(**op_tags)
            d_override_dfs = e.d_override_dfs
            if not d_override_dfs:
                return False
            test_df = spark.createDataFrame(
                [   
                    ("A4091064","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","DEFAULT_WRD_WORKING"),
                    ("C3241001","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","DEFAULT_WRD_WORKING"),
                    ("B2411153","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","DEFAULT_WRD_WORKING"),
                    ("B1261022","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","DEFAULT_WRD_WORKING")
                    ],
                StructType([
                    StructField("STUDY_ID",StringType(),True),
                    StructField("WRD_FLAG", StringType(), True),
                    StructField("STUDY_TYPE", StringType(), True),
                    StructField("WRD_WORKING", StringType(), True),
                    ])
            )
            
            expected_df = spark.createDataFrame(
                [   
                    ("A4091064","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","DEFAULT_WRD_WORKING","None"),
                    ("C3241001","EXCLUDE","DEFAULT_STUDY_TYPE","Manual-BRDU","WRD_WORKING;WRD_FLAG"),
                    ("B2411153","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","Manual- Wyeth Acq","WRD_WORKING"),
                    ("B1261022","DEFAULT_WRD_FLAG","DEFAULT_STUDY_TYPE","DEFAULT_WRD_WORKING","None")
                    ],
                StructType([
                    StructField("STUDY_ID",StringType(),True),
                    StructField("WRD_FLAG", StringType(), True),
                    StructField("STUDY_TYPE", StringType(), True),
                    StructField("WRD_WORKING", StringType(), True),
                    StructField("OVERRIDE_COLUMNS",StringType(),True)
                    ])
            ) 
            op_tags = {'entity_name':'default'}
            res_df,error = func.override_columns(test_df,d_override_dfs,**op_tags)
            if error:
                log.error(error)
                return False
            res_df.show()
            if res_df.orderBy(["STUDY_ID"]).collect() == expected_df.orderBy(["STUDY_ID"]).collect():
                return True
            
            return False
        except:
            e = get_exception()
            log.error(e)
            return False
def main():
    try:
        tdf = TestDataframeFunctions()
        l_functions = ['filter_rows','join_dataset','override_columns','validate_timestamp','sync_files']
        for i,f in enumerate(l_functions[-1:]):
            qual_f = 'tdf.test_'+f+'()'
            res = "Failed"
            print(qual_f)
            stat = eval(qual_f)
            if stat:
                res = "Passed"
            log.warn("#TESTCASE_RESULT#: {}. TestCase for function {} has {}".format(str(i+1),f,res))
        
        
    except:
        e = get_exception()
        log.error(e)
if __name__ == '__main__':
    main()