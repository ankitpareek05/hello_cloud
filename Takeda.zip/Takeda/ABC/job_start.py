import pymysql.cursors
import argparse
from datetime import datetime

def insert_entry(job_id, batch_id):
    ct_dt = datetime.now()
    ct_str = ct_dt.strftime('%Y%m%d%H%M%S%f')
    connection = pymysql.connect(host='takeda-stork.cdx5arsfqrjr.us-east-1.rds.amazonaws.com',
                             user='tak_stork',
                             password='tak_stork',
                             db='common_data_services',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

    try:
        with connection.cursor() as cursor:
            sql = "INSERT INTO `common_data_services`.`T_ABC_JOB_TASK_EXCN_STATISTICS` " \
                  "(`TASK_ID`, `JOB_ID`, `BATCH_ID`, `STATUS_CD`, `START_TIME`) VALUES (%s, %s, %s, %s, %s)"
            cursor.execute(sql, (ct_str, job_id, batch_id, '1', ct_dt))
        connection.commit()
        return {'task_id': ct_str}
    finally:
        connection.close()
        
def main():
    hub_parser = argparse.ArgumentParser(description="Hub App")
    hub_parser.add_argument('--job_id', help='job_id of the job to run', required=True)
    hub_parser.add_argument('--batch_id', help='batch_id for the job to run', required=True)
    args = hub_parser.parse_args()
    job_id = args.job_id
    batch_id = args.batch_id
    insert_entry(job_id, batch_id)

if __name__ == '__main__':
    main()

