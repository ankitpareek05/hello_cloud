import pymysql.cursors
import argparse
from datetime import datetime

def update_entry(task_id):
    ct_dt = datetime.now()
    ct_str = ct_dt.strftime('%Y%m%d%H%M%S')
    connection = pymysql.connect(host='takeda-stork.cdx5arsfqrjr.us-east-1.rds.amazonaws.com',
                             user='tak_stork',
                             password='tak_stork',
                             db='common_data_services',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

    try:
        with connection.cursor() as cursor:
            sql = "SELECT TASK_ID, JOB_ID, STATUS_CD FROM `common_data_services`.`T_ABC_JOB_TASK_EXCN_STATISTICS` " \
                  "WHERE TASK_ID = %s"
            cursor.execute(sql, task_id)
            res_set = cursor.fetchall()
            if len(res_set) > 1:
                raise Exception('More than one entry with same TASK_ID')
            if len(res_set) < 1:
                raise Exception("TASK_ID doesn't exist")
            if int(res_set[0]['STATUS_CD']) == 2:
                raise Exception("Task already ended")
            if int(res_set[0]['STATUS_CD']) == 3:
                raise Exception("Task already ended in error")
            sql = "UPDATE `common_data_services`.`T_ABC_JOB_TASK_EXCN_STATISTICS` " \
                  "SET END_TIME = %s, STATUS_CD = %s WHERE TASK_ID = %s"
            cursor.execute(sql, (ct_str, '3', task_id))
        connection.commit()
        return {'task_id': task_id}
    finally:
        connection.close()

def main():
    hub_parser = argparse.ArgumentParser(description="Hub App")
    hub_parser.add_argument('--task_id', help='task_id for the job to be ended', required=True)
    args = hub_parser.parse_args()
    task_id = args.task_id
    update_entry(task_id)

if __name__ == '__main__':
    main()

