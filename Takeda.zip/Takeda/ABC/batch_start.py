import pymysql.cursors
import argparse
from datetime import datetime

def insert_entry(batch_name):
    ct_dt = datetime.now()
    ct_str = ct_dt.strftime('%Y%m%d%H%M%S%f')
    connection = pymysql.connect(host='takeda-stork.cdx5arsfqrjr.us-east-1.rds.amazonaws.com',
                             user='tak_stork',
                             password='tak_stork',
                             db='common_data_services',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

    try:
        with connection.cursor() as cursor:
            sql = "INSERT INTO `common_data_services`.`T_ABC_BATCH_STATISTICS` " \
                  "(`BATCH_ID`, `BATCH_NAME`, `BATCH_START_TIME`, `BATCH_STTS_CD`) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (ct_str, batch_name, ct_dt, '1'))
        connection.commit()
        return {'batch_id': ct_str}
    finally:
        connection.close()
        
def main():    
    hub_parser = argparse.ArgumentParser(description="Hub App")
    hub_parser.add_argument('--batch_name', help='batch_name for the batch to be created', required=False)
    args = hub_parser.parse_args()
    batch_name = args.batch_name if args.batch_name else ''
    insert_entry(batch_name)

if __name__ == '__main__':
    main()
