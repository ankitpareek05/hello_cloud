import pymysql.cursors
import subprocess
import re
import psycopg2
import time

from ABC import batch_start
from ABC import job_start
from ABC import job_end
from ABC import batch_end
from ABC import job_end_error

def write_to_redshift(job_id, batch_id, table, s3_path):
    print('Running job for job_id', job_id)
    time.sleep(1)
    try:
        job_info = job_start.insert_entry(job_id, batch_info['batch_id'])
        con=psycopg2.connect(dbname= 'mpidb', host='mpi-db.cxwfalbnhvrc.us-east-1.redshift.amazonaws.com', 
            port= '5439', user= 'mpi_user', password= 'Mp1#user')
        cur = con.cursor()
        temp_table = table + '_temp'
        command = "delete from " + temp_table + ";"
        cur.execute(command)
        command = "copy " + temp_table + " \
            from '" + s3_path + "' \
            iam_role 'arn:aws:iam::480394630711:role/MPI_Redshidt_For_S3_Access' \
            format as parquet;"
        cur.execute(command)
        command = "delete from " + table + ";"
        cur.execute(command)
        command = "insert into "+ table + " select * from " + temp_table + ";"
        cur.execute(command)
        command = "delete from " + temp_table + ";"
        cur.execute(command)
        con.commit()
        job_end.update_entry(job_info['task_id'])
    except Exception as e:
        print('Redshift Job with job_id: ' + job_id + ' failed')
        job_end_error.update_entry(job_info['task_id'])

def run_job(job_id, batch_id):
    print('Running job for job_id', job_id)
    time.sleep(1)
    job_info = job_start.insert_entry(job_id, batch_info['batch_id'])
    sp = subprocess.Popen(["spark-submit", "--deploy-mode", "client", \
        "/home/hadoop/Code/sparkhub/run.py", "--job_id", job_id], \
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = sp.communicate()
    # print(out)
    # print(err)
    if sp.returncode == 0 and len(re.findall('[0-9]{2}/[0-9]{2}/[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2} ERROR',err)) == 0:
        job_end.update_entry(job_info['task_id'])
        pass
    else:
        print(out)
        print(err)
        print('Spark Job with job_id: ' + job_id + ' failed')
        job_end_error.update_entry(job_info['task_id'])

batch_info = batch_start.insert_entry('')

run_job('10001', batch_info['batch_id'])
run_job('10002', batch_info['batch_id'])
run_job('10004', batch_info['batch_id'])
run_job('20000', batch_info['batch_id'])
write_to_redshift('20500', batch_info['batch_id'], 'processed.dim_product_master', 's3://takeda-vcu/n_demo/Processed/dim_product_master/')
run_job('21000', batch_info['batch_id'])
write_to_redshift('21500', batch_info['batch_id'], 'processed.dim_cust_terr_algnt', 's3://takeda-vcu/n_demo/Processed/dim_cust_terr_algnt/')
run_job('22000', batch_info['batch_id'])
write_to_redshift('22500',batch_info['batch_id'], 'processed.fact_xpo_plantrak', 's3://takeda-vcu/n_demo/Processed/fact_xpo_plantrak/')

batch_end_info = batch_end.update_entry(batch_info['batch_id'])

if batch_end_info['batch_id'] == batch_info['batch_id']:
    print('Run Complete')

  