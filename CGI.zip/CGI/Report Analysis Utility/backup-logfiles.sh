#!/bin/sh
# Backup the Log Files
#******************************************

#*****SET ENVIRONMENT VARIABLES******
export PATH=.:$PATH
. setIAETLEnv.lib
#************************************

# section below created to backup ETL logs and ASCII Files (AK1 - 9/11/2006)
if [ ! -d ${ETL_HOME}/logs/Backup ]
then 
	mkdir ${ETL_HOME}/logs/Backup
fi

export DATETIME=`date '+%Y.%m.%d.%H.%M.%S'`

if [[ ${BACKUP_LOGS} = "YES" && "$1" != "-ascii" && "$1" != "-DA" ]]
then
	echo "\nBacking logs from previous ETL run...\n"
	if [ ! -d ${ETL_BKP_LOGS_HOME}/logs_${DATETIME} ]
	then
		mkdir -p ${ETL_BKP_LOGS_HOME}/logs_${DATETIME}
	fi

	mv ${ETL_HOME}/logs/execute ${ETL_BKP_LOGS_HOME}/logs_${DATETIME}/execute 2>/dev/null
	mv ${ETL_HOME}/logs/reject ${ETL_BKP_LOGS_HOME}/logs_${DATETIME}/reject 2>/dev/null
	mkdir ${ETL_HOME}/logs/execute
	mkdir ${ETL_HOME}/logs/reject
fi

if [[ ${BACKUP_ASCII} = "YES" && "$1" != "-log" && "$1" != "-DA" ]]
then
	if [ ! -d ${ETL_BKP_ASCII_HOME}/ascii_${DATETIME} ]
	then 
		mkdir -p ${ETL_BKP_ASCII_HOME}/ascii_${DATETIME}
	fi

	mv ${ETL_HOME}/ascii/extract ${ETL_BKP_ASCII_HOME}/ascii_${DATETIME}/extract 2>/dev/null
	mv ${ETL_HOME}/ascii/transform ${ETL_BKP_ASCII_HOME}/ascii_${DATETIME}/transform 2>/dev/null

	mkdir ${ETL_HOME}/ascii/extract
	mkdir ${ETL_HOME}/ascii/transform
	echo "\nBacking up of ETL logs completed\n"
fi



# section below created to backup DA logs and CSV Files 
if [[ ${BACKUP_LOGS} = "YES" && "$1" = "-DA" && "$2" = "-STEP1" ]] 
then 
        echo "\nBacking logs from previous ETL run...\n" 
        if [ ! -d ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP1 ] 
        then 
                mkdir -p ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP1 
        fi 
	 mv ${ETL_HOME}/logs/data_assurance ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP1/data_assurance 2>/dev/null 
        mv ${ETL_HOME}/logs/execute ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP1/execute 2>/dev/null 
        mv ${ETL_HOME}/logs/reject ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP1/reject 2>/dev/null 
        mkdir ${ETL_HOME}/logs/execute
        mkdir ${ETL_HOME}/logs/reject
        mkdir ${ETL_HOME}/logs/data_assurance
    echo "\nBacking up of DA logs and CSV completed\n"
	fi	

	if [[ ${BACKUP_LOGS} = "YES" && "$1" = "-DA" && "$2" = "-STEP2" ]] 
then 
        echo "\nBacking logs from previous ETL run...\n" 
        if [ ! -d ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP2 ] 
        then 
                mkdir -p ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP2 
        fi 
	 mv ${ETL_HOME}/logs/data_assurance ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP2/data_assurance 2>/dev/null 
        mv ${ETL_HOME}/logs/execute ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP2/execute 2>/dev/null 
        mv ${ETL_HOME}/logs/reject ${ETL_BKP_LOGS_HOME}/DA_logs_${DATETIME}_STEP2/reject 2>/dev/null 
        mkdir ${ETL_HOME}/logs/execute
        mkdir ${ETL_HOME}/logs/reject
        mkdir ${ETL_HOME}/logs/data_assurance
echo "\nBacking up of DA logs and CSV completed\n"
	fi	

	