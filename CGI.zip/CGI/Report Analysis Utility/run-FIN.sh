#!/bin/sh

# *-------------------------------------------------------------------------*
# Set environment variables
# *-------------------------------------------------------------------------*

export PATH=.:$PATH
. setIAETLEnv.lib

# *-------------------------------------------------------------------------*
# Set OnError event
# *-------------------------------------------------------------------------*

OnError()
{
	echo ""
	echo "/nThe current ETL run is incomplete."
        echo "The next run will resume from the point of failure."
        
        if [[ "$ADVHRM_INSTALLED" != "true" ]] 
	  then
	    backup-logfiles.sh -log
	fi
         
        exit 1
}

OnETLVerificationError()
{
	echo ""
	echo "\nSome ETL Verification test failed.Check the runETLVerification log file for more details."
	echo "\nThe current ETL run is incomplete."
        echo "The next run will resume from the point of failure."
        
        if [[ "$ADVHRM_INSTALLED" != "true" ]] 
	  then
	    backup-logfiles.sh -log
	fi
         
        exit 1
}

# *-------------------------------------------------------------------------*
# Execute pre-Archival Check
# *-------------------------------------------------------------------------*
if [ "$PRE_ARCHIVAL_ETL_CHECK" == "YES" ]
  then
    runetl.sh -i $ETL_HOME/etc/config-FIN.xml -h $ETL_HOME -a ADVFIN -e $ETL_HOME/etc/keyfile.txt -y
    error=$?      # Exit status of 'pre_etl_verification_check' step.

    if [ "$error" -eq 0 ]
      then
   

	# *-------------------------------------------------------------------------*
	# Start then
	# *-------------------------------------------------------------------------*

	# *-------------------------------------------------------------------------*
	# Execute pre-ETL environment CDC/Trigger Test
	# *-------------------------------------------------------------------------*

if [ "$PRE_ETL_CHECK" == "YES" ]
  then
    runetl.sh -i $ETL_HOME/etc/config-FIN.xml -h $ETL_HOME -a ADVFIN -e $ETL_HOME/etc/keyfile.txt -T TG_CDC,TC_TRIG_EXIST
    error=$?      # Exit status of 'pre_etl_verification_check' step.

    if [ "$error" -eq 0 ]
      then
        echo ""
      else
    	OnETLVerificationError
    fi
fi

	# *-------------------------------------------------------------------------*
	# Execute pre-ETL environment checks
	# *-------------------------------------------------------------------------*

if [ "$PRE_ETL_CHECK" == "YES" ]
  then
    runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -z
    error=$?      # Exit status

    if [ "$error" -eq 0 ]
      then
        echo ""
      else
    	OnError
    fi
fi
 

	# *-------------------------------------------------------------------------*
	# End then 
	# *-------------------------------------------------------------------------*

      else
    	OnETLVerificationError
    fi
fi




# *-------------------------------------------------------------------------*
# EXTRACT for facts and dimensions
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -S --stepname Extract -A DIM_EXTRACT,FACT_EXTRACT,FACT_DELETE_EXTRACT,DIM_CVL_EXTRACT,RESTORE_EXTRACT -# ${EXTRACT_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi  

# *-------------------------------------------------------------------------*
# CDC Backup Process
# *-------------------------------------------------------------------------*

if [ "$ENABLE_CDC_BACKUP_RESTORE" == "true" ]
  then
    runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname CDC_Backup -A CDC_BACKUP_PROCESS
    error=$?      # Exit status

    if [ "$error" -eq 0 ]
      then
        echo ""
      else
    	OnError
    fi
fi

# *-------------------------------------------------------------------------*
# Post-extract processes, e.g. DW_SE_TBL Load and CDC Cleanup
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Post_Extract_Processes -A POST_EXTRACT_PROCESS 

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# TRANSFORM for basic dimensions
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dimension_Transform -A DIM_TRANSFORM -# ${TRANSFORM_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for basic dimensions
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dimension_Load -A DIM_LOAD

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# TRANSFORM for snowflake dimensions
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Snowflake_Dimension_Transform -A DIM_SNOWFLAKE_TRANSFORM -# ${TRANSFORM_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for snowflake dimensions
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Snowflake_Dimension_Load -A DIM_SNOWFLAKE_LOAD 

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# EXTRACT for post-dimension (fiscal year 9999) objects
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Post_Dim_Extract -A POST_DIM_EXTRACT -# ${EXTRACT_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 



# *-------------------------------------------------------------------------*
# TRANSFORM for post-dimension (fiscal year 9999) objects
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Post_Dim_Transform -A POST_DIM_TRANSFORM -# ${TRANSFORM_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for post-dimension (fiscal year 9999) objects
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Post_Dim_Load -A POST_DIM_LOAD -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# TRANSFORM for facts (including non-aggregating SMRYs)
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Fact_Transform -A FACT_TRANSFORM,RESTORE_TRANSFORM -# ${TRANSFORM_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *--------------------------------------------------------------------------------*
# TRANSFORM - TRANSFORM step for removing deleted fact records from the warehouse
# *--------------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Fact_Transform -A FACT_DELETE_TRANSFORM -# ${TRANSFORM_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# TRANSFORM - special surrogate key generation step for high-volume facts
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Surrogate_Key_Generation -A SK_GENERATION -# ${SK_GENERATION_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# Clear records from full-refresh tables
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Table_Refresh -A FACT_REFRESH -# ${TABLE_REFRESH_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 

# *-------------------------------------------------------------------------*
# LOAD step for removing dependent on the FACT_DELETE_LOAD_1 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Delete_1 -A DPNDNT_FACT_DELETE_LOAD_1 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi

# *-------------------------------------------------------------------------*
# LOAD step for removing dependent on the FACT_DELETE_LOAD_2 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Delete_2 -A DPNDNT_FACT_DELETE_LOAD_2 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi

# *-------------------------------------------------------------------------*
# LOAD step for removing dependent on the FACT_DELETE_LOAD_3 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Delete_3 -A DPNDNT_FACT_DELETE_LOAD_3 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi

# *-------------------------------------------------------------------------*
# LOAD step for removing dependent on the FACT_DELETE_LOAD_4 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Delete_4 -A DPNDNT_FACT_DELETE_LOAD_4 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi

# *-------------------------------------------------------------------------*
# LOAD step for removing deleted fact records from the warehouse
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Fact_Delete_Load -A FACT_DELETE_LOAD -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 

# *-------------------------------------------------------------------------*
# LOAD for facts (including non-aggregating SMRYs)
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Fact_Load -A FACT_LOAD,RESTORE_LOAD -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for facts dependent on the FACT_LOAD group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Load_1 -A DPNDNT_FACT_LOAD_1,RESTORE_DPNDT_LOAD_1 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for facts dependent on the FACT_LOAD_1 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Load_2 -A DPNDNT_FACT_LOAD_2 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for facts dependent on the FACT_LOAD_2 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Load_3 -A DPNDNT_FACT_LOAD_3 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD for facts dependent on the FACT_LOAD_3 group
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Dependent_Fact_Load_4 -A DPNDNT_FACT_LOAD_4 -# ${LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD step for basic aggregating summary tables (e.g. SMRY_LDGRC)
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Smry_Ldgr_A_Load -r SMRY_LDGRA_O

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Smry_Ldgr_B_Load -r SMRY_LDGRB_O

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Smry_Ldgr_C_Load -r SMRY_LDGRC_O

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# LOAD step for AP Open Items Summary
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname OI_Summary_Load -r SMRY_AP_OI_P

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# Post-processing step for special fields (e.g. those in DIM_APD or DIM_FY)
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Post_ETL_Process -A POST_ETL_PROCESS

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 

# *-------------------------------------------------------------------------*
#  Processing Step to clean up  DOC_ARCH_STAGING table
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname DOC_ARCH_STAGING_CLEANUP -G DOC_ARCH_STAGING_CLEANUP

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# Fact Cleanup Step (removes obsolete records from insert-only tables)
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -C --stepname Fact_Cleanup -A INCREMENTAL_FACT_CLEANUP -# ${POST_LOAD_THREADS}

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# Summary Table Objects with non-standard logic: e.g. Summary Balance
# *-------------------------------------------------------------------------*

runetl.sh -i ${ETL_HOME}/etc/config-FIN.xml -h ${ETL_HOME} -a ADVFIN -e ${ETL_HOME}/etc/keyfile.txt -E --stepname Summary_Special_Processing -A SUMMARY_SPECIAL_PROCESSING

error=$?      # Exit status
if [ "$error" -eq 0 ]
  then
    echo ""
  else
    OnError
fi 


# *-------------------------------------------------------------------------*
# End of ETL
# *-------------------------------------------------------------------------*

echo "This infoAdvantage ETL run for the ADVFIN application has ended."


# *-------------------------------------------------------------------------*
# Back up log and ASCII files after a successful run
# *-------------------------------------------------------------------------*

if [[ "$ADVHRM_INSTALLED" != "true" ]] 
  then
    backup-logfiles.sh
fi