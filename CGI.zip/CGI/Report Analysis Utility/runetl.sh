#!/bin/sh


#*****SET ENVIRONMENT VARIABLES******
export PATH=.:$PATH
. setIAETLEnv.lib
#************************************


exec $JAVA_HOME/bin/java -Xms${INITIAL_JAVA_HEAP_SIZE}m -Xmx${MAX_JAVA_HEAP_SIZE}m -Dcsf.preferences.url=file://$ETL_HOME/etc/CSF.properties -classpath $CLASSPATH com.amsinc.psg.dwfmwk.launcher.DWLaunchMgr $*



return $?
