package com.amsinc.psg.BIUtil;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilErrorCodes;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilException;
import com.amsinc.psg.BIUtil.logging.BIUtilLogMgr;

public class InfoStoreMetadata 
{
	private String msBaseURL = "http://<<REPO>>:6405/biprws";
	
	// Enterprise Authentication Credentials
	private String msUsername = null;
	private String msPassword = null;
	private static String msBoAuthType = "secEnterprise";
	private static String msLogonToken = null;
	
	// Enable Fiddler Trace.  This causes the requests to go through a proxy on port 8888 which fiddler listens on
	static boolean enableFiddler = false;
	
	public InfoStoreMetadata(String fsRepoNm,String UserName, String lsPaswd) throws BIUtilException
	{
		
		if(fsRepoNm.contains(":"))
		{
			fsRepoNm = fsRepoNm.substring(0,fsRepoNm.indexOf(":"));
		}
		
		msBaseURL = msBaseURL.replace("<<REPO>>", fsRepoNm);
		msUsername = UserName;
		msPassword = lsPaswd;
		
		intialize();
		

	}		
	
	/**
	 * This method initialize the BI repository connection
	 * @throws BIUtilException 
	 */
	private void intialize() throws BIUtilException 
	{
		String logonXMLlString = "";
		try
		{
			BIUtilLogMgr.getRunTimeLogger().info("Creating logon token for Restful web service");
			
			String lsLogonURL = msBaseURL + "/logon/long";
			// -----------------------
			// Logon to Enterprise
			// -----------------------
			logonXMLlString = "<attrs><attr name=\"userName\" type=\"string\" >" + msUsername + "</attr><attr name=\"password\" type=\"string\" >" 
								+ msPassword 
								+ "</attr><attr name=\"auth\" type=\"string\" possibilities=\"secEnterprise,secLDAP,secWinAD,secSAPR3\">" 
								+ msBoAuthType + "</attr></attrs>";
			
			String logonXML = BIUtilCommon.restPost(enableFiddler, lsLogonURL, logonXMLlString, "","","","");
			// The quotes are added because the webi URL require quotes around the token
			msLogonToken = "\"" + getLogonTokenFromXML(logonXML) + "\"";

			//System.out.println(msLogonToken);
			
			
		}catch(Exception loExp)
		{
			throw new BIUtilException(BIUtilErrorCodes.E000005, "Error during creating Restful web session");
		}
		
	}  // End intialize
	
	/**
	 * This method extract the logon token 
	 * @param xmlString
	 * @return
	 * @throws Exception
	 */
	private String getLogonTokenFromXML(String xmlString) throws Exception {
		Document doc = BIUtilCommon.convertStringToDom(xmlString);
		NodeList nodes = doc.getElementsByTagName("attr");

		for (int i = 0; i < nodes.getLength(); i++) {
		  Element element = (Element) nodes.item(i);
		  
		  // Is this the correct XML token
		  if (element.getAttribute("name").equals("logonToken")) {
		   return(element.getTextContent());
		  }
		}
		return("");
		}
	
	/**
	 * This method will set the folder properties along with sub-folder and report names
	 * @param fsFolder
	 */
	public void setMetadataInformation(String fsFolder)
	{
		String lsFolderUrl = msBaseURL + "/v1/folders";
		String lsGetXMLString = "";
		
		try
		{
			System.out.println(lsFolderUrl); 
			lsGetXMLString = BIUtilCommon.restGet(enableFiddler, lsFolderUrl, "X-SAP-LogonToken",msLogonToken, "","");
			 System.out.println(lsGetXMLString);
			 if(!lsGetXMLString.contains("<error>")){
				 
				Document loDoc =  BIUtilCommon.convertStringToDom(lsGetXMLString);
				
				NodeList loNodeList = loDoc.getElementsByTagName("parameter");
				
				System.out.println(lsGetXMLString);
				 		
			  }else{
					   BIUtilLogMgr.getRunTimeLogger().info("Error while getting folder details: " + fsFolder,true); 
					   
					   //Get the Error details
					  String lsErrorCode = BIUtilCommon.getErrorCodeDetails(lsGetXMLString);
					  String lsErrorMessage = BIUtilCommon.getErrorMessageDetails(lsGetXMLString);
					   
					  
					  // BIUtilLogMgr.loadReportRefreshStatRecord(loItr.getValue().getRptRootFldrNm(), lsRptNm, "No", String.valueOf(llDiff),lsErrorCode,lsErrorMessage);
						 
			  } //End If
			 
		}catch(Exception loExp)
		{
			
		}
	}

		
}
