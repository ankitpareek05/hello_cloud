package com.amsinc.psg.BIUtil;


import static com.amsinc.psg.BIUtil.BIUtilConstant.*;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;

import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilErrorCodes;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilException;
import com.amsinc.psg.BIUtil.logging.BIUtilLogMgr;

/**
 * This class read the BIUTil.properties and initialize the necessary parameter
 * require for connecting BI repository and executing various operations
 * @author shivansh.saxena
 *
 */
public class BIUtilConfig {


	private static String msUtilPath = null;
	
	private static String msCmsName = null;
	private static String msUserName = null;
	private static String msPassword = null;
	//private static String msFolderNm = null;
	private static String msUniverseFolderNm = null;
	private static String msRptInfoFilePth = null;
	private static String msRptSchdFormat = null;
	private static String msRptSchdDest = null;
	private static String msPurgeExcList = null;
	private static String msReportNm = null;
	
	public static boolean mBoolRptDeploy = false;
	public static boolean mBoolRptRefresh = false;
	public static boolean mBoolRptPurge = false;
	public static boolean mBoolRptChgSource = false;
	public static boolean mBoolRptSchedule = false;
	public static boolean mBoolRptScheduleInfoGen = false;
	public static boolean mBoolRptScheduleHistory = false;
	public static boolean mBoolRptMetadata = false;
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		
		String[] laFolderNm = null;
		try 
		{
			String lsUtilPath = args[0];
			
			if(lsUtilPath == null)
			{
				throw new Exception ("BI Util Home is not set");
			}else
			{
				File loFile = new File(lsUtilPath);
				
				if(!loFile.isDirectory())
				{
					throw new Exception ("Incorrect Path provided: " + lsUtilPath);
				}else
				{
					msUtilPath = lsUtilPath;
					BIUtilLogMgr.initLogMgr(msUtilPath);
				}
					
				
			}
			
			intializeBIStep(args[1]);
			
			String lsPropFilePth = msUtilPath + File.separatorChar + CONFIG_FOLDER + File.separatorChar + CONFIG_FILE_NM;
			
			BIUtilLogMgr.getRunTimeLogger().debug("Loading property file: "+lsPropFilePth);
			//FileWriter loWriter  = null;
			
			File loPropFile = new File(lsPropFilePth);
			
			if(loPropFile.exists())
			{
				
				Properties loProp = new Properties();
				loProp.load(new FileInputStream(loPropFile));
				
				msCmsName = loProp.getProperty(CMS_NAME);
				if(msCmsName == null || msCmsName.isEmpty())
				{
					throw new Exception ("CMS Name is empty in configuration file: ");
				}
				
				BIUtilLogMgr.getRunTimeLogger().info("Executing Utility for CMS Server: "+msCmsName);
				
				msUserName = loProp.getProperty(CMS_USERNAME);
				
				BIUtilLogMgr.getRunTimeLogger().debug("CMS UserName: "+msUserName);
				
				if(msUserName == null || msUserName.isEmpty())
				{
					throw new Exception ("CMS UserName is empty in configuration file: ");
				}
				
				msPassword = loProp.getProperty(CMS_PASSWORD);
				
				String lsFolderNm  = loProp.getProperty(REPORT_FOLDER_NAME);
				
				msReportNm  = loProp.getProperty(REPORT_NAME);
				
				if(lsFolderNm == null || lsFolderNm.isEmpty())
				{
					throw new Exception ("CMS FolderName is empty in configuration file: ");
				}
				
				laFolderNm = lsFolderNm.split(",");
				
				
				//BIUtilLogMgr.getRunTimeLogger().info("Utility is getting executed for Folder: "+msFolderNm);
				
				
					
				execute(laFolderNm);
					
			}else
			{
				System.out.println("Utility Configuration File is not present: " + lsPropFilePth);
				//throw new BIUtilException ("Utility Configuration File is not present: " + lsPropFilePth);
				throw new BIUtilException(BIUtilErrorCodes.E000001, "Configuration File is not present" + lsPropFilePth);
			}
		
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}// End Main
	
	/**
	 * This method control the execution of utility
	 * @param faFolderNm
	 * @throws BIUtilException 
	 * @throws Exception
	 */
	private static void execute(String[] faFolderNm) throws BIUtilException  
	{
		InfoStoreMetadata loObj= null;
		WebiRptOperations loRestObj = null;
		try
		{
			//loObj = new InfoStoreMetadata(msCmsName, msUserName,msPassword);
			
			for(String lsFolder : faFolderNm)
			{
				
				BIUtilLogMgr.getRunTimeLogger().info("Utility is getting executed for Folder: "+lsFolder,true);
				//loObj.setMetadataInformation(lsFolder);
				loRestObj = new WebiRptOperations(msCmsName,msUserName,msPassword);
				
				if(mBoolRptDeploy)
				{
					BIUtilLogMgr.getRunTimeLogger().info("Deploying WEBI reports...");
					//ArrayList<File> laFldr = new ArrayList<File>();
					//ArrayList<String> laRpt = new ArrayList<String>();
					String lsPath = msUtilPath + File.separatorChar + REPORT_FLDR_NAME+File.separatorChar+lsFolder+File.separatorChar+msReportNm;
					System.out.println(lsPath);
					
					File loFile = new File(lsPath);
					
					if(loFile.exists())
					{
						loRestObj.deployWebiReports(loFile);
					}else
					{
						System.out.println("File doesn't exist");
					}
					
				}
				

				
				
				if(mBoolRptMetadata)
				{
					BIUtilLogMgr.getRunTimeLogger().info("Generating Meatadata for WEBI reports...");
					BIUtilLogMgr.intializeCSVLogFiles(msUtilPath, 'm');
					loRestObj.reportMetadata();
					BIUtilLogMgr.closeTarget();
				}
				
				/*if(mBoolRptRefresh)
				{
					BIUtilLogMgr.getRunTimeLogger().info("Refreshing WEBI reports...");
					BIUtilLogMgr.intializeCSVLogFiles(msUtilPath, 'r');
					loRestObj.refreshReports();
				}
				
				if(mBoolRptPurge)
				{
					BIUtilLogMgr.getRunTimeLogger().info("Purging WEBI reports...");
					BIUtilLogMgr.intializeCSVLogFiles(msUtilPath, 'p');
					loRestObj.PurgeReport(msPurgeExcList);
				}
				
				if(mBoolRptScheduleInfoGen)
				{
					BIUtilLogMgr.getRunTimeLogger().info("Generating WEBI reports prompt information for scheduling...",true);
					loRestObj.getPromptDetails();
					ExcelDataReaderWriter loWriter = new ExcelDataReaderWriter(msRptInfoFilePth);
					loWriter.writeExcel(loObj.getReportInfo());
				}
				
				if(mBoolRptSchedule)
				{
					BIUtilLogMgr.getRunTimeLogger().info("Scheduling WEBI reports...");
					
					//read prompt details from excel
					ExcelDataReaderWriter loReader = new ExcelDataReaderWriter(msRptInfoFilePth);
					ArrayList<WebiReportInfo> loSchedulabe = loReader.readExcel(loObj.getReportInfo());
					
					//validate prompt details
					loRestObj.getPromptDetails();
					loObj.validateSchedulePrompts(loSchedulabe);
					
					//intialize csv file
					BIUtilLogMgr.intializeCSVLogFiles(msUtilPath, 's');
					
					loRestObj.scheduleReports(msRptSchdFormat,msRptSchdDest);
					
					
				}
				
				if(mBoolRptScheduleHistory)
				{
					
					BIUtilLogMgr.getRunTimeLogger().info("Getting status of last instance of Webi Report...",true);
					//intialize csv file
					BIUtilLogMgr.intializeCSVLogFiles(msUtilPath, 'h');
					
					//Get the status of latest instance
					loObj.getSchedulingStatus();
				}*/
				
				
			}// End For
			BIUtilLogMgr.closeTarget();
				
			
		}catch(Exception loExp)
		{
			loExp.printStackTrace();
			BIUtilLogMgr.getRunTimeLogger().logStackTrace(loExp);
			throw new BIUtilException(BIUtilErrorCodes.E000001,"Error while executing utility", loExp);
			
		}finally
		{
			
			//loRptObj.sessionOff();
		}
		
		
		
	}

	

	/**
	 * This will read the BIUtil specific argument
	 * @param string
	 */
	private static void intializeBIStep(String fsArgument) 
	{
		if (fsArgument.equalsIgnoreCase(GENERATE_METADATA))
		{
			mBoolRptMetadata = true;
			
		}else if(fsArgument.equalsIgnoreCase(DEPLOY_REPORT))
		{
			mBoolRptDeploy = true;
		}
		
		
	}

}
