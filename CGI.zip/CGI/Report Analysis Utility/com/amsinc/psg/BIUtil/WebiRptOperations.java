package com.amsinc.psg.BIUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;



import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;




import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilErrorCodes;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilException;
import com.amsinc.psg.BIUtil.logging.BIUtilEventLogger;
import com.amsinc.psg.BIUtil.logging.BIUtilLogMgr;

import sun.font.BidiUtils;



/**
 * This class perform various operations on WEBI report example refresh,purge etc.
 * using RestFul webservice
 * @author shivansh.saxena
 *
 */
public class WebiRptOperations {

	
	// Enterprise Authentication Credentials
		private static String msUsername = "";
		private static String msPassword = "";
		private static String msBoAuthType = "secEnterprise";
		private static String msLogonToken = null;

		 
		// Enable Fiddler Trace.  This causes the requests to go through a proxy on port 8888 which fiddler listens on
		static boolean enableFiddler = false;

		
		// Sample Variables
		static String msReportID = "";
		
		private Map<Integer,WebiReportInfo> moRptInfo = null;
		
		private  final String DATE_VALUE = "2013-12-17T06:04:47.000-07:00";
		private  final String STRING_INT_VALUE = "01";
				
		// Restful URL's
		private String msBaseURL = "http://<<REPO>>:6405/biprws";
		private String msLogonURL = null;
		private String msLogoffURL = null;
		private String msBaseWebiURL = null;
		
		//Schedule String
		private String msSchedule = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"+
									"<schedule><name>RestFullCodeSchedule</name><format type=\"<<FORMAT>>\"/><destination>"+
									"<useSpecificName><<REPORT_NAME>></useSpecificName>"+
									"<filesystem><username></username><password></password>"+
									"<directory><<DESTINATION>></directory></filesystem></destination>"+
									"<<PARAMETER>></schedule>";
	    
		private String msPreviousVal = "<info cardinality=\"<<CARDINALITY_TOKEN>>\"><previous><value></value></previous></info></answer></parameter>";
		
		private  final String FORMAT_TOKEN = "<<FORMAT>>";
		private  final String REPORT_NAME_TOKEN = "<<REPORT_NAME>>";
		private  final String DESTINATIONE_TOKEN = "<<DESTINATION>>";
		private  final String PARAMETER_TOKEN = "<<PARAMETER>>";
		private  final String CARDINALITY_TOKEN = "<<CARDINALITY_TOKEN>>";
		private  final String DATE_VALUE_SCHEDULE = "T00:00:00.000-07:00";
		
		//DataProvide ID
		private ArrayList<String> moDataProvideIDList = null;
		//Variable ID
				private ArrayList<String> moVariableIDList = null;
				private LinkedHashMap<String,String> moVarIdMap = null;
		
		
																
	/**
	 * @param args
	 */
			
		
	public WebiRptOperations(String fsRepoNm,String UserName, String lsPaswd) throws BIUtilException
	{
		System.out.println("here");
		if(fsRepoNm.contains(":"))
		{
			fsRepoNm = fsRepoNm.substring(0,fsRepoNm.indexOf(":"));
		}
		
		msBaseURL = msBaseURL.replace("<<REPO>>", fsRepoNm);
		msUsername = UserName;
		msPassword = lsPaswd;
		
		msLogonURL = msBaseURL + "/logon/long";
		msLogoffURL = msBaseURL + "/logoff";
		msBaseWebiURL = msBaseURL + "/raylight/v1/documents";
	
		intialize();
		

	}		
	
	
	/**
	 * This method initialize the BI repository connection
	 * @throws BIUtilException 
	 */
	private void intialize() throws BIUtilException 
	{
		String logonXMLlString = "";
		try
		{
			BIUtilLogMgr.getRunTimeLogger().info("Creating logon token for Restful web service");
			
			
			// -----------------------
			// Logon to Enterprise
			// -----------------------
			logonXMLlString = "<attrs><attr name=\"userName\" type=\"string\" >" + msUsername + "</attr><attr name=\"password\" type=\"string\" >" 
								+ msPassword 
								+ "</attr><attr name=\"auth\" type=\"string\" possibilities=\"secEnterprise,secLDAP,secWinAD,secSAPR3\">" 
								+ msBoAuthType + "</attr></attrs>";
			
			String logonXML = BIUtilCommon.restPost(enableFiddler, msLogonURL, logonXMLlString, "","","","");
			// The quotes are added because the webi URL require quotes around the token
			msLogonToken = "\"" + getLogonTokenFromXML(logonXML) + "\"";

			//System.out.println(msLogonToken);
			
			
		}catch(Exception loExp)
		{
			throw new BIUtilException(BIUtilErrorCodes.E000005, "Error during creating Restful web session");
		}
		
	}

	public void reportMetadata () throws BIUtilException
	{
		Document loDoc = null;
		Document loVarDoc = null;
		try
		{
			String lsReportId;
			String lsReportName;
			String lsParamUrl;
			String lsObjectURL;
			String lsVarIDURL;
			String lsVarURL;
			String lsGetXMLString;
			String lsGetObjectXMLString;
			String lsGetVarIDXMLString;
			String lsGetVarXMLString;
			
			HashMap<String,String> loPrompt = null;
			HashMap<String,String> loVarValue = new HashMap<>();
			
				lsReportId = "6914";
				//WebiReportInfo loInfo = loEntry.getValue();
				
				
				
				lsReportName = "OADM - Document Message Report";
				
				BIUtilLogMgr.getRunTimeLogger().info("Getting Report Count of Document: " + lsReportName,false);
				BIUtilLogMgr.getRunTimeLogger().info("Getting Structure of Report: Report11" ,true);
				lsParamUrl = msBaseWebiURL +  "/" + lsReportId + "/reports/2/specification" ;
				System.out.println(lsParamUrl);
				lsGetXMLString = BIUtilCommon.restTextGet(enableFiddler, lsParamUrl, "X-SAP-LogonToken",msLogonToken, "","");
				//BIUtilLogMgr.getRunTimeLogger().info("Getting Structure information of: " + lsReportName,true);
				//System.out.println(lsGetXMLString);
				
				HashMap<String,String> loStrcuture = processStrutureInformation(lsGetXMLString);
				
				
				lsParamUrl = msBaseWebiURL +  "/" + lsReportId +"/dataproviders";
				System.out.println(lsParamUrl);
				lsGetXMLString = BIUtilCommon.restGet(enableFiddler, lsParamUrl, "X-SAP-LogonToken",msLogonToken, "","");
				System.out.println(lsGetXMLString);
				//getDocumentInformation(lsGetXMLString);
				//System.exit(1);
				try
				{
					if(!lsGetXMLString.contains("<error>") )
					{
					
						setDataProviderID(lsGetXMLString);
						
						
						for (String lsDPId : getDataProviderID())
						{
							lsObjectURL = msBaseWebiURL +  "/" + lsReportId + "/dataproviders/DPd/parameters";
							System.out.println(lsObjectURL);
							lsGetObjectXMLString = BIUtilCommon.restGet(enableFiddler, lsObjectURL, "X-SAP-LogonToken",msLogonToken, "","");
							
							//System.out.println(lsGetObjectXMLString);
						
							//BIUtilLogMgr.getRunTimeLogger().info(lsGetObjectXMLString);
							//System.out.println(lsGetObjectXMLString);
							//System.exit(1);
							
							loDoc = BIUtilCommon.convertStringToDom(lsGetObjectXMLString);
							
							loPrompt =	getPromptDetails(lsGetObjectXMLString);
							System.out.println(loPrompt.size());
						/*	String lsDPName=loDoc.getElementsByTagName("name").item(0).getTextContent();
							
							String lsUnivID = loDoc.getElementsByTagName("dataSourceId").item(0).getTextContent();
							
							
							
							//String lsUnivNm = ((IInfoObject)loObject).getTitle();
							//System.out.println(lsUnivNm);
							
							String lsObjectName = null;
							
							NodeList loNodeList = loDoc.getElementsByTagName("expression"); 
						
							//System.out.println(loNodeList.getLength());
							for(int liCtr = 0 ; liCtr < loNodeList.getLength(); liCtr++)
							{
								Node loParentNode = loNodeList.item(liCtr);
								
								NodeList loNodeLst = loParentNode.getChildNodes();
								
								for(int i =0 ; i< loNodeLst.getLength(); i++)
								{
									Node loNode = loNodeLst.item(i);
									
									if(loNode.getNodeName().equalsIgnoreCase("name"))
									{
										lsObjectName = loNode.getTextContent();
										//BIUtilLogMgr.loadReportObjectMetadataRecord(loInfo.getRptRootFldrNm(), lsReportName, "",lsDPName, lsObjectName);
									}
								}// End for(int i =0 ; i< loNodeLst.getLength(); i++)
									
									
							}// End for(int liCtr = 0 ; liCtr < loNodeList.getLength(); liCtr++)
							*/
						} 
						
						//getting variables details
						lsVarIDURL = msBaseWebiURL +  "/" + lsReportId + "/variables";
						lsGetVarIDXMLString = BIUtilCommon.restGet(enableFiddler, lsVarIDURL, "X-SAP-LogonToken",msLogonToken, "","");
						setVariableID(lsGetVarIDXMLString);
						
						for(String lsVarId:getVariableID())
						{
							lsVarURL = msBaseWebiURL +  "/" + lsReportId + "/variables/"+ lsVarId;
							lsGetVarXMLString = BIUtilCommon.restGet(enableFiddler, lsVarURL, "X-SAP-LogonToken",msLogonToken, "","");
							
							loVarDoc = BIUtilCommon.convertStringToDom(lsGetVarXMLString);
							
							String lsVarName=loVarDoc.getElementsByTagName("name").item(0).getTextContent();
							String lsVarDef=loVarDoc.getElementsByTagName("definition").item(0).getTextContent();
							
							
							ArrayList<String> loVarList = new ArrayList<>();
							loVarList.add(lsVarName);
							System.out.println(lsVarDef);
							if(lsVarDef.contains("Document"))
							{
								
								
								loVarValue.put("Variable - " + lsVarName, lsVarDef.replace("=", ""));
								
							}
							
							//BIUtilLogMgr.loadReportVariableMetadataRecord(loInfo.getRptRootFldrNm(), lsReportName, lsVarName, lsVarDef);
							
						}// End for(String lsVarId:getVariableID())
						
						
					} 	
					else
					 {
						BIUtilLogMgr.getRunTimeLogger().info("Generation failed for report: " + lsReportName,true);
									  
					 }
						
					}catch(Exception loExp)
					{
						BIUtilLogMgr.getRunTimeLogger().error("Error While getting  information of report: " + lsReportName);
						BIUtilLogMgr.getRunTimeLogger().logStackTrace(loExp);
					}
					
					//load data
					
					for (Map.Entry<String, String> entry : loStrcuture.entrySet())
					{
						BIUtilLogMgr.loadReportObjectMetadataRecord("Test", lsReportName, entry.getValue(), entry.getKey(),"");
						
					}
					System.out.println(loPrompt.size());
					for (Map.Entry<String, String> entry : loPrompt.entrySet())
					{
						BIUtilLogMgr.loadReportObjectMetadataRecord("Test", lsReportName, entry.getValue(), entry.getKey(),"");
						
					}
					
					for (Map.Entry<String, String> entry : loVarValue.entrySet())
					{
						BIUtilLogMgr.loadReportObjectMetadataRecord("Test", lsReportName, entry.getKey(), entry.getValue(),"");
						
					}
			
		}catch(Exception loExp)
		{
			throw new BIUtilException (BIUtilErrorCodes.E000017,"Error while retrieving metadata details");
		}
	}
	
	/**
	 * This method will process the structure to identify the impact of any caption change 
	 * @param lsGetXMLString
	 */
	private HashMap<String,String> processStrutureInformation(String fsRptStruture) {
		// TODO Auto-generated method stub
		HashMap<String,String> loMap = new HashMap<String, String>();
		try 
		{
			Document loDoc = BIUtilCommon.convertStringToDom(fsRptStruture);
			
			NodeList loNodeList = loDoc.getElementsByTagName("CONTENT");
			List<String> loList = Arrays.asList(new String[] {"PAGE_HEADER","PAGE_BODY","PAGE_FOOTER"});
			for(int liCtr=0; liCtr<loNodeList.getLength();liCtr++)
			{
				//NodeList loNodeList1 = loNodeList.item(liCtr).getChildNodes();
				String lsValue = loNodeList.item(liCtr).getTextContent();
				Node loPraentNode = null;
				//ignoring object and variable
				
					System.out.println(lsValue);
					String[] laValue = lsValue.split(" ");
					
					for(String lsWord : laValue)
					{
						if(lsWord.equalsIgnoreCase("document") || lsWord.equalsIgnoreCase("docs") ||lsWord.equalsIgnoreCase("doc") )
						{
							System.out.println(lsWord);
							loPraentNode = loNodeList.item(liCtr).getParentNode();
							while (!loList.contains(loPraentNode.getNodeName()))
							{
								loPraentNode = loPraentNode.getParentNode();
							}
							
							if(!lsValue.startsWith("="))
								loMap.put(lsValue, "Structure - " + loPraentNode.getNodeName() );
							//else
								//loMap.put(lsValue, "Object/Variable Structure - " + loPraentNode.getNodeName() );
							break;
						}
					} // end for
					
					
				
				
				
				
				//System.out.println(loMap);
				
				
			}// End For
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return loMap;
	}


	private void getDocumentInformation(String fsDef)
	{
		try
		{
			Document doc = BIUtilCommon.convertStringToDom(fsDef);
			String lsDocFullName = doc.getElementsByTagName("name").item(0).getTextContent();
			//String lsDocPath = doc.getElementsByTagName("path").item(0).getTextContent();
			String lsDocId = lsDocFullName.substring(0,lsDocFullName.indexOf(" "));
			String lsDocNm = lsDocFullName.substring(lsDocFullName.indexOf(" ")+1,lsDocFullName.length());
			String lsDocAutor = doc.getElementsByTagName("createdBy").item(0).getTextContent();
			String lsRefreshOnOpen = doc.getElementsByTagName("refreshOnOpen").item(0).getTextContent();
			
					
			System.out.println("DOC_FULL_NM: "+lsDocFullName);
			System.out.println("APPL_NM: FIN");
			//System.out.println("DOC_PTH: " + lsDocPath);
			System.out.println("DOC_DESC: ");
			System.out.println("DOC_ID: "+lsDocId);
			System.out.println("DOC_NM: "+lsDocNm);
			System.out.println("AUTHOR: "+lsDocAutor);
			System.out.println("CREATION_DATE: "+doc.getElementsByTagName("creationdate").item(0).getTextContent());
			System.out.println("DP_COUNT");
			System.out.println("OBJ_COUNT");
			System.out.println("VAR_COUNT");
			System.out.println("FILTER_COUNT");
			System.out.println("AUTO_MERGE_DIM_FL" + doc.getElementsByTagName("mergeprompts").item(0).getTextContent());
			System.out.println("EXTENDED_MERGE_DIM_VAL_FL: "+  doc.getElementsByTagName("extendmergedimension").item(0).getTextContent());
			System.out.println("MERGE_PRMOPTS_BEX_FL: ");
			System.out.println("REFRESH_ON_OPEN_FL: " + lsRefreshOnOpen);
			System.out.println("ENHANCED_VIEWING_FL: "+ doc.getElementsByTagName("enhancedViewing").item(0).getTextContent());
			System.out.println("HIDE_WARN_CHART_FL");
			System.out.println("QUERY_DRILL_FL: " + doc.getElementsByTagName("querydrill").item(0).getTextContent());
			System.out.println("PERM_REG_FORMAT_FL: "+ doc.getElementsByTagName("permanentregionalformatting").item(0).getTextContent());
			System.out.println("COMMENTS");


		}catch(Exception loExp)
		{
			loExp.printStackTrace();
		}
	}
	
	
	/**
	 * This method refresh the WEBI reports 
	 * @throws BIUtilException 
	 */
	public void refreshReports() throws BIUtilException
	{}// End Report Refresh
		
	

	public void sessionOff() throws Exception
	{
		try
		{
			// Now log off
			String lsLogOffString = BIUtilCommon.restPost(enableFiddler, msLogoffURL, "", "X-SAP-LogonToken",msLogonToken,"","");
			
		}catch(Exception loExp)
		{
			throw new BIUtilException(BIUtilErrorCodes.E000008, "Error Logging off session",loExp);
		}
		
	}
	
	/**
	 * This method purge the data from the report
	 * @param fsPurgeExcList 
	 * @throws BIUtilException 
	 */
	public void PurgeReport(String fsPurgeExcList) throws BIUtilException
	{}
	
	
	public void scheduleReports(String fsRptSchdFormat, String fsRptSchdDest) 
	{}
			 
	
	

	public HashMap<String,String> getPromptDetails(String fsPromptDetails) throws Exception
	{
		
		// TODO Auto-generated method stub
				HashMap<String,String> loMap = new HashMap<String, String>();
				try 
				{
					Document loDoc = BIUtilCommon.convertStringToDom(fsPromptDetails);
					
					NodeList loNodeList = loDoc.getElementsByTagName("name");
					List<String> loList = Arrays.asList(new String[] {"PAGE_HEADER","PAGE_BODY","PAGE_FOOTER"});
					for(int liCtr=0; liCtr<loNodeList.getLength();liCtr++)
					{
						//NodeList loNodeList1 = loNodeList.item(liCtr).getChildNodes();
						String lsValue = loNodeList.item(liCtr).getTextContent();
						//Node loPraentNode = null;
						
						//System.out.println(lsValue);
						String[] laValue = lsValue.split(" ");
							
						for(String lsWord : laValue)
						{
								if(lsWord.equalsIgnoreCase("document") || lsWord.equalsIgnoreCase("docs") ||lsWord.equalsIgnoreCase("doc") )
								{
									System.out.println(lsWord);
									Element loPraentNode = (Element) loNodeList.item(liCtr).getParentNode();
									
									if(loPraentNode.getAttribute("type").equalsIgnoreCase("prompt"));
									{
										loMap.put(lsValue, "Prompt");
									}
									break;
								}
						} // end for
							
						
						System.out.println(loMap);
						
						
					}// End For
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return loMap;
	}
	
	/**
	 * This method return the data provider ID's of the report
	 * @return
	 */
	private ArrayList<String> getDataProviderID()
	{
		return moDataProvideIDList;
	}
	
	/**
	 * This method return the data provider ID's of the report
	 * @return
	 */
	private ArrayList<String> getVariableID()
	{
		return moVariableIDList;
	}
	
	/**
	 * This method return the data provider ID's of the report
	 * @return
	 * @throws Exception 
	 */
	private void setDataProviderID(String lsDPText) throws Exception
	{
		moDataProvideIDList = new ArrayList<String>();
		
		Document loDoc = BIUtilCommon.convertStringToDom(lsDPText);
		
		// Now Loop through all the dataprovider nodes that were returned
		// It is assumed that each dataprovider node will only have one ID tag
		NodeList loDPNodes = loDoc.getElementsByTagName("id");
		  
		for (int liCtr = 0; liCtr < loDPNodes.getLength(); liCtr++) {
			  Element loDPElement = (Element) loDPNodes.item(liCtr);
			  
			  // Get the string value
			  String loDPId = (String)loDPElement.getTextContent();
			  moDataProvideIDList.add(loDPId);
		}
		
	}
	
	/**
	 * This method return the data provider ID's of the report
	 * @return
	 * @throws Exception 
	 */
	private void setVariableID(String lsText) throws Exception
	{
		moVariableIDList = new ArrayList<String>();
		moVarIdMap = new LinkedHashMap<String, String>();
		Document loDoc = BIUtilCommon.convertStringToDom(lsText);
		
		// Now Loop through all the dataprovider nodes that were returned
		// It is assumed that each dataprovider node will only have one ID tag
		NodeList loDPNodes = loDoc.getElementsByTagName("id");
		  
		for (int liCtr = 0; liCtr < loDPNodes.getLength(); liCtr++) {
			  Element loDPElement = (Element) loDPNodes.item(liCtr);
			  
			  // Get the string value
			  String loDPId = (String)loDPElement.getTextContent();
			  moVariableIDList.add(loDPId);
		}
		
		
		
		
		
	}
	

	
	
	
	
	
	
	/**
	 * This method extract the logon token 
	 * @param xmlString
	 * @return
	 * @throws Exception
	 */
	private String getLogonTokenFromXML(String xmlString) throws Exception {
		Document doc = BIUtilCommon.convertStringToDom(xmlString);
		NodeList nodes = doc.getElementsByTagName("attr");

		for (int i = 0; i < nodes.getLength(); i++) {
		  Element element = (Element) nodes.item(i);
		  
		  // Is this the correct XML token
		  if (element.getAttribute("name").equals("logonToken")) {
		   return(element.getTextContent());
		  }
		}
		return("");
		}
	
	
	
	public static void writeStringToFile(String fsString, String lsFilePth) throws IOException
	{
		FileWriter loWriter = null;
		try 
		{
			 loWriter = new FileWriter(lsFilePth);
			 loWriter.write(fsString);
			 loWriter.flush();
		} catch (IOException e) {
			System.err.println("Error writing in file");
			e.printStackTrace();
		}finally
		{
			if (loWriter != null)
			{
				loWriter.close();
			}
		}
	}
	
	private String getErrorCodeDetails(String fsXML){
		
		int liErrorStartIndex = fsXML.indexOf(BIUtilConstant.ERROR_STRING_START) + BIUtilConstant.ERROR_STRING_START.length();
		int liErrorEndIndex = fsXML.indexOf(BIUtilConstant.ERROR_STRING_END);
		
		String lsErrorCode = fsXML.substring(liErrorStartIndex,liErrorEndIndex);

		return lsErrorCode;
	}
		
		private String getErrorMessageDetails(String fsXML){
			
			int liMessagestartIndex = fsXML.indexOf(BIUtilConstant.MESSAGE_STRING_START) + BIUtilConstant.MESSAGE_STRING_START.length();;
			int liMessageEndIndex = fsXML.indexOf(BIUtilConstant.MESSAGE_STRING_END);;
			
			String lsMessage = fsXML.substring(liMessagestartIndex,liMessageEndIndex);

			return lsMessage;
		}


		public void deployWebiReports(File foFile) 
		{
			try
			{
				BIUtilLogMgr.getRunTimeLogger().info("Deploying Report: " + foFile.getName(),true);
				
				String lsdeployUrl = msBaseURL +  "/infostore/folder/28090/file"  ;
				
				System.out.println(lsdeployUrl);
				
				//String lsPostXMLString = BIUtilCommon.restPostFile(enableFiddler, lsdeployUrl, foFile, "X-SAP-LogonToken",msLogonToken,"","");
				
				//System.out.println(lsPostXMLString);
					
			}catch(Exception loExp)
			{
				loExp.printStackTrace();
			}
			
		}
	
}
