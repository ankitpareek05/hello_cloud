package com.amsinc.psg.BIUtil.ErrorHandler;



	public class BIUtilException extends Exception
	{

		
		/* Stores a error */
		private BIUtilErrorCodes  moError = null;
		
		/* Stores a error detail */
		private String  msErrorDetail = null;

		/* Stores a error cause */
		private Throwable  moCause = null;
		
		/* Stores a thread name which raised the Exception */
		private String  moThreadName = null;
		

	   /**
	    * Constructor for FrameworkException.
	    */
	   public BIUtilException(BIUtilErrorCodes foError, String fsErrorDetail,Throwable foCause)
	   {
		   moError = foError;
		   msErrorDetail = fsErrorDetail;
		   moCause = foCause;
		   moThreadName = Thread.currentThread().getName();

	   }
	   
	   /**
	    * Constructor for FrameworkException.
	    */
	   public BIUtilException(BIUtilErrorCodes foError, String fsErrorDetail)
	   {
		   moError = foError;
		   msErrorDetail = fsErrorDetail;
		   moThreadName = Thread.currentThread().getName();

	   }
	   
	   /**
	    * Returns an error code for this message
	    * @return error_code Error code for this exception
	    */
	   public String getErrorCode()
	   {
	      return moError.toString();
	   }

	   /*
	    * Returns an error message for this exception
	    */
	   public String getMessage()
	   {

	      return moError.getErrorMessage();
	   }
	   
	   /*
	    * Returns an error message for this exception
	    */
	   public String getErrorDetail()
	   {

	      return msErrorDetail;
	   }
	   
	   /*
	    * Returns an error cause for this exception
	    */
	   public Throwable getCause()
	   {

	      return moCause;
	   }

	}


