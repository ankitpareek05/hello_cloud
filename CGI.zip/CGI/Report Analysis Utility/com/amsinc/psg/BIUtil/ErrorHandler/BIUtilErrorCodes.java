package com.amsinc.psg.BIUtil.ErrorHandler;

public enum BIUtilErrorCodes
{
	/*
	 * Codes for Errors/Exception that can cause Utility Execution Failure	 *
	 */
	E000001 ("Error Encountered"),
	E000002 ("Error initializing the log base folder, and build all the necessary sub folders"),
	E000003 ("Error opening file"),
	E000004 ("Error in utility configuration"),
	E000005 ("Error creating logon token"),
	E000006 ("Error Refreshing Reports"),
	E000007 ("Error While Refreshing Report"),
	E000008 ("Error closing BI Session"),
	E000009 ("Error while preparing XML"),
	E000010 ("Error writing to file"),
	E000011 ("Error opening Writer"),
	E000012 ("Error opening Reader"),
	E000013 ("Error Closing Reader"),
	E000014 ("Invalid File/Directory path"),
	E000015 ("Error opening BI Session"),
	E000016 ("Error retrieving from CMC"),
	E000017 ("Error while retrieving Metadata from report"),

	//Scheduling Error Message
	S000001 ("Prompt Value/Values is/are incorrect in spreadsheet"),;


	private String msErrorMessage;
	private BIUtilErrorCodes(String fsErrorMessage)
	{
		msErrorMessage = fsErrorMessage;
	}

	public String getErrorMessage()
	{
		return msErrorMessage;
	}

}


