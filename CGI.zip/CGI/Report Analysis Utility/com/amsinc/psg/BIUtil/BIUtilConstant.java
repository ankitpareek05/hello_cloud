package com.amsinc.psg.BIUtil;

public final class BIUtilConstant
{
	
	public static final String CMS_NAME = "LCM_CMS";
	public static final String CMS_USERNAME = "LCM_USERNAME";
	public static final String CMS_PASSWORD = "LCM_PASSWORD";
	public static final String REPORT_FOLDER_NAME = "REPORT_FOLDER_NAME";
	public static final String REPORT_NAME = "REPORT_NAME";
	public static final String SOURCE_UNIVERSE_FOLDER = "SOURCE_UNIVERSE_FOLDER";
	public static final String DESTINATION_UNIVERSE_FOLDER = "DESTINATION_UNIVERSE_FOLDER";
	public static final String REPORT_PROMPT_FILE_PATH = "REPORT_PROMPT_FILE_PATH";
	public static final String REPORT_EXCLUSION_LIST_PURGE = "EXCLUDED_REPORTS_PURGE";
	public static final String REPORT_SCHEDULE_FORMAT = "REPORT_SCHEDULE_FORMAT";
	public static final String REPORT_SCHEDULE_DESTINATION = "REPORT_SCHEDULE_DESTINATION";
	
	public static final String FOLDER_NAME_TOKEN = "<<FLDR_NM>>";
	public static final String UNIVERSE_ID_TOKEN = "<<UNIV_ID>>";
	
	public static final String CONFIG_FOLDER = "config";
	public static final String CONFIG_FILE_NM = "BIUtilConfig.properties";
	
	public static final String ALL_STEPS = "-all";
	public static final String REPORT_REFRESH = "-r";
	public static final String REPORT_PURGE = "-p";
	public static final String CHANGE_SOURCE = "-c";
	public static final String DEPLOY_REPORT = "-d";
	public static final String SCHEDULE_REPORT = "-s";
	public static final String GENERATE_REPORT_EXCEL = "-g";
	public static final String SCHEDULE_HISTORY = "-h";
	public static final String GENERATE_METADATA = "-m";
	
	public static final String EXCEL_SHEET_NAME = "Report_Prompt_Information";
	
	public static final String PROMPT_TEXT = "PROMPT_TEXT";
	public static final String PROMPT_OPTIONAL_PROPERTY = "ISOPTIONAL";
	public static final String PROMPT_RESPONSE_TYPE = "RESPONSE_TYPE";
	public static final String PROMPT_TYPE = "PROMPT_TYPE";
	public static final String PROMPT_VALUE = "PROMPT_VALUE";
	
	public static final String ERROR_STRING_START = "<error_code>";
	public static final String ERROR_STRING_END = "</error_code>";
	public static final String MESSAGE_STRING_START = "<message>";
	public static final String MESSAGE_STRING_END = "</message>";
	
	public static final String REPORT_FLDR_NAME = "Report";
	
	 /* Stores CR-LF style line endings */
    public static final String NEWLINE = new String(new char[]{(char)0x0D,(char)0x0A});
   
    
    /* Field delimiters used in CSV files.
     */
    public static final char FIELD_DELIMITER = '"';
    public static final char FIELD_SEPARATOR = ',';
    
    //ScheduleError
    
	
}
