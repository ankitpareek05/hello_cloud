package com.amsinc.psg.BIUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.List;



/**
 * DelimitedCSVFileWriter prints String arrays into a  CSV file format.
 * <br><br>
 * 
 *
 */
public class DelimitedCSVFileWriter
{
	private static final int DEFAULT_BUFFER_SIZE=0;
	private String msFileAbsolutePath;

	private PrintWriter moWriter;

	private String[] maHeaderColumns;

	private int miNumberOfCols;

		private boolean mboolIsOpen;

	private int miBufferSize = DEFAULT_BUFFER_SIZE;
	
	private boolean mboolAppendMode = false;
	
	private String msFieldDelimiter = new String(new char[] {BIUtilConstant.FIELD_DELIMITER} );
	private String msEscapedFieldDelimiter =
		new String(new char[] {
				BIUtilConstant.FIELD_DELIMITER,
				BIUtilConstant.FIELD_DELIMITER} );
	
	/**
	 * Construct a DelimitedAsciiFileWriter to output to an ASCII file with standard PDI-friendly formatting
	 *
	 * @param fsFileAbsolutePath Absolute file path to the target file
	 */
	public DelimitedCSVFileWriter(String fsFileAbsolutePath, boolean fbAppendMode) throws IOException
	{
		msFileAbsolutePath = fsFileAbsolutePath;
		mboolIsOpen = false;
		mboolAppendMode = fbAppendMode;
	}
	
	/**
	 * Gets the size of the record buffer (in # of records)
	 * @return the buffer size (in # of records)
	 */
	public int getBufferSize()
	{
		return miBufferSize;
	}
	
	/**
	 * Sets the size of the record buffer (in # of records)
	 * @param fiBufferSize new buffer size (in # of records)
	 */
	public void setBufferSize(int fiBufferSize)
	{
		miBufferSize=fiBufferSize;
	}

	/**
	 * Write out a line to the output file.  This method safe for multi-threaded access,
	 * but it does not guarantee the records will be written in any particular
	 * order.
	 * @param faFieldArray Array of string values to be written out to the file
	 */
	public List<String[]> putRecord(String[] faFieldArray) throws Exception
	{

		char[] laOutputLine = buildOutputLine(faFieldArray);
		
		synchronized (moWriter)
		{
			if (!mboolIsOpen)
			{
				throw new Exception("File reader is not open");
			}
			
			moWriter.write(laOutputLine);
		}

		return null;
	}


	/**
	 * translates the array of strings into a line of text ready to be written to the
	 * output stream
	 * @param faFieldArray array of strings that comprise the output values
	 * @return
	 */
	private char[] buildOutputLine(String[] faFieldArray) throws Exception
	{
		if (faFieldArray.length != maHeaderColumns.length)
		{
			throw new Exception("Incorrect number of fields in output record");
		}
		
		StringBuffer lsbOutputLine = new StringBuffer();

		for (int liItr = 0; liItr < miNumberOfCols; ++liItr)
		{
			String lsCurrentField = faFieldArray[liItr] == null ? "" : faFieldArray[liItr];
			if (lsCurrentField.indexOf('"') != -1)
			{
				lsCurrentField = lsCurrentField.replaceAll(msFieldDelimiter, msEscapedFieldDelimiter);
			}
			lsbOutputLine.append('"');
			lsbOutputLine.append( lsCurrentField );
			lsbOutputLine.append('"');
			if (liItr < miNumberOfCols - 1)
			{
				lsbOutputLine.append(',');
			}
		}
		lsbOutputLine.append(BIUtilConstant.NEWLINE);
		char[] laOutputLine = lsbOutputLine.toString().toCharArray();
		return laOutputLine;
	}

	/**
	 * Close the writer
	 */
	public synchronized List<String[]> closeTarget() throws Exception
	{
		if (mboolIsOpen)
		{
			synchronized(moWriter)
			{
				moWriter.close();
				if (moWriter.checkError())
				{
					throw new Exception ("I/O error encountered writing to file " + msFileAbsolutePath);
				}
				mboolIsOpen = false;
				moWriter.notifyAll();
			}
		}
		return null;
	}

	
	public synchronized void openTarget(String[] faHeaderColumns) throws Exception
	{
		if (!mboolIsOpen)
		{
			try
			{
				File loFile = new File(msFileAbsolutePath);
				
				if(loFile.exists())
				{
					loFile.delete();
				}
					
				moWriter = new PrintWriter(new BufferedWriter(
						new FileWriter(msFileAbsolutePath, mboolAppendMode)));
			}
			catch (IOException loExp)
			{
				throw new Exception("Error opening file writer for: " + msFileAbsolutePath, loExp);
			}
			maHeaderColumns = (String[])faHeaderColumns.clone();
			miNumberOfCols = maHeaderColumns.length;
			
			synchronized(moWriter)
			{
				mboolIsOpen = true;
				putRecord(faHeaderColumns);
			}
		}
	}

	
	/**
	 * Force flushing the output stream to disk
	 */
	public void flush()
	{
		moWriter.flush();
	}

	/**
	 * Check the error status of the underlying output stream.
	 *
	 * @return true if any I/O errors have been encountered, otherwise returns false
	 */
	public boolean checkError()
	{
		return moWriter.checkError();
	}
}
