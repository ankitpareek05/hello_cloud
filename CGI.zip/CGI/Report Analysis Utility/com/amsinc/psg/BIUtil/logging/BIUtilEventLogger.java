package com.amsinc.psg.BIUtil.logging;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import org.apache.log4j.PropertyConfigurator;

import com.amsinc.psg.BIUtil.BIUtilConstant;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilErrorCodes;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilException;



/**
 * Logs events during a session.
 *
 * @author shivansh.saxena
 */
public class BIUtilEventLogger
{
   /**
    * Log4J Logger for this class
    */
   private static final Logger logger= Logger.getRootLogger();

   /**
    * Maximum recursive depth of error logging
    */
   private static final int MAX_ERROR_CAUSE_DEPTH=25;

   public BIUtilEventLogger()
   {
   }

   /**
    * Adds an information event.
    *
    * @param fsDescription The event description - required
    */
   public final void info(String fsDescription)
   {
      info(fsDescription,false);
   } // info
   
   /**
    * Adds an information event.
    *
    * @param fsDescription The event description - required
    */
   public final void info(String fsDescription,boolean fBoolDisplayOnConsole)
   {
	   if(fBoolDisplayOnConsole)
	     System.out.println(fsDescription); 
		   
	  if (logger.isInfoEnabled())
      {
         logger.info(fsDescription);
      }
   } // info


   /**
    * Adds an warn event.
    *
    * @param loExp
    */
   public final void warning(BIUtilException foFExp)
   {
	   if (logger.isEnabledFor(Priority.WARN))
	   {
		   String lsDescription = getFormattedErrorMsg(foFExp);
		   logger.warn(lsDescription);

       }
   } // warning

   /**
    * Adds a warning event.
    *
    * @param fsDescription The event description - required
    */
   public final void warning(String fsDescription)
   {
      if (logger.isEnabledFor(Priority.WARN))
      {
         logger.warn(fsDescription);
      }
   } // warning

   /**
    * Adds an error event.
    *
    * @param loExp
    */
   public final void error(BIUtilException foFExp)
   {
	   if (logger.isEnabledFor(Priority.ERROR))
	   {
		   String lsDescription = getFormattedErrorMsg(foFExp);
		   logger.error(lsDescription);
       }
   } // error

   /**
    * Adds an error event.
    *
    * @param fsDescription The event description - required
    */
   public final void error(String fsDescription)
   {
      if (logger.isEnabledFor(Priority.ERROR))
      {
    	 String lsDescription = BIUtilErrorCodes.E000001 + ": " + fsDescription;
         logger.error(lsDescription);

      }

   } // error

   /**
    * Adds an fatal event.
    *
    * @param loExp
    */
   public final void fatal(BIUtilException foFExp)
   {
	   if (logger.isEnabledFor(Priority.FATAL))
	   {
		   String lsDescription = getFormattedErrorMsg(foFExp);
		   logger.fatal(lsDescription);

		   String lsStartDate = (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss")).format(new Date());

       }
   } // fatal

   /**
    * Adds an fatal event.
    *
    * @param fsDescription The event description - required
    */
   public final void fatal(String fsDescription)
   {
      if (logger.isEnabledFor(Priority.FATAL))
      {
    	 String lsDescription = BIUtilErrorCodes.E000001 + ": " + fsDescription;
         logger.fatal(lsDescription);

      }

   } // error

   /**
    * Adds a debug event
    *
    * @param fsDescription The event description - required
    */
   public final void debug(String fsDescription)
   {
      if (logger.isDebugEnabled())
      {
         logger.debug(fsDescription);
      }
   } // debug


   /**
    * Adds a trace event.
    *
    * @param fsDescription The event description - required
    */
    public final void trace(String fsDescription)
    {
       if (logger.isTraceEnabled())
       {
          logger.trace(fsDescription);
       }

    } // trace



   /**
    * Logs the stack trace from the provided exception in debug mode
    * @param loExp Exception for which the stack trace will be logged
    */
   public final void logStackTrace(Throwable foExp)
   {
   	synchronized(logger)
   	{
   	   	int liExceptionsLogged = 0;
   	   	Throwable loCurrentException = foExp;
   	   	StringBuffer lsbStackTrace = new StringBuffer();
   	   	while (liExceptionsLogged++ < MAX_ERROR_CAUSE_DEPTH && loCurrentException != null)
   	   	{
   		   	if (liExceptionsLogged > 1)
   		   	{
   		   		lsbStackTrace.append(BIUtilConstant.NEWLINE + "Caused by:" + BIUtilConstant.NEWLINE);
   		   	}
   		   	lsbStackTrace.append(loCurrentException.getMessage());
   		   	if (loCurrentException instanceof BIUtilException)
   		   	{
   		   		lsbStackTrace.append(": ").append(((BIUtilException)loCurrentException).getErrorDetail());
   		   	}

   	   		lsbStackTrace.append(BIUtilConstant.NEWLINE);
   		   	//Log the stack trace
   		   	lsbStackTrace.append(" [");
   		   	StackTraceElement[] laStackTrace = loCurrentException.getStackTrace();
   		   	for (int liItr =0; liItr < laStackTrace.length; ++liItr)
   		   	{
   		   		lsbStackTrace.append(laStackTrace[liItr].toString());
   		   		if(liItr != (laStackTrace.length - 1))
   		   			lsbStackTrace.append(BIUtilConstant.NEWLINE + " ");
   		   	}
   		   	lsbStackTrace.append("]");
   		   	loCurrentException = loCurrentException.getCause();
   	   	}

   	   	logger.debug(lsbStackTrace.toString());

   	   	if (liExceptionsLogged >= MAX_ERROR_CAUSE_DEPTH && loCurrentException != null)
   	   	{
   	   		logger.debug("... additional causes found for this exception but are not being logged "
   	   				+ "because the maximum of " + MAX_ERROR_CAUSE_DEPTH
   	   				+ " has been exceeded");
   	   	}

   	} // synchronized(logger)

   }
   /**
    * Returns the message in a standard format
    * TopLevelMessage + NEWLINE + MostSpecificErrCode: + MostSpecificErrMsg + MostSpecificErrDetails.
    * @param foFExp
    * @return
    */
   private final String getFormattedErrorMsg(BIUtilException foFExp)
   {
	   StringBuffer lsbDescription = new StringBuffer();

		   //Store values of topmost exception
		   BIUtilException loLowestfwExp = foFExp;
		   String lsTopLevelMsg = loLowestfwExp.getMessage();

		   //Iterate to the lowest (most specific) BIUtilException
		   Throwable loThrow = loLowestfwExp;
		   while (loThrow.getCause() != null)
		   {
			   loThrow = loThrow.getCause();
			   if (loThrow instanceof BIUtilException)
				   loLowestfwExp = (BIUtilException)loThrow;
		   }
		   String lsDetail = loLowestfwExp.getErrorDetail();
		   /*while (fwExp.getCause() instanceof BIUtilException)
			   fwExp = (BIUtilException)fwExp.getCause();*/

		   //Store values of lowest exception
		   String lsErrorCode = loLowestfwExp.getErrorCode();

		   if (lsDetail != null)
			   lsbDescription.append(lsTopLevelMsg).append(BIUtilConstant.NEWLINE).append(
					    lsErrorCode).append(": ").append(loLowestfwExp.getMessage()).append(": ").append(lsDetail);
		   else
			   lsbDescription.append(lsTopLevelMsg).append(BIUtilConstant.NEWLINE).append(
					    lsErrorCode).append(": ").append(loLowestfwExp.getMessage());


	   return lsbDescription.toString();

   }

   public String isDebugEnabled(){
	   if(logger.isDebugEnabled()){
		   return "Yes";
	   }
	   else{
		   return "No";
	   }
   }

} /* of class EventLogReport */

