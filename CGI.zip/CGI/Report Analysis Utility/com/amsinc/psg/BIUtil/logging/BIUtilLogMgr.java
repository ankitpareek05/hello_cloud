package com.amsinc.psg.BIUtil.logging;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.File;
import java.io.IOException;


import com.amsinc.psg.BIUtil.BIUtilConstant;
import com.amsinc.psg.BIUtil.DelimitedCSVFileWriter;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilErrorCodes;
import com.amsinc.psg.BIUtil.ErrorHandler.BIUtilException;




/**
 * Log manager class.  A number of different types of logs are generated through
 * the framework / toolkit.
 *
 * 
 */
public class BIUtilLogMgr
{
   private static boolean mboolInitialized= false;

   /**
    * Log4J Logger for this class - Using Root logger for this
    *
    */
   private static final Logger logger= Logger.getRootLogger();

   /*
    * The runtime logger
    */
   	 public static BIUtilEventLogger moRunTimeLogger= null;
   	 
   	 
   	 //ScheduleWriter
   	public static DelimitedCSVFileWriter moScheduleInstanceWriter = null;
    
   	//schedule history writer
   	public static DelimitedCSVFileWriter moScheduleHistoryWriter = null;
   	
	//Refresh writer
   	public static DelimitedCSVFileWriter moRefreshWriter = null;
   
  //Refresh writer
   	public static DelimitedCSVFileWriter moPurgeWriter = null;
   
  //Report Metadata writer
   	public static DelimitedCSVFileWriter moObjectWriter = null;
   	public static DelimitedCSVFileWriter moVariableWriter = null;
   	public static DelimitedCSVFileWriter moReportDefWriter = null;
   	
   	
   	//CSV File Names
 	private static final String CSV_SCHED_INST = "Schedule_Instance_Detail.csv";
 	private static final String CSV_SCHED_HIST = "Schedule_History_Detail.csv";
 	private static final String CSV_RPT_REFRESH = "Refresh_Detail.csv";
 	private static final String CSV_RPT_PURGE = "Purge_Detail.csv";
 	private static final String CSV_RPT_Object_List = "Report_Detail.csv";
 	private static final String CSV_RPT_Variable_List = "Variable_Detail.csv";
 	private static final String CSV_RPT_Def_List = "Report_Def_Detail.csv";
 	
 	//private static final String CSV_STAT = "ETL_RUN_STATS-FW_Logs.csv";
 	//private static final String CSV_REJREC = "ETL_RUN_REJ_RECS-FW_Logs.csv";
 	//private static final String CSV_STUBREC = "ETL_RUN_STUB_RECS-FW_Logs.csv";
     

   /**
    * Initialize the log base folder, and build all the necessary sub folders.
    * fsLogBaseFolderName should be an absolute path, i.e. c:\\report.
    *
    * @param fsETLHomeDir The base folder path at which the logs are
    * located
    * @throws DWKitException
    */
   public static final void initLogMgr(String fsMetadataHomeDir)
      throws IOException, BIUtilException
   {
	try
	{
	
   	String lsLogPropFilePath;
   	File loHomeDirFile= new File(fsMetadataHomeDir);
   	File loLogPropFile;

   		lsLogPropFilePath=
   			loHomeDirFile.getAbsolutePath()
            	+ File.separatorChar
            	+ "config"
            	+ File.separatorChar
            	+ "log4j.properties";
//   	}

      loLogPropFile= new File(lsLogPropFilePath);
      
      /*
       * Otherwise if the default log properties file is found,
       * continue with that.
       */
   	if (loLogPropFile.exists())
      {
         PropertyConfigurator.configureAndWatch(lsLogPropFilePath, 30000);
      } //if (loLogPropFile.exists())
      else
      {
         // Set up a simple configuration that logs on the console.
         BasicConfigurator.configure();
      }

   	BIUtilLogMgr.getRunTimeLogger().debug("Initialize the log base folder, and build all the necessary sub folders.");
      logger.info(
         "-------------------------------------------------------------------"
            + BIUtilConstant.NEWLINE);
      logger.info("Logger initialized...");
      
	}
	catch(Exception e)
	{
		throw new BIUtilException(BIUtilErrorCodes.E000002, e.getMessage() , e);
	}

   } //initLogMgr

   public static void intializeCSVLogFiles(String fsMetadataHomeDir,char fsValue) throws Exception
   {
	  
	   switch (fsValue)
	   {
	   	case 's': 
	   	 
	   		if(moScheduleInstanceWriter == null)
	   		{
	   			moScheduleInstanceWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
	 				   File.separator + CSV_SCHED_INST,true);
	 		   
	 		   moScheduleInstanceWriter.openTarget(new String[] {"FOLDER_NAME","REPORT_NAME","SCHEDULING_INSTANCE_CREATED?","ERROR"});
	 		   
	   		}
	   		break;
		   
	   	case 'h': 
	   		
	   		if(moScheduleHistoryWriter == null)
	   		{
	   			moScheduleHistoryWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
						   File.separator + CSV_SCHED_HIST,true);
				   
		   		moScheduleHistoryWriter.openTarget(new String[] {"FOLDER_NAME","REPORT_NAME","SCHEDULE_STATUS","SCHEDULE_START_TIME","SCHEDULE_END_TIME","DURATION(sec)","CREATED_BY","TYPE","PARAMETERS","ERROR"});
			}
	   		
	   		   break;
			   
	   	case 'r': 
	   		
	   		if(moRefreshWriter == null)
	   		{
	   			moRefreshWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
						   File.separator + CSV_RPT_REFRESH,true);
				   
		   		moRefreshWriter.openTarget(new String[] {"FOLDER_NAME","REPORT_NAME","REFRESH_STATUS","REFRESH_TIME(Seconds)","ERROR_ID","ERROR_MSG"});
				   
	   		}
	   		break;
	   		
	   	case 'p': 
	   		
	   		if(moPurgeWriter == null)
	   		{
	   			moPurgeWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
						   File.separator + CSV_RPT_PURGE,true);
				   
	   			moPurgeWriter.openTarget(new String[] {"FOLDER_NAME","REPORT_NAME","PURGE_STATUS","ERROR_ID","ERROR_MSG"});
				  
	   		}
	   	    break;
	   	    
       case 'm': 
	   		
	   		if(moObjectWriter == null)
	   		{
	   			moObjectWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
						   File.separator + CSV_RPT_Object_List,true);
				   
	   			moObjectWriter.openTarget(new String[] {"FOLDER_NAME","REPORT_NAME","COMPONENT","VALUE","COMPONENT_ADD_DETAIL"});
				  
	   		}
	   		
	   		if(moVariableWriter == null)
	   		{
	   			moVariableWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
						   File.separator + CSV_RPT_Variable_List,true);
				   
	   			moVariableWriter.openTarget(new String[] {"FOLDER_NAME","REPORT_NAME","VARIABLE_NAME","VARIABLE_DEFINATION"});
				  
	   		}
	   		
	   		if(moReportDefWriter == null)
	   		{
	   			moReportDefWriter = new DelimitedCSVFileWriter(fsMetadataHomeDir + File.separator + "logs" +
						   File.separator + CSV_RPT_Def_List,true);
				   
	   			moReportDefWriter.openTarget(new String[] {"DOC_NM","APPL_NM","DOC_PTH","DOC_DESC","DOC_ID","AUTHOR","CREATION_DATE","DP_COUNT","OBJ_COUNT","RPT_COUNT","AUTO_MERGE_DIM_FL","EXTENDED_MERGE_DIM_VAL_FL",
	   					                "MERGE_PRMOPTS_BEX_FL","REFRESH_ON_OPEN_FL","ENHANCED_VIEWING_FL","HIDE_WARN_CHART_FL","QUERY_DRILL_FL","PERM_REG_FORMAT_FL","COMMENTS"});
				  
	   		}
	   		
	   		
	   	    break;
	   	    
	   } // End Switch
	   
	  
   }
   
   /**
    * Returns the runtime logger object
    * @return The runtime logger
    */
   public static BIUtilEventLogger getRunTimeLogger()
   {

      if (moRunTimeLogger == null)
      {
         moRunTimeLogger= new BIUtilEventLogger();
      } //if (moRunTimeLogger ==null)
      return moRunTimeLogger;
   }

   
   /**
    * Write the record in csv
    * @param fsFolderName
    * @param fsReportName
    * @param fsSchInstStatus
    * @param fsError
    */
   public static synchronized void loadScheduleRunStatRecord(String fsFolderName, String fsReportName, String fsSchInstStatus, 
			   String fsError)
	{
	   try 
	   {
	   //Populate CSV file
	 		String laRecValues[] = {fsFolderName,fsReportName,fsSchInstStatus,fsError};
	   		
				if (moScheduleInstanceWriter != null)
					BIUtilLogMgr.moScheduleInstanceWriter.putRecord(laRecValues);
				else
					throw new Exception("Log File Objects not initialized");

		}
		catch (Exception loExp)
		{
			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
		}

	
	}

   /**
    * Write the record in csv
    * @param fsFolderName
    * @param fsReportName
    * @param fsSchInstStatus
    * @param fsError
    */
   public static synchronized void loadScheduleHistoryStatRecord(String fsFolderName, String fsReportName, String fsSchdStatus,String fsSchdStartTime,String fsSchdEndTime,String fsDuration, String fsUser,String fsSchdTyp
			   , String fsPrompts,String fsError)
	{
	   try 
	   {
	   //Populate CSV file
	 		String laRecValues[] = {fsFolderName,fsReportName,fsSchdStatus,fsSchdStartTime,fsSchdEndTime,fsDuration,fsUser,fsSchdTyp,fsPrompts,fsError};
	   		
				if (moScheduleHistoryWriter != null)
					BIUtilLogMgr.moScheduleHistoryWriter.putRecord(laRecValues);
				else
					throw new Exception("Log File Objects not initialized");

		}
		catch (Exception loExp)
		{
			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
		}

	
	}
   
   /**
    * Write the record in csv
    * @param fsFolderName
    * @param fsReportName
    * @param fsSchInstStatus
    * @param fsError
    */
   public static synchronized void loadReportRefreshStatRecord(String fsFolderName, String fsReportName, String fsRefreshStatus,String fsTime,String fsErrorId, String fsErroMsg)
	{
	   try 
	   {
		   //Populate CSV file
	 		String laRecValues[] = {fsFolderName,fsReportName,fsRefreshStatus,fsTime,fsErrorId,fsErroMsg};
	   		
				if (moRefreshWriter != null)
					BIUtilLogMgr.moRefreshWriter.putRecord(laRecValues);
				else
					throw new Exception("Log File Objects not initialized");

		}
		catch (Exception loExp)
		{
			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
		}

	
	}
   
   /**
    * Write the record in csv
    * @param fsFolderName
    * @param fsReportName
    * @param fsSchInstStatus
    * @param fsError
    */
   public static synchronized void loadReportPurgeStatRecord(String fsFolderName, String fsReportName, String fsRefreshStatus,String fsErrorId, String fsErroMsg)
	{
	   try 
	   {
	   //Populate CSV file
	 		String laRecValues[] = {fsFolderName,fsReportName,fsRefreshStatus,fsErrorId,fsErroMsg};
	   		
				if (moPurgeWriter != null)
					BIUtilLogMgr.moPurgeWriter.putRecord(laRecValues);
				else
					throw new Exception("Log File Objects not initialized");

		}
		catch (Exception loExp)
		{
			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
		}

	
	}
   
   /**
    * Write the record in csv
    * @param fsFolderName
    * @param fsReportName
    * @param fsDPName
    * @param fsObjectName
    */
   public static synchronized void loadReportDefMetadataRecord(String fsReportName, String fsAplNm,String fsRptPth, String fsRptDesc,String fsRptId, String fsAuthor, String fsCreaDate, String fsDpCount,
		   															String fsRptObjCount,String fsRptCount, String fsAutoMergeFl, String fsExtMereFl, String fsMergPrompt, String fsRefOnOpen, String fsEnh, String fsHideCharFl
		   															, String fsQueryDrill, String fsPerRgFrmFl,String fsComment )
	{
	   try 
	   {
	   //Populate CSV file
	 		String laRecValues[] = {fsReportName, fsAplNm,fsRptPth, fsRptDesc,fsRptId, fsAuthor, fsCreaDate, fsDpCount,fsRptObjCount, fsRptCount, fsAutoMergeFl, fsExtMereFl, fsMergPrompt, 
	 								fsRefOnOpen, fsEnh, fsHideCharFl, fsQueryDrill, fsPerRgFrmFl,  fsComment};
	   			
	 			if (moReportDefWriter != null)
	   				BIUtilLogMgr.moReportDefWriter.putRecord(laRecValues);
				else
					throw new Exception("Log File Objects not initialized");

		}
		catch (Exception loExp)
		{
			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
		}

	
	}
   
   /**
    * 
    * @param fsFolderName
    * @param fsReportName
    * @param fsUnivNm
    * @param fsDPName
    * @param fsObjectName
    */
		   
   public static synchronized void loadReportObjectMetadataRecord(String fsFolderName, String fsReportName,String fsUnivNm, String fsDPName,String fsObjectName)
  	{
  	   try 
  	   {
  	   //Populate CSV file
  	 		String laRecValues[] = {fsFolderName,fsReportName,fsUnivNm,fsDPName,fsObjectName};
  	   			if (moObjectWriter != null)
  	   				BIUtilLogMgr.moObjectWriter.putRecord(laRecValues);
  				else
  					throw new Exception("Log File Objects not initialized");

  		}
  		catch (Exception loExp)
  		{
  			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
  		}

  	
  	}
   
   /**
    * Write the record in csv
    * @param fsFolderName
    * @param fsReportName
    * @param fsDPName
    * @param fsObjectName
    */
   public static synchronized void loadReportVariableMetadataRecord(String fsFolderName, String fsReportName, String fsVarName, String fsVarSelect)
	{
	   try 
	   {
	   //Populate CSV file
	 		String laRecValues[] = {fsFolderName,fsReportName,fsVarName,fsVarSelect};
	   		
				if (moVariableWriter != null)
					BIUtilLogMgr.moVariableWriter.putRecord(laRecValues);
				else
					throw new Exception("Log File Objects not initialized");

		}
		catch (Exception loExp)
		{
			BIUtilLogMgr.getRunTimeLogger().error("Error inserting log information: " + loExp.getMessage());
		}

	
	}
   
   
   
   public static void closeTarget() throws Exception
   {
	   if(moScheduleInstanceWriter != null)
		   moScheduleInstanceWriter.closeTarget();
	   
	   if(moScheduleHistoryWriter != null)
		   moScheduleHistoryWriter.closeTarget();
	   
	   if(moRefreshWriter != null)
		   moRefreshWriter.closeTarget();
	   
	   if(moObjectWriter!=null)
		   moObjectWriter.closeTarget();
	   
	   if(moVariableWriter!=null)
		   moVariableWriter.closeTarget();
	   
	   
	   
   }


} // of class LogMgr
