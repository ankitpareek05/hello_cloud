package com.amsinc.psg.BIUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import com.amsinc.psg.BIUtil.logging.BIUtilLogMgr;

public class WebiReportInfo 
{

	private String msReportName;
	private String msRptRootFldrNm;
	private List<Integer> msAssociatedUnivId;
	private List<String> msDataProviderID;
	
	private String msReportText;
	private LinkedHashMap<String,Properties> msReportPromptDetails;
	Properties moPromptProperty ;
	

	
	WebiReportInfo(String fsRptName)
	{
		msReportName = fsRptName;
		msAssociatedUnivId = new ArrayList<Integer>();
		msReportPromptDetails = new LinkedHashMap<String,Properties>();
		msDataProviderID = new ArrayList<String>();
		
	}
	
	public void setUniverseId(int fsId){
		if(!msAssociatedUnivId.contains(fsId))
			 msAssociatedUnivId.add(fsId);
	}
	
	public void setPromptDetails(String fsPromptText,String fsOptional,String fsPromptRespType,String fsPromptType)
	{
		
		setPromptDetails(fsPromptText,fsOptional,fsPromptRespType,fsPromptType,"");
	}
	
	
	public String getReportName()
	{
		return msReportName;
	}
	
	public LinkedHashMap<String,Properties> getPromptsDetails()
	{
		return msReportPromptDetails;
	}
	
	public void setPromptDetails(String fsPromptText,String fsOptional,String fsPromptRespType,String fsPromptType,String fsPromptValue)
	{
		moPromptProperty = new Properties();
		
		//Adding prompt properties
		moPromptProperty.put(BIUtilConstant.PROMPT_TEXT, fsPromptText);
		moPromptProperty.put(BIUtilConstant.PROMPT_OPTIONAL_PROPERTY, fsOptional);
		moPromptProperty.put(BIUtilConstant.PROMPT_RESPONSE_TYPE, fsPromptRespType);
		moPromptProperty.put(BIUtilConstant.PROMPT_TYPE, fsPromptType);
		moPromptProperty.put(BIUtilConstant.PROMPT_VALUE, fsPromptValue);
		
		msReportPromptDetails.put(fsPromptText,moPromptProperty);
		
	}
	
	public void setRptRootFldrNm(String fsFolder)
	{
		msRptRootFldrNm = fsFolder;
	}

	public String getRptRootFldrNm()
	{
		return msRptRootFldrNm;
	}
	
	public void setRptDataProviderID(String fsDPId)
	{
		msDataProviderID.add(fsDPId);
	}

	public List<String> getRptDataProviderID()
	{
		return msDataProviderID;
	}
	
}
