package com.amsinc.psg.BIUtil;




import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.sun.org.apache.xerces.internal.parsers.DOMParser;
/**
 * This class contains the common method used across the utility
 * @author shivansh.saxena
 *
 */
public class BIUtilCommon 
{
	public static Document convertStringToDom(String domXMLSTring) throws Exception {
		DOMParser parser = new DOMParser();
		parser.parse(new InputSource(new java.io.StringReader(domXMLSTring)));
		return (parser.getDocument());
		}
	
	
	// Allow for two parameters to be passed to the post request along with the XML string.
		// The most common one will be the "X-SAP-LogonToken" parameter
	public  static String restPost(Boolean enableFiddler, String urlStr, String XMLString, String param1Name, String param1Value, String param2Name, String param2Value ) throws Exception {

		 
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		try {
		  
		  
		 
		  HttpPost httpPost = new HttpPost(urlStr);
		  httpPost.addHeader("Accept", "application/xml");
		  httpPost.addHeader("Content-Type", "application/xml");
		  
		  if (!param1Name.equals("")) {
		   httpPost.addHeader(param1Name, param1Value);
		  }
		  if (!param2Name.equals("")) {
		   httpPost.addHeader(param2Name, param2Value);
		  }
		  
		  httpPost.setEntity(new StringEntity(XMLString));
		   
		  HttpResponse response = httpClient.execute(httpPost);
		  int statusCode = response.getStatusLine().getStatusCode();
		  HttpEntity entity = response.getEntity();
		  String responseBody = (String)EntityUtils.toString(entity);
		  return(responseBody);
		} finally {
		  // When HttpClient instance is no longer needed,
		        // shut down the connection manager to ensure
		        // immediate deallocation of all system resources
		       // httpClient.getConnectionManager().shutdown();
			httpClient.close();
			}
		}
	

	
	
	public  static String restGet(Boolean enableFiddler, String urlStr, String param1Name, String param1Value, String param2Name, String param2Value ) throws Exception 
	{

		CloseableHttpClient httpClient = HttpClientBuilder.create().build();

		 
		try {
		  

		  HttpGet httpget = new HttpGet(urlStr);
		  
		  httpget.addHeader("Accept", "application/xml");
		  httpget.addHeader("Content-Type", "application/xml");
		  
		  if (!param1Name.equals("")) {
		   httpget.addHeader(param1Name, param1Value);
		  }
		  if (!param2Name.equals("")) {
		   httpget.addHeader(param2Name, param2Value);
		  }
		  
		  HttpResponse response = httpClient.execute(httpget);
		  int statusCode = response.getStatusLine().getStatusCode();
		  HttpEntity entity = response.getEntity();
		  String responseBody = (String)EntityUtils.toString(entity);
		  return(responseBody);
		}catch(Exception Ex)
		{
			Ex.printStackTrace();
			throw new Exception();
		}
		finally {
		  // When HttpClient instance is no longer needed,
		        // shut down the connection manager to ensure
		        // immediate deallocation of all system resources
			httpClient.close();
		}
	} // End restGet

	public static String restTextGet(Boolean enableFiddler, String urlStr, String param1Name, String param1Value, String param2Name, String param2Value ) throws Exception 
	{

		CloseableHttpClient httpClient = HttpClientBuilder.create().build();

		 
		try
		{
		  HttpGet httpget = new HttpGet(urlStr);
		  
		  httpget.addHeader("Accept", "text/xml");
		  httpget.addHeader("Content-Type", "text/xml");
		  
		  if (!param1Name.equals("")) {
		   httpget.addHeader(param1Name, param1Value);
		  }
		  if (!param2Name.equals("")) {
		   httpget.addHeader(param2Name, param2Value);
		  }
		  
		  HttpResponse response = httpClient.execute(httpget);
		  int statusCode = response.getStatusLine().getStatusCode();
		  HttpEntity entity = response.getEntity();
		  String responseBody = (String)EntityUtils.toString(entity);
		  return(responseBody);
		}catch(Exception Ex)
		{
			Ex.printStackTrace();
			throw new Exception();
		}
		finally {
		  // When HttpClient instance is no longer needed,
		        // shut down the connection manager to ensure
		        // immediate deallocation of all system resources
			httpClient.close();
		}
	} // End restGet
	
	 public static String getErrorCodeDetails(String fsXML){
			
			int liErrorStartIndex = fsXML.indexOf(BIUtilConstant.ERROR_STRING_START) + BIUtilConstant.ERROR_STRING_START.length();
			int liErrorEndIndex = fsXML.indexOf(BIUtilConstant.ERROR_STRING_END);
			
			String lsErrorCode = fsXML.substring(liErrorStartIndex,liErrorEndIndex);

			return lsErrorCode;
		}
			
	  public static String getErrorMessageDetails(String fsXML)  {
				
				int liMessagestartIndex = fsXML.indexOf(BIUtilConstant.MESSAGE_STRING_START) + BIUtilConstant.MESSAGE_STRING_START.length();;
				int liMessageEndIndex = fsXML.indexOf(BIUtilConstant.MESSAGE_STRING_END);;
				
				String lsMessage = fsXML.substring(liMessagestartIndex,liMessageEndIndex);

				return lsMessage;
		}

	

}
