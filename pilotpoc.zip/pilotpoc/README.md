# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Bank Of Montreal POC Framwork
* Version - 1.0
* Build Tool - SBT
* Scala Version - 2.11.0
* Spark Version - 2.2.0

### How do I get set up? ###

* Setup Spark Scala IDE (EClipse/IntelliJ) on your machine
* Take a clone of this git repo
* Do a clean compile of this repo using SBT to create IDE files and reference jars.

### Who do I talk to? ###

* Yakub Pasha Shaik
* Anshuman
* Ankit Pareek
* Vishal Agrawal