package com.deloitte.bmo.framework

object ErrorHandling {
  
}