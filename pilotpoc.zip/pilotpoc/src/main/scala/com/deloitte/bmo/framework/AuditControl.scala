package com.deloitte.bmo.framework

import com.deloitte.bmo.generic.utils.SparkInitialization
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SaveMode

/**
 * '''A Case Class for Audit Table '''
 * @constructor Creates a new Audit Table Object with 'BATCH_ID', 'ARCHITECTURE_LAYER', 'FILE_NAME', 'START_TIME', 'END_TIME', 'STATUS'
 */
case class AuditTable(BATCH_ID: String, ARCHITECTURE_LAYER: String, FILE_NAME: String, START_TIME: String, END_TIME: String, STATUS: String)
case class AuditCDCTable(BATCH_ID: String, ARCHITECTURE_LAYER: String, FILE_NAME: String, HIST_DATA_CNT: String, INC_DATA_CNT: String, START_TIME: String, END_TIME: String, STATUS: String)
/**
 * '''Class for Audit Balance and Control Framework'''
 *
 * {{{
 * val a = new AuditControl()
 * a.addToAuditTable("BATCH_ID", "ARCHITECTURE_LAYER", "FILE_NAME", "START_TIME", "END_TIME", "STATUS")
 * a.saveAuditData("auditOutputPath")
 * }}}
 *
 *
 *
 * @constructor Create a new Audit Control Object with Audit Parameters ("BATCH_ID", "ARCHITECTURE_LAYER", "FILE_NAME", "START_TIME", "END_TIME", "STATUS").
 * @param auditOutputPath Output path to save Audit Table.
 * @author Deloitte
 * @version 1.0
 * @todo Add Functionality
 */
class AuditControl(tableType: String) {

  /*
   * Initialization of Mutable Array for Audit Table
   */

  val spark = SparkInitialization.getSparkSession()
  val sc = SparkInitialization.getSparkContext()
  var auditTableList = List[AuditTable]()
  var auditTableCDCList = List[AuditCDCTable]()

  /**
   * Method to create the Audit Table.
   *
   * @param BATCH_ID	Batch ID of process.
   * @param ARCHITECTURE_LAYER	Layer Name for Process.
   * @param FILE_NAME	File Name of Process.
   * @param START_TIME	Start time of Process.
   * @param END_TIME	End time of Process.
   * @param STATUS	Status of Process.
   */

  def addToAuditTable(BATCH_ID: String, ARCHITECTURE_LAYER: String, FILE_NAME: String, START_TIME: String, END_TIME: String, STATUS: String) = {

    auditTableList = auditTableList :+ AuditTable(BATCH_ID, ARCHITECTURE_LAYER, FILE_NAME, START_TIME, END_TIME, STATUS)
  }

  /**
   * Method to create the Audit Table for CDC.
   *
   * @param BATCH_ID	Batch ID of process.
   * @param ARCHITECTURE_LAYER	Layer Name for Process.
   * @param FILE_NAME	File Name of Process.
   * @param HIST_DATA_CNT History Data Count.
   * @param INC_DATA_CNT Increment Data Count
   * @param START_TIME	Start time of Process.
   * @param END_TIME	End time of Process.
   * @param STATUS	Status of Process.
   */
  def addToAuditCDCTable(BATCH_ID: String, ARCHITECTURE_LAYER: String, FILE_NAME: String, HIST_DATA_CNT: String, INC_DATA_CNT: String, START_TIME: String, END_TIME: String, STATUS: String) = {

    auditTableCDCList = auditTableCDCList :+ AuditCDCTable(BATCH_ID, ARCHITECTURE_LAYER, FILE_NAME, HIST_DATA_CNT, INC_DATA_CNT, START_TIME, END_TIME, STATUS)

  }

  /**
   * Method to save the Audit Table in parquet format
   * @param auditOutputPath Path to save Audit data
   */
  def saveAuditData(auditOutputPath: String) = {

    this.tableType match {
      case "AuditTable"    => spark.createDataFrame(sc.parallelize(auditTableList)).coalesce(1).write.option("header", "true").mode(SaveMode.Append).csv(auditOutputPath)
      case "AuditCDCTable" => spark.createDataFrame(sc.parallelize(auditTableCDCList)).coalesce(1).write.option("header", "true").mode(SaveMode.Append).csv(auditOutputPath)
    }

  }
}