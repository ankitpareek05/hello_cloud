package com.deloitte.bmo.generic.utils
import scala.beans.BeanProperty

/**
 * A class to define a ''Global Variables''.
 *
 * These varibales can be used anywhere in th code
 * as and when required
 * {{{
 * @BeanProperty var source_name = new String
 * }}}
 * @example val sourceName= GlobalVariables.getSource_name()
 * @version 1.0
 * @author Deloitte
 * @todo Add more functionality.
 */
object GlobalVariables {
  @BeanProperty var source_name = new String
  @BeanProperty var layerName = new String
}