package com.deloitte.bmo.framework
import org.apache.log4j.{ Level, LogManager, PropertyConfigurator }

trait Logging {
  //@transient val log = org.apache.log4j.LogManager.getLogger("log4j.properties")
  @transient val log = LogManager.getLogger(getClass.getName)
  @transient lazy val logErr = LogManager.getLogger("errorLogger")
}