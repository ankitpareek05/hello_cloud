package com.deloitte.bmo.operationsImpl
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import scala.collection.Map
import org.apache.spark.sql.functions._
import java.io.File
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StringType
import com.deloitte.bmo.rules.CleanseRule
import com.deloitte.bmo.framework.Logging

class RuleProcessImpl extends Logging {

  def processUtilityRule(mainDF: DataFrame, layerName: String, inputConfigData: Map[String, String]): DataFrame = {

    var standardDf = mainDF
    val ruleAction = inputConfigData.keySet.filter(x => x.contains("_RULE"))

    if (!ruleAction.isEmpty) {

      //val actionRuleConcatenate = (layerName + ".rulestandardizeconcatenate").toLowerCase()
      val actionRuleConcatNullCheck = (layerName + ".rule.concatnullcheck").toLowerCase()
      val actionRuleConcatWithPipe = (layerName + "_STANDARIZATION_RULE_CONCATENATEWITHPIPE").toUpperCase()
      val actionRuleConcatWithComma = (layerName + "_STANDARIZATION_RULE_CONCATENATEWITHCOMMA").toUpperCase()
      val actionRuleConcatWithSpace = (layerName + ".rule.standardizeconcatenatewithspace").toUpperCase()
      val actionRuleConcatWithHyphen = (layerName + "_STANDARIZATION_RULE_CONCATENATEWITHHYPHEN").toUpperCase()
      // val actionRuleAddDefaultValue = (layerName + ".rule.addAddionalcolumnwithdefaultvalue").toUpperCase()
      val actionRuleCreateDuplicateColumn = (layerName + "_STANDARIZATION_RULE_CREATEDUPLICATECOLUMN").toUpperCase()

      val actionRuleAddDefaultValue = (layerName + "_STANDARIZATION_RULE_ADDADDIONALCOLUMNWITHDEFAULTVALUE").toUpperCase()
      val actionRuleSplitName = (layerName + "_STANDARIZATION_RULE_SPLITNAMES").toUpperCase()
      val actionRuleTitleCase = (layerName + "_STANDARIZATION_RULE_TITLECASE").toUpperCase()
      val actionURLreplace = (layerName + "_STANDARIZATION_RULE_URL_HTTP_REPLACE_WITH_SPACE").toUpperCase()
      val actionUpperCase = (layerName + "_STANDARIZATION_RULE_UPPERCASE").toUpperCase()
      val actionLowerCase = (layerName + "_STANDARIZATION_RULE_LOWERCASE").toUpperCase()
      val actionRemoveNonNumber = (layerName + "_STANDARIZATION_RULE_REMOVE_NON_NUMBER").toUpperCase()
      val actionReplaceHyphenUnderscorewithSpace = (layerName + "_STANDARIZATION_RULE_REPLACE_HYPHEN_UNDERSCORE_WITH_SPACE").toUpperCase()
      val actionRemoveNonAlphaNumeric = (layerName + "_STANDARIZATION_RULE_REMOVE_NON_ALPHANUMERIC").toUpperCase()
      val actionReplaceSlashwithSpace = (layerName + "_STANDARIZATION_RULE_REPLACE_SLASH_WITH_SPACE").toUpperCase()
      val actionReplacePeriodWithSpace = (layerName + "_STANDARIZATION_RULE_REPLACE_PERIOD_WITH_SPACE").toUpperCase()
      val actionTrim = (layerName + "_STANDARIZATION_RULE_TRIM").toUpperCase()
      val actionRemoveLeadingZero = (layerName + "_STANDARIZATION_RULE_REMOVE_LEADING_ZERO").toUpperCase()
      val actionAddParenthesis = (layerName + "_STANDARIZATION_RULE_ADD_PARENTHESIS_START_END").toUpperCase()

      val actiondobvalidaton = (layerName + "_STANDARIZATION_RULE_DOB_VALIDATION").toUpperCase()
      val actionruledatevalidation = (layerName + "_STANDARIZATION_RULE_DATE_VALIDATION").toUpperCase()
      val actioncompleteness = (layerName + "_STANDARIZATION_RULE_COMPLETENESS").toUpperCase()
      val actionisnumeric = (layerName + "_STANDARIZATION_RULE_IS_NUMERIC").toUpperCase()
      val actionruleusaphnnovalidate = (layerName + "_STANDARIZATION_RULE_USA_PHONE_NO_VALIDATION").toUpperCase()
      val actionusaphnoparsevalidate = (layerName + "_STANDARIZATION_RULE_USA_PHONE_PARSE_STANDARIZE_VALIDATE").toUpperCase()
      val actionusastatevalidation = (layerName + "_STANDARIZATION_RULE_USA_STATE_VALIDATION").toUpperCase()
      val actionusazipcodevalidation = (layerName + "_STANDARIZATION_RULE_USA_ZIP_CODE_VALIDATION").toUpperCase()
      val actionPhoneNoStadarization=(layerName + "_STANDARIZATION_RULE_PHONE_NUMBER").toUpperCase()

      ruleAction.map { rule =>
        log.info("Rule running : " + rule)
        val ruleValue = inputConfigData.getOrElse(rule, "NA").split("##").toList
        if (!ruleValue(0).equalsIgnoreCase("NA")) {
          ruleValue.map({ col =>

            rule match {
              case `actionRuleConcatWithPipe`               => standardDf = CleanseRule.rule_concatColumnsWithPipe(standardDf, col, "|")
              case `actionRuleConcatWithComma`              => standardDf = CleanseRule.rule_concatColumnsWithComma(standardDf, col, ",")
              case `actionRuleConcatWithSpace`              => standardDf = CleanseRule.rule_concatColumnsWithSpace(standardDf, col, " ")
              case `actionRuleConcatWithHyphen`             => standardDf = CleanseRule.rule_concatColumnsWithHyphen(standardDf, col, "-")
              case `actionRuleConcatNullCheck`              => standardDf = CleanseRule.rule_concatColumnWithOneNullAlways(standardDf, col)
              case `actionURLreplace`                       => standardDf = CleanseRule.rule_UrlToStartWithHttps(standardDf, col)
              case `actionRuleCreateDuplicateColumn`        => standardDf = CleanseRule.rule_createDuplicateColumn(standardDf, col)
              case `actionRuleSplitName`                    => standardDf = CleanseRule.rule_splitname(standardDf, col)
              case `actionRuleTitleCase`                    => standardDf = CleanseRule.ruleTitleCase(standardDf, col)
              case `actionRuleAddDefaultValue`              => standardDf = CleanseRule.rule_addAddionalColumnWithDefaultValue(standardDf, col)
              case `actionReplaceHyphenUnderscorewithSpace` => standardDf = CleanseRule.rule_Replace_Hyphen_Underscore_with_Space(standardDf, col)
              case `actionRemoveNonNumber`                  => standardDf = CleanseRule.rule_Remove_Non_Numbers(standardDf, col)
              case `actionRemoveNonAlphaNumeric`            => standardDf = CleanseRule.rule_Replace_Non_Alphabetic_with_Space(standardDf, col)
              case `actionReplaceSlashwithSpace`            => standardDf = CleanseRule.rule_replaceSlashesWithSpace(standardDf, col)
              case `actionReplacePeriodWithSpace`           => standardDf = CleanseRule.rule_Replace_Period_With_Space(standardDf, col)
              case `actionTrim`                             => standardDf = CleanseRule.rule_All_Trim(standardDf, col)
              case `actionRemoveLeadingZero`                => standardDf = CleanseRule.rule_Remove_All_Leading_Zeros(standardDf, col)
              case `actionAddParenthesis`                   => standardDf = CleanseRule.rule_addParenthesesAtStartEndofLine(standardDf, col)

              case `actiondobvalidaton`                     => standardDf = CleanseRule.rule_dateofbirthvalidation(standardDf, col)
              case `actionruledatevalidation`               => standardDf = CleanseRule.rule_datevalidation(standardDf, col)
              case `actioncompleteness`                     => standardDf = CleanseRule.rule_completeness(standardDf, col)
              case `actionisnumeric`                        => standardDf = CleanseRule.rule_isnumeric(standardDf, col)
              case `actionruleusaphnnovalidate`             => standardDf = CleanseRule.rule_usaphonenumbervalidation(standardDf, col)
              case `actionusaphnoparsevalidate`             => standardDf = CleanseRule.rule_usaphoneparsestandardizevalidate(standardDf, col)
              case `actionusastatevalidation`               => standardDf = CleanseRule.rule_usastatevalidation(standardDf, col)
              case `actionusazipcodevalidation`               => standardDf = CleanseRule.rule_usazipcodevalidation(standardDf, col)
              case  `actionPhoneNoStadarization`             => standardDf = CleanseRule.rule_phonenumberstandarization(standardDf, col)
              case `actionUpperCase`                        => standardDf = CleanseRule.rule_upperCase(standardDf, col)
              case `actionLowerCase`                        => standardDf = CleanseRule.rule_lowerCase(standardDf, col)
              case _                                        => "No rules applicable"

            }

          })
          //val delimeter = inputConfigData.getOrElse((layerName + ".concatenatedelimeter").trim(), List("NA")).mkString
          //log.info("delimeter : " + delimeter)

        }

      }

    }
    standardDf
  }

}