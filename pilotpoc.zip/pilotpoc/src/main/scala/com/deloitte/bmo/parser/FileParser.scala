package com.deloitte.bmo.parser

import com.deloitte.bmo.generic.utils.SparkInitialization
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import scala.collection.Map
import com.deloitte.bmo.generic.utils.GlobalVariables
import com.deloitte.bmo.generic.utils.CommonUtils

class FileParser {
  val sparkSession = SparkInitialization.getSparkSession()

  def ebcdic_parser(configData: Map[String, String]): DataFrame = {

    println(GlobalVariables.getLayerName() + "_EBCDIC_COPY_BOOK_PATH")
    val copyBookPath = configData.getOrElse(GlobalVariables.getLayerName() + "_EBCDIC_COPY_BOOK_PATH", "NA")
    //println(copyBookPath)
    val ebcdicPath = configData.getOrElse(GlobalVariables.getLayerName() + "_EBCDIC_INPUT_PATH", "NA")
   // println(ebcdicPath)

    var parsedDf = sparkSession.read.format("za.co.absa.cobrix.spark.cobol.source")
      .option("copybook", copyBookPath)
      .option("is_record_sequence", "true")
      .option("schema_retention_policy", "collapse_root")
     // .option("segment_field", "SEGMENT_ID")
      //.option("segment_id_level0", "C")
      //.option("segment_id_level1", "P")
      .load(ebcdicPath)

    parsedDf= parsedDf.select(CommonUtils.flattenSchema(parsedDf.schema):_*)
    parsedDf

  }

  def xml_parser() {

  }

  def config_parser(configPath: String, fileName: String): Map[String, String] = {
    var readConfigAsDf = CommonUtils.readFromCsvFile(configPath, "true", "false").na.fill("NA")

    readConfigAsDf = readConfigAsDf.filter(readConfigAsDf("FILE_NAME") === fileName.trim().toUpperCase())

    readConfigAsDf = readConfigAsDf.withColumn("KEY", concat(readConfigAsDf("ARCHITECTURE_LAYER"), lit("_"), readConfigAsDf("ACTION"), lit("_"), readConfigAsDf("KEY"))).withColumn("VALUE", readConfigAsDf("VALUE"))
    // var mappedDF = readConfigAsDf.groupBy("KEY").agg((collect_list("VALUE")).alias("VALUE"))
    readConfigAsDf.show()
    //mappedDF.show()
    var configRdd = readConfigAsDf.rdd.map(x => {
      (x.getAs[String]("KEY"), x.getAs[String]("VALUE").asInstanceOf[String])

    }).collectAsMap()
    configRdd

  }
}