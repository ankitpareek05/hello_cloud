package com.deloitte.bmo.generic.utils

import com.deloitte.bmo.framework.Logging
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import java.text.SimpleDateFormat
import java.util.Calendar
import org.apache.spark.sql.Column
import org.apache.spark.sql.types.StructType
import com.deloitte.bmo.rules.ValidationRules

import scala.collection.Map
import scala.collection.mutable._


/**
 * '''Object for Common Utility Functions'''
 * @constructor Collections of Common Utility Functions
 * @author Deloitte
 * @version 1.0
 * @todo Add Functionality
 */
object CommonUtils extends Logging {

  // Getting sparkSession object
  private val sparkSession = SparkInitialization.getSparkSession()

  // Getting sparkContext object
  private val sparkContext = SparkInitialization.getSparkContext()

  // Getting sqlContext object
  private val sqlContext = SparkInitialization.getSqlContext()

  /**
   * Read data from Delimited file and convert it into DataFrame [required Delimiter]
   * @param inputfilePath Input file Path
   * @param delimiter
   * @param Header (True/False)
   * @return Dataframe
   */
  def readFromDelimiterFile(inputFile: String, delimiter: String, headerVal: String): DataFrame = {
    val dataFrame = sparkSession.read
      .option("inferSchema", "true")
      .option("delimiter", delimiter)
      .option("parserLib", "univocity")
      .option("header", headerVal)
      .option("nullValue", "null").csv(inputFile).toDF()
    dataFrame
  }

  /**
   * Read data from CSV file and convert it into DataFrame
   * @param inputfilePath Input file Path
   * @param headerVal (True/False)
   * @param inferSchema (True/False)
   * @return Dataframe
   */

  def readFromCsvFile(inputFile: String, headerVal: String, inferSchema: String): DataFrame = {

    val dataFrame = sparkSession.read
      .option("header", headerVal)
      .option("inferSchema", inferSchema)
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .csv(inputFile)
    dataFrame
  }

  /**
   * Read data from Parquet file and convert it into DataFrame
   * @param inputfilePath Input file Path
   * @param headerVal (True/False)
   * @return Dataframe
   */
  def readFromParquetFile(inputPath: String, headerRequired: String) = {

    var readParquetDF = sparkSession.read
      .option("header", headerRequired)
      .option("inferSchema", "true")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .option("mergeSchema", "true")
      .parquet(inputPath)
    readParquetDF
  }

  /**
   * Write data to Parquet file
   * @param df DataFrame
   * @param outputPath Output path to save file
   * @param headerRequired (True/False)
   * @param writeMode (append/overwrite/ignore)
   * @return Dataframe
   */
  def writeToParquetFile(df: DataFrame, outputPath: String, headerRequired: String, writeMode: String) = {
    df.coalesce(4)
      .write
      .option("header", headerRequired)
      .option("nullValue", "")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("multiLine", "true")
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .mode(writeMode)
      .parquet(outputPath)
  }

  /**
   * Write data to CSV file
   * @param df DataFrame
   * @param outputPath Output path to save file
   * @param headerRequired (True/False)
   * @param writeMode (append/overwrite/ignore)
   * @return Dataframe
   */
  def writeToCsvFile(df: DataFrame, outputPath: String, headerRequired: String, writeMode: String) = {
    df.coalesce(4)
      .write
      .option("header", headerRequired)
      .option("nullValue", "")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("multiLine", "true")
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .mode(writeMode)
      .csv(outputPath)
  }

  /**
   * Function to get Date in YYYY-MM-DD format
   * @return YYYY-MM-dd
   */
  def getDateYYYYMMDD() = {
    val format = new SimpleDateFormat("YYYY-MM-dd")
    val date = format.format(Calendar.getInstance().getTime())
    date
  }
  
   /*
   * This method is responsible to read the Config file 
   * and Parse it into Key/Value pair
   * @return map<Key, value>
   * @args: Config path, file name
   */

  def parseConfigFile(configPath: String, fileName: String): Map[String,String] = {
    var readConfigAsDf = CommonUtils.readFromCsvFile(configPath, "true", "false").na.fill("NA")

   readConfigAsDf = readConfigAsDf.filter(readConfigAsDf("FILE_NAME")===fileName.trim().toUpperCase())

    readConfigAsDf = readConfigAsDf.withColumn("KEY", concat(readConfigAsDf("ARCHITECTURE_LAYER"), lit("_"),readConfigAsDf("KEY"))).withColumn("VALUE", readConfigAsDf("VALUE"))
    // var mappedDF = readConfigAsDf.groupBy("KEY").agg((collect_list("VALUE")).alias("VALUE"))
    readConfigAsDf.show()
    //mappedDF.show()
    var configRdd = readConfigAsDf.rdd.map(x => {
      (x.getAs[String]("KEY"), x.getAs[String]("VALUE").asInstanceOf[String]) 

    }).collectAsMap()
    configRdd

  }
  
  
   def parseConfigFile1(configPath: String, fileName: String): Map[String,String] = {
    var readConfigAsDf = CommonUtils.readFromCsvFile(configPath, "true", "false").na.fill("NA")

   readConfigAsDf = readConfigAsDf.filter(readConfigAsDf("FILE_NAME")===fileName.trim().toUpperCase())

    readConfigAsDf = readConfigAsDf.withColumn("KEY", concat(readConfigAsDf("ARCHITECTURE_LAYER"), lit("_"),readConfigAsDf("ACTION"), lit("_"),readConfigAsDf("KEY"))).withColumn("VALUE", readConfigAsDf("VALUE"))
    // var mappedDF = readConfigAsDf.groupBy("KEY").agg((collect_list("VALUE")).alias("VALUE"))
    readConfigAsDf.show()
    //mappedDF.show()
    var configRdd = readConfigAsDf.rdd.map(x => {
      (x.getAs[String]("KEY"), x.getAs[String]("VALUE").asInstanceOf[String]) 

    }).collectAsMap()
    configRdd

  }

   /*
    * This method is responsible to flatten the nested Schema
    * @param Dataframe Schema
    * @prefix[optional]
    * @return Array[column]
    */
  def flattenSchema(schema: StructType, prefix: String = null): Array[Column] = {
    schema.fields.flatMap(schemaCol => {
      val colName = if (prefix == null) schemaCol.name else (prefix + "." + schemaCol.name)

      schemaCol.dataType match {
        case st: StructType => flattenSchema(st, colName)
        case _              => Array(col(colName))
      }
    })
}
  
    def getDfAfterKeyValidation(strutDF: DataFrame, configData: Map[String, String]): DataFrame =
    {
      var ruleProcess: ValidationRules = new ValidationRules()
      var keyValidatedDf = ruleProcess.processKeyValidationRule(strutDF, configData)
      keyValidatedDf
    }
    
      /**
   * @input: array of column names
   * @return : array of columns
   */
  def getColumnsArray(keyColumns: Array[String]): Array[Column] = {
    val arrKeyColumns = keyColumns.map { column =>
      col(column)
    }
    arrKeyColumns
  }
  
  
}