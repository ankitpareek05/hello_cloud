package com.deloitte.bmo.rules


import org.apache.spark.sql.SQLContext
import scala.collection.Map
import org.apache.spark.sql.Row
import com.deloitte.bmo.generic.utils.GlobalVariables
case class ErrorTable( SOURCE : String, ERROR_CODE : String,ERROR_CATEGOERY : String,ERROR_COLUMN :String, ERROR_DESCRIPTION : String, ERROR_RECORDS : String )


class KeyFieldValidation extends Serializable {
  //By Kanika start
  def isValidationPassed(colValue: String): String = {

    if ((colValue != null && !colValue.trim.isEmpty && !colValue.trim().equalsIgnoreCase("null")))
      return "true";
    else
      return "false";
  }

  def fieldValidationCheck(colName: String, row: Row, inputConfigData: Map[String, String]) = {
    
    var source = GlobalVariables.getSource_name()
    //var firmName = GlobalVariables.getSourceId
    //var fileName = GlobalVariables.
    var errorCode = ""
    var errorCategoery = "Key Field Validation"
    var errorColumn = colName
    var errorDescription = "Key Field validation check faild. Blank and null found in Key field. "
    var errorRecords = ""
    errorCode = "ERR-001"
    errorRecords = row.mkString("|")

    try {

      val colValue = row.getAs[String](colName)

      val fieldValidationCheckOutput = isValidationPassed(colValue)

      
      if (fieldValidationCheckOutput.equalsIgnoreCase("false")) {

       // errorDescription = fieldValidationCheckOutput.toString()

        (row, ErrorTable(source, errorCode, errorCategoery, errorColumn, errorDescription, errorRecords))

      } else {

        (null, null)

      }

    } catch {
      case e: Exception => {
        errorDescription = "Exception: =>  " + e.getMessage
        (row, ErrorTable(source, errorCode, errorCategoery, errorColumn, errorDescription, errorRecords))
      }
    }
  }


}