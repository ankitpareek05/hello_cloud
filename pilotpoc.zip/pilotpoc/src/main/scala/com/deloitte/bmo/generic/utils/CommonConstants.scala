package com.deloitte.bmo.generic.utils

object CommonConstants {

  /*
   * Constants related to CDC
   */
  val END_DATE_COL_NAME = "END_DATE"
  val START_DATE_COL_NAME = "START_DATE"
  val CURRENT_FLAG = "CURRENT_FLAG"

}