package com.deloitte.bmo.driver

import com.deloitte.bmo.generic.utils.CommonUtils
import com.deloitte.bmo.generic.utils.GlobalVariables
import com.deloitte.bmo.parser.FileParser
import scala.collection.Map
import com.deloitte.bmo.framework.Logging

object EbcdicParserDriver extends Logging {

  def main(args: Array[String]) {

    if (args.length != 4) {
      logErr.error("Invalid number of arguments passed")
      logErr.error("Arguments Usage: <config-file path> <source-name>  <Layer Name><File Name>")
      System.exit(1)
    }

    val configPath = args(0).trim()
    val sourceName = args(1).trim().toUpperCase()
    val layerName = args(2).trim().toUpperCase()
    val fileName = args(3).trim().toUpperCase()

    //    val configPath = "src/main/resources/config.csv"
    //    val sourceName = "SOURCE".toUpperCase()
    //    val layerName = "L0".toUpperCase()
    //    val fileType = "CSV".toUpperCase()
    //    val fileName = "ACCOUNT".toUpperCase()

    GlobalVariables.setLayerName(layerName)
    GlobalVariables.setSource_name(sourceName)

    val configDataRaw: Map[String, String] = CommonUtils.parseConfigFile1(configPath, fileName)

    val fileParser = new FileParser()
    //
    val ebcdicConfigData = configDataRaw.filter(key => key._1.startsWith(layerName) && key._1.contains("EBCDIC"))
    val outputPath = configDataRaw.getOrElse(layerName + "_EBCDIC_OUTPUT_PATH", "NA")

    val ebcdicDf = fileParser.ebcdic_parser(ebcdicConfigData)
    ebcdicDf.show()
    //ebcdicDf.select(col, cols)

    CommonUtils.writeToParquetFile(ebcdicDf, outputPath, "true", "overwrite")

  }

}