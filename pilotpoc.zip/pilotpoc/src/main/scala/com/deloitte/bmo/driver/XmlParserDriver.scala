package com.deloitte.bmo.driver

import org.apache.spark.sql.functions._

import com.deloitte.bmo.generic.utils.SparkInitialization

object XmlParserDriver {
  def main(args: Array[String]) = {

    val spark = SparkInitialization.getSparkSession()
    import spark.implicits._
    var ds = spark.read
      .format("com.databricks.spark.xml")
      .option("rowTag", "dataset")
      .option("rootTag", "datasets")
      .load("src/main/resources/nasa.xml")

    ds.show()
    ds = ds.filter($"_subject" === lit("astronomy")).cache
    ds.createTempView("ds")

    spark.sql("""select a.title, explode(a.author.initial), a.author.lastName from (select title, (explode(reference.source.other.author)) as author from ds) a""").show()

    //"descriptions.description.para",
    val selectedData: List[String] = List("reference.source.other.author", "title")

    ds = ds.select(selectedData.head, selectedData.tail: _*)

    ds.printSchema()
    /* ds.columns.map(x => {
      ds = ds.withColumn(x, explode(col(x)))
    })*/
    ds.show()
    ds = ds.select(explode($"author").as("author"), $"title").select($"author.initial", $"author.lastName", $"title")
    ds.select(explode_outer($"initial"), ($"lastName"), ($"title")).show()
    ds.printSchema()
  }

}
