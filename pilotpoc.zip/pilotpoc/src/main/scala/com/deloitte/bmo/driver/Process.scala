package com.deloitte.bmo.driver

import com.deloitte.bmo.generic.utils.CommonUtils
import com.deloitte.bmo.framework.ChangeDataCapture
import com.deloitte.bmo.generic.utils.CommonConstants
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SaveMode
import scala.collection.Map
import com.deloitte.bmo.framework.Logging
import com.deloitte.bmo.generic.utils.GlobalVariables
import com.deloitte.bmo.generic.utils.GlobalVariables

object Process extends Logging {

  def main(args: Array[String]) = {

    //    val configPath=args(0).trim()
    //    val sourceName= args(1).trim().toUpperCase()
    //    val layerName=args(2).trim().toUpperCase()
    //    val fileName=args(3).trim().toUpperCase()

    val configPath = "src/main/resources/config.csv"
    val sourceName = "SOURCE".toUpperCase()
    val layerName = "L0".toUpperCase()
    val fileType = "CSV".toUpperCase()
    val fileName = "ACCOUNT".toUpperCase()

    log.info(this.getClass.getName() + ": ***Logging Started for source, " + sourceName + " Change Data Capture utility running ***")

    val configData: Map[String, String] = CommonUtils.parseConfigFile(configPath, fileName).filter(key => key._1.startsWith(layerName))
    configData.map(x => println(x._1 + " --> " + x._2))

    val isIncrement = configData.getOrElse(layerName + "_" + "IS_INCREMENT", "FALSE")
    val outputPath = configData.getOrElse(layerName + "_" + "OUTPUT_PATH", "NA")
    val historyDataInputPath = configData.getOrElse(layerName + "_" + "HISTORY_DATA_INPUT_PATH", "NA")
    val incDataInputPath = configData.getOrElse(layerName + "_" + "INC_DATA_INPUT_PATH", "NA")

    try {
      if (isIncrement.equalsIgnoreCase("false")) {

        println("===> History Load")
        val data1 = CommonUtils.readFromCsvFile(historyDataInputPath, "true", "true")
          .withColumn(CommonConstants.START_DATE_COL_NAME, lit(CommonUtils.getDateYYYYMMDD()))
          .withColumn(CommonConstants.END_DATE_COL_NAME, lit("9999-12-31"))
          .withColumn(CommonConstants.CURRENT_FLAG, lit("Y"))
        println("===> Full Data")
        data1.show()
        data1.coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(outputPath + "CURRENT_FLAG=Y/")

      } else if (isIncrement.equalsIgnoreCase("true")) {

        println("===> Incremental Load")
        val oldData2 = CommonUtils.readFromCsvFile(historyDataInputPath + "CURRENT_FLAG=Y/*", "true", "true")
        println("===> Hist Data")
        oldData2.show()
        val data2 = CommonUtils.readFromCsvFile(incDataInputPath, "true", "true")
          .withColumn(CommonConstants.START_DATE_COL_NAME, lit(CommonUtils.getDateYYYYMMDD()))
          .withColumn(CommonConstants.END_DATE_COL_NAME, lit(""))
          .withColumn(CommonConstants.CURRENT_FLAG, lit(""))
        println("===> Increment Data")
        data2.show()

        val df2 = ChangeDataCapture.scd2(oldData2, data2, configData)

        println("===> Hist Data After CDC")
        df2._1.sort("Client_Id").show()
        println("===> Outdated data after CDC")
        df2._2.sort("Client_Id").show()

        df2._2.sort("Client_Id").coalesce(1).write.mode(SaveMode.Append).option("header", "true").csv(outputPath + "CURRENT_FLAG=N/")
        df2._1.sort("Client_Id").coalesce(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(outputPath + "CURRENT_FLAG=Y/")
      }
    } catch {
      case e: Exception =>
        e.printStackTrace()
    }
  }
}
