package com.deloitte.bmo.parser

import com.deloitte.bmo.generic.utils.SparkInitialization

class XmlParser {
  val spark = SparkInitialization.getSparkSession()

  def readXMLFile(rowTag: String, rootTag: String, xmlPath: String) = {
    spark.read
      .format("xml")
      .option("rowTag", rowTag)
      .option("rootTag", rootTag)
      .load(xmlPath)
  }
}