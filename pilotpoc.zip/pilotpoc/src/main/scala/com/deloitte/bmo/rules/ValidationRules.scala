package com.deloitte.bmo.rules

import com.deloitte.bmo.generic.utils.SparkInitialization
import org.apache.spark.sql._
import com.deloitte.bmo.framework.Logging
import org.apache.spark.sql.types._
import scala.util._
import org.apache.spark.sql.functions._
import com.deloitte.bmo.generic.utils.GlobalVariables
import scala.collection.Map
import scala.collection.mutable._
import com.deloitte.bmo.generic.utils.CommonUtils

class ValidationRules extends Logging {

  val sparkSession = SparkInitialization.getSparkSession()
  val sqlContext=sparkSession.sqlContext
  //  val logger = Logger("CustomLogger")

  /*
   * Validate the primary key columns based on the respective
   * Config paramter
   * @return List[Dataframe]
   */

  def validateNotNull(df: DataFrame, primary_key_col_list: Array[String]): List[DataFrame] = {

    var primaryCheckCorrect = ""
    var primary_check_incorrect = ""

    for (z <- primary_key_col_list) {
      primaryCheckCorrect = primaryCheckCorrect + "and length(trim(" + z + "))>0 "
      primary_check_incorrect = primary_check_incorrect + "OR " + z + " is null OR length(trim(" + z + "))=0 "
    }
    df.show()

    df.createOrReplaceTempView("input_data")

    val valid_records_query = "select * from input_data where " + (primaryCheckCorrect.drop(3))
    val invalid_records_query = "select * from input_data where " + (primary_check_incorrect.drop(2))

    log.info(this.getClass.getName() + ": ***valid_records_query:- " + valid_records_query + "***")
    log.info(this.getClass.getName() + ": ***invalid_records_query:- " + invalid_records_query + "***")

    val valid_records = sparkSession.sql(valid_records_query)
    val invalid_records = sparkSession.sql(invalid_records_query)

    List(valid_records, invalid_records)

  }

  /*
   * Validate the Schema based on the No of columns
   * @args Dafataframe and Schema
   * @return Status in integer
   */
  def validateSchemaCheck(df: DataFrame, schemaList: String): Int = {
    val schemaListArr = schemaList.replace("|", "#").split("#")
    //df.columns.map(x => println(x))
    schemaListArr.map(x => println(x))
    if (df.columns.map(x => x.toUpperCase()).deep == schemaListArr.map(x => x.toUpperCase()).deep)
      return 0
    else
      return 1

  }

  def dataTypeStandarization(inputDf: DataFrame, schemaList: String): DataFrame = {

    log.info(this.getClass.getName() + ": *** DataType Standarization process started  ***")
    var seqDf = inputDf
    var dataTypeMap = Map.empty[String, String]

    val dataTypeWithCol = schemaList

    val arrdatatypeWithCol = dataTypeWithCol.replace("||", "##").split("##")

    arrdatatypeWithCol.map({ x =>
      dataTypeMap = dataTypeMap ++ Map(x.split("::")(0) -> x.split("::")(1))
    })

    val colName = dataTypeMap.keySet

    for (key <- colName) {
      //,when(seqDf.schema(i).dataType =="STRINGTYPE",seqDf(i).cast(StringType))
      dataTypeMap.getOrElse(key, "NA").toUpperCase() match {
        case "STRINGTYPE" | "STRING"  | "VARCHAR" => seqDf = seqDf.withColumn(key, seqDf(key).cast(StringType))
        case "INTEGER" | "INT"  => seqDf = seqDf.withColumn(key, seqDf(key).cast(IntegerType))
        case "DOUBLE"     => seqDf = seqDf.withColumn(key, seqDf(key).cast(DoubleType))
        case "BOOLEAN"    => seqDf = seqDf.withColumn(key, seqDf(key).cast(BooleanType))
        case "LONG"       => seqDf = seqDf.withColumn(key, seqDf(key).cast(LongType))
        case "FLOAT"      => seqDf = seqDf.withColumn(key, seqDf(key).cast(FloatType))
        case _            => seqDf = seqDf.withColumn(key, seqDf(key).cast(StringType))

      }

    }
    log.info(this.getClass.getName() + ": *** DataType Standarization process ended  ***")
    seqDf
  }

  
  
   def processKeyValidationRule(sourceDataDF: DataFrame, inputConfigData: Map[String, String]): DataFrame = {

    log.info("Starting Key Validation Process")
    val layerName = GlobalVariables.getLayerName
    val keyFieldValidationObject = new KeyFieldValidation()

    var errorColumn = inputConfigData.get(layerName + "_VALIDATION_KEY_FIELD").get.replace("||", "##").split("##").toList//.split("||")

    log.info("validate col:" + errorColumn.foreach(println))
    //log.info(errorColumn(0) + errorColumn(0).equalsIgnoreCase("na"))

    // if(!errorColumn(0).equalsIgnoreCase("na") || errorColumn(0).isEmpty()){
    log.info("Performing KeyValidation on Column(s): " + errorColumn)
    //var firmName = inputConfigData.get(CommonConstants.KEY_FIRM_CD).get(0)
    var firmName = ""

    val mainRDD = sourceDataDF.rdd
    val names = sourceDataDF.columns
    val schema = StructType(names.map(col => StructField(col, StringType, true)))

    var result = mainRDD.map(row => {

      errorColumn.map(col =>

        keyFieldValidationObject.fieldValidationCheck(col, row, inputConfigData)) //.filter(_ != null)

    }).flatMap(data => data).distinct()

    import sqlContext.implicits._
    var errorTable = result.map(line => line._2).filter(_ != null).toDF()

    errorTable.show()
    CommonUtils.writeToParquetFile(errorTable, "src//main//resources//error//", "true", "overwrite")
   // errorTable.showOrNoShow(debugFlag)

    var junkRow = result.map(_._1).filter(_ != null)
    var junkRecords = sourceDataDF.sqlContext.createDataFrame(junkRow, sourceDataDF.schema)
    var finalRecords = sourceDataDF.except(junkRecords)
    log.info("Done with Key Validation Process")
    finalRecords
    /* }
    else{
         log.info("Done with Key Validation Process,there were no columns for validation")
      sourceDataDF
    }*/

  }

  
  
}