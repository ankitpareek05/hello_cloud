package com.deloitte.bmo.operationsImpl
import org.apache.spark.sql._
import com.deloitte.bmo.generic.utils.GlobalVariables
import com.deloitte.bmo.rules.ValidationRules
import org.apache.spark.sql.functions._
//import scala.collection.mutable.Map
import scala.collection.Map
import com.deloitte.bmo.framework.Logging
import org.apache.spark.sql.types._
import com.deloitte.bmo.generic.utils.CommonUtils
import com.deloitte.bmo.generic.utils.SparkInitialization



/*
 * This class is responsible for DataQuality.
 * Validates all the required checkes
 *
 */
class ValidationCheckImpl extends Logging {
  
  val sparkSession= SparkInitialization.getSparkSession()

  //  val logger = Logger("CustomLogger")
  /*
 * This method performs basic validation which includes
 * schema validation, null check, not null check and datatype conversion
 * @ param Dataframe and config file
 */
  def performValidationCheck(inputDf: DataFrame, configData: Map[String, String]): DataFrame= {
    GlobalVariables.getLayerName()
    val primary_key_col_list: String = configData.getOrElse( GlobalVariables.getLayerName()+"_VALIDATION_PRIMARY_KEY", "NA")
    val configSchema: String = configData.getOrElse(GlobalVariables.getLayerName()+"_VALIDATION_SCHEMA_CHECK", "NA")
    val schemaWithDatatype=configData.getOrElse(GlobalVariables.getLayerName()+"_VALIDATION_DATATYPE_CONVERSION", "NA")
    val rules = new ValidationRules()

    val schemaCheck: Int = rules.validateSchemaCheck(inputDf, configSchema)
    println(schemaCheck)

    /* Calling Schema Checks */

    if (schemaCheck != 0) {
      log.info(this.getClass.getName() + ": ***Source file schema columns and Config File schema unmatched. Please check the config File***")
      System.exit(0)
    } else {
      log.info(this.getClass.getName() + ": ***Source File schema Columns matched with the schema mentioned in Config file***")
    }
    
    var standarizedDf=sparkSession.emptyDataFrame
    
    /*  Validating null checks  */
    if (!primary_key_col_list.isEmpty) {
      val validatedDf = rules.validateNotNull(inputDf, primary_key_col_list.replace("||","##").split("##"))
      
      standarizedDf=validatedDf(0)
      log.info(this.getClass.getName() + ": ***Primary Key validated Dataframe=PASS  ***")
      standarizedDf.show()

     
      
      val FailValidatedPkCheck = validatedDf(1)
      log.info(this.getClass.getName() + ": ***Primary Key validated Dataframe:FAIL  ***")
      FailValidatedPkCheck.show()
      
     standarizedDf=rules.dataTypeStandarization(standarizedDf, schemaWithDatatype)
      
      log.info(this.getClass.getName() + ": ***Schema After Datatype Standarization***")
      standarizedDf.printSchema()
      
      log.info(this.getClass.getName() + ": ***DataFrame After Datatype Standarization***")
      standarizedDf.show()
    
    }
    /* Calling Datatype Standarization */

    /* Calling */
    standarizedDf

  }

  
}