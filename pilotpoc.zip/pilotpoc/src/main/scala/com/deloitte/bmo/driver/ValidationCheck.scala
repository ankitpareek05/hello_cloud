package com.deloitte.bmo.driver

import scala.collection.Map

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.current_timestamp
import org.apache.spark.sql.functions.input_file_name
import org.apache.spark.sql.functions.row_number
import org.apache.spark.sql.functions.unix_timestamp
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel
import com.deloitte.bmo.generic.utils.GlobalVariables

//import scala.collection.mutable.Map
import com.deloitte.bmo.framework.Logging
import com.deloitte.bmo.generic.utils.CommonUtils
import com.deloitte.bmo.generic.utils.SparkInitialization
import com.deloitte.bmo.operationsImpl.RuleProcessImpl
import com.deloitte.bmo.operationsImpl.ValidationCheckImpl

/**
 * Data Validation Program Implements a functionality
 * that validates the basic checks in the source.
 * It performs the validation for null check / blank check
 * on Primary columns, Schema check , Datatype check/cast as
 * per target table and Data field format check for all the
 * sources with the help of config file
 *
 * @version 1.0
 * @author Deloitte
 * @todo Add more functionality.
 */

object ValidationCheck extends Logging {

  case class AUDIT_TABLE(var AUDIT_ID: String, var FILE_NAME: String, var SOURCE: String, var LAYER: String, var TOTAL_RECORD_COUNT: String, var TOTAL_ERROR_RECORD_COUNT: String, var TOTAL_PROCESSED_RECORD_COUNT: String, var PROCESSED_DATE: String, var STATUS: String)

  val sparkSession = SparkInitialization.getSparkSession()
  
  import sparkSession.implicits._
  

  def main(args: Array[String]) {

    // Uncomment the below logic before running on Cluster

    /*    val logger = Logger("CustomLogger")

    if (args.length != 4) {
      logErr.error("Invalid number of arguments passed")
      logErr.error("Arguments Usage: <config-file path> <source-name>  <Layer Name><File Name>")
      System.exit(1)
    }



    val configPath = args(0).trim()
    val sourceName = args(1).trim().toUpperCase()
    val layerName = args(2).trim().toUpperCase()
    val fileName = args(3).trim().toUpperCase()*/

    /** Assign Input parameters to values */

    val configPath = "src/main/resources/config.csv"
    val sourceName = "SALESFORCE".toUpperCase()
    val layerName = "L0".toUpperCase()
    val fileType = "CSV".toUpperCase()
    val fileName = "ACCOUNT".toUpperCase()
    //
    GlobalVariables.setLayerName(layerName)
    GlobalVariables.setSource_name(sourceName)

    var processedCount = "0"

    log.info(this.getClass.getName() + ": ***Logging Started for source, " + sourceName + " DQ Check utility running ***")

    /* Parse the config file */

    val configDataRaw: Map[String, String] = CommonUtils.parseConfigFile1(configPath, fileName)

    var configData = configDataRaw.filter(key => key._1.startsWith(layerName) && key._1.contains("VALIDATION") || key._1.contains("STANDARIZATION"))
    //configData.map(x => println(x._1 + "+++" + x._2))

    /* Read the data from */

    val filePath = configData.getOrElse(layerName + "_" + "VALIDATION_INPUT_PATH", "NA")
    log.info(this.getClass.getName() + ": Source file input path= " + filePath)

    val outputPath = configData.getOrElse(layerName + "_" + "VALIDATION_OUTPUT_PATH", "NA")
    log.info(this.getClass.getName() + ": Source file output path= " + outputPath)

    val auditpath = configData.getOrElse(layerName + "_" + "VALIDATION_AUDIT_TABLE_OUTPUT_PATH", "NA")
    log.info(this.getClass.getName() + ": Audit table output path= " + auditpath)

    var inputDf = CommonUtils.readFromCsvFile(filePath, "true", "false")
    inputDf = inputDf.toDF(inputDf.columns.map(_.toUpperCase()): _*)

    val inputFilePath = inputDf.withColumn("input_file", input_file_name).select("input_file").head.getString(0)
    val totalCount = inputDf.count().toString()

    try {
      val basicChecks = new ValidationCheckImpl()

      // var standardDf = basicChecks.performValidationCheck(inputDf, configData)
      //standardDf.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

      /* Calling Key field Validation Check */
      var standardDf = CommonUtils.getDfAfterKeyValidation(inputDf, configData)

      val ruleAction = configData.keySet.filter(x => x.contains("_RULE"))

      /* Calling Rules implemenatation service layer */
      if (!ruleAction.isEmpty) {
        log.info("Calling Rules Based on Config File")
        val ruleCall = new RuleProcessImpl
        standardDf = ruleCall.processUtilityRule(standardDf, layerName, configData)

      }

      standardDf = standardDf.select("CLIENT_ID", "CLIENT_ID_NUMERIC_VALIDATION_RULE", "PARTY_TYPE", "CONCATENATE_PIPE_S", "CONCATENATE_HYPHEN_S",
        "NAME", "NAME_UPPERCASE_S", "NAME_LOWERCASE_S", "DOB", "DOB_VALIDATION_RULE", "MSTATUS", "MSTATUS_INITCAP_S",
        "SYSDATE", "SYSDATE_REMOVE_LEADING_ZERO_C", "UID", "UID_REMOVE_NONNUMBER_C", "UID_HYPHN_REPLACMENT_C",
        "URL", "URL_HTTP_REPLACMENT_S", "COUNTRY", "CONTACT_NUMBER", "PHONE_NO_STANDARIZATION_IS_VALID", "PHONE_NO_STANDARIZATION", "CONTACT_NUMBER_PARSE_S", "CONTACT_NUMBER_VALIDATION_RULE",
        "US_STATE", "USA_STATE_VALIDATION_RULE", "US_ZIP_CODE", "USA_ZIP_CODE_VALIDATION_RULE", "ADDRESS", "ADDRESS_REPLACE_SLASH_C", "SOURCE", "SOURCE_REMOVE_PERIOD_C", "SOURCE_TRIM_C")

      val processedCount = standardDf.count().toString()
      standardDf.show()
      val errorCount = ""

      CommonUtils.writeToParquetFile(standardDf, outputPath, "true", "overwrite")
      
      val auditTableSeq = Seq(AUDIT_TABLE("", inputFilePath, sourceName, layerName, totalCount, "", processedCount, "", "SUCCESS"))
      var auditTable = auditTableSeq.toDF()
      auditTable = auditTable.withColumn("AUDIT_ID", unix_timestamp() + row_number().over(Window.orderBy("SOURCE")))
        .withColumn("TOTAL_ERROR_RECORD_COUNT", col("TOTAL_RECORD_COUNT").cast(IntegerType) - col("TOTAL_PROCESSED_RECORD_COUNT").cast(IntegerType))
        .withColumn("TOTAL_ERROR_RECORD_COUNT", col("TOTAL_ERROR_RECORD_COUNT").cast(StringType))
        .withColumn("PROCESSED_DATE", current_timestamp())

        auditTable.show()
      CommonUtils.writeToParquetFile(auditTable, auditpath, "true", "append")

    } catch {
      case ex: Exception => {

        val auditTableSeq = Seq(AUDIT_TABLE("", inputFilePath, sourceName, layerName, totalCount, "", processedCount, "", "FAILED"))
        var auditTable = auditTableSeq.toDF()
        auditTable = auditTable.withColumn("AUDIT_ID", unix_timestamp() + row_number().over(Window.orderBy("SOURCE")))
          .withColumn("TOTAL_ERROR_RECORD_COUNT", col("TOTAL_RECORD_COUNT").cast(IntegerType) - col("TOTAL_PROCESSED_RECORD_COUNT").cast(IntegerType))
          .withColumn("TOTAL_ERROR_RECORD_COUNT", col("TOTAL_ERROR_RECORD_COUNT").cast(StringType))
          .withColumn("PROCESSED_DATE", current_timestamp())

      }
    }

  }
}