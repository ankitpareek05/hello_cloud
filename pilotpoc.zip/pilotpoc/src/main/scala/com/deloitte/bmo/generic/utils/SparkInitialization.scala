package com.deloitte.bmo.generic.utils

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.SparkSession
import com.deloitte.bmo.framework.Logging

/**
 * '''Object for Spark Initialization'''
 * Access the sessions like
 *
 * {{{
 * val spark = SparkInitialization.getSparkSession()
 * val sc = SparkInitialization.getSparkContext()
 * }}}
 *
 * @constructor Initialize Spark Session/Context, SQL Context
 */

object SparkInitialization extends Logging {

  val properties = System.getProperties()
  properties.setProperty("hadoop.home.dir", "C:\\winutils")

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("org").setLevel(Level.ERROR)

  log.info("Initiating SparkSession")

  private val sparkSession = SparkSession.builder().appName("Pilot Project")
    .master("local[*]")
    .config("spark.sql.broadcastTimeout", "36000")
    .config("spark.serializer", classOf[KryoSerializer].getName)
    .config("spark.sql.tungsten.enabled", "true")
    .config("spark.sql.crossJoin.enabled", "true")
    .config("spark.io.compression.codec", "snappy")
    .config("spark.rdd.compress", "true")
    .config("spark.ui.showConsoleProgress", "false")
    //    .enableHiveSupport()
    .getOrCreate()

  log.info("SparkSession created")

  private val sparkContext = sparkSession.sparkContext
  private val sqlContext = sparkSession.sqlContext

  /*  sparkContext.hadoopConfiguration.set("fs.s3a.access.key", "AKIAI7KL5GPRKX633QJA")
  sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", "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")
  sparkContext.hadoopConfiguration.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
  sparkContext.hadoopConfiguration.set("fs.s3a.connection.timeout", "200000")*/

  /*  val executorNum = sparkContext.getConf.getOption("spark.executor.instances").getOrElse("NA")
  log.info("Number of Executor : " + executorNum)
  val executorCore = sparkContext.getConf.getOption("spark.executor.cores").getOrElse("NA")
  log.info("Each Executor Core : " + executorCore)

  if (!executorNum.equalsIgnoreCase("NA") && !executorCore.equalsIgnoreCase("NA")) {
    val repartitionNum = (8 * executorNum.toInt * executorCore.toInt).toInt
    GlobalVariables.setRepartitionNum(repartitionNum)
    log.info("Repartition Number is set to - " + repartitionNum.toString())
  }
*/
  /**
   * Getter for Spark Session
   */

  def getSparkSession(): SparkSession = {
    log.info("Getting Spark Session")
    this.sparkSession
  }

  /**
   * Getter for Spark Context
   */
  def getSparkContext(): SparkContext = {
    log.info("Getting Spark Context")
    this.sparkContext
  }

  /**
   * Getter for SQL Context
   */
  def getSqlContext(): SQLContext = {
    log.info("Getting SQL Context")
    this.sqlContext
  }

}