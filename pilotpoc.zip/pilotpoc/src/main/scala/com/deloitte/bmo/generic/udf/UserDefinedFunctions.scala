package com.deloitte.bmo.generic.udf

object UserDefinedFunctions {
  
}