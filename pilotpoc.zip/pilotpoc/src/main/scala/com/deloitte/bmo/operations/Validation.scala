package com.deloitte.bmo.operations

trait Validation {
  
}