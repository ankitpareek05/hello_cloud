package com.deloitte.bmo.framework

import java.text.SimpleDateFormat
import java.util.Calendar
import scala.collection.Map
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel

import com.deloitte.bmo.generic.utils.CommonConstants
import com.deloitte.bmo.generic.utils.CommonUtils
import com.deloitte.bmo.generic.utils.SparkInitialization
import java.util.regex.Pattern

/**
 * '''Object for Change Data Capture Framework'''
 *
 * Contains Implementation of SCD-1 and SCD-2
 *
 * @author Deloitte
 * @version 1.0
 * @todo Add Functionality
 */
object ChangeDataCapture {
  val spark = SparkInitialization.getSparkSession()

  /**
   * '''SCD Type 2 Implementation'''
   * @param old_DF History DataFrame
   * @param incrementDF Increment DataFrame
   * @return (latestDF, historyDF)
   */
  def scd2(oldDF: DataFrame, incrementDF: DataFrame, configData: Map[String, String]): (DataFrame, DataFrame) = {

    val layerName = "L0"
    val partitionByCol: String = configData.getOrElse(layerName + "_" + "PARTITION_BY_COL", "NA").split(Pattern.quote("||")).map(_.trim()).mkString(",")
    val orderByCol: String = configData.getOrElse(layerName + "_" + "ORDER_BY_COL", "NA").split(Pattern.quote("||")).map(_.trim()).mkString(",")
    val keyColDataCapture: Seq[String] = configData.getOrElse(layerName + "_" + "KEY_COL_DATA_CAPTURE", "NA").split(Pattern.quote("||")).map(_.trim()).toSeq

    println(partitionByCol)
    println(orderByCol)
    println(keyColDataCapture)
    val formatter = new SimpleDateFormat("YYYY-MM-dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -1)
    val oneDayBefore = formatter.format(cal.getTime())
    //println(formatter.format(oneDayBefore))

    try {

      var incrementDF1 = incrementDF.join(oldDF, keyColDataCapture, "left_anti")
      incrementDF1.printSchema()
      oldDF.printSchema()
      var unionDF = oldDF.union(incrementDF1)

      unionDF.createOrReplaceTempView("unionDF")

      val sqlQuery = s"SELECT * , row_number() over(partition by $partitionByCol order by $orderByCol) as row_num FROM unionDF"
      println(sqlQuery)
      var sqlDF = spark.sql(sqlQuery)
      println("===> UnionDF")
      sqlDF.show()
      sqlDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

      /*
       * Adding Infinite date to the latest Data
       */
      var latestDF = sqlDF.filter(sqlDF("row_num") === 1)
        .withColumn(CommonConstants.END_DATE_COL_NAME, lit("9999-12-31"))
        .withColumn(CommonConstants.CURRENT_FLAG, lit("Y"))

      /*
			 * Adding date a day before processing date.
			 */
      var outdatedDF = sqlDF.filter(sqlDF("row_num") > 1).withColumn(CommonConstants.END_DATE_COL_NAME, lit(oneDayBefore))
        .withColumn(CommonConstants.CURRENT_FLAG, lit("N"))

      latestDF.persist()
      outdatedDF.persist()
      (latestDF.drop("row_num"), outdatedDF.drop("row_num"))

    } catch {
      case e: Exception =>
        e.printStackTrace()
        (null, null)
    }
  }

  /**
   * '''SCD Type 1 Implementation'''
   * @param old_DF History DataFrame
   * @param incrementDF Increment DataFrame
   * @return latestDF
   */
  def scd1(oldDF: DataFrame, incrementDF: DataFrame, configData: Map[String, Array[String]]): DataFrame = {

    val partitionByCol: String = Array().mkString(",")
    val orderByCol: String = Array().mkString(",")

    try {
      var unionDF = oldDF.union(incrementDF)

      unionDF.createOrReplaceTempView("unionDF")

      val sqlQuery = """SELECT * , row_number().over(partition by $partitionByCol order by $orderByCol) as row_num FROM unionDF"""

      var sqlDF = spark.sql(sqlQuery)
      sqlDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

      var latestDF = sqlDF.filter(sqlDF("row_num") === 1)

      latestDF

    } catch {
      case e: Exception =>
        e.printStackTrace()
        null
    }
  }
}