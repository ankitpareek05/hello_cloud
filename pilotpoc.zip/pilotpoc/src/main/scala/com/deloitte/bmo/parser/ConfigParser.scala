package com.deloitte.bmo.parser

class ConfigParser {
  
}