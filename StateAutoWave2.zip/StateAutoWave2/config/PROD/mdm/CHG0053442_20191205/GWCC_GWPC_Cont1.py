# Import all required libraries
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext, Row, Column
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.dataframe import *
from pyspark.sql.column import *
from pyspark.sql.window import *
from pyspark.ml import Pipeline, Model, PipelineModel
from pyspark.ml.feature import RegexTokenizer, Tokenizer, NGram, HashingTF, MinHashLSH
import datetime as dt
import pymongo, pandas, json, os, sys, string, uuid
import base64 as b64
from base64 import b64decode 

# Main Module

if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 23:
       print("Error usage: GWCC_GWPC_Cont1.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)

    cc_stage = sys.argv[1]
    cc_prcsd_secr = sys.argv[2] 
    cc_stage_secr = sys.argv[3]
    
    pl_stage_secr = sys.argv[4]
    pl_stage = sys.argv[5]
    pl_prcsd_secr = sys.argv[6]
    
    cl_stage_secr = sys.argv[7]
    cl_stage = sys.argv[8]
    cl_prcsd_secr = sys.argv[9]
    
    muserid = sys.argv[10]
    mpwd = sys.argv[11]
    mhost = sys.argv[12]
    mport = sys.argv[13]
    mprop1 = sys.argv[14]
    mprop2 = sys.argv[15]
    mprop3 = sys.argv[16]
    mprop4 = sys.argv[17]
    
    mdatabase = sys.argv[18]
    mcustomer = sys.argv[19]
    mstats = sys.argv[20]
    
    cc_pc_grp_data_loc = sys.argv[21]
    cc_pc_apc_data_loc = sys.argv[22]
		
    # Setup required Batch variables
    print("[INFO] Setting up Batch variables....")
    Batch_Start_Time = dt.datetime.now()
    date_ext = Batch_Start_Time.strftime("%Y-%m-%d")
    mpassword = b64decode(mpwd).decode('utf-8')    
    ConnString = "mongodb://{0}:{1}@{2}:{3}/?{4}&{5}&{6}&{7}".format(muserid, mpassword, mhost, mport, mprop1, mprop2, mprop3, mprop4)	
    print("MongoDB Connection: " + ConnString)

    print("[INFO] Spark Session Setup....")   
    spark = SparkSession.builder.appName("GWCC_GWPC_Cont1").enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    
    # Create a MongoDB Client
    print("[INFO] Connecting to Mongo DB Server....")
    mclient = pymongo.MongoClient(ConnString)
    
    # Database and Collection to be used
    mdb = mclient[mdatabase]
    mcustcoll = mdb[mcustomer]
    mstatcoll = mdb[mstats]
    
    # Setup transform MDM Stats variables
    print("[INFO] Setting up transform mdm stat variables....") 
    run_name_cc = "GWCC_Contacts"
    run_name_pc_pl = "GWPL_Contacts"
    run_name_pc_cl = "GWCL_Contacts" 
    ing_dttm = dt.datetime.now()
    ingestn_dttm = ing_dttm.strftime("%Y-%m-%d %H:%M:%S.%f")
    init_mut = "1900-01-01 00:00:00.000000"
    
    # Location to read combined Claims and Policy data
    CC_PC_Grouped_Data_Location = cc_pc_grp_data_loc+date_ext
    CC_PC_APC_Data_Location = cc_pc_apc_data_loc+date_ext
    
    #Read transform_mdm_stats table to get previous run max update time, 
    #First Run, Reads 1900-01-01 00:00:00.000000 and will read all records > this time, gives historical load
    #Last Step, inserts current run max update time 
    #Subsequent Run, Reads previous run max update time, and will records > this time, gives incremental load
    print("[INFO] Reading Stats table to get previous run max update time to read Incremental....")
    if mstatcoll.count({"RUN_NAME":"GWCC_Contacts"}, limit = 1) == 0:
       ccdata = [(run_name_cc,ingestn_dttm,init_mut)]
       cc_df = spark.createDataFrame(ccdata,["RUN_NAME","INGESTION_DTTM","MAX_UPD_TIME"])	
       cc_list = cc_df.toJSON().collect()
       cc_ld = [json.loads(sts) for sts in cc_list]
       mstatcoll.insert_one(cc_ld[0])       	
    if mstatcoll.count({"RUN_NAME":"GWPL_Contacts"}, limit = 1) == 0:
       pldata = [(run_name_pc_pl,ingestn_dttm,init_mut)]
       pl_df = spark.createDataFrame(pldata,["RUN_NAME","INGESTION_DTTM","MAX_UPD_TIME"])	
       pl_list = pl_df.toJSON().collect()
       pl_ld = [json.loads(sts) for sts in pl_list]
       mstatcoll.insert_one(pl_ld[0])
    if mstatcoll.count({"RUN_NAME":"GWCL_Contacts"}, limit = 1) == 0:
       cldata = [(run_name_pc_cl,ingestn_dttm,init_mut)]
       cl_df = spark.createDataFrame(cldata,["RUN_NAME","INGESTION_DTTM","MAX_UPD_TIME"])	
       cl_list = cl_df.toJSON().collect()
       cl_ld = [json.loads(sts) for sts in cl_list]
       mstatcoll.insert_one(cl_ld[0])
	
    prev_cc = list(mstatcoll.find({"RUN_NAME":"GWCC_Contacts"},{"MAX_UPD_TIME":1, "_id":0}).sort("MAX_UPD_TIME", pymongo.DESCENDING).limit(1))
    prev_pc_pl = list(mstatcoll.find({"RUN_NAME":"GWPL_Contacts"},{"MAX_UPD_TIME":1, "_id":0}).sort("MAX_UPD_TIME", pymongo.DESCENDING).limit(1))
    prev_pc_cl = list(mstatcoll.find({"RUN_NAME":"GWCL_Contacts"},{"MAX_UPD_TIME":1, "_id":0}).sort("MAX_UPD_TIME", pymongo.DESCENDING).limit(1))
    
    prev_cc_mut = str(prev_cc[0]["MAX_UPD_TIME"])
    prev_pc_pl_mut = str(prev_pc_pl[0]["MAX_UPD_TIME"])
    prev_pc_cl_mut = str(prev_pc_cl[0]["MAX_UPD_TIME"])
    
    # Source Table Data
    print("[INFO] Reading Source Table Data from S3 Bucket Locations....")
    # Read Claims data from Data Lake
    print("[INFO] Reading GWCC Tables Data....")
    cc_contact = spark.read.parquet(cc_prcsd_secr + "cc_contact").where(col("UpdateTime") > prev_cc_mut)
    cc_claim = spark.read.parquet(cc_stage + "cc_claim")
    cc_policy = spark.read.parquet(cc_stage + "cc_policy")
    cc_claimcontact = spark.read.parquet(cc_stage_secr + "cc_claimcontact")
    cc_claimcontactrole = spark.read.parquet(cc_stage + "cc_claimcontactrole")
    cc_address = spark.read.parquet(cc_stage + "cc_address")
    cc_officialid = spark.read.parquet(cc_prcsd_secr + "cc_officialid")
    
    # Read Policy Center - Personal Lines data from Data Lake
    print("[INFO] Reading GWPL Tables Data....")
    pc_pl_contact = spark.read.parquet(pl_stage_secr + "pc_contact").where(col("UpdateTime") > prev_pc_pl_mut)
    pc_pl_policyperiod = spark.read.parquet(pl_stage_secr + "pc_policyperiod")
    pc_pl_policy = spark.read.parquet(pl_stage + "pc_policy")
    pc_pl_policycontactrole = spark.read.parquet(pl_stage_secr + "pc_policycontactrole")
    pc_pl_address = spark.read.parquet(pl_stage + "pc_address")
    pc_pl_account = spark.read.parquet(pl_stage + "pc_account")
    pc_pl_accountcontact = spark.read.parquet(pl_stage + "pc_accountcontact")
    pc_pl_officialid = spark.read.parquet(pl_prcsd_secr + "pc_officialid")
    
    # Read Policy Center - Commercial Lines data from Data Lake
    print("[INFO] Reading GWCL Tables Data....")
    pc_cl_contact = spark.read.parquet(cl_stage_secr + "pc_contact").where(col("UpdateTime") > prev_pc_cl_mut)
    pc_cl_policyperiod = spark.read.parquet(cl_stage_secr + "pc_policyperiod")
    pc_cl_policy = spark.read.parquet(cl_stage + "pc_policy")
    pc_cl_policycontactrole = spark.read.parquet(cl_stage_secr + "pc_policycontactrole")
    pc_cl_address = spark.read.parquet(cl_stage + "pc_address")
    pc_cl_account = spark.read.parquet(cl_stage + "pc_account")
    pc_cl_accountcontact = spark.read.parquet(cl_stage + "pc_accountcontact")
    pc_cl_officialid = spark.read.parquet(cl_prcsd_secr + "pc_officialid")
    
    #Get the current run contacts max update time to insert in transform_mdm_stats, which will be used for next run
    print("[INFO] Read current run contacts and get max update time to insert to mdm stats for next run....")
    cc_cont_cnt = cc_contact.count()
    pc_pl_cont_cnt = pc_pl_contact.count()
    pc_cl_cont_cnt = pc_cl_contact.count()

    if cc_cont_cnt == 0:
       curr_cc_mut = prev_cc_mut
    else:
       curr_cc_mut = cc_contact.agg({"updatetime":"max"}).head()['max(updatetime)'].strftime("%Y-%m-%d %H:%M:%S.%f")
    
    if pc_pl_cont_cnt == 0:
       curr_pc_pl_mut = prev_pc_pl_mut
    else:
       curr_pc_pl_mut = pc_pl_contact.agg({"updatetime":"max"}).head()['max(updatetime)'].strftime("%Y-%m-%d %H:%M:%S.%f")

    if pc_cl_cont_cnt == 0:
       curr_pc_cl_mut = prev_pc_cl_mut
    else:
       curr_pc_cl_mut = pc_cl_contact.agg({"updatetime":"max"}).head()['max(updatetime)'].strftime("%Y-%m-%d %H:%M:%S.%f")
    
    ### Curate Claims Contact data and write the final output to S3 ####
    
    # Select required fields from sourced data
    print("[INFO] Selecting required columns from Claims source....")
    cc_claim_select = cc_claim.select('id',
                                      'policyprefixnum_ext', 
                                      'policysuffixnum_ext',
                                      'claimnumber',
                                      to_date('lossdate'),
                                      'policyid').toDF('Claim_ID',
                                                       'Policy_Prefix',
                                                       'Policy_Number',
                                                       'Claim_Number',
                                                       'Loss_Date',
                                                       'PolicyID')
    
    cc_policy_lob = cc_policy.withColumn("LOB",
                                             when(trim(col('cctl_policytype_name_policytype')).isin('Businessowners (Legacy)',
                                                                                                   'Commercial Auto (Legacy - BAP)',
                                                                                                   'Commercial Package',
                                                                                                   'Commercial Property',
                                                                                                   'Crime',
                                                                                                   'Employment Practices Liability',
                                                                                                   'Farm',
                                                                                                   'General Liability',
                                                                                                   'Inland Marine - Commercial',
                                                                                                   'BusinessownersRetired',
                                                                                                   'Directors and officers',
                                                                                                   'Professional liability',
                                                                                                   'BusinessOwners',
                                                                                                   'Commercial Auto',
                                                                                                   'Commercial Umbrella',
																								   'FAFarmAuto',
																								   'FarmUmbrella',
																								   'FRMFarmRanch',
																								   'CommercialPackage'),
                                             "CL").otherwise(when(trim(col('cctl_policytype_name_policytype')).isin('Boat/Yacht',
                                                                                                                   'Dwelling Fire',
                                                                                                                   'Homeowners',
                                                                                                                   'Inland Marine - Personal',
                                                                                                                   'Personal Auto',
                                                                                                                   'Personal Package',
                                                                                                                   'Personal Umbrella',
                                                                                                                   'Umbrella',
                                                                                                                   'Personal travel'),
                                             "PL").otherwise("Other")))
    
    cc_policy_select = cc_policy_lob.select('id',
                                            'policysystemperiodid',
                                            'policytype',
    #                                        'accountnumber',
                                            'accountnumber_decrypted',											
                                            trim(col('cctl_policytype_name_policytype')),
                                            trim(col('cctl_policysource_typecode_policysource')),
                                            'LOB').toDF('Policy_ID',
                                                       'policysystemperiodid',
                                                       'policytype',
                                                       'Account_Number',
                                                       'Product',
													   'pol_typecode',
                                                       'LOB')
    
    cc_contact_phone = cc_contact.withColumn("Primary_Phone",
                                             when(trim(col('primaryphone')) == 3,
                                             trim(col('cellphone'))).otherwise(when(trim(col('primaryphone')) == 2,
                                             trim(col('homephone'))).otherwise(when(trim(col('primaryphone')) == 1,
                                             trim(col('workphone'))).otherwise(trim(col('primaryphone'))))))
    
    # Remove ASCII values (non alphabets [A-Z; a-z] and non numbers [0-9]) from First, Last, and Entity names
    cc_contact_select = cc_contact_phone.select('id',
                                          upper(trim(regexp_replace(col('firstnamedenorm'),r'[^A-Za-z0-9\x20]',''))),
                                          upper(trim(regexp_replace(col('lastnamedenorm'),r'[^A-Za-z0-9\x20]',''))),
                                          upper(trim(regexp_replace(col('namedenorm'),r'[^A-Za-z0-9\x20\&]',''))),
                                          date_format('dateofbirth','yyyy-MM-dd'),
                                          'primaryaddressid',
                                          'gender',
                                          trim(col('taxid')),
    #                                      trim(col('licensenumber')),
                                          trim(col('licensenumber_decrypted')),										  
                                          trim(col('Primary_Phone')),
                                          lower(trim(col('emailaddress1')))).toDF('Contact_ID',
                                                                                   'First_Name',
                                                                                   'Last_Name',
                                                                                   'Entity_Name',
                                                                                   'DOB',
                                                                                   'primaryaddressid',
                                                                                   'Gender',
                                                                                   'Tax_ID',
                                                                                   'License_Number',
                                                                                   'Primary_Phone',
                                                                                   'Email')
    
    cc_address_select = cc_address.select('id',
                                          upper(trim(col('addressline1'))),
                                          upper(trim(col('city'))),
                                          'cctl_state_typecode_state',
                                          substring(col('postalcode'),0,5)).toDF('id',
                                                                                 'AddressLine1',
                                                                                 'City',
                                                                                 'State',
                                                                                 'Zip_Code')
    
    cc_claimcontactrole_select = cc_claimcontactrole.select('claimcontactid',
                                                            'cctl_contactrole_name_role').toDF('Claim_Contact_ID',
                                                                                          'Contact_Role')
    
    cc_claimcontact_select = cc_claimcontact.select('id',
                                                    'contactid',
                                                    'claimid').toDF('Claim_Contact_ID',
                                                                    'Contact_ID',
                                                                    'Claim_ID')
    
    cc_officialid_select = cc_officialid.filter(upper(trim(col("cctl_officialidtype_name_officialidtype"))) == "SSN").select('contactid',
                                                                                                          'officialidtype',
                                                                                                          'officialidvalue',
                                                                                                          'cctl_officialidtype_name_officialidtype').toDF('Contact_ID',
                                                                                                                                                          'officialidtype',
                                                                                                                                                          'officialidvalue',
                                                                                                                                                          'ID_Type')
    
    # JOINS
    print("[INFO] Joining the CC Claims sources....")
    cc_claim_product = cc_claim_select.join(cc_policy_select, cc_claim_select.PolicyID == cc_policy_select.Policy_ID,
                                           how='left')
    
    cc_claimcontact_product = cc_claimcontact_select.join(cc_claim_product, 
                                                         cc_claimcontact_select.Claim_ID == cc_claim_product.Claim_ID,
                                                         how='left').drop(cc_claim_product.Claim_ID)
    
    cc_offid_type_contact = cc_contact_select.join(cc_officialid_select, 
                                                        cc_contact_select.Contact_ID == cc_officialid_select.Contact_ID, 
                                                        how='left').drop(cc_officialid_select.Contact_ID)
    
    cc_claimcontact_role = cc_claimcontact_product.join(cc_claimcontactrole_select,
                                     cc_claimcontact_product.Claim_Contact_ID == cc_claimcontactrole_select.Claim_Contact_ID,
                                          how='left').drop(cc_claimcontactrole_select.Claim_Contact_ID)
    
    cc_contact_role = cc_offid_type_contact.join(cc_claimcontact_role, 
                                             cc_offid_type_contact.Contact_ID == cc_claimcontact_role.Contact_ID,
                                             how='left').drop(cc_claimcontact_role.Contact_ID)
    
    cc_contact_add = cc_contact_role.join(cc_address_select, 
                                           cc_contact_role.primaryaddressid == cc_address_select.id,
                                           how='left').drop(cc_address_select.id)
    
    # Transformations
    print("[INFO] Applying transformations on Claims source....")
    # Some contacts have First, Last, or Entity Name as Address. If so, remove names as addresses. Cleansing rule
    cc_contact_address = cc_contact_add.withColumn("Address_Line1", 
                                                   when((trim(regexp_replace(col('AddressLine1'),r'[^A-Za-z0-9\x20]','')) == trim(col('First_Name'))) | 
                                                        (trim(regexp_replace(col('AddressLine1'),r'[^A-Za-z0-9\x20]','')) == trim(col('Last_Name'))) |
                                                        (trim(regexp_replace(col('AddressLine1'),r'[^A-Za-z0-9\x20]','')) == concat_ws("",trim(col('First_Name')),lit(' '),trim(col('Last_Name')))) |														
                                                        (trim(regexp_replace(col('AddressLine1'),r'[^A-Za-z0-9\x20\&]','')) == trim(col('Entity_Name'))),
                                                    None).otherwise(trim(col('AddressLine1'))))
    
    cc_contact_final = cc_contact_address.select(concat_ws("",lit('CC-'),col('Contact_ID')),
                                                 'Account_Number',
                                                 when(col('pol_typecode') == 'pods',
												 concat_ws("",col('Policy_Prefix'),col('Policy_Number'))).otherwise(col('Policy_Number')),
                                                 'Claim_ID',
                                                 'Claim_Number',
                                                 'Loss_Date',  
                                                 concat_ws("-",col('LOB'),col('Product')),
                                                 'License_Number',
                                                 'ID_Type',
                                                 'officialidvalue',
                                                 when((length(trim(concat_ws(" ",col('First_Name'),col('Last_Name')))) == 0),col('Entity_Name')).otherwise(trim(concat_ws(" ",col('First_Name'),col('Last_Name')))),
                                                 trim(col('Entity_Name')),
                                                 'DOB',                                             
                                                 'Gender',                                           
                                                 when((length(trim(col('Primary_Phone'))) == 7),
												 concat_ws("",lit('000'),lit('-'),substring(col('Primary_Phone'),1,3),lit('-'),substring(col('Primary_Phone'),4,4))).otherwise(when((length(trim(col('Primary_Phone'))) == 10),
												 concat_ws("",substring(col('Primary_Phone'),1,3),lit('-'),substring(col('Primary_Phone'),4,3),lit('-'),substring(col('Primary_Phone'),7,4))).otherwise(when((length(trim(col('Primary_Phone'))) == 11),
												 concat_ws("",substring(col('Primary_Phone'),2,3),lit('-'),substring(col('Primary_Phone'),5,3),lit('-'),substring(col('Primary_Phone'),8,4))).otherwise(None))),
                                                 'Email',
                                                 when((cc_contact_address["Address_Line1"].isNull() & cc_contact_address["City"].isNull() & cc_contact_address["State"].isNull()), 
                                                 None).otherwise(concat_ws("",lit('"'),col('Address_Line1'),lit(", "),col('City'),lit(", "),col('State'),lit('"'))),                                             
                                                 'Zip_Code',                                                                                    
                                                 'Contact_Role',                                           
                                                 'LOB').toDF('Contact_ID',
                                                             'Account_Number',
                                                             'Policy_Number',
                                                             'Claim_ID',
                                                             'Claim_Number',
                                                             'Loss_Date',   
                                                             'Product',
                                                             'License_Number',
                                                             'ID_Type',
                                                             'ID_Value',
                                                             'Full_Name',
                                                             'Entity_Name',
                                                             'DOB',
                                                             'Gender',                                                       
                                                             'Primary_Phone',
                                                             'Email',
                                                             'Address',
                                                             'Zip_Code',
                                                             'Contact_Role',                                                       
                                                             'LOB')
    
    # Filter data based on roles - business requirement
    cc_contact_rolefilter = cc_contact_final.filter(trim(col('Contact_Role')).isin('Insured Vehicle Driver',
                                                                                    'Injured Person',
                                                                                    'Plaintiff',
                                                                                    'Property Owner',
                                                                                    'Policy Contact',
                                                                                    'Claimant Driver',
                                                                                    'Excluded Party',
                                                                                    'Driver',
                                                                                    'Doing Business As',
                                                                                    'Check Payee',
                                                                                    'Former Driver',
                                                                                    'Unlisted Insured Vehicle Driver',
                                                                                    'Loss Payee',
                                                                                    'Former Doing Business As',
                                                                                    'Main Contact',
                                                                                    'Alternate Contact',
                                                                                    'Other',
                                                                                    'Covered Party',
                                                                                    'Former Insured',
                                                                                    'Passenger',
                                                                                    'Former Policy Contact',
                                                                                    'Former Check Payee',
                                                                                    'Former Excluded Party',
                                                                                    'Adverse Party',
                                                                                    'Former Covered Party',
                                                                                    'Injured Company',
                                                                                    'Reporter',
                                                                                    'Insured',
                                                                                    'Pedestrian',
                                                                                    'Tenant',
                                                                                    'Claimant',
                                                                                    'Policy holder',
                                                                                    'Former Policy Holder',
                                                                                    'Owner'))
    
    # Drop duplicate records resulted from the JOINs
    cc_contact_unique = cc_contact_final.dropDuplicates()
    cc_contact_runique = cc_contact_rolefilter.dropDuplicates()
    
    # Divide the data into two sets
    # 1. Data which has Entity Names
    # 2. Data which does not have Entity Names (has Full_Name). 
	#    This data set also includes data which have both Entity and Full Names (~ 5 records as of Aug 5th, 2019)
    
    cc_entity_name = cc_contact_runique.filter(((col("Entity_Name").isNotNull()) & (col("Full_Name").isNull()))).select('Contact_ID',
                                                                                                                        'Account_Number',
                                                                                                                        'Policy_Number',
                                                                                                                        'Claim_ID',
                                                                                                                        'Claim_Number',
                                                                                                                        'Loss_Date',   
                                                                                                                        'Product',
                                                                                                                        'Contact_Role',
                                                                                                                        'License_Number',
                                                                                                                        'ID_Type',
                                                                                                                        'ID_Value',
                                                                                                                        'Entity_Name',
                                                                                                                        'DOB', 
                                                                                                                        'Primary_Phone',
                                                                                                                        'Email',
                                                                                                                        'Address',
                                                                                                                        'Zip_Code',
																														'LOB').toDF('Contact_ID',
                                                                                                                                    'Account_Number',
                                                                                                                                    'Policy_Number',
                                                                                                                                    'Claim_ID',
                                                                                                                                    'Claim_Number',
                                                                                                                                    'Loss_Date',   
                                                                                                                                    'Product',
                                                                                                                                    'Contact_Role',
                                                                                                                                    'License_Number',
                                                                                                                                    'ID_Type',
                                                                                                                                    'ID_Value',
                                                                                                                                    'Customer_Name',
                                                                                                                                    'DOB',
                                                                                                                                    'Phone',
                                                                                                                                    'Email',
                                                                                                                                    'Address',
                                                                                                                                    'Zip_Code',                                                                      
                                                                                                                                    'LOB')
    #Filter records where "Full_Name" is not NULL
    cc_full_name = cc_contact_runique.filter(col("Full_Name").isNotNull()).select('Contact_ID',
                                                                                    'Account_Number',
                                                                                    'Policy_Number',
                                                                                    'Claim_ID',
                                                                                    'Claim_Number',
                                                                                    'Loss_Date',   
                                                                                    'Product',
                                                                                    'Contact_Role',
                                                                                    'License_Number',
                                                                                    'ID_Type',
                                                                                    'ID_Value',
                                                                                    'Full_Name',
                                                                                    'DOB',                                                     
                                                                                    'Primary_Phone',
                                                                                    'Email',
                                                                                    'Address',
                                                                                    'Zip_Code',          
                                                                                    'LOB').toDF('Contact_ID',
                                                                                                'Account_Number',
                                                                                                'Policy_Number',
                                                                                                'Claim_ID',
                                                                                                'Claim_Number',
                                                                                                'Loss_Date',   
                                                                                                'Product',
                                                                                                'Contact_Role',
                                                                                                'License_Number',
                                                                                                'ID_Type',
                                                                                                'ID_Value',
                                                                                                'Customer_Name',
                                                                                                'DOB',                                                       
                                                                                                'Phone',
                                                                                                'Email',
                                                                                                'Address',
                                                                                                'Zip_Code',                    
                                                                                                'LOB')
    
    # Union the above two data sets into a single data set
    cc_customer_union = cc_entity_name.union(cc_full_name)
    
    # Filter records that do not have License Number OR SSN/FEIN OR DOB OR Phone OR Email OR Zip Code
    cc_customer = cc_customer_union.filter(~(cc_customer_union.License_Number.isNull() & 
                                             cc_customer_union.ID_Value.isNull() & 
                                             cc_customer_union.DOB.isNull() & 
                                             cc_customer_union.Phone.isNull() &
                                             cc_customer_union.Email.isNull() &
                                             cc_customer_union.Zip_Code.isNull()))
    
    # Filter all Customer_Name contacts which have only special characters and (or) numbers
    cc_customer_alpha = cc_customer.filter(~(cc_customer.Customer_Name.rlike('^[^A-Z]*$')))
    
    # Filter all Customer_Name contacts which are noted as 'Unknown' or 'Unk' or 'Converted Claim'
    cc_customer_final = cc_customer_alpha.filter(~(cc_customer_alpha.Customer_Name.isin('UNKNOWN','UNK','CONVERTED CLAIM')))
      
    
    ### Curate Policy Contact data and write the final output to S3 ####
   
    ### SOURCE PL DATA ###
    print("[INFO] Selecting required columns and Applying transformations on PC_PL source....")
    # Select required columns; Add columns as required; 
    # Some contacts have middle initial suffixed to First Name. Below logic is to remove middle initial from First Name
    pc_pl_policyperiod_bound = pc_pl_policyperiod.filter(col('PolicyNumber').isNotNull())   
    
    pc_pl_policyperiod_quote = pc_pl_policyperiod.filter(col('PolicyNumber').isNull())
    
    pc_pl_contact_fname_1 = pc_pl_contact.withColumn("FName_2ndWord", split(col("firstname")," ")[1])
    
    pc_pl_contact_fname_1 = pc_pl_contact_fname_1.withColumn("FName_2ndW_Len", length(col("FName_2ndWord")))
    
    pc_pl_contact_fname = pc_pl_contact_fname_1.withColumn("First_Name", 
                                             when(col("FName_2ndW_Len") > 2, pc_pl_contact_fname_1["firstname"]).otherwise(split(col("firstname")," ")[0]))
    
    pc_pl_contact_phone = pc_pl_contact_fname.withColumn("Primary_Phone", 
                                             when(trim(col('primaryphone')) == 3, 
                                            trim(col('cellphone'))).otherwise(when(trim(col('primaryphone')) == 2, 
                                            trim(col('homephone'))).otherwise(when(trim(col('primaryphone')) == 1, 
                                            trim(col('workphone'))).otherwise(trim(col('primaryphone'))))))
    
    pc_pl_contact_phone_stg = pc_pl_contact_phone.select('First_Name',
                                                     'lastname',
                                                     'name',
                                                     'dateofbirth',
                                                     trim(col('Primary_Phone')),
                                                     'emailaddress1',
                                                     'licensenumber',
                                                     'id',
                                                     'primaryaddressid',
                                                     'updatetime').toDF('First_Name',
                                                                        'Last_Name',
                                                                        'Entity_Name',
                                                                        'DOB',
                                                                        'Primary_Phone',
                                                                        'Email',
                                                                        'License_Number',
                                                                        'Contact_ID',
                                                                        'primaryaddressid',
                                                                        'Update_Time')
    
    # There are some (5 asof Aug 17th, 2019) Policy contacts that start with "!". Ex: !ST STATE BANK, !ST NATIONAL BANK ISAOA, !ST FINANCIAL FEDERAL CREDIT UNION, !ST NATIONAL BANK, 1ST PREF
    # The below logic is to replace "!" with "1"
    
    pc_pl_temp_replace = pc_pl_contact_phone_stg.filter(col("Entity_Name").like('!%'))
    pc_pl_temp_retain = pc_pl_contact_phone_stg.subtract(pc_pl_temp_replace)
    pc_pl_replaced = pc_pl_temp_replace.select('First_Name',
                                        'Last_Name',
                                        regexp_replace(col('Entity_Name'),r'[\x21]','1'),
                                        'DOB',
                                        'Primary_Phone',
                                        'Email',
                                        'License_Number',
                                        'Contact_ID',
                                        'primaryaddressid',
                                        'Update_Time').toDF('First_Name',
                                                            'Last_Name',
                                                            'Entity_Name',
                                                            'DOB',
                                                            'Primary_Phone',
                                                            'Email',
                                                            'License_Number',
                                                            'Contact_ID',
                                                            'primaryaddressid',
                                                            'Update_Time')
    
    pc_pl_contact_stg1 = pc_pl_temp_retain.union(pc_pl_replaced)
    
    pc_pl_contact_phone_select = pc_pl_contact_stg1.select(upper(trim(regexp_replace(col('First_Name'),r'[^A-Za-z0-9\x20]',''))),
                                                     upper(trim(regexp_replace(col('Last_Name'),r'[^A-Za-z0-9\x20]',''))),
                                                     upper(trim(regexp_replace(col('Entity_Name'),r'[^A-Za-z0-9\x20\&]',''))),
                                                     date_format('DOB','yyyy-MM-dd'),
                                                     trim(col('Primary_Phone')),
                                                     lower(trim(col('Email'))),
                                                     trim(col('License_Number')),
                                                     'Contact_ID',
                                                     'primaryaddressid',
                                                     'Update_Time').toDF('First_Name',
                                                                        'Last_Name',
                                                                        'Entity_Name',
                                                                        'DOB',
                                                                        'Primary_Phone',
                                                                        'Email',
                                                                        'License_Number',
                                                                        'Contact_ID',
                                                                        'primaryaddressid',
                                                                        'Update_Time')
																		
    pc_pl_policyperiod_select = pc_pl_policyperiod_bound.select('id', 
                                                     'policyid',
                                                     'policynumber'
                                                     ).toDF('policyperiodid',
                                                            'Policy_ID',
                                                            'Policy_Number')
																												
    pc_pl_address_select = pc_pl_address.select('id',
                                           'pctl_addresstype_name',
                                           upper(trim(col('addressline1'))),
                                           upper(trim(col('city'))),
                                           'pctl_state_typecode',
                                           substring(col('postalcode'),0,5)).toDF('addressid',
                                                              'Address_Type',
                                                              'Address_Line1',
                                                              'City',
                                                              'State',
                                                              'Zip_Code')
														  
    pc_pl_policy_select = pc_pl_policy.select('AccountID',
                                        'ID',
                                        trim(col('ProductCode'))).toDF('Account_ID',
                                                            'Policy_ID',
                                                            'ProductCode')
															
    pc_pl_policycontactrole_select = pc_pl_policycontactrole.select('contactdenorm',
                                                              'branchid',															  
                                                              trim(col('pctl_policycontactrole_name'))).toDF('Contact_ID',
                                                                              'policyperiodid',
                                                                              'Contact_Role')
																		  
    pc_pl_account_select = pc_pl_account.select('ID',
                                          'AccountNumber').toDF('Account_ID',
                                                                'Account_Number')
																
    pc_pl_accountcontact_select = pc_pl_accountcontact.select('contact',
                                                        'account').toDF('Contact_ID',
                                                                        'Account_ID')																		
																		
    pc_pl_officialid_select = pc_pl_officialid.filter(upper(trim(col("pctl_officialidtype_name"))) == "SSN").select('officialidtype',
                                                                                                 'pctl_officialidtype_name',
                                                                                                 trim(col('officialidvalue')),
                                                                                                 'contactid').toDF('officialidtype',													
                                                                                                                   'ID_Type',
                                                                                                                   'ID_Value',
                                                                                                                   'Contact_ID')															  

    print("[INFO] Adding Source System Code Column for PC_PL source....")
    pc_pl_contact_phone_select_ssc = pc_pl_contact_phone_select.withColumn("cssc",lit("GWPL"))
    pc_pl_policyperiod_select_ssc = pc_pl_policyperiod_select.withColumn("ppssc",lit("GWPL"))    
    pc_pl_address_select_ssc = pc_pl_address_select.withColumn("adssc",lit("GWPL"))    
    pc_pl_policy_select_ssc = pc_pl_policy_select.withColumn("pssc",lit("GWPL"))    
    pc_pl_policycontactrole_select_ssc = pc_pl_policycontactrole_select.withColumn("pcrssc",lit("GWPL"))    
    pc_pl_account_select_ssc = pc_pl_account_select.withColumn("acssc",lit("GWPL"))    
    pc_pl_accountcontact_select_ssc = pc_pl_accountcontact_select.withColumn("accssc",lit("GWPL"))    
    pc_pl_officialid_select_ssc = pc_pl_officialid_select.withColumn("ossc",lit("GWPL"))
																	  
    ### SOURCE CL DATA ###
    print("[INFO] Selecting required columns and Applying transformations on PC_CL source....")
    # Select required columns; Add columns as required; 
    # Some contacts have middle initial suffixed to First Name. Below logic is to remove middle initial from First Name
    pc_cl_policyperiod_bound = pc_cl_policyperiod.filter(col('PolicyNumber').isNotNull())
	   
    pc_cl_policyperiod_quote = pc_cl_policyperiod.filter(col('PolicyNumber').isNull())
    
    pc_cl_contact_fname_1 = pc_cl_contact.withColumn("FName_2ndWord", split(col("firstname")," ")[1])
    
    pc_cl_contact_fname_1 = pc_cl_contact_fname_1.withColumn("FName_2ndW_Len", length(col("FName_2ndWord")))
    
    pc_cl_contact_fname = pc_cl_contact_fname_1.withColumn("First_Name", 
                                             when(col("FName_2ndW_Len") > 2, pc_cl_contact_fname_1["firstname"]).otherwise(split(col("firstname")," ")[0]))
    
    pc_cl_contact_phone = pc_cl_contact_fname.withColumn("Primary_Phone", 
                                             when(trim(col('primaryphone')) == 3, 
                                            trim(col('cellphone'))).otherwise(when(trim(col('primaryphone')) == 2, 
                                            trim(col('homephone'))).otherwise(when(trim(col('primaryphone')) == 1, 
                                            trim(col('workphone'))).otherwise(trim(col('primaryphone'))))))
    
    pc_cl_contact_phone_stg = pc_cl_contact_phone.select('First_Name',
                                                     'lastname',
                                                     'name',
                                                     'dateofbirth',
                                                     trim(col('Primary_Phone')),
                                                     'emailaddress1',
                                                     'licensenumber',
                                                     'id',
                                                     'primaryaddressid',
                                                     'updatetime').toDF('First_Name',
                                                                        'Last_Name',
                                                                        'Entity_Name',
                                                                        'DOB',
                                                                        'Primary_Phone',
                                                                        'Email',
                                                                        'License_Number',
                                                                        'Contact_ID',
                                                                        'primaryaddressid',
                                                                        'Update_Time')
    
    # There are some (5 asof Aug 17th, 2019) Policy contacts that start with "!". Ex: !ST STATE BANK, !ST NATIONAL BANK ISAOA, !ST FINANCIAL FEDERAL CREDIT UNION, !ST NATIONAL BANK, 1ST PREF
    # The below logic is to replace "!" with "1"
    
    pc_cl_temp_replace = pc_cl_contact_phone_stg.filter(col("Entity_Name").like('!%'))
    pc_cl_temp_retain = pc_cl_contact_phone_stg.subtract(pc_cl_temp_replace)
    pc_cl_replaced = pc_cl_temp_replace.select('First_Name',
                                        'Last_Name',
                                        regexp_replace(col('Entity_Name'),r'[\x21]','1'),
                                        'DOB',
                                        'Primary_Phone',
                                        'Email',
                                        'License_Number',
                                        'Contact_ID',
                                        'primaryaddressid',
                                        'Update_Time').toDF('First_Name',
                                                            'Last_Name',
                                                            'Entity_Name',
                                                            'DOB',
                                                            'Primary_Phone',
                                                            'Email',
                                                            'License_Number',
                                                            'Contact_ID',
                                                            'primaryaddressid',
                                                            'Update_Time')
    
    pc_cl_contact_stg1 = pc_cl_temp_retain.union(pc_cl_replaced)
    
    pc_cl_contact_phone_select = pc_cl_contact_stg1.select(upper(trim(regexp_replace(col('First_Name'),r'[^A-Za-z0-9\x20]',''))),
                                                     upper(trim(regexp_replace(col('Last_Name'),r'[^A-Za-z0-9\x20]',''))),
                                                     upper(trim(regexp_replace(col('Entity_Name'),r'[^A-Za-z0-9\x20\&]',''))),
                                                     date_format('DOB','yyyy-MM-dd'),
                                                     trim(col('Primary_Phone')),
                                                     lower(trim(col('Email'))),
                                                     trim(col('License_Number')),
                                                     'Contact_ID',
                                                     'primaryaddressid',
                                                     'Update_Time').toDF('First_Name',
                                                                        'Last_Name',
                                                                        'Entity_Name',
                                                                        'DOB',
                                                                        'Primary_Phone',
                                                                        'Email',
                                                                        'License_Number',
                                                                        'Contact_ID',
                                                                        'primaryaddressid',
                                                                        'Update_Time')
																	
    pc_cl_policyperiod_select = pc_cl_policyperiod_bound.select('id', 
                                                     'policyid',
                                                     'policynumber'
                                                     ).toDF('policyperiodid',
                                                            'Policy_ID',
                                                            'Policy_Number')
     
    pc_cl_address_select = pc_cl_address.select('id',
                                           'pctl_addresstype_name',
                                           upper(trim(col('addressline1'))),
                                           upper(trim(col('city'))),
                                           'pctl_state_typecode',
                                           substring(col('postalcode'),0,5)).toDF('addressid',
                                                              'Address_Type',
                                                              'Address_Line1',
                                                              'City',
                                                              'State',
                                                              'Zip_Code')
    
    pc_cl_policy_select = pc_cl_policy.select('AccountID',
                                        'ID',
                                        trim(col('ProductCode'))).toDF('Account_ID',
                                                            'Policy_ID',
                                                            'ProductCode')
    
    pc_cl_policycontactrole_select = pc_cl_policycontactrole.select('contactdenorm',
                                                              'branchid',															  
                                                              trim(col('pctl_policycontactrole_name'))).toDF('Contact_ID',
                                                                              'policyperiodid',
                                                                              'Contact_Role')
    
    pc_cl_account_select = pc_cl_account.select('ID',
                                          'AccountNumber').toDF('Account_ID',
                                                                'Account_Number')
    
    pc_cl_accountcontact_select = pc_cl_accountcontact.select('contact',
                                                        'account').toDF('Contact_ID',
                                                                        'Account_ID')
    
    pc_cl_officialid_select = pc_cl_officialid.filter(upper(trim(col("pctl_officialidtype_name"))) == "SSN").select('officialidtype',
                                                                                                 'pctl_officialidtype_name',
                                                                                                 trim(col('officialidvalue')),
                                                                                                 'contactid').toDF('officialidtype',
                                                                                                                   'ID_Type',
                                                                                                                   'ID_Value',
                                                                                                                   'Contact_ID')

    print("[INFO] Adding Source System Code Column for PC_CL source....")
    pc_cl_contact_phone_select_ssc = pc_cl_contact_phone_select.withColumn("cssc",lit("GWCL"))
    pc_cl_policyperiod_select_ssc = pc_cl_policyperiod_select.withColumn("ppssc",lit("GWCL"))
    pc_cl_address_select_ssc = pc_cl_address_select.withColumn("adssc",lit("GWCL"))
    pc_cl_policy_select_ssc = pc_cl_policy_select.withColumn("pssc",lit("GWCL"))
    pc_cl_policycontactrole_select_ssc = pc_cl_policycontactrole_select.withColumn("pcrssc",lit("GWCL"))
    pc_cl_account_select_ssc = pc_cl_account_select.withColumn("acssc",lit("GWCL"))
    pc_cl_accountcontact_select_ssc = pc_cl_accountcontact_select.withColumn("accssc",lit("GWCL"))
    pc_cl_officialid_select_ssc = pc_cl_officialid_select.withColumn("ossc",lit("GWCL"))	
																	  
    # Combine PL and CL data sets
    print("[INFO] Combining the PL and CL Extract as PC Extracts....")
    pc_policy_select = pc_pl_policy_select_ssc.union(pc_cl_policy_select_ssc)
    pc_policyperiod_select = pc_pl_policyperiod_select_ssc.union(pc_cl_policyperiod_select_ssc)
    pc_policycontactrole_select = pc_pl_policycontactrole_select_ssc.union(pc_cl_policycontactrole_select_ssc)
    pc_accountcontact_select = pc_pl_accountcontact_select_ssc.union(pc_cl_accountcontact_select_ssc)
    pc_account_select = pc_pl_account_select_ssc.union(pc_cl_account_select_ssc)
    pc_contact_phone_select = pc_pl_contact_phone_select_ssc.union(pc_cl_contact_phone_select_ssc)
    pc_officialid_select = pc_pl_officialid_select_ssc.union(pc_cl_officialid_select_ssc)
    pc_address_select = pc_pl_address_select_ssc.union(pc_cl_address_select_ssc)
    
    # JOINS
    print("[INFO] Joining the PC Policy Sources....")
    pc_policyperiod_policy = pc_policyperiod_select.join(pc_policy_select, 
                                                         (pc_policyperiod_select.Policy_ID == pc_policy_select.Policy_ID) &
														 (pc_policyperiod_select.ppssc == pc_policy_select.pssc)).drop(pc_policy_select.Policy_ID).drop(pc_policy_select.pssc)
    
    pc_policyperiod_policy_contactrole = pc_policyperiod_policy.join(pc_policycontactrole_select,
                                                                     (pc_policyperiod_policy.policyperiodid == pc_policycontactrole_select.policyperiodid) &
																	 (pc_policyperiod_policy.ppssc == pc_policycontactrole_select.pcrssc),
                                                                    how='left').drop(pc_policycontactrole_select.policyperiodid).drop(pc_policycontactrole_select.pcrssc)
    
    pc_account_accontact = pc_accountcontact_select.join(pc_account_select,
                                                        (pc_accountcontact_select.Account_ID == pc_account_select.Account_ID) &
														(pc_accountcontact_select.accssc == pc_account_select.acssc),
                                                        how='left').drop(pc_account_select.Account_ID).drop(pc_account_select.acssc)
    
    pc_offid_type_contact = pc_contact_phone_select.join(pc_officialid_select, 
                                                        (pc_contact_phone_select.Contact_ID == pc_officialid_select.Contact_ID) &
														(pc_contact_phone_select.cssc == pc_officialid_select.ossc), 
                                                        how='left').drop(pc_officialid_select.Contact_ID).drop(pc_officialid_select.ossc)
    
    pc_contact_stg1 = pc_offid_type_contact.join(pc_policyperiod_policy_contactrole, 
                                            (pc_offid_type_contact.Contact_ID == pc_policyperiod_policy_contactrole.Contact_ID) &
											(pc_offid_type_contact.cssc == pc_policyperiod_policy_contactrole.ppssc)).drop(pc_policyperiod_policy_contactrole.Contact_ID).drop(pc_policyperiod_policy_contactrole.ppssc)
    
    pc_contact_stg2 = pc_contact_stg1.join(pc_address_select, 
                                          (pc_contact_stg1.primaryaddressid == pc_address_select.addressid) &
										  (pc_contact_stg1.cssc == pc_address_select.adssc),
                                          how='left').drop(pc_address_select.addressid).drop(pc_address_select.adssc)
    
    pc_contact_acstg = pc_contact_stg2.join(pc_account_accontact,
                                           (pc_contact_stg2.Contact_ID == pc_account_accontact.Contact_ID) &
										   (pc_contact_stg2.cssc == pc_account_accontact.accssc),
                                           how='left').drop(pc_account_accontact.Contact_ID).drop(pc_account_accontact.acssc)
       
    # Add LOB column
    print("[INFO] Applying transformations and filters on PC Extracts....")
    pc_contact_withLOB = pc_contact_acstg.withColumn("LOB", when(trim(col('ProductCode')).isin('BP7BusinessOwners',
                                                                                               'CA7CommAuto',
																							   'CUCommercialUmbrella',
																							   'FAFarmAuto',
																							   'FarmUmbrella',
																							   'FRMFarmRanch',
																							   'CommercialPackage'), 
                                                                "CL").otherwise(when(trim(col('ProductCode')).isin('Homeowners',
																                                                   'PersonalAuto',
																												   'PersonalUmbrella'), 
                                                                                     "PL").otherwise(when(trim(col('ProductCode')).isin('WorkersComp'), "RTW").otherwise("Other"))))
    
    # Select output columns
    pc_contact_stg3 = pc_contact_withLOB.select(concat_ws("",col('LOB'),lit('-'),col('Contact_ID')),
                                               'Account_Number',
                                               'Policy_Number',
                                               concat_ws("-",col('LOB'),col('ProductCode')),
                                               'License_Number',
                                               'ID_Type',
                                               'ID_Value',
                                               when((length(trim(concat_ws(" ",col('First_Name'),col('Last_Name')))) == 0),col('Entity_Name')).otherwise(trim(concat_ws(" ",col('First_Name'),col('Last_Name')))),
                                               'DOB',
                                               'Entity_Name',
                                               when((length(trim(col('Primary_Phone'))) == 7),
                                               concat_ws("",lit('000'),lit('-'),substring(col('Primary_Phone'),1,3),lit('-'),substring(col('Primary_Phone'),4,4))).otherwise(when((length(trim(col('Primary_Phone'))) == 10),
                                               concat_ws("",substring(col('Primary_Phone'),1,3),lit('-'),substring(col('Primary_Phone'),4,3),lit('-'),substring(col('Primary_Phone'),7,4))).otherwise(when((length(trim(col('Primary_Phone'))) == 11),
                                               concat_ws("",substring(col('Primary_Phone'),2,3),lit('-'),substring(col('Primary_Phone'),5,3),lit('-'),substring(col('Primary_Phone'),8,4))).otherwise(None))),
                                               'Email',
                                               concat_ws("",lit('"'),col('Address_Line1'),lit(", "),col('City'),lit(", "),col('State'),lit('"')),
                                               'Zip_Code',
                                               trim(col('Contact_Role')),
                                               'LOB').toDF('Contact_ID',
                                                           'Account_Number',
                                                           'Policy_Number',
                                                           'Product',
                                                           'License_Number',
                                                           'ID_Type',
                                                           'ID_Value',
                                                           'Prc_Name',
                                                           'DOB',
                                                           'Entity_Name',
                                                           'Primary_Phone',
                                                           'Email',
                                                           'Address',
                                                           'Zip_Code',
                                                           'Contact_Role',
                                                           'LOB')
    
    # Eliminate duplicates
    pc_contact_unique = pc_contact_stg3.dropDuplicates()
    
    # Remove records with NULL values for Entity Name and Primary Contact Name
    pc_contact_all = pc_contact_unique.where(~((col("Prc_Name").isNull()) & (col("Entity_Name").isNull())))
    
    # Split the dataset into two sets of same schema. One with Entity Name and other with Primary Contact Name
    pc_entity = pc_contact_all.filter("Entity_Name is not null").select('Contact_ID',
                                                                       'Account_Number',
                                                                       'Policy_Number',
                                                                       'Product',
                                                                       'Contact_Role',
                                                                       'License_Number',
                                                                       'ID_Type',
                                                                       'ID_Value',
                                                                       'Entity_Name',
                                                                       'DOB',
                                                                       'Primary_Phone',
                                                                       'Email',
                                                                       'Address',
                                                                       'Zip_Code',
                                                                       'LOB').toDF('Contact_ID',
                                                                                   'Account_Number',
                                                                                   'Policy_Number',
                                                                                   'Product',
                                                                                   'Contact_Role',
                                                                                   'License_Number',
                                                                                   'ID_Type',
                                                                                   'ID_Value',
                                                                                   'Customer_Name',
                                                                                   'DOB',
                                                                                   'Phone',
                                                                                   'Email',
                                                                                   'Address',
                                                                                   'Zip_Code',
                                                                                   'LOB')
    
    pc_prc_name = pc_contact_all.filter("Prc_Name is not null").select('Contact_ID',
                                                                       'Account_Number',
                                                                       'Policy_Number',
                                                                       'Product',
                                                                       'Contact_Role',
                                                                       'License_Number',
                                                                       'ID_Type',
                                                                       'ID_Value',
                                                                       'Prc_Name',
                                                                       'DOB',
                                                                       'Primary_Phone',
                                                                       'Email',
                                                                       'Address',
                                                                       'Zip_Code',
                                                                       'LOB').toDF('Contact_ID',
                                                                                   'Account_Number',
                                                                                   'Policy_Number',
                                                                                   'Product',
                                                                                   'Contact_Role',
                                                                                   'License_Number',
                                                                                   'ID_Type',
                                                                                   'ID_Value',
                                                                                   'Customer_Name',
                                                                                   'DOB',
                                                                                   'Phone',
                                                                                   'Email',
                                                                                   'Address',
                                                                                   'Zip_Code',
                                                                                   'LOB')
    
    # Union the above two data sets
    pc_customer_union = pc_entity.union(pc_prc_name)
    
    # Filter records that do not have License Number OR SSN/FEIN OR DOB OR Phone OR Email OR Zip Code
    pc_customer = pc_customer_union.filter(~(pc_customer_union.License_Number.isNull() & 
                                             pc_customer_union.ID_Value.isNull() & 
                                             pc_customer_union.DOB.isNull() & 
                                             pc_customer_union.Phone.isNull() &
                                             pc_customer_union.Email.isNull() &
                                             pc_customer_union.Zip_Code.isNull()))
    
    # Filter all Customer_Name contacts which have only special characters and (or) numbers
    pc_customer_alpha = pc_customer.filter(~(pc_customer.Customer_Name.rlike('^[^A-Z]*$')))
    
    # Join Customer Policy info with Claim info
    pc_customer_claim = pc_customer_alpha.join(cc_claim_select, pc_customer_alpha.Policy_Number == cc_claim_select.Policy_Number,
                             how='left').drop(cc_claim_select.Policy_Number)
    
    pc_customer_final = pc_customer_claim.select('Contact_ID',
                                                 'Account_Number',
                                                 'Policy_Number',
                                                 'Claim_ID',
                                                 'Claim_Number',
                                                 'Loss_Date',
                                                 'Product',
                                                 'Contact_Role',
                                                 'License_Number',
                                                 'ID_Type',
                                                 'ID_Value',
                                                 'Customer_Name',
                                                 'DOB',
                                                 'Phone',
                                                 'Email',
                                                 'Address',
                                                 'Zip_Code',
                                                 'LOB')
       
    # Combine Claims Center and Policy Center data
    print("[INFO] Creating Customer by Merging CC and PC final data....")
    cc_pc_customer = cc_customer_final.union(pc_customer_final)
    
    # Create a unique identifier (Group By column) for the Customer by concatenating Name + DOB + Zip
    print("[INFO] Creating the key columns with Name,Dob,Zip....")
    cc_pc_fname = cc_pc_customer.withColumn("Customer_Key", concat_ws(" ",cc_pc_customer.Customer_Name,cc_pc_customer.DOB,cc_pc_customer.Zip_Code))
    chk_cc_pc_fname = cc_pc_fname.count()
    if chk_cc_pc_fname == 0:
       print("[INFO] There is NO New Contacts to Group and Write Step-I Output....")
    else:   
       # Group customer data by above created Group By column
       print("[INFO] Group by on key column and creating a collection of Customer Details....")
       cc_pc_group = cc_pc_fname.groupBy("Customer_Key","Customer_Name").agg(collect_set("Contact_ID").alias("Contact_ID"),
                                      collect_set("Account_Number").alias("Account_Number"),
                                      collect_set("Policy_Number").alias("Policy_Number"),
                                      collect_set("Claim_ID").alias("Claim_ID"),
                                      collect_set("Claim_Number").alias("Claim_Number"),
                                      collect_set("Loss_Date").alias("Loss_Date"),
                                      collect_set("Product").alias("Product"),
                                      collect_set("Contact_Role").alias("Contact_Role"),
                                      collect_set("DOB").alias("DOB"),
                                      collect_set("License_Number").alias("License_Number"), 
                                      collect_set("ID_Value").alias("ID_Value"),
                                      collect_set("Phone").alias("Phone"), 
                                      collect_set("Email").alias("Email"),
                                      collect_set("Address").alias("Address"),
                                      collect_set("Zip_Code").alias("Zip_Code")).orderBy("Customer_Name")
       
       print("[INFO] Group on key, account, policy, claims to create Account Policy Claim field....")
       customerapc = cc_pc_fname.select("Customer_Key","Customer_Name","Account_Number","Policy_Number","Claim_Number")
       customerapc.createOrReplaceTempView("mdm_gr_custapc")
       customerapc1 = spark.sql("select Customer_Key,Customer_Name,case when Account_Number is null then 'NA' else Account_Number end as Account_Number,case when Policy_Number is null then 'NA' else Policy_Number end as Policy_Number,collect_set(Claim_Number) as Claim_Numbers from mdm_gr_custapc group by Customer_Key,Customer_Name,Account_Number,Policy_Number")
       customerapc1.createOrReplaceTempView("mdm_gr_custapc1")	
       customerapc2 = spark.sql("select Customer_Key,Customer_Name,Account_Number,collect_set(struct(Policy_Number,Claim_Numbers)) as Policy_Claims from mdm_gr_custapc1 group by Customer_Key,Customer_Name,Account_Number")
       customerapc2.createOrReplaceTempView("mdm_gr_custapc2")
       customerapc3 = spark.sql("select Customer_Key as Customer_Key1,Customer_Name as Customer_Name1,collect_set(struct(Account_Number,Policy_Claims)) as Account_Policy_Claim from mdm_gr_custapc2 group by Customer_Key,Customer_Name")
       customerapc3.createOrReplaceTempView("mdm_gr_custapc3")
       cc_pc_apc = spark.sql("select Customer_Key1,Customer_Name1,Account_Policy_Claim from mdm_gr_custapc3")
   
       print("[INFO] Joining the Customer details grouping with Acc Pol Clm grouping....")
       cc_pc_final = cc_pc_group.join(cc_pc_apc,(cc_pc_group.Customer_Key == cc_pc_apc.Customer_Key1) &
                                                (cc_pc_group.Customer_Name == cc_pc_apc.Customer_Name1)).drop(cc_pc_apc.Customer_Key1).drop(cc_pc_apc.Customer_Name1)                                                  	
   	
       print("[INFO] Writing CC and PC Grouped Data to S3 for Next Step ML Lib Process for Fuzzy Match....")
       # Write grouped customer data to S3
       cc_pc_final.write.parquet(CC_PC_Grouped_Data_Location)
       print("[INFO] Writing CC and PC Acc_Pol_Clm Data to S3 for Next Day Accumulation Process....")
       customerapc.write.parquet(CC_PC_APC_Data_Location)
	   
       #Insert the Max Update time for each of the source in transform mdm stats for incremental read in the Next Run 	
       print("[INFO] Inserting the Max Update time for each source in Stats for next run....")
       sdata = [(run_name_cc,ingestn_dttm,curr_cc_mut),(run_name_pc_pl,ingestn_dttm,curr_pc_pl_mut),(run_name_pc_cl,ingestn_dttm,curr_pc_cl_mut)]
       stat_df = spark.createDataFrame(sdata,["RUN_NAME","INGESTION_DTTM","MAX_UPD_TIME"])	
       stat_list = stat_df.toJSON().collect()
       stat_ld = [json.loads(sts) for sts in stat_list]
       mstatcoll.insert_many(stat_ld)
       
       print("[INFO] Step I - Completed writing of CC and PC Grouped Data to S3....")
    spark.stop()