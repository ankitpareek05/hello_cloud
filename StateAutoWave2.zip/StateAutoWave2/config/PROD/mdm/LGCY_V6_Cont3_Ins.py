# Import all required libraries
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext, Row, Column
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.dataframe import *
from pyspark.sql.column import *
from pyspark.sql.window import *
from pyspark.ml import Pipeline, Model, PipelineModel
from pyspark.ml.feature import RegexTokenizer, Tokenizer, NGram, HashingTF, MinHashLSH
import datetime as dt
import pymongo, pandas as pd, json, os, sys, string, uuid
from collections import OrderedDict
from functools import reduce
from itertools import groupby
from operator import add, itemgetter
import base64 as b64
from base64 import b64decode
import bson

# Main Module
 
if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 17:
       print("Error usage: LGCY_V6_Cont3_Ins.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)
  
    muserid = sys.argv[1]
    mpwd = sys.argv[2]
    mhost = sys.argv[3]
    mport = sys.argv[4]
    mprop1 = sys.argv[5]
    mprop2 = sys.argv[6]
    mprop3 = sys.argv[7]
    mprop4 = sys.argv[8]
    
    mdatabase = sys.argv[9]
    mcustomer = sys.argv[10]
    mstats = sys.argv[11]
    
    lgcy_golden_data_loc = sys.argv[12]
    lgcy_apc_data_loc = sys.argv[13]
    cc_pc_apc_full_data_loc = sys.argv[14]
    lgcy_mdm_excp_loc = sys.argv[15]
    curr_yyyymm = sys.argv[16]
		
    # Setup required Batch variables
    print("[INFO] Setting up Batch variables....")
    Batch_Start_Time = dt.datetime.now()
    date_ext = Batch_Start_Time.strftime("%Y-%m-%d")
    mpassword = b64decode(mpwd).decode('utf-8')
    ConnString = "mongodb://{0}:{1}@{2}:{3}/?{4}&{5}&{6}&{7}".format(muserid, mpassword, mhost, mport, mprop1, mprop2, mprop3, mprop4)	
    print("MongoDB Connection: " + ConnString)

    print("[INFO] Spark Session Setup....")   
    spark = SparkSession.builder.appName("LGCY_V6_Cont3_Ins").enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    
    # Create a MongoDB Client
    print("[INFO] Connecting to Mongo DB Server....")
    mclient = pymongo.MongoClient(ConnString)
    
    # Database and Collection to be used
    mdb = mclient[mdatabase]
    mcustcoll = mdb[mcustomer]
    mstatcoll = mdb[mstats]
	   
    # Location to store final golden records
    LGCY_Golden_Data_Location = lgcy_golden_data_loc+curr_yyyymm
    LGCY_APC_Data_CYYYYMM_Location = lgcy_apc_data_loc+curr_yyyymm
    LGCY_MDM_Excp_Location = lgcy_mdm_excp_loc+curr_yyyymm
	   
    # Read final data set from S3
    print("[INFO] Reading Golden Records copy from S3 for Target Loading....")
    lgcy_customer_r = spark.read.parquet(LGCY_Golden_Data_Location)

    #print("[INFO] Creating MDM_ID Column with Unique ID....")
    print("[INFO] UDF for uid and Creating Unique ID Column MDM_ID....")	
    uuidUDF = udf(lambda : str(uuid.uuid4()), StringType())
    lgcy_customer = lgcy_customer_r.withColumn("MDM_ID", uuidUDF())    
    
    print("[INFO] Incremental Load - Inserting the Golden Record to Target....")   
    print("[INFO] Taking Only Keys from Incremental Dataframe as Incremental Keys List....")
    lgcy_customer_keys = lgcy_customer.select("Customer_Key")
    incr_keys_list = list(lgcy_customer_keys.toPandas()["Customer_Key"])
	
    print("[INFO] Creating PandasDF from Customer360 Collection....")
    pdf = pd.DataFrame(list(mcustcoll.find({},{"_id":0,"Customer_Name":0,"Account_Policy_Claim":0,"MDM_ID":0})))    
    print("[INFO] Selecting Required Columns in the Collection Order for Key Match....")
    pdf1 = pdf[['Customer_Key','Alias_Name','Contact_ID','Account_Number','Policy_Number','Claim_ID','Claim_Number', \
                'Loss_Date','Product','Contact_Role','DOB','License_Number','ID_Value','Phone','Email','Address','Zip_Code']]        
    print("[INFO] Creating DB Found Documents List from Full Collection as PandasDF....")
    pdf2 = pdf1[pdf1['Customer_Key'].isin(incr_keys_list)]
	
    print("[INFO] With DB Found Keys List, Creating Found & Not Found Keys from Incremental Keys List....")       
    keys_fnd = []
    pdf3 = pdf2['Customer_Key']
    keys_fnd = pdf3.to_list()
    keys_nfnd = list(set(incr_keys_list) - set(keys_fnd))	

    print("[INFO] With Not Found Keys List, Generating New Documents To Insert....")
    nfnd_sdf = lgcy_customer.filter(col("Customer_Key").isin(keys_nfnd))	
    lgcy_ins_list = nfnd_sdf.toJSON(False).collect()        
	
    print("[INFO] New Documents Bulk Insert In Progress....")			
    if len(lgcy_ins_list) == 0:
       print("[INFO] No New Keys Documents to Insert")			
    else:			
       ins_sublist = [lgcy_ins_list[x:x+50000] for x in range(0, len(lgcy_ins_list), 50000)]
       for sub_list in ins_sublist:
           mongo_ins_list = []
           for customer in sub_list:
              mongo_ins_list.append(eval(customer))
           rmv_ins_list = []
           for chkj in range(0,len(mongo_ins_list),1):
               if len(bson.BSON.encode(mongo_ins_list[chkj])) > 16793600:
                  excp_doc = lgcy_customer.filter(col("Customer_Key") == mongo_ins_list[chkj]["Customer_Key"]).select("Customer_Key","Customer_Name","Contact_ID","Account_Number","Policy_Number","Claim_ID","Claim_Number","Loss_Date","Product","Contact_Role","Account_Policy_Claim")
                  excp_doc.write.mode('append').json(LGCY_MDM_Excp_Location)				  
                  rmv_ins_list.append(mongo_ins_list[chkj])
                  print("[INFO] Key Exceeds Limit Removed: {0}".format(str(mongo_ins_list[chkj]["Customer_Key"])))
           if len(rmv_ins_list) == 0:
              mcustcoll.insert_many(mongo_ins_list)
              print("[INFO] Number of Documents Inserted: {0}".format(len(mongo_ins_list)))
           else:
              fnl_ins_list = [ely for ely in mongo_ins_list if ely not in rmv_ins_list]			  
              mcustcoll.insert_many(fnl_ins_list)
              print("[INFO] Number of Documents Inserted: {0}".format(len(fnl_ins_list)))

    print("[INFO] List Of Keys that are Inserted:")
    print(keys_nfnd)
    print("[INFO] Total Number of Documents Inserted: {0}".format(len(keys_nfnd)))
    print("[INFO] Total Number of Legacy Incremental Documents  : {0}".format(len(keys_fnd) + len(keys_nfnd)))

    print("[INFO] Step III - Completed Inserting Golden Records to Target Collection....")
    spark.stop()