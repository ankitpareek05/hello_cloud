# Import all required libraries
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext, Row, Column
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.dataframe import *
from pyspark.sql.column import *
from pyspark.sql.window import *
from pyspark.ml import Pipeline, Model, PipelineModel
from pyspark.ml.feature import RegexTokenizer, Tokenizer, NGram, HashingTF, MinHashLSH
import datetime as dt
import pymongo, pandas as pd, json, os, sys, string, uuid
from collections import OrderedDict
from functools import reduce
from itertools import groupby
from operator import add, itemgetter
import base64 as b64
from base64 import b64decode
import bson

def merge_records_by(key, combine):
    return lambda rec_a, rec_b: {
        k: rec_a[k] if k == key else list(set(combine(rec_a[k], rec_b[k])))
        for k in rec_a
    }

def merge_list_of_records_by(key, combine):
    keyprop = itemgetter(key)
    return lambda lst: [
        reduce(merge_records_by(key, combine), records)
        for _, records in groupby(sorted(lst, key=keyprop), keyprop)
    ]

# Main Module
 
if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 17:
       print("Error usage: LGCY_V6_Cont3.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)
  
    muserid = sys.argv[1]
    mpwd = sys.argv[2]
    mhost = sys.argv[3]
    mport = sys.argv[4]
    mprop1 = sys.argv[5]
    mprop2 = sys.argv[6]
    mprop3 = sys.argv[7]
    mprop4 = sys.argv[8]
    
    mdatabase = sys.argv[9]
    mcustomer = sys.argv[10]
    mstats = sys.argv[11]
    
    lgcy_golden_data_loc = sys.argv[12]
    lgcy_apc_data_loc = sys.argv[13]
    cc_pc_apc_full_data_loc = sys.argv[14]
    lgcy_mdm_excp_loc = sys.argv[15]
    curr_yyyymm = sys.argv[16]
		
    # Setup required Batch variables
    print("[INFO] Setting up Batch variables....")
    Batch_Start_Time = dt.datetime.now()
    date_ext = Batch_Start_Time.strftime("%Y-%m-%d")
    mpassword = b64decode(mpwd).decode('utf-8')
    ConnString = "mongodb://{0}:{1}@{2}:{3}/?{4}&{5}&{6}&{7}".format(muserid, mpassword, mhost, mport, mprop1, mprop2, mprop3, mprop4)	
    print("MongoDB Connection: " + ConnString)

    print("[INFO] Spark Session Setup....")   
    spark = SparkSession.builder.appName("LGCY_V6_Cont3").enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    
    # Create a MongoDB Client
    print("[INFO] Connecting to Mongo DB Server....")
    mclient = pymongo.MongoClient(ConnString)
    
    # Database and Collection to be used
    mdb = mclient[mdatabase]
    mcustcoll = mdb[mcustomer]
    mstatcoll = mdb[mstats]
	   
    # Location to store final golden records
    LGCY_Golden_Data_Location = lgcy_golden_data_loc+curr_yyyymm
    LGCY_APC_Data_CYYYYMM_Location = lgcy_apc_data_loc+curr_yyyymm
    LGCY_MDM_Excp_Location = lgcy_mdm_excp_loc+curr_yyyymm
	
    print("[INFO] Getting Last Run date to read Curr Full APC....")
    cdttm = list(mstatcoll.find({"RUN_NAME":"GWCC_Contacts"},{"INGESTION_DTTM":1, "_id":0}).sort("INGESTION_DTTM", pymongo.DESCENDING).limit(1))
    CDate = str(cdttm[0]["INGESTION_DTTM"][0:10])
    print("[INFO] Curr APC Full Date: {0}".format(CDate))
    CCPC_APC_Full_Data_CDate_Location = cc_pc_apc_full_data_loc+CDate  
    
    # Read final data set from S3
    print("[INFO] Reading Golden Records copy from S3 for Target Loading....")
    lgcy_customer_r = spark.read.parquet(LGCY_Golden_Data_Location)

    #print("[INFO] Creating MDM_ID Column with Unique ID....")
    print("[INFO] UDF for uid and Creating Unique ID Column MDM_ID....")	
    uuidUDF = udf(lambda : str(uuid.uuid4()), StringType())
    lgcy_customer = lgcy_customer_r.withColumn("MDM_ID", uuidUDF())    
    
    #Writing the Golden Record to Target Mongo DB of 75000 records for each insert
    print("[INFO] Taking the count of Target Customer360 to decide Historical or Incremental....")
    gld_cust_count = mcustcoll.count({})
    if gld_cust_count == 0: 
        print("[INFO] Historical Load - Inserting the Golden Record to Target....")
        for idxx in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
            print("[INFO] Processing the Load for Alpha/Number: {0}".format(idxx))
            gold_cust = lgcy_customer.filter(col("Customer_Name").like(idxx+'%'))
            chk_df = gold_cust.count()
            if chk_df == 0:
               print("[INFO] Skipping Load as there is no records for Alpha/Number: {0}".format(idxx))			
               continue		
            lgcy_mylist = gold_cust.toJSON(False).collect()
            lgcy_mysublists = [lgcy_mylist[x:x+75000] for x in range(0, len(lgcy_mylist), 75000)]
            for sub_list in lgcy_mysublists:
                mongo_list = []
                for customer in sub_list:
                    mongo_list.append(eval(customer))              
                print("[INFO] Size of Current Insert List: {0}".format(str(sys.getsizeof(str(mongo_list)[1:-1]))))
                rmv_list = []
                for chki in range(0,len(mongo_list),1):
                    if len(bson.BSON.encode(mongo_list[chki])) > 16793600:				
                       excp_doc = lgcy_customer.filter(col("Customer_Key") == mongo_list[chki]["Customer_Key"]).select("Customer_Key","Customer_Name","Contact_ID","Account_Number","Policy_Number","Claim_ID","Claim_Number","Loss_Date","Product","Contact_Role","Account_Policy_Claim")
                       excp_doc.write.mode('append').json(LGCY_MDM_Excp_Location)					   
                       rmv_list.append(mongo_list[chki])
                       print("[INFO] Key Exceeds Limit Removed: {0}".format(str(mongo_list[chki]["Customer_Key"])))
                if len(rmv_list) == 0:
                   mcustcoll.insert_many(mongo_list)
                else:				   
                   fnl_list = [elx for elx in mongo_list if elx not in rmv_list]
                   mcustcoll.insert_many(fnl_list)
        fnl_cust_count = mcustcoll.count({})
        print("[INFO] LGCY APC Hist Write Append to Full APC Accumulation....")
        lgcy_apc_h = spark.read.parquet(LGCY_APC_Data_CYYYYMM_Location)
        lgcy_apc_h.write.mode('append').parquet(CCPC_APC_Full_Data_CDate_Location)
        print("[INFO] Total Number of Historical Records Loaded: {0}".format(fnl_cust_count))
    else:
        print("[INFO] Incremental Load - Updating/Inserting the Golden Record to Target....")
        print("[INFO] Initializing variables and Creating Schema....")
        upd_fnl_schema = StructType([
                         StructField('Customer_Key', StringType(), True),
                         StructField('Alias_Name', ArrayType(StringType()), True),
                         StructField('Contact_ID', ArrayType(StringType()), True),
                         StructField('Account_Number', ArrayType(StringType()), True),
                         StructField('Policy_Number', ArrayType(StringType()), True),
                         StructField('Claim_ID', ArrayType(StringType()), True),
                         StructField('Claim_Number', ArrayType(StringType()), True),
                         StructField('Loss_Date', ArrayType(StringType()), True),
                         StructField('Product', ArrayType(StringType()), True),
                         StructField('Contact_Role', ArrayType(StringType()), True),
                         StructField('DOB', ArrayType(StringType()), True),
                         StructField('License_Number', ArrayType(StringType()), True),
                         StructField('ID_Value', ArrayType(StringType()), True),
                         StructField('Phone', ArrayType(StringType()), True),
                         StructField('Email', ArrayType(StringType()), True),
                         StructField('Address', ArrayType(StringType()), True),
                         StructField('Zip_Code', ArrayType(StringType()), True)])

        print("[INFO] LGCY APC Curr Date Incr - Read for APC Accumulation....")
        lgcy_apc_i = spark.read.parquet(LGCY_APC_Data_CYYYYMM_Location)
        print("[INFO] CCPC APC Curr Date Full - Read for APC Accumulation....")
        ccpc_apc_f = spark.read.parquet(CCPC_APC_Full_Data_CDate_Location)

        print("[INFO] LGCY APC Curr Date Incr + CCPC APC Curr Date Full = APC Curr Date Full - Creating....")		
        apc_union = ccpc_apc_f.union(lgcy_apc_i)
        lgcy_apc = apc_union.dropDuplicates()		
        
        print("[INFO] Taking Only Keys from Incremental Dataframe as Incremental Keys List....")
        lgcy_customer_keys = lgcy_customer.select("Customer_Key")
        incr_keys_list = list(lgcy_customer_keys.toPandas()["Customer_Key"])
			
        print("[INFO] Creating PandasDF from Customer360 Collection....")
        pdf = pd.DataFrame(list(mcustcoll.find({},{"_id":0,"Customer_Name":0,"Account_Policy_Claim":0,"MDM_ID":0})))    
        print("[INFO] Selecting Required Columns in the Collection Order for Key Match....")
        pdf1 = pdf[['Customer_Key','Alias_Name','Contact_ID','Account_Number','Policy_Number','Claim_ID','Claim_Number', \
                    'Loss_Date','Product','Contact_Role','DOB','License_Number','ID_Value','Phone','Email','Address','Zip_Code']]        
        print("[INFO] Creating DB Found Documents List from Full Collection as PandasDF....")
        pdf2 = pdf1[pdf1['Customer_Key'].isin(incr_keys_list)]
        db_fnd_list = []
        db_fnd_list = pdf2.to_dict(orient='records')
		
        print("[INFO] With DB Found Keys List, Creating Found & Not Found Keys from Incremental Keys List....")       
        keys_fnd = []
        pdf3 = pdf2['Customer_Key']
        keys_fnd = pdf3.to_list()
        keys_nfnd = list(set(incr_keys_list) - set(keys_fnd))

        print("[INFO] With Found Keys List, Generating Existing Documents To Update....")
        lgcy_customer_upd = lgcy_customer.drop("Customer_Name","Account_Policy_Claim","MDM_ID")\
                                         .filter(col("Customer_Key").isin(keys_fnd))
        lgcy_customer_upd_json = lgcy_customer_upd.toJSON(False).collect()
        upd_list = []
        for idxc in lgcy_customer_upd_json: 
            upd_list.append(eval(idxc))

        print("[INFO] Merging db_fnd_list(Collection Values) with upd_list(Incremental Values) for Update....")
        merger = merge_list_of_records_by("Customer_Key", add)
        upd_fnl_list = merger(upd_list + db_fnd_list)
        print("[INFO] And Converting that as SparkDF....")
        upd_fnl_rdd = spark.sparkContext.parallelize(upd_fnl_list).map(lambda x: Row(**OrderedDict(sorted(x.items()))))
        upd_fnl_sdf = spark.createDataFrame(upd_fnl_rdd,upd_fnl_schema) 
      
        print("[INFO] With Found Keys List, Generating Existing Documents Account_Policy_Claim to Update....")
        lgcy_apc_upd = lgcy_apc.filter(col("Customer_Key").isin(keys_fnd))
        lgcy_apc_upd.createOrReplaceTempView("mdm_lgcy_upd_custapc")
        lgcy_apc_upd1 = spark.sql("select Customer_Key,Customer_Name,case when Account_Number is null then 'NA' else Account_Number end as Account_Number,case when Policy_Number is null then 'NA' else Policy_Number end as Policy_Number,collect_set(Claim_Number) as Claim_Numbers from mdm_lgcy_upd_custapc group by Customer_Key,Customer_Name,Account_Number,Policy_Number")
        lgcy_apc_upd1.createOrReplaceTempView("mdm_lgcy_upd_custapc1")	
        lgcy_apc_upd2 = spark.sql("select Customer_Key,Customer_Name,Account_Number,collect_set(struct(Policy_Number,Claim_Numbers)) as Policy_Claims from mdm_lgcy_upd_custapc1 group by Customer_Key,Customer_Name,Account_Number")
        lgcy_apc_upd2.createOrReplaceTempView("mdm_lgcy_upd_custapc2")
        lgcy_apc_upd3 = spark.sql("select Customer_Key,Customer_Name,collect_set(struct(Account_Number,Policy_Claims)) as Account_Policy_Claim from mdm_lgcy_upd_custapc2 group by Customer_Key,Customer_Name")
        lgcy_apc_upd3.createOrReplaceTempView("mdm_lgcy_upd_custapc3")
        lgcy_apc_upd_fnl = spark.sql("select Customer_Key,Account_Policy_Claim from mdm_lgcy_upd_custapc3")		

        print("[INFO] Join upd_fnl_sdf and lgcy_apc_upd_fnl as One SparkDF for Update....")
        upd_mongo_sdf = upd_fnl_sdf.join(lgcy_apc_upd_fnl, upd_fnl_sdf.Customer_Key == lgcy_apc_upd_fnl.Customer_Key,how='inner').drop(lgcy_apc_upd_fnl.Customer_Key)
        lgcy_upd_list = upd_mongo_sdf.toJSON(False).collect()
	    
        print("[INFO] Existing Documents Bulk Update In Progress....")       		
        if len(lgcy_upd_list) == 0:
           print("[INFO] No Matching Keys Documents to Update")			
        else:
           upd_sublist = [lgcy_upd_list[x:x+25000] for x in range(0, len(lgcy_upd_list), 25000)]
           for sub_ulist in upd_sublist:
               mongo_upd_list = []
               for ucustomer in sub_ulist:
                  mongo_upd_list.append(eval(ucustomer))
               bulk = mcustcoll.initialize_unordered_bulk_op()		   
               for idz in range(0,len(mongo_upd_list),1):
                       bulk.find({"Customer_Key" : mongo_upd_list[idz]["Customer_Key"]}).update(
                                        {"$set":{"Alias_Name" : mongo_upd_list[idz]["Alias_Name"],
                                                 "Contact_ID" : mongo_upd_list[idz]["Contact_ID"],
                                                 "Account_Number" : mongo_upd_list[idz]["Account_Number"],
                                                 "Policy_Number" : mongo_upd_list[idz]["Policy_Number"],
                                                 "Claim_ID" : mongo_upd_list[idz]["Claim_ID"],
                                                 "Claim_Number" : mongo_upd_list[idz]["Claim_Number"],
                                                 "Loss_Date" : mongo_upd_list[idz]["Loss_Date"],
                                                 "Product" : mongo_upd_list[idz]["Product"],
                                                 "Contact_Role" : mongo_upd_list[idz]["Contact_Role"],
                                                 "DOB" : mongo_upd_list[idz]["DOB"],
                                                 "License_Number" : mongo_upd_list[idz]["License_Number"],
                                                 "ID_Value" : mongo_upd_list[idz]["ID_Value"],
                                                 "Phone" : mongo_upd_list[idz]["Phone"],
                                                 "Email" : mongo_upd_list[idz]["Email"],
                                                 "Address" : mongo_upd_list[idz]["Address"],
                                                 "Zip_Code" : mongo_upd_list[idz]["Zip_Code"],
                                                 "Account_Policy_Claim": mongo_upd_list[idz]["Account_Policy_Claim"]}})
               bulk.execute()
               print("[INFO] Number of Documents Updated: {0}".format(len(mongo_upd_list)))			   

        print("[INFO] With Not Found Keys List, Generating New Documents To Insert....")
        nfnd_sdf = lgcy_customer.filter(col("Customer_Key").isin(keys_nfnd))
        lgcy_ins_list = nfnd_sdf.toJSON(False).collect()        
		
        print("[INFO] New Documents Bulk Insert In Progress....")			
        if len(lgcy_ins_list) == 0:
           print("[INFO] No New Keys Documents to Insert")			
        else:			
           ins_sublist = [lgcy_ins_list[x:x+50000] for x in range(0, len(lgcy_ins_list), 50000)]
           for sub_list in ins_sublist:
               mongo_ins_list = []
               for customer in sub_list:
                  mongo_ins_list.append(eval(customer))
               rmv_ins_list = []
               for chkj in range(0,len(mongo_ins_list),1):
                   if len(bson.BSON.encode(mongo_ins_list[chkj])) > 16793600:
                      excp_doc = lgcy_customer.filter(col("Customer_Key") == mongo_ins_list[chkj]["Customer_Key"]).select("Customer_Key","Customer_Name","Contact_ID","Account_Number","Policy_Number","Claim_ID","Claim_Number","Loss_Date","Product","Contact_Role","Account_Policy_Claim")
                      excp_doc.write.mode('append').json(LGCY_MDM_Excp_Location)				  
                      rmv_ins_list.append(mongo_ins_list[chkj])
                      print("[INFO] Key Exceeds Limit Removed: {0}".format(str(mongo_ins_list[chkj]["Customer_Key"])))
               if len(rmv_ins_list) == 0:
                  mcustcoll.insert_many(mongo_ins_list)
                  print("[INFO] Number of Documents Inserted: {0}".format(len(mongo_ins_list)))
               else:
                  fnl_ins_list = [ely for ely in mongo_ins_list if ely not in rmv_ins_list]			  
                  mcustcoll.insert_many(fnl_ins_list)
                  print("[INFO] Number of Documents Inserted: {0}".format(len(fnl_ins_list)))

        print("[INFO] LGCY APC Curr Date Incr - Write to CCPC APC Curr Date Accumulation....")		
        lgcy_apc_i.dropDuplicates().write.mode('append').parquet(CCPC_APC_Full_Data_CDate_Location)

        print("[INFO] List Of Keys that are Updated:")
        print(keys_fnd)
        print("[INFO] List Of Keys that are Inserted:")
        print(keys_nfnd)
        print("[INFO] Total Number of Documents Updated: {0}".format(len(keys_fnd)))
        print("[INFO] Total Number of Documents Inserted: {0}".format(len(keys_nfnd)))
        print("[INFO] Total Number of Incremental Records Processed: {0}".format(len(keys_fnd) + len(keys_nfnd)))

    print("[INFO] Step III - Completed Writing Golden Records to Target Collection....")
    spark.stop()