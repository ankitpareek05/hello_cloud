# Import all required libraries
import datetime as dt
import pymongo, os, sys, string
import base64 as b64
from base64 import b64decode

# Main Module

if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 13:
       print("Error usage: mdm_delete_stat_entry.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)
   
    muserid = sys.argv[1]
    mpwd = sys.argv[2]
    mhost = sys.argv[3]
    mport = sys.argv[4]
    mprop1 = sys.argv[5]
    mprop2 = sys.argv[6]
    mprop3 = sys.argv[7]
    mprop4 = sys.argv[8]   
    mdatabase = sys.argv[9]
    mstats = sys.argv[10]
    fdate = sys.argv[11]
    fsys = sys.argv[12]
		
    # Setup required Batch variables
    print("[INFO] Setting up Variables and MongoDB Connection....")
    Batch_Start_Time = dt.datetime.now()
    date_run = Batch_Start_Time.strftime("%Y-%m-%d_%H:%M:%S")
    print("[INFO] Python source execution time: {0}".format(date_run))
    mpassword = b64decode(mpwd).decode('utf-8')
    ConnString = "mongodb://{0}:{1}@{2}:{3}/?{4}&{5}&{6}&{7}".format(muserid, mpassword, mhost, mport, mprop1, mprop2, mprop3, mprop4)	
    #print("Connection String: " + ConnString)
    
    # Create a MongoDB Client
    print("[INFO] Connecting to Mongo DB Server....")
    mclient = pymongo.MongoClient(ConnString)  
    # Database and Collection to be used
    mdb = mclient[mdatabase]
    mstatcoll = mdb[mstats]
    
    docQry = {"$and":[{"RUN_NAME":{"$regex":"^"+fsys}},{"INGESTION_DTTM":{"$regex":"^"+fdate}}]}
    print("[INFO] Printing the Documents Before Deleting....")
    print("Qry: {0}".format(docQry))
    for doc in mstatcoll.find(docQry):
       print(doc)
    print("[INFO] Deleting the Documents....")
    delCnt = mstatcoll.delete_many(docQry)
    print("[INFO] {0} Documents Deleted for Date {1}".format(delCnt.deleted_count,fdate))
   
    print("[INFO] Python - Completed Deleting Stat Entries for the given MDM Daily Date....")