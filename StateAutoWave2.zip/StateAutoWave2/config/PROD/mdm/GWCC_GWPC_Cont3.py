# Import all required libraries
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext, Row, Column
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.dataframe import *
from pyspark.sql.column import *
from pyspark.sql.window import *
from pyspark.ml import Pipeline, Model, PipelineModel
from pyspark.ml.feature import RegexTokenizer, Tokenizer, NGram, HashingTF, MinHashLSH
import datetime as dt
import pymongo, pandas, json, os, sys, string, uuid
from functools import reduce
from itertools import groupby
from operator import add, itemgetter
import base64 as b64
from base64 import b64decode
import bson

def merge_records_by(key, combine):
    return lambda rec_a, rec_b: {
        k: rec_a[k] if k == key else list(set(combine(rec_a[k], rec_b[k])))
        for k in rec_a
    }

def merge_list_of_records_by(key, combine):
    keyprop = itemgetter(key)
    return lambda lst: [
        reduce(merge_records_by(key, combine), records)
        for _, records in groupby(sorted(lst, key=keyprop), keyprop)
    ]

# Main Module
 
if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 16:
       print("Error usage: GWCC_GWPC_Cont3.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)
  
    muserid = sys.argv[1]
    mpwd = sys.argv[2]
    mhost = sys.argv[3]
    mport = sys.argv[4]
    mprop1 = sys.argv[5]
    mprop2 = sys.argv[6]
    mprop3 = sys.argv[7]
    mprop4 = sys.argv[8]
    
    mdatabase = sys.argv[9]
    mcustomer = sys.argv[10]
    mstats = sys.argv[11]
    
    golden_data_loc = sys.argv[12]
    cc_pc_apc_data_loc = sys.argv[13]
    cc_pc_apc_full_data_loc = sys.argv[14]
    mdm_excp_loc = sys.argv[15]
		
    # Setup required Batch variables
    print("[INFO] Setting up Batch variables....")
    Batch_Start_Time = dt.datetime.now()
    date_ext = Batch_Start_Time.strftime("%Y-%m-%d")
    mpassword = b64decode(mpwd).decode('utf-8')
    ConnString = "mongodb://{0}:{1}@{2}:{3}/?{4}&{5}&{6}&{7}".format(muserid, mpassword, mhost, mport, mprop1, mprop2, mprop3, mprop4)	
    print("MongoDB Connection: " + ConnString)

    print("[INFO] Spark Session Setup....")   
    spark = SparkSession.builder.appName("GWCC_GWPC_Cont3").enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    
    # Create a MongoDB Client
    print("[INFO] Connecting to Mongo DB Server....")
    mclient = pymongo.MongoClient(ConnString)
    
    # Database and Collection to be used
    mdb = mclient[mdatabase]
    mcustcoll = mdb[mcustomer]
    mstatcoll = mdb[mstats]
	   
    # Location to store final golden records
    Golden_Data_Location = golden_data_loc+date_ext
    CC_PC_APC_Data_CDate_Location = cc_pc_apc_data_loc+date_ext
    CC_PC_APC_Full_Data_CDate_Location = cc_pc_apc_full_data_loc+date_ext
    MDM_Excp_Location = mdm_excp_loc+date_ext
    
    # Read final data set from S3
    print("[INFO] Reading Golden Records copy from S3 for Target Loading....")
    ccpc_customer_r = spark.read.parquet(Golden_Data_Location)

    #print("[INFO] Creating MDM_ID Column with Unique ID....")
    print("[INFO] UDF for uid and Creating Unique ID Column MDM_ID....")	
    uuidUDF = udf(lambda : str(uuid.uuid4()), StringType())
    ccpc_customer = ccpc_customer_r.withColumn("MDM_ID", uuidUDF())    
    
    #Writing the Golden Record to Target Mongo DB of 75000 records for each insert
    print("[INFO] Taking the count of Target Customer360 to decide Historical or Incremental....")
    gld_cust_count = mcustcoll.count({})
    if gld_cust_count == 0: 
        print("[INFO] Historical Load - Inserting the Golden Record to Target....")
        for x in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
            gold_cust = ccpc_customer.filter(col("Customer_Name").like(x+'%'))
            chk_df = gold_cust.count()
            if chk_df == 0:
               print("[INFO] Skipping Load as there is no records for Alpha/Number: {0}".format(x))			
               continue		
            ccpc_mylist = gold_cust.toJSON(False).collect()
            ccpc_mysublists = [ccpc_mylist[x:x+75000] for x in range(0, len(ccpc_mylist), 75000)]
            for sub_list in ccpc_mysublists:
                mongo_list = []
                for customer in sub_list:
                    mongo_list.append(eval(customer))              
                print("[INFO] Size of Current Insert List: {0}".format(str(sys.getsizeof(str(mongo_list)[1:-1]))))
                rmv_list = []
                for chki in range(0,len(mongo_list),1):
                    if len(bson.BSON.encode(mongo_list[chki])) >  16793600:
                       excp_doc = ccpc_customer.filter(col("Customer_Key") == mongo_list[chki]["Customer_Key"]).select("Customer_Key","Customer_Name","Contact_ID","Account_Number","Policy_Number","Claim_ID","Claim_Number","Loss_Date","Product","Contact_Role","Account_Policy_Claim")
                       excp_doc.write.mode('append').json(MDM_Excp_Location)					   
                       rmv_list.append(mongo_list[chki])
                       print("[INFO] Key Exceeds Limit Removed: {0}".format(str(mongo_list[chki]["Customer_Key"])))
                if len(rmv_list) == 0:
                   mcustcoll.insert_many(mongo_list)
                else:				   
                   fnl_list = [elx for elx in mongo_list if elx not in rmv_list]
                   mcustcoll.insert_many(fnl_list)
        fnl_cust_count = mcustcoll.count({})
        print("[INFO] APC Hist Write to APC Accumulation....")
        ccpc_apc_h = spark.read.parquet(CC_PC_APC_Data_CDate_Location)
        ccpc_apc_h.write.parquet(CC_PC_APC_Full_Data_CDate_Location)
        print("[INFO] Total Number of Historical Records Loaded: {0}".format(fnl_cust_count))
    else:
        print("[INFO] Incremental Load - Updating/Inserting the Golden Record to Target....")
        print("[INFO] Getting Previous run date to read Prev Full APC....")
        pdttm = list(mstatcoll.find({"RUN_NAME":"GWCC_Contacts"},{"INGESTION_DTTM":1, "_id":0}).sort("INGESTION_DTTM", pymongo.DESCENDING).limit(2))
        dt_list = []
        for i in range(0,len(pdttm),1):
            dt_list.append(pdttm[i]["INGESTION_DTTM"])
        dt_list.sort()
        PDate = dt_list[0][0:10]
        print("[INFO] Curr_and_Prev_Dates: {0}".format(pdttm))
        print("[INFO] Prev_Date: {0}".format(PDate))
        CC_PC_APC_Full_Data_PDate_Location = cc_pc_apc_full_data_loc+PDate       

        print("[INFO] APC Curr Date Incr - Read for APC Accumulation....")
        ccpc_apc_i = spark.read.parquet(CC_PC_APC_Data_CDate_Location)
        print("[INFO] APC Prev Date Full - Read for APC Accumulation....")
        ccpc_apc_f = spark.read.parquet(CC_PC_APC_Full_Data_PDate_Location)

        print("[INFO] APC Curr Date Incr + APC Prev Date Full = APC Curr Date Full - Creating....")		
        ccpc_apc_full = ccpc_apc_f.union(ccpc_apc_i)
        ccpc_apc = ccpc_apc_full.dropDuplicates()
	   
        print("[INFO] Converting Full Incremental Dataframe as Incremental List....")	    
        gld_df_json = ccpc_customer.toJSON(False).collect()
        gld_df_list=[]
        for idxa in gld_df_json: 
            gld_df_list.append(eval(idxa))

        print("[INFO] Converting Full Incremental Dataframe without few columns as Incremental List to use for update....")	    
        ccpc_customer_upd = ccpc_customer.drop("Customer_Name","Account_Policy_Claim","MDM_ID")
        gld_df_upd_json = ccpc_customer_upd.toJSON(False).collect()
        gld_df_upd_list=[]
        for idxb in gld_df_upd_json: 
            gld_df_upd_list.append(eval(idxb))			
			
        print("[INFO] Taking Only Keys from Incremental Dataframe as Incremental Keys List....")
        gld_df_keys_list = list(ccpc_customer.toPandas()["Customer_Key"])

        print("[INFO] Doings Keys Match with DB Collection and Creating DB Found Keys List....")
        db_fnd_list=[]
        pipeline = [{"$match" : {"Customer_Key" : {"$in":gld_df_keys_list}}},{"$project": {"_id":0,"Customer_Name":0,"Account_Policy_Claim":0,"MDM_ID":0}}]
        for doct in mcustcoll.aggregate(pipeline):
            db_fnd_list.append(doct)

        print("[INFO] With DB Found Keys List, Creating Found & Not Found Keys from Incremental Keys List,....")       
        keys_fnd = []
        keys_nfnd = []
        for xkey in gld_df_keys_list:
           for idw in range(0,len(db_fnd_list),1):
               if db_fnd_list[idw]["Customer_Key"] == xkey:
                  keys_fnd.append(xkey)

        keys_nfnd = list(set(gld_df_keys_list) - set(keys_fnd))			
		
        print("[INFO] With Found Keys List, Generating Existing Documents Update List from Incremental List....")
        upd_list=[]
        for fkey in keys_fnd:
           for idx in range(0,len(gld_df_upd_list),1):
               if gld_df_upd_list[idx]["Customer_Key"] == fkey:
                  upd_list.append(gld_df_upd_list[idx])		

        print("[INFO] Merging db_fnd_list(Collection Values) with upd_list(Incremental Values) as List for Update....")
        merger = merge_list_of_records_by("Customer_Key", add)
        upd_fnl_list = merger(upd_list + db_fnd_list)

        print("[INFO] With Not Found Keys List, Generating New Documents Insert List from Incremental List....")
        ins_list=[]
        for nkey in keys_nfnd:
           for idy in range(0,len(gld_df_list),1):
              if gld_df_list[idy]["Customer_Key"] == nkey:
                 ins_list.append(gld_df_list[idy])        
		
        print("[INFO] With Found Keys List, Generating Account_Policy_Claim to Update Existing Documents....")
        ccpc_apc_upd = ccpc_apc.filter(col("Customer_Key").isin(keys_fnd))
        ccpc_apc_upd.createOrReplaceTempView("mdm_upd_custapc")
        ccpc_apc_upd1 = spark.sql("select Customer_Key,Customer_Name,case when Account_Number is null then 'NA' else Account_Number end as Account_Number,case when Policy_Number is null then 'NA' else Policy_Number end as Policy_Number,collect_set(Claim_Number) as Claim_Numbers from mdm_upd_custapc group by Customer_Key,Customer_Name,Account_Number,Policy_Number")
        ccpc_apc_upd1.createOrReplaceTempView("mdm_upd_custapc1")	
        ccpc_apc_upd2 = spark.sql("select Customer_Key,Customer_Name,Account_Number,collect_set(struct(Policy_Number,Claim_Numbers)) as Policy_Claims from mdm_upd_custapc1 group by Customer_Key,Customer_Name,Account_Number")
        ccpc_apc_upd2.createOrReplaceTempView("mdm_upd_custapc2")
        ccpc_apc_upd3 = spark.sql("select Customer_Key,Customer_Name,collect_set(struct(Account_Number,Policy_Claims)) as Account_Policy_Claim from mdm_upd_custapc2 group by Customer_Key,Customer_Name")
        ccpc_apc_upd3.createOrReplaceTempView("mdm_upd_custapc3")
        ccpc_apc_upd_fnl = spark.sql("select Customer_Key,Customer_Name,Account_Policy_Claim from mdm_upd_custapc3")		
        ccpc_apc_upd_json = ccpc_apc_upd_fnl.toJSON(False).collect()
        ccpc_apc_upd_list=[]
        for idxc in ccpc_apc_upd_json: 
            ccpc_apc_upd_list.append(eval(idxc))		
		
        print("[INFO] Existing Documents Bulk Update In Progress....")
        bulk1 = mcustcoll.initialize_unordered_bulk_op()
        for idz in range(0,len(upd_fnl_list),1):
            bulk1.find({"Customer_Key" : upd_fnl_list[idz]["Customer_Key"]}).update(
                             {"$set":{"Alias_Name" : upd_fnl_list[idz]["Alias_Name"],
                                      "Contact_ID" : upd_fnl_list[idz]["Contact_ID"],
                                      "Account_Number" : upd_fnl_list[idz]["Account_Number"],
                                      "Policy_Number" : upd_fnl_list[idz]["Policy_Number"],
                                      "Claim_ID" : upd_fnl_list[idz]["Claim_ID"],
                                      "Claim_Number" : upd_fnl_list[idz]["Claim_Number"],
                                      "Loss_Date" : upd_fnl_list[idz]["Loss_Date"],
                                      "Product" : upd_fnl_list[idz]["Product"],
                                      "Contact_Role" : upd_fnl_list[idz]["Contact_Role"],
                                      "DOB" : upd_fnl_list[idz]["DOB"],
                                      "License_Number" : upd_fnl_list[idz]["License_Number"],
                                      "ID_Value" : upd_fnl_list[idz]["ID_Value"],
                                      "Phone" : upd_fnl_list[idz]["Phone"],
                                      "Email" : upd_fnl_list[idz]["Email"],
                                      "Address" : upd_fnl_list[idz]["Address"],
                                      "Zip_Code" : upd_fnl_list[idz]["Zip_Code"]}})
        bulk1.execute()		

        print("[INFO] Existing Documents Account_Policy_Claim Update In Progress....")
        bulk2 = mcustcoll.initialize_unordered_bulk_op()
        for idu in range(0,len(ccpc_apc_upd_list),1):
            bulk2.find({"Customer_Key" : ccpc_apc_upd_list[idu]["Customer_Key"]}).update(
                             {"$set":{"Account_Policy_Claim" : ccpc_apc_upd_list[idu]["Account_Policy_Claim"]}})
        bulk2.execute()		
	
        print("[INFO] New Documents Bulk Insert In Progress....")
        ins_sublist = [ins_list[x:x+10000] for x in range(0, len(ins_list), 10000)]
        for sub_list in ins_sublist:
           mongo_ins_list = []
           for customer in sub_list:
              mongo_ins_list.append(customer)
           print("[INFO] Size of Current Insert List: {0}".format(str(sys.getsizeof(str(mongo_ins_list)[1:-1]))))
           rmv_ins_list = []
           for chkj in range(0,len(mongo_ins_list),1):
               if len(bson.BSON.encode(mongo_ins_list[chkj])) > 16793600:
                  excp_doc = ccpc_customer.filter(col("Customer_Key") == mongo_ins_list[chkj]["Customer_Key"]).select("Customer_Key","Customer_Name","Contact_ID","Account_Number","Policy_Number","Claim_ID","Claim_Number","Loss_Date","Product","Contact_Role","Account_Policy_Claim")
                  excp_doc.write.mode('append').json(MDM_Excp_Location)				  
                  rmv_ins_list.append(mongo_ins_list[chkj])
                  print("[INFO] Key Exceeds Limit Removed: {0}".format(str(mongo_ins_list[chkj]["Customer_Key"])))
           if len(rmv_ins_list) == 0:
              mcustcoll.insert_many(mongo_ins_list)
           else:
              fnl_ins_list = [ely for ely in mongo_ins_list if ely not in rmv_ins_list]			  
              mcustcoll.insert_many(fnl_ins_list)        

        print("[INFO] APC Curr Date Full - Write to APC Accumulation....")		
        ccpc_apc.write.parquet(CC_PC_APC_Full_Data_CDate_Location)
		   
        total_cnt = len(upd_list) + len(ins_list)
        print("[INFO] List Of Keys that are Updated")
        print(keys_fnd)
        print("[INFO] List Of Keys that are Inserted")
        print(keys_nfnd)	
        print("[INFO] Total Number of Documents Updated: {0}".format(len(upd_list)))
        print("[INFO] Total Number of Documents Updated Acc_Pol_Clm: {0}".format(len(ccpc_apc_upd_list)))
        print("[INFO] Total Number of Documents Inserted: {0}".format(len(ins_list)))	
        print("[INFO] Total Number of Incremental Records Processed: {0}".format(total_cnt))

    print("[INFO] Step III - Completed Writing Golden Records to Target Collection....")
    spark.stop()