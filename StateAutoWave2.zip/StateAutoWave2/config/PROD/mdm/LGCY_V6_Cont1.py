# Import all required libraries
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext, Row, Column
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.dataframe import *
from pyspark.sql.column import *
from pyspark.sql.window import *
from pyspark.ml import Pipeline, Model, PipelineModel
from pyspark.ml.feature import RegexTokenizer, Tokenizer, NGram, HashingTF, MinHashLSH
import datetime as dt
import pymongo, pandas, json, os, sys, string, uuid, re
import base64 as b64
from base64 import b64decode 

def Chk_City(Derived_City): 
    regex = re.compile('[1234567890@_!#$%^&*()<>?/\|}{~:]') 
    if(regex.search(Derived_City) != None) or (len(Derived_City.strip()) == 1): 
       return None   
    else: 
       return Derived_City

# Main Module

if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 25:
       print("Error usage: LGCY_V6_Cont1.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)

    v6_secr_data = sys.argv[1] 
    dmact_data = sys.argv[2] 
    v6_data = sys.argv[3] 
    pinfo53k = sys.argv[4] 
    amlob = sys.argv[5] 
    pifaddr = sys.argv[6] 
    commnt5k = sys.argv[7] 
    driver5k = sys.argv[8] 
    desc53k = sys.argv[9] 
    prev_yyyymm = sys.argv[10]
    curr_yyyymm = sys.argv[11]	
    
    muserid = sys.argv[12]
    mpwd = sys.argv[13]
    mhost = sys.argv[14]
    mport = sys.argv[15]
    mprop1 = sys.argv[16]
    mprop2 = sys.argv[17]
    mprop3 = sys.argv[18]
    mprop4 = sys.argv[19]
    
    mdatabase = sys.argv[20]
    mcustomer = sys.argv[21]
    mstats = sys.argv[22]
    
    lgcy_grp_data_loc = sys.argv[23]
    lgcy_apc_data_loc = sys.argv[24]
		
    # Setup required Batch variables
    print("[INFO] Setting up Batch variables....")
    Batch_Start_Time = dt.datetime.now()
    date_ext = Batch_Start_Time.strftime("%Y-%m-%d")
    mpassword = b64decode(mpwd).decode('utf-8')    
    ConnString = "mongodb://{0}:{1}@{2}:{3}/?{4}&{5}&{6}&{7}".format(muserid, mpassword, mhost, mport, mprop1, mprop2, mprop3, mprop4)	
    print("MongoDB Connection: " + ConnString)

    print("[INFO] Spark Session Setup....")   
    spark = SparkSession.builder.appName("LGCY_V6_Cont1").enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
	
    #print("[INFO]  Spark and Hive Configuration Setup....")
    spark.conf.set("hive.exec.dynamic.partition", "true")
    spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    spark.conf.set("hive.support.concurrency", "true")
    #spark.conf.set("spark.sql.shuffle.partitions", "200")
	
    # Create a MongoDB Client
    print("[INFO] Connecting to Mongo DB Server....")
    mclient = pymongo.MongoClient(ConnString)
    
    # Database and Collection to be used
    mdb = mclient[mdatabase]
    mcustcoll = mdb[mcustomer]
    mstatcoll = mdb[mstats]
    
    # Setup transform MDM Stats variables
    print("[INFO] Setting up transform mdm stat variables....") 
    run_name = "LGCY_V6_Contacts" 
    ing_dttm = dt.datetime.now()
    ingestn_dttm = ing_dttm.strftime("%Y-%m-%d %H:%M:%S.%f")
    
    # Location to read combined Claims and Policy data
    LGCY_Grouped_Data_Location = lgcy_grp_data_loc+curr_yyyymm
    LGCY_APC_Data_Location = lgcy_apc_data_loc+curr_yyyymm
    
    #Read transform_mdm_stats table to get previous run yyyymm, 
    #First Run, Reads 201803 and will read all records > this time, gives historical load
    #Last Step, inserts current run max update time 
    #Subsequent Run, Reads previous run max update time, and will records > this time, gives incremental load
    print("[INFO] Reading Stats table to get previous run yyyymm....")
    if mstatcoll.count({"RUN_NAME":"LGCY_V6_Contacts"}, limit = 1) == 0:
       prev_yyyymm = 201803
       lgdata = [(run_name,ingestn_dttm,prev_yyyymm)]
       lg_df = spark.createDataFrame(lgdata,["RUN_NAME","INGESTION_DTTM","TRAN_YYYYMM"])	
       lg_list = lg_df.toJSON().collect()
       lg_ld = [json.loads(sts) for sts in lg_list]
       mstatcoll.insert_one(lg_ld[0])
       print("[INFO] First Time Historic Load from >= {0}".format(prev_yyyymm))
    else:
       prev_ym = list(mstatcoll.find({"RUN_NAME":"LGCY_V6_Contacts"},{"TRAN_YYYYMM":1, "_id":0}).sort("TRAN_YYYYMM", pymongo.DESCENDING).limit(1))
       prev_yyyymm = int(prev_ym[0]["TRAN_YYYYMM"])
       print("[INFO] Sub Sequent Incremental Load from >= {0}".format(prev_yyyymm))
    
    prev_yyyymm = int(prev_yyyymm)     
    curr_yyyymm = int(curr_yyyymm)
	
    print("[INFO] Query Assignment to Variable....")
    lgcyQry = "select  \
               ' ' as ID, \
               ' ' as Customer_Key, \
               insured_name.Insured_name as Derived_Customer_Name, \
               ' ' as Alias_Name, \
               insured_name.Derived_MasterItemID_Contact_ID, \
               insured_name.Derived_Contact_ID, \
               ' ' as Account_Number, \
               p.policy_symbol || p.policy_number as Policy_Number, \
               ' ' as Claim_ID, \
               ' ' as Claim_Number, \
               ' ' as Loss_Date, \
               case when ref.description is null then 'PL-LOB is ' || p.line_of_business \
                    else 'PL-' || ref.description \
               end as Product, \
               'Legacy Insured' as Derived_Contact_Role, \
               ' ' as DOB, \
               ' ' as License_Number, \
               ' ' as ID_Value, \
               Insured_phone.Phone_Number as Phone, \
               ' ' as Email, \
               case when scrubbed_02_addr.MasterItemID > 0 \
                            and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 1) = ' &' \
		              then substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 2) \
                    when scrubbed_02_addr.MasterItemID > 0 \
	                        and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)))) = '&' \
		              then substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 1) \
                    when scrubbed_02_addr.MasterItemID > 0 \
	                        and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, 2) = '- ' \
		              then substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 3, length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 2) \
	                when scrubbed_02_addr.MasterItemID > 0 \
                      then scrubbed_02_addr.ADDRESS_LINE_1 \
	                else \
	                  case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
		                          and length(rtrim(p.PIF_ADDRESS_LINE_3)) = 0 \
			                 then p.PIF_ADDRESS_LINE_2 \
			               when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 AND \
		                       (rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
					           rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
					           rtrim(p.pif_address_line_2) like 'C/O %' OR \
						       substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
						       substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
						       substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
						       substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &' OR \
						       substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' OR \
						       position(rtrim(p.PIF_ADDRESS_LINE_2) in insured_name.Insured_name) > 0 \
						       ) \
		                     then p.PIF_ADDRESS_LINE_3 \
				           else p.PIF_ADDRESS_LINE_2 end \
	               end \
  	             as DERIVED_address_line_1, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.ADDRESS_LINE_2 \
               	  else \
               		case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
               		     then case when (rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
               			                 rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
               							 rtrim(p.pif_address_line_2) like 'C/O %' OR \
               							 substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
               							 substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
               							 substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
               							 substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
                                            substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR'  OR \
               							 position(rtrim(p.PIF_ADDRESS_LINE_2) in insured_name.Insured_name) > 0 \
               							 ) \
               		               then ' ' else p.PIF_ADDRESS_LINE_3 end \
               			else ' '	end \
               	  end \
                     as DERIVED_address_line_2, \
                case when scrubbed_02_addr.MasterItemID > 0	 \
                     then scrubbed_02_addr.CITY  \
               	  else  \
               	    case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 then substring(rtrim(p.pif_address_line_4), 1, length(rtrim(p.PIF_ADDRESS_LINE_4)) - 4) \
               	            else case when length(rtrim(p.pif_address_line_3)) > 0 \
               				          then substring(rtrim(p.pif_address_line_3), 1, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 4)  \
               						  else '' end \
               					 end \
               	  end \
               	  as DERIVED_city, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.STATE \
               	  else  \
               	    case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 then substring(rtrim(p.pif_address_line_4), length(rtrim(p.PIF_ADDRESS_LINE_4)) - 1, 2) \
               	            else case when length(rtrim(p.pif_address_line_3)) > 0 \
               				          then substring(rtrim(p.pif_address_line_3), length(rtrim(p.PIF_ADDRESS_LINE_3)) - 1, 2) \
               						  else '' end \
               					 end \
               	  end \
               	  as DERIVED_state, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.US_ZIP \
               	  else \
               	    case when length(p.PIF_ZIP_POSTAL_CODE) = 6 then SUBSTRING(p.PIF_ZIP_POSTAL_CODE, 2, 5) else p.PIF_ZIP_POSTAL_CODE end \
               	  end as Zip_Code, \
               'NA-' || p.policy_symbol || p.policy_number as Account_Policy, \
               ' ' as MDM_ID, \
               p.pif_agency_number as Agency_Code, \
               p.line_of_business as LOB, \
               p.policy_mod as Policy_Mod, \
               p.pif_address_line_1 as SOURCE_pif_address_line_1, \
               p.pif_address_line_2 as SOURCE_pif_address_line_2, \
               p.pif_address_line_3 as SOURCE_pif_address_line_3, \
               p.pif_address_line_4 as SOURCE_pif_address_line_4, \
               p.pif_zip_postal_code as SOURCE_pif_zip_postal_code, \
               pif_zip_plus_4 as SOURCE_pif_zip_plus_4 \
               ,scrubbed_02_addr.MasterItemID as SCRUBBED_MasterItemID, scrubbed_02_addr.address_line_1 as SCRUBBED_address_line_1, scrubbed_02_addr.ADDRESS_LINE_2 as SCRUBBED_address_line_2, \
               scrubbed_02_addr.CITY as SCRUBBED_city, scrubbed_02_addr.STATE as SCRUBBED_state, scrubbed_02_addr.US_ZIP as SCRUBBED_us_zip, scrubbed_02_addr.US_ZIP4 as SCRUBBED_us_zip4, \
               scrubbed_02_addr.US_RESULT_CODE as SCRUBBED_us_result_code, scrubbed_02_addr.US_NUMERIC_RESULT_CODE as SCRUBBED_us_numeric_result_code, \
               scrubbed_02_addr.US_RESULT_CODE_DESC as SCRUBBED_us_result_code_desc \
               from {0}.{3} p \
               left join {1}.{4} ref on rtrim(p.line_of_business) = rtrim(ref.code) \
               join ( \
               select \
               (rtrim(cast(p.transactionyyyymm as varchar(6))) 	||	 '_' 	|| \
               rtrim(cast(p.masteritemid as varchar(20))) 	||	 '_' 	||	 cast(p.pif_record_id as char(2)) ||		 '_' 	||	 rtrim(cast(p.itemid as varchar(20)))) \
               as Derived_MasterItemID_Contact_ID, \
               p.policy_symbol || p.policy_number || '_' || cast(p.pif_record_id as char(2)) || '_00' as Derived_Contact_ID, \
               masteritemid, \
               case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
                    then \
	                  case \
                        when length(rtrim(p.PIF_ADDRESS_LINE_3)) = 0 \
			              then  rtrim(p.pif_address_line_1)	\
			            when \
			                 ( \
		                     rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
					         rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
					         rtrim(p.pif_address_line_2) like 'C/O %' OR \
						     substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
						     substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
						     substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) = ' AND' OR \
						     substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 1) = ' &' OR \
						     substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
						     substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
						     substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
						     ) \
						     AND ( \
			                 rtrim(p.pif_address_line_2) like '%PO BOX %' OR rtrim(p.pif_address_line_2) like '%P.O. BOX %' OR  rtrim(p.pif_address_line_2) like '%P O BOX %' OR \
					         rtrim(p.pif_address_line_3) like 'APT %' OR rtrim(p.pif_address_line_3) like 'APT.%' OR \
                             substring(p.PIF_ADDRESS_LINE_2, 1, 1) in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') OR \
					         rtrim(p.pif_address_line_3) like 'UNIT %' OR rtrim(p.pif_address_line_3) like 'LOT %' OR \
					         substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 6, 7) = ' COUNTY' OR \
					         substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 2, 3) = ' CO' \
					            ) \
                      then \
                        case when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = '& OR' \
					           then substring(p.PIF_ADDRESS_LINE_1, 6, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 5) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = '&/OR' \
					           then substring(p.PIF_ADDRESS_LINE_1, 6, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 5)	\
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 6) = '& AND ' \
					           then substring(p.PIF_ADDRESS_LINE_1, 7, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 6) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 7) = 'AND C/O' \
					           then substring(p.PIF_ADDRESS_LINE_1, 9, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 8) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = 'AND ' \
					           then substring(p.PIF_ADDRESS_LINE_1, 5, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 2) = '& ' \
                               then substring(p.PIF_ADDRESS_LINE_1, 3, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 1) = '&' \
					           then substring(p.PIF_ADDRESS_LINE_1, 2, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = '%/OR' \
					           then substring(p.PIF_ADDRESS_LINE_1, 6, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 5) \
                             when substring(p.PIF_ADDRESS_LINE_1, 1, 3) = 'C/O' \
					           then substring(p.PIF_ADDRESS_LINE_1, 5, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4) \
                             when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) = ' AND' \
                               then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 4) \
                             when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 1) = ' &' \
                               then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 2) \
                             when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 2) = ' OR' \
                               then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) \
                             when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) = ' C/O' \
                               then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 4) \
					         else \
			                   rtrim(p.pif_address_line_1) \
					    end \
			          when \
			                 ( \
		                     rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
					         rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
					         rtrim(p.pif_address_line_2) like 'C/O %' OR \
						     substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
						     substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
						     substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
						     substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
						     substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
						     ) \
                        then \
			              rtrim(p.pif_address_line_1) || ' ' 	||	 rtrim(p.pif_address_line_2) \
			          when ( \
			                 rtrim(p.pif_address_line_2) like '%PO BOX %' OR rtrim(p.pif_address_line_2) like '%P.O. BOX %' OR  rtrim(p.pif_address_line_2) like '%P O BOX %' OR \
					         rtrim(p.pif_address_line_3) like 'APT %' OR rtrim(p.pif_address_line_3) like 'APT.%' OR \
                             substring(p.PIF_ADDRESS_LINE_2, 1, 1) in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') OR \
					         rtrim(p.pif_address_line_3) like 'UNIT %' OR rtrim(p.pif_address_line_3) like 'LOT %' OR \
					         substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 6, 7) = ' COUNTY' OR \
					         substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 2, 3) = ' CO' \
					       ) \
                        then \
			              rtrim(p.pif_address_line_1) \
			            else \
                          rtrim(p.pif_address_line_1) 	||	 ' ' 	||	 rtrim(p.pif_address_line_2) \
	                    end \
                    else \
                      case when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = '& OR' \
					         then substring(p.PIF_ADDRESS_LINE_1, 6, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 5) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = '&/OR' \
					         then substring(p.PIF_ADDRESS_LINE_1, 6, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 5) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 6) = '& AND ' \
					         then substring(p.PIF_ADDRESS_LINE_1, 7, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 6) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 7) = 'AND C/O' \
					         then substring(p.PIF_ADDRESS_LINE_1, 9, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 8) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = 'AND ' \
					         then substring(p.PIF_ADDRESS_LINE_1, 5, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4) \
				           when substring(p.PIF_ADDRESS_LINE_1, 1, 2) = '& ' \
                             then substring(p.PIF_ADDRESS_LINE_1, 3, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 1) = '&' \
					         then substring(p.PIF_ADDRESS_LINE_1, 2, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 4) = '%/OR' \
					         then substring(p.PIF_ADDRESS_LINE_1, 6, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 5) \
                           when substring(p.PIF_ADDRESS_LINE_1, 1, 3) = 'C/O' \
					         then substring(p.PIF_ADDRESS_LINE_1, 5, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4)	\
                           when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) = ' AND' \
                             then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 4) \
                           when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 1) = ' &' \
                             then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 2) \
                           when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 2) = ' OR' \
                             then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) \
                           when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) = ' C/O' \
                             then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 4) \
                           when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 6) = ' AND/OR' \
                             then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 7) \
					       else \
			                 rtrim(p.pif_address_line_1) \
					       end \
                  end \
                as Insured_name \
                from {0}.{3} p \
                where transactionyyyymm >= {9} and transactionyyyymm < {10} and p.policy_mod <= '59'	and	rtrim(p.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') and \
                (substring(p.pif_address_line_1, 1, 3) <> 'LN#' and substring(p.pif_address_line_1, 1, 4) <> 'REF ') and \
                ( \
                 length(rtrim(p.PIF_ADDRESS_LINE_4)) = 0 \
                 OR  ( length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 and  length(rtrim(p.PIF_ADDRESS_LINE_3)) = 0 ) \
                 OR  ( \
               			        rtrim(p.pif_address_line_2) like '%PO BOX %' OR rtrim(p.pif_address_line_2) like '%P.O. BOX %' OR rtrim(p.pif_address_line_2) like '%P O BOX %' OR \
               					rtrim(p.pif_address_line_3) like 'APT %' OR rtrim(p.pif_address_line_3) like 'APT.%' OR \
                                   substring(p.PIF_ADDRESS_LINE_2, 1, 1) in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') OR \
               					rtrim(p.pif_address_line_3) like 'UNIT %' OR rtrim(p.pif_address_line_3) like 'LOT %' OR \
               					substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 6, 7) = ' COUNTY' OR \
               					substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 2, 3) = ' CO' \
               					) \
                 ) \
               union \
               select \
               (rtrim(cast(p.transactionyyyymm as varchar(6))) 	||	 '_' 	|| \
               rtrim(cast(p.masteritemid as varchar(20))) 	||	 '_' 	||	 cast(p.pif_record_id as char(2)) ||		 '_' 	||	 rtrim(cast(p.itemid as varchar(20))) \
               || '_01') \
               as Derived_MasterItemID_Contact_ID, \
               p.policy_symbol || p.policy_number || '_' || cast(p.pif_record_id as char(2)) || '_01' as Derived_Contact_ID, \
               masteritemid, \
               case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
                      then \
	                    case \
                          when length(rtrim(p.PIF_ADDRESS_LINE_3)) = 0 \
			                then  rtrim(p.pif_address_line_1) \
			              when 	substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' \
			                then substring(p.PIF_ADDRESS_LINE_1, 1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4) \
			              when substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &' \
			                then substring(p.PIF_ADDRESS_LINE_1, 1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1) \
			              when substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
			                then substring(p.PIF_ADDRESS_LINE_1, 1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2) \
                          when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) = ' AND' \
                            then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 4) \
                          when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 1) = ' &' \
                            then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 2) \
                          when substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 2) = ' OR' \
                            then substring(ltrim(rtrim(p.PIF_ADDRESS_LINE_1)), 1, length(ltrim(rtrim(p.PIF_ADDRESS_LINE_1))) - 3) \
			              when ( \
			                   rtrim(p.pif_address_line_2) like '%PO BOX %' OR rtrim(p.pif_address_line_2) like '%P.O. BOX %' OR  rtrim(p.pif_address_line_2) like '%P O BOX %' OR \
					           rtrim(p.pif_address_line_3) like 'APT %' OR rtrim(p.pif_address_line_3) like 'APT.%' OR \
                               substring(p.PIF_ADDRESS_LINE_2, 1, 1) in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') OR 				rtrim(p.pif_address_line_3) like 'UNIT %' OR rtrim(p.pif_address_line_3) like 'LOT %' OR \
					           substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 6, 7) = ' COUNTY' OR \
					           substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 2, 3) = ' CO' \
					           ) \
                            then \
			                  rtrim(p.pif_address_line_1) \
			              else \
                            rtrim(p.pif_address_line_1) \
	                 end \
                     else rtrim(p.pif_address_line_1) \
                 end \
               as Insured_name \
               from {0}.{3} p \
                where transactionyyyymm >= {9} and transactionyyyymm < {10} and p.policy_mod <= '59'	and	rtrim(p.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') and \
                (substring(p.pif_address_line_1, 1, 3) <> 'LN#' and substring(p.pif_address_line_1, 1, 4) <> 'REF ') and \
                 length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
                and \
               			               ( \
               		                   rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
               					       rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
               					       rtrim(p.pif_address_line_2) like 'C/O %' OR \
               						   substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
               						   substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
               						   substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
               						   substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
               						   substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
               						   ) \
               union \
               select \
               (rtrim(cast(p.transactionyyyymm as varchar(6))) 	||	 '_' 	|| \
               rtrim(cast(p.masteritemid as varchar(20))) 	||	 '_' 	||	 cast(p.pif_record_id as char(2)) ||		 '_' 	||	 rtrim(cast(p.itemid as varchar(20))) \
               || '_02') \
               as Derived_MasterItemID_Contact_ID, \
               p.policy_symbol || p.policy_number || '_' || cast(p.pif_record_id as char(2)) || '_02' as Derived_Contact_ID, \
               masteritemid, \
               case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
                      then \
	                    case \
                          when length(rtrim(p.PIF_ADDRESS_LINE_3)) = 0 \
			                then  rtrim(p.pif_address_line_1) \
                          when substring(ltrim(rtrim(p.pif_address_line_2)), length(ltrim(rtrim(p.pif_address_line_2))) - 3) = ' C/O' \
                            then  substring(ltrim(rtrim(p.pif_address_line_2)), 1, length(ltrim(rtrim(p.pif_address_line_2))) - 4) \
                          when substring(ltrim(rtrim(p.pif_address_line_2)), length(ltrim(rtrim(p.pif_address_line_2))) - 1) = ' &' AND \
                                  rtrim(p.PIF_ADDRESS_LINE_2) like '& %' \
                            then  substring(ltrim(rtrim(p.pif_address_line_2)), 3, length(ltrim(rtrim(p.pif_address_line_2))) - 3) \
                          when substring(ltrim(rtrim(p.pif_address_line_2)), length(ltrim(rtrim(p.pif_address_line_2))) - 1) = ' &' \
                            then  substring(ltrim(rtrim(p.pif_address_line_2)), 1, length(ltrim(rtrim(p.pif_address_line_2))) - 2) \
		                  when substring(ltrim(rtrim(p.pif_address_line_2)), 1, 8) = 'AND /OR ' \
			                then  substring(rtrim(p.pif_address_line_2), 9, length(ltrim(rtrim(p.pif_address_line_2))) - 8) \
		                  when substring(ltrim(rtrim(p.pif_address_line_2)), 1, 6) = '& /OR ' \
			                then  substring(rtrim(p.pif_address_line_2), 7, length(ltrim(rtrim(p.pif_address_line_2))) - 6) \
		                  when substring(ltrim(rtrim(p.pif_address_line_2)), 1, 6) = '& /0R ' \
			                then  substring(rtrim(p.pif_address_line_2), 7, length(ltrim(rtrim(p.pif_address_line_2))) - 6) \
                          when  substring(ltrim(rtrim(p.pif_address_line_2)), length(ltrim(rtrim(p.pif_address_line_2)))) = '*' \
		                    then  substring(ltrim(rtrim(p.pif_address_line_2)), 1, length(ltrim(rtrim(p.pif_address_line_2))) - 1) \
		                  when substring(rtrim(p.pif_address_line_2), 1, 4) = '%/OR'   and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('PO BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '%/OR'   and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '%/OR'  and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('P O BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '%/OR' \
                            then  substring(rtrim(p.pif_address_line_2), 6, length(rtrim(p.pif_address_line_2))) \
		                  when substring(rtrim(p.pif_address_line_2), 1, 6) = '& AND '  and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 7, (POSITION('PO BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 6) = '& AND '   and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 7, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 6) = '& AND '   and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 7, (POSITION('P O BOX ' in p.pif_address_line_2) - 6)) \
                          when substring(rtrim(p.pif_address_line_2), 1, 6) = '& AND ' \
                            then  substring(rtrim(p.pif_address_line_2), 7, length(rtrim(p.pif_address_line_2))) \
		                  when substring(rtrim(p.pif_address_line_2), 1, 1) = '%'  and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 3, (POSITION('PO BOX ' in p.pif_address_line_2) - 3)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 1) = '%'   and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 3, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 3)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 1) = '%'   and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 3, (POSITION('P O BOX ' in p.pif_address_line_2) - 3)) \
                          when substring(rtrim(p.pif_address_line_2), 1, 1) = '%' \
                            then  substring(rtrim(p.pif_address_line_2), 3, length(rtrim(p.pif_address_line_2))) \
		                  when substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR'   and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('PO BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR'   and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR'  and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('P O BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' \
                            then  substring(rtrim(p.pif_address_line_2), 6, length(rtrim(p.pif_address_line_2))) \
		                  when substring(rtrim(p.pif_address_line_2), 1, 4) = '& OR'   and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('PO BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '& OR'   and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '& OR'  and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 6, (POSITION('P O BOX ' in p.pif_address_line_2) - 6)) \
			              when substring(rtrim(p.pif_address_line_2), 1, 4) = '& OR' \
                            then  substring(rtrim(p.pif_address_line_2), 6, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 8, (POSITION('PO BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 8, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 8, (POSITION('P O BOX ' in p.pif_address_line_2) - 8))	\
			              when 	rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' \
                            then  substring(rtrim(p.pif_address_line_2), 8, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 8, (POSITION('PO BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 8, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 8, (POSITION('P O BOX ' in p.pif_address_line_2) - 8))	\
                          when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' \
                            then  substring(rtrim(p.pif_address_line_2), 8, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %'  and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('PO BOX ' in p.pif_address_line_2) - 5)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %'  and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 5)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %'  and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('P O BOX ' in p.pif_address_line_2) - 5))	\
                          when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' \
                            then  substring(rtrim(p.pif_address_line_2), 5, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like '& C/O%' and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 7, (POSITION('PO BOX ' in p.pif_address_line_2) - 7)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like '& C/O %' and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 7, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 7)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like '& C/O %' and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 7, (POSITION('P O BOX ' in p.pif_address_line_2) - 7)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like '& C/O %' \
                            then  substring(rtrim(p.pif_address_line_2), 7, length(rtrim(p.pif_address_line_2))) \
                          when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND C/O%' and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 9, (POSITION('PO BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND C/O %' and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 9, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND C/O %' and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 9, (POSITION('P O BOX ' in p.pif_address_line_2) - 8)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND C/O %' \
                            then  substring(rtrim(p.pif_address_line_2), 9, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('PO BOX ' in p.pif_address_line_2) - 4)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 4)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('P O BOX ' in p.pif_address_line_2) - 4)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' \
                            then  substring(rtrim(p.pif_address_line_2), 5, length(rtrim(p.pif_address_line_2))) \
 		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like '& %' and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 3, (POSITION('PO BOX ' in p.pif_address_line_2) - 3)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like '& %' and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 3, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 3)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like '& %' and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 3, (POSITION('P O BOX ' in p.pif_address_line_2) - 3)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like '& %' \
                            then  substring(rtrim(p.pif_address_line_2), 3, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %'  and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 4, (POSITION('PO BOX ' in p.pif_address_line_2) - 4)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %'  and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 4, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 4)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %'  and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 4, (POSITION('P O BOX ' in p.pif_address_line_2) - 4)) \
                          when  rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' \
                            then  substring(rtrim(p.pif_address_line_2), 4, length(rtrim(p.pif_address_line_2))) \
		                  when  rtrim(p.PIF_ADDRESS_LINE_2) like 'C/O %'  and rtrim(p.pif_address_line_2) like '%PO BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('PO BOX ' in p.pif_address_line_2) - 5)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'C/O %'  and  rtrim(p.pif_address_line_2) like '%P.O. BOX %' \
                            then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('P.O. BOX ' in p.pif_address_line_2) - 5)) \
			              when  rtrim(p.PIF_ADDRESS_LINE_2) like 'C/O %'  and  rtrim(p.pif_address_line_2) like '%P O BOX %' \
			                then  substring(rtrim(p.pif_address_line_2), 5, (POSITION('P O BOX ' in p.pif_address_line_2) - 5)) \
			              when rtrim(p.pif_address_line_2) like 'C/O %' \
                            then  substring(rtrim(p.pif_address_line_2), 5, length(rtrim(p.pif_address_line_2))) \
			              when ( \
			                    rtrim(p.pif_address_line_2) like '%PO BOX %' OR rtrim(p.pif_address_line_2) like '%P.O. BOX %' OR rtrim(p.pif_address_line_2) like '%P O BOX %' OR \
					            rtrim(p.pif_address_line_3) like 'APT %' OR rtrim(p.pif_address_line_3) like 'APT.%' OR	\
                                substring(p.PIF_ADDRESS_LINE_2, 1, 1) in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') OR \
					            rtrim(p.pif_address_line_3) like 'UNIT %' OR rtrim(p.pif_address_line_3) like 'LOT %' OR \
					            substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 6, 7) = ' COUNTY' OR \
					            substring(p.PIF_ADDRESS_LINE_3, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 2, 3) = ' CO' \
					           ) \
                            then \
			                  rtrim(p.pif_address_line_1) \
			              else \
				            rtrim(p.pif_address_line_2) \
	                   end \
                    else rtrim(p.pif_address_line_1) \
                  end \
                as Insured_name \
                from {0}.{3} p \
                 where transactionyyyymm >= {9} and transactionyyyymm < {10} and p.policy_mod <= '59'	and	rtrim(p.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') and \
                 (substring(p.pif_address_line_1, 1, 3) <> 'LN#' and substring(p.pif_address_line_1, 1, 4) <> 'REF ') and \
                 length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
                and \
                  ( \
                  rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
                  rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
                  rtrim(p.pif_address_line_2) like 'C/O %' OR \
                  substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
                  substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
                  substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
                  substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
                  substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
                  ) \
                ) as insured_name \
                on p.MasterItemID = insured_name.MasterItemID \
               left join ( \
               select a.MasterItemID, a.address_line_1, a.ADDRESS_LINE_2, a.CITY, a.STATE, a.US_ZIP, a.US_ZIP4, a.US_RESULT_CODE, a.US_NUMERIC_RESULT_CODE, a.US_RESULT_CODE_DESC \
               from {2}.{5} a \
               where transactionyyyymm >= {9} and transactionyyyymm < {10} and a.policy_mod <= '59' and rtrim(a.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') and \
               a.record_type = '02' \
               ) scrubbed_02_addr \
               on p.MasterItemID = scrubbed_02_addr.MasterItemID \
               left join ( \
               select distinct c.masteritemid, \
               (rtrim(cast(c.transactionyyyymm as varchar(6))) 	||	 '_' 	|| \
               rtrim(cast(c.masteritemid as varchar(20))) 	||	 '_' 	||	 cast(c.comments_id as char(2)) ) \
               as Derived_MasterItemID_Contact_ID, \
               'Legacy Phone Number' as Derived_Contact_Role, \
               c.phno_telephone as Phone_Number \
               from {0}.{6} c \
               where  \
               c.COMMENTS_REASON_SUSPENDED = 'PC' \
               and c.PHNO_IND = 'PHNO' \
               and c.PHNO_TELEPHONE not like ('N/A%') and c.PHNO_TELEPHONE not like ('NA%') \
               ) \
               as Insured_phone \
               on Insured_phone.MasterItemID = p.MasterItemID \
               where transactionyyyymm >= {9} and transactionyyyymm < {10} and policy_mod <= '59' and	rtrim(p.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') \
               union \
               select \
               ' ' as ID, \
               ' ' as Customer_Key, \
               case when substring(ltrim(rtrim(d.driver_name)), length(ltrim(rtrim(d.driver_name))) - 3) = ' AND' \
                      then substring(ltrim(rtrim(d.driver_name)), 1, length(ltrim(rtrim(d.driver_name))) - 4) \
                    when substring(ltrim(rtrim(d.driver_name)), length(ltrim(rtrim(d.driver_name))) - 1) = ' &' \
                      then substring(ltrim(rtrim(d.driver_name)), 1, length(ltrim(rtrim(d.driver_name))) - 2) \
                    when substring(ltrim(rtrim(d.driver_name)), length(ltrim(rtrim(d.driver_name))) - 2) = ' OR' \
                      then substring(ltrim(rtrim(d.driver_name)), 1, length(ltrim(rtrim(d.driver_name))) - 3) \
                    when substring(ltrim(rtrim(d.driver_name)), 1, 4) = '/OR ' \
                      then  substring(rtrim(d.driver_name), 5, length(ltrim(rtrim(d.driver_name))) - 4) \
                    else ltrim(rtrim(d.driver_name)) \
                 end \
               as Derived_Customer_Name, \
               ' ' as Alias_Name, \
               (rtrim(cast(d.transactionyyyymm as varchar(6))) 	||	 '_' 	|| \
               (rtrim(cast(d.masteritemid as varchar(20))) || '_' || cast(d.driver_record_id as char(2)) || '_' || rtrim(cast(d.itemid as varchar(20))))) \
               as Derived_MasterItemID_Contact_ID, \
               d.policy_symbol || d.policy_number || '_' || cast(d.driver_record_id as char(2)) || '_' || cast(rtrim(d.driver_date_birth_yyyymmdd) as char(8)) as Derived_Contact_ID, \
               ' ' as Account_Number, \
               d.policy_symbol || d.policy_number as Policy_Number, \
               ' ' as Claim_ID, \
               ' ' as Claim_Number, \
               ' ' as Loss_Date, \
               case when ref.description is null then 'PL-LOB is ' || p.line_of_business \
                    else 'PL-' || ref.description end \
               	 as Product, \
               'Legacy Driver' as Derived_Contact_Role, \
               case when length(rtrim(d.driver_date_birth_yyyymmdd)) = 8 \
                      then substring(d.driver_date_birth_yyyymmdd, 1, 4) || '-' || substring(d.driver_date_birth_yyyymmdd, 5, 2) || '-' || substring(d.driver_date_birth_yyyymmdd, 7, 8) \
                      else d.driver_date_birth_yyyymmdd \
                      end \
               as DOB, \
               d.driver_license_number as License_Number, \
               case when length(rtrim(d.driver_ssn)) = 9 \
                      then substring(d.driver_ssn, 1, 3) || '-' || substring(d.driver_ssn, 4, 2) || '-' || substring(d.driver_ssn, 6, 4) \
                      else d.driver_ssn \
                      end \
               as ID_Value, \
               ' ' as Phone, \
               ' ' as Email, \
               pif_address_info.DERIVED_address_line_1 as DERIVED_address_line_1, \
               pif_address_info.DERIVED_address_line_2 as DERIVED_address_line_2, \
               pif_address_info.DERIVED_city as DERIVED_city, \
               pif_address_info.DERIVED_state as DERIVED_state, \
               pif_address_info.zip_code as zip_code, \
               'NA-' || d.policy_symbol || d.policy_number as Account_Policy, \
               ' ' as MDM_ID, \
               p.pif_agency_number as Agency_Code, \
               d.line_of_business as LOB, \
               d.policy_mod as Policy_Mod, \
               pif_address_info.SOURCE_pif_address_line_1 as SOURCE_pif_address_line_1, \
               pif_address_info.SOURCE_pif_address_line_2 as SOURCE_pif_address_line_2, \
               pif_address_info.SOURCE_pif_address_line_3 as SOURCE_pif_address_line_3, \
               pif_address_info.SOURCE_pif_address_line_4 as SOURCE_pif_address_line_4, \
               pif_address_info.SOURCE_pif_zip_postal_code as SOURCE_pif_zip_postal_code, \
               pif_address_info.SOURCE_pif_zip_plus_4 as SOURCE_pif_zip_plus_4, \
               pif_address_info.SCRUBBED_MasterItemID as SCRUBBED_MasterItemID, \
               pif_address_info.SCRUBBED_address_line_1 as SCRUBBED_address_line_1, \
               pif_address_info.SCRUBBED_address_line_2 as SCRUBBED_address_line_2, \
               pif_address_info.SCRUBBED_city as SCRUBBED_city, \
               pif_address_info.SCRUBBED_state as SCRUBBED_state, \
               pif_address_info.SCRUBBED_us_zip as SCRUBBED_us_zip, \
               pif_address_info.SCRUBBED_us_zip4 as SCRUBBED_us_zip4, \
               pif_address_info.SCRUBBED_us_result_code as SCRUBBED_us_result_code, \
               pif_address_info.SCRUBBED_us_numeric_result_code as SCRUBBED_us_numeric_result_code, \
               pif_address_info.SCRUBBED_us_result_code_desc as SCRUBBED_us_result_code_desc \
               from {0}.{7} d \
               inner join {0}.{3} p on p.MasterItemID = d.MasterItemID \
               left join {1}.{4} ref on rtrim(d.line_of_business) = rtrim(ref.code) \
               left join ( \
               select p.masteritemid, \
                 case when scrubbed_02_addr.MasterItemID > 0 \
                          and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 1) = ' &' \
		                then substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 2) \
                      when scrubbed_02_addr.MasterItemID > 0 \
 	                       and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, 4) = '&/0R' \
		                then ' ' \
                      when scrubbed_02_addr.MasterItemID > 0 \
	                       and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)))) = '&' \
		                then substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 1) \
                      when scrubbed_02_addr.MasterItemID > 0 \
	                       and substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 1, 2) = '- ' \
		                then substring(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1)), 3, length(ltrim(rtrim(scrubbed_02_addr.ADDRESS_LINE_1))) - 2) \
	                  when scrubbed_02_addr.MasterItemID > 0 \
                        then scrubbed_02_addr.ADDRESS_LINE_1 \
	                  else \
	                    case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
		                          and length(rtrim(p.PIF_ADDRESS_LINE_3)) = 0 \
			                   then p.PIF_ADDRESS_LINE_2 \
			                 when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 AND \
		                          (rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
					              rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR	\
					              rtrim(p.pif_address_line_2) like 'C/O %' OR \
						          substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
						          substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
						          substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
						          substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
						          substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
						          ) \
		                       then p.PIF_ADDRESS_LINE_3 \
				               else p.PIF_ADDRESS_LINE_2 end \
	             end \
	            as DERIVED_address_line_1, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.ADDRESS_LINE_2 \
               	  else \
               		case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 \
               		     then case when (rtrim(p.PIF_ADDRESS_LINE_2) like 'AND/OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND?OR %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'AND %' OR \
               			                 rtrim(p.PIF_ADDRESS_LINE_2) like '& %' OR rtrim(p.PIF_ADDRESS_LINE_2) like 'OR %' OR \
               							 rtrim(p.pif_address_line_2) like 'C/O %' OR \
               							 substring(rtrim(p.pif_address_line_2), 1, 1) = '%' OR \
               							 substring(rtrim(p.pif_address_line_2), 1, 4) = '&/OR' OR \
               							 substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 4, 5) = ' &/OR' OR \
               							 substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 1, 2) = ' &'  OR \
                                            substring(p.PIF_ADDRESS_LINE_1, length(rtrim(p.PIF_ADDRESS_LINE_1)) - 2, 3) = ' OR' \
               							 ) \
               		               then ' ' else p.PIF_ADDRESS_LINE_3 end \
               			else ' '	end \
               	  end \
                     as DERIVED_address_line_2, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.CITY \
               	  else \
               	    case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 then substring(rtrim(p.pif_address_line_4), 1, length(rtrim(p.PIF_ADDRESS_LINE_4)) - 4) \
               	            else case when length(rtrim(p.pif_address_line_3)) > 0 \
               				          then substring(rtrim(p.pif_address_line_3), 1, length(rtrim(p.PIF_ADDRESS_LINE_3)) - 4) \
               						  else '' end \
               					 end \
               	  end \
               	  as DERIVED_city, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.STATE \
               	  else \
               	    case when length(rtrim(p.PIF_ADDRESS_LINE_4)) > 0 then substring(rtrim(p.pif_address_line_4), length(rtrim(p.PIF_ADDRESS_LINE_4)) - 1, 2) \
               	            else case when length(rtrim(p.pif_address_line_3)) > 0 \
               				          then substring(rtrim(p.pif_address_line_3), length(rtrim(p.PIF_ADDRESS_LINE_3)) - 1, 2) \
               						  else '' end \
               					 end \
               	  end \
               	  as DERIVED_state, \
                case when scrubbed_02_addr.MasterItemID > 0 \
                     then scrubbed_02_addr.US_ZIP \
               	  else \
               	    case when length(p.PIF_ZIP_POSTAL_CODE) = 6 then SUBSTRING(p.PIF_ZIP_POSTAL_CODE, 2, 5) else p.PIF_ZIP_POSTAL_CODE end \
               	  end \
               	  as Zip_Code, \
               p.pif_address_line_1 as SOURCE_pif_address_line_1, \
               p.pif_address_line_2 as SOURCE_pif_address_line_2, \
               p.pif_address_line_3 as SOURCE_pif_address_line_3, \
               p.pif_address_line_4 as SOURCE_pif_address_line_4, \
               p.pif_zip_postal_code as SOURCE_pif_zip_postal_code, \
               pif_zip_plus_4 as SOURCE_pif_zip_plus_4 \
               ,scrubbed_02_addr.MasterItemID as SCRUBBED_MasterItemID, scrubbed_02_addr.address_line_1 as SCRUBBED_address_line_1, scrubbed_02_addr.ADDRESS_LINE_2 as SCRUBBED_address_line_2, \
               scrubbed_02_addr.CITY as SCRUBBED_city, scrubbed_02_addr.STATE as SCRUBBED_state, scrubbed_02_addr.US_ZIP as SCRUBBED_us_zip, scrubbed_02_addr.US_ZIP4 as SCRUBBED_us_zip4, \
               scrubbed_02_addr.US_RESULT_CODE as SCRUBBED_us_result_code, scrubbed_02_addr.US_NUMERIC_RESULT_CODE as SCRUBBED_us_numeric_result_code, \
               scrubbed_02_addr.US_RESULT_CODE_DESC as SCRUBBED_us_result_code_desc \
               from {0}.{3} p \
               left join \
               ( \
               select a.MasterItemID, a.address_line_1, a.ADDRESS_LINE_2, a.CITY, a.STATE, a.US_ZIP, a.US_ZIP4, a.US_RESULT_CODE, a.US_NUMERIC_RESULT_CODE, a.US_RESULT_CODE_DESC \
               from {2}.{5} a \
               where a.transactionyyyymm >= {9} and a.transactionyyyymm < {10} and a.policy_mod <= '59' and rtrim(a.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') and \
               a.record_type = '02' \
               ) scrubbed_02_addr \
               on p.MasterItemID = scrubbed_02_addr.MasterItemID \
                where p.transactionyyyymm >= {9} and p.transactionyyyymm < {10} and p.policy_mod <= '59' and rtrim(p.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') \
               ) as pif_address_info \
               on pif_address_info.MasterItemID = d.MasterItemID \
               where d.transactionyyyymm >= {9} and d.transactionyyyymm < {10} and d.policy_mod <= '59' and rtrim(d.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') \
               union \
               select \
               ' ' as ID, \
               ' ' as Customer_Key, \
               case when substring(d.description_line_1, 1, 3) = 'LN#' OR substring(d.description_line_1, 1, 4) = 'REF ' \
                    then \
                      case when substring(d.description_line_2, 1, 4) = '& OR' \
					         then substring(d.description_line_2, 6, length(rtrim(d.description_line_2)) - 5) \
                           when substring(d.description_line_2, 1, 4) = '&/OR' \
					         then substring(d.description_line_2, 6, length(rtrim(d.description_line_2)) - 5) \
                           when substring(d.description_line_2, 1, 6) = '& AND ' \
					         then substring(d.description_line_2, 7, length(rtrim(d.description_line_2)) - 6)	\
                           when substring(d.description_line_2, 1, 7) = 'AND C/O' \
					         then substring(d.description_line_2, 9, length(rtrim(d.description_line_2)) - 8) \
                           when substring(d.description_line_2, 1, 4) = 'AND ' \
					         then substring(d.description_line_2, 5, length(rtrim(d.description_line_2)) - 4) \
                           when substring(d.description_line_2, 1, 2) = '& ' \
                             then substring(d.description_line_2, 3, length(rtrim(d.description_line_2)) - 2) \
                           when substring(d.description_line_2, 1, 1) = '&' \
					         then substring(d.description_line_2, 2, length(rtrim(d.description_line_2)) - 1) \
                           when substring(d.description_line_2, 1, 4) = '%/OR' \
					         then substring(d.description_line_2, 6, length(rtrim(d.description_line_2)) - 5) \
                           when substring(d.description_line_2, 1, 3) = 'C/O' \
					         then substring(d.description_line_2, 5, length(rtrim(d.description_line_2)) - 4) \
	                       else \
 	                           rtrim(d.description_line_2) \
				       end \
	                else \
                      case when substring(d.description_line_1, 1, 4) = '& OR' \
					         then substring(d.description_line_1, 6, length(rtrim(d.description_line_1)) - 5) \
                           when substring(d.description_line_1, 1, 4) = '&/OR' \
					         then substring(d.description_line_1, 6, length(rtrim(d.description_line_1)) - 5)	\
                           when substring(d.description_line_1, 1, 6) = '& AND ' \
					         then substring(d.description_line_1, 7, length(rtrim(d.description_line_1)) - 6)	\
                           when substring(d.description_line_1, 1, 7) = 'AND C/O' \
					         then substring(d.description_line_1, 9, length(rtrim(d.description_line_1)) - 8)	\
                           when substring(d.description_line_1, 1, 4) = 'AND ' \
					         then substring(d.description_line_1, 5, length(rtrim(d.description_line_1)) - 4)	\
                           when substring(d.description_line_1, 1, 2) = '& ' \
                             then substring(d.description_line_1, 3, length(rtrim(d.description_line_1)) - 2)	\
                           when substring(d.description_line_1, 1, 1) = '&' \
					         then substring(d.description_line_1, 2, length(rtrim(d.description_line_1)) - 1)	\
                           when substring(d.description_line_1, 1, 4) = '%/OR' \
					         then substring(d.description_line_1, 6, length(rtrim(d.description_line_1)) - 5)	\
                           when substring(ltrim(rtrim(d.description_line_1)), 1, 3) = 'C/O' AND \
					                 substring(ltrim(rtrim(d.description_line_1)), length(ltrim(rtrim(d.description_line_1))) - 1) = ' &' \
					         then substring(d.description_line_1, 5, length(rtrim(d.description_line_1)) - 6) \
                           when substring(d.description_line_1, 1, 3) = 'C/O' \
					         then substring(d.description_line_1, 5, length(rtrim(d.description_line_1)) - 4)	\
                           when substring(ltrim(rtrim(d.description_line_1)), length(ltrim(rtrim(d.description_line_1))) - 6) = ' AND OR' \
                             then substring(ltrim(rtrim(d.description_line_1)), 1, length(ltrim(rtrim(d.description_line_1))) - 7) \
                           when substring(ltrim(rtrim(d.description_line_1)), length(ltrim(rtrim(d.description_line_1))) - 3) = ' AND' \
                             then substring(ltrim(rtrim(d.description_line_1)), 1, length(ltrim(rtrim(d.description_line_1))) - 4) \
                           when substring(ltrim(rtrim(d.description_line_1)), length(ltrim(rtrim(d.description_line_1))) - 1) = ' &' \
                             then substring(ltrim(rtrim(d.description_line_1)), 1, length(ltrim(rtrim(d.description_line_1))) - 2) \
                           when substring(ltrim(rtrim(d.description_line_1)), length(ltrim(rtrim(d.description_line_1))) - 2) = ' OR' \
                             then substring(ltrim(rtrim(d.description_line_1)), 1, length(ltrim(rtrim(d.description_line_1))) - 3) \
                           when  substring(ltrim(rtrim(d.description_line_1)), length(ltrim(rtrim(d.description_line_1)))) = '*' \
		                     then  substring(ltrim(rtrim(d.description_line_1)), 1, length(ltrim(rtrim(d.description_line_1))) - 1) \
                           when substring(ltrim(rtrim(d.DESCRIPTION_LINE_1)), length(ltrim(rtrim(d.DESCRIPTION_LINE_1))) - 3) = ' C/O' \
		                     then  substring(ltrim(rtrim(d.description_line_1)), 1, length(ltrim(rtrim(d.description_line_1))) - 3) \
					       else \
			                   rtrim(d.description_line_1)	\
				      end	\
	             end \
               as Customer_Name, \
               ' ' as Alias_Name, \
               (rtrim(cast(d.transactionyyyymm as varchar(6))) 	||	 '_' 	|| \
               rtrim(cast(d.masteritemid as varchar(20))) 	||	 '_' 	||	 cast(d.description_record_id as char(2)) 	||	 '_' ||		 rtrim(cast(d.itemid as varchar(20)))) as Derived_MasterItemID_Contact_ID, \
               d.policy_symbol || d.policy_number || '_' || cast(d.description_record_id as char(2))  || '_' || cast(d.description_use_code as char(2)) || '_' ||  \
               cast(d.description_use_location as char(3)) \
               as Derived_Contact_ID, \
               ' ' as Account_Number, \
               d.policy_symbol || d.policy_number as Policy_Number, \
               ' ' as Claim_ID, \
               ' ' as Claim_Number, \
               ' ' as Loss_Date, \
               case when ref.description is null then 'PL-LOB is ' || p.line_of_business \
                    else 'PL-' || ref.description end \
               	 as Product, \
               'Legacy Other Contacts: ' 	||	 \
               case when d.DESCRIPTION_USE_CODE = 'AI' then 'Additional Insured' \
                    when d.DESCRIPTION_USE_CODE = 'CP' then 'Covered Persons' \
               	    when d.DESCRIPTION_USE_CODE = 'IN' then 'Additional Insured' \
               	    when d.DESCRIPTION_USE_CODE = 'NI' then 'Named Insured' \
               	 else 'Other' \
               end \
               as Derived_Contact_Role, \
               ' ' as DOB, \
               ' ' as License_Number, \
               ' ' as ID_Value, \
               ' ' as Phone, \
               ' ' as Email, \
               case when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 \
		                    and length(rtrim(d.DESCRIPTION_LINE_3)) = 0 \
			        then d.DESCRIPTION_LINE_2 \
			        when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 AND \
		               (rtrim(d.DESCRIPTION_LINE_2) like '%TRUST%' OR rtrim(d.DESCRIPTION_LINE_2) like '%TRST%' OR rtrim(d.DESCRIPTION_LINE_2) like '%TRUSTEE%') \
				    then ' ' \
                    when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 AND \
	                  ltrim(rtrim(d.DESCRIPTION_LINE_2)) like '-%' \
		            then ' ' \
                    when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 AND \
						       substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 1) = '(' and \
						       substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), length(ltrim(rtrim(d.DESCRIPTION_LINE_2))) - 1, 1) = ')' \
				    then rtrim(d.DESCRIPTION_LINE_3) \
                    when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 	  AND \
			              d.DESCRIPTION_USE_CODE = 'NI' AND length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) < 5 \
				    then ' ' \
			        when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 AND \
		               (rtrim(d.DESCRIPTION_LINE_2) like 'AND/OR %' OR rtrim(d.DESCRIPTION_LINE_2) like 'AND?OR %' OR rtrim(d.DESCRIPTION_LINE_2) like 'AND %' OR \
					       rtrim(d.DESCRIPTION_LINE_2) like '& %' OR rtrim(d.DESCRIPTION_LINE_2) like 'OR %' OR	\
					       rtrim(d.DESCRIPTION_LINE_2) like 'C/O %' OR \
						   substring(rtrim(d.DESCRIPTION_LINE_2), 1, 1) = '%' OR \
						   substring(rtrim(d.DESCRIPTION_LINE_2), 1, 4) = '&/OR' OR \
						   substring(d.DESCRIPTION_LINE_1, length(rtrim(d.DESCRIPTION_LINE_1)) - 4, 5) = ' &/OR' OR \
						   substring(d.DESCRIPTION_LINE_1, length(rtrim(d.DESCRIPTION_LINE_1)) - 1, 2) = ' &'  OR \
						   substring(d.DESCRIPTION_LINE_2, length(rtrim(d.DESCRIPTION_LINE_2)) - 1, 2) = ' &'  OR \
                           substring(ltrim(rtrim(d.DESCRIPTION_LINE_1)), length(ltrim(rtrim(d.DESCRIPTION_LINE_1))) - 3) = ' C/O' OR \
						   substring(d.DESCRIPTION_LINE_1, length(rtrim(d.DESCRIPTION_LINE_1)) - 2, 3) = ' OR' \
						   ) \
		            then d.DESCRIPTION_LINE_3 \
				    else \
                        case when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 3) = 'C/O' \
					             and substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 5, 1) in ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9') \
					         then substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 5, length(rtrim(d.DESCRIPTION_LINE_2)) - 4) \
						     when  substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 3) = 'C/O' \
						     then ' ' \
						     when  substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 6) = 'AND-OR' \
						     then ' ' \
						     when  substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 3) = 'AND' \
						     then ' ' \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 4) = '& OR' \
					         then ' ' \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 4) = '&/OR' \
					         then ' ' \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 2) = '& ' \
                             then ' ' \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 1) = '&' \
					         then ' ' \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 4) = '%/OR' \
					         then ' ' \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 1) = '(' and \
						       substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), length(ltrim(rtrim(d.DESCRIPTION_LINE_2))), 1) = ')' \
					         then rtrim(d.DESCRIPTION_LINE_3) \
                             when substring(ltrim(rtrim(d.DESCRIPTION_LINE_2)), 1, 3) = ';& ' \
					         then rtrim(d.DESCRIPTION_LINE_3) \
                             when d.DESCRIPTION_USE_CODE = 'NI' AND length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) < 5 \
					         then ' ' \
					         else \
			                     rtrim(d.DESCRIPTION_LINE_2) \
					    end \
				    end \
               as DERIVED_address_line_1, \
		       case when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 \
		            then \
			            case when (rtrim(d.DESCRIPTION_LINE_2) like 'AND/OR %' OR rtrim(d.DESCRIPTION_LINE_2) like 'AND?OR %' OR  rtrim(d.DESCRIPTION_LINE_2) like 'AND %' OR \
			                 rtrim(d.DESCRIPTION_LINE_2) like '& %' OR rtrim(d.DESCRIPTION_LINE_2) like 'OR %' OR \
							 rtrim(d.DESCRIPTION_LINE_2) like 'C/O %' OR \
							 substring(rtrim(d.DESCRIPTION_LINE_2), 1, 1) = '%' OR \
							 substring(rtrim(d.DESCRIPTION_LINE_2), 1, 4) = '&/OR' OR \
							 substring(d.DESCRIPTION_LINE_1, length(rtrim(d.DESCRIPTION_LINE_1)) - 4, 5) = ' &/OR' OR \
							 substring(d.DESCRIPTION_LINE_1, length(rtrim(d.DESCRIPTION_LINE_1)) - 1, 2) = ' &'  OR \
						     substring(d.DESCRIPTION_LINE_2, length(rtrim(d.DESCRIPTION_LINE_2)) - 1, 2) = ' &'  OR \
		                     rtrim(d.DESCRIPTION_LINE_2) like '%TRUST%' OR rtrim(d.DESCRIPTION_LINE_2) like '%TRST%' OR rtrim(d.DESCRIPTION_LINE_2) like '%TRUSTEE%' OR \
                             substring(d.DESCRIPTION_LINE_1, length(rtrim(d.DESCRIPTION_LINE_1)) - 2, 3) = ' OR' \
		                     OR substring(d.description_line_1, 1, 3) = 'LN#' OR substring(d.description_line_1, 1, 4) = 'REF '	\
                             OR (d.DESCRIPTION_USE_CODE = 'NI' AND length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) < 5) \
							 ) \
		                     then ' ' else d.DESCRIPTION_LINE_3 end	\
                    when d.DESCRIPTION_USE_CODE = 'NI' AND length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) < 5 \
				      then ' ' \
			        else ' '	end	\
   	           as DERIVED_address_line_2, \
		       case when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 \
		                   AND (rtrim(d.DESCRIPTION_LINE_4) like '%TRUST%' OR rtrim(d.DESCRIPTION_LINE_4) like '%TRST%' OR rtrim(d.DESCRIPTION_LINE_4) like '%TRUSTEE%') \
				    then ' ' \
                    when d.DESCRIPTION_USE_CODE = 'NI' AND length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) < 5 \
				    then ' ' \
		            when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 \
		            then substring(rtrim(d.DESCRIPTION_LINE_4), 1, length(rtrim(d.DESCRIPTION_LINE_4)) - 4) \
	                else case when length(rtrim(d.DESCRIPTION_LINE_3)) > 0	\
				              then substring(rtrim(d.DESCRIPTION_LINE_3), 1, length(rtrim(d.DESCRIPTION_LINE_3)) - 4) \
						      else '' end \
			   end \
               as DERIVED_city, \
 	           case when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 \
		                   AND (rtrim(d.DESCRIPTION_LINE_4) like '%TRUST%' OR rtrim(d.DESCRIPTION_LINE_4) like '%TRST%' OR rtrim(d.DESCRIPTION_LINE_4) like '%TRUSTEE%') \
				    then ' ' \
                    when d.DESCRIPTION_USE_CODE = 'NI' AND length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) < 5 \
				    then ' ' \
		            when length(rtrim(d.DESCRIPTION_LINE_4)) > 0 \
		            then substring(rtrim(d.DESCRIPTION_LINE_4), length(rtrim(d.DESCRIPTION_LINE_4)) - 1, 2) \
	                else case when length(rtrim(d.DESCRIPTION_LINE_3)) > 0	\
				              then substring(rtrim(d.DESCRIPTION_LINE_3), length(rtrim(d.DESCRIPTION_LINE_3)) - 1, 2) \
						      else '' end \
			   end \
               as DERIVED_state, \
               case when length(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE))) = 6 then SUBSTRING(ltrim(rtrim(d.DESCRIPTION_ZIP_CODE)), 2, 5) else ltrim(rtrim(d.DESCRIPTION_ZIP_CODE)) end \
               as Zip_Code, \
               'NA-' || d.policy_symbol || d.policy_number as Account_Policy, \
               ' ' as MDM_ID, \
               p.pif_agency_number as Agency_Code, \
               d.line_of_business as LOB, \
               d.policy_mod as Policy_Mod, \
               d.DESCRIPTION_LINE_1, \
               d.DESCRIPTION_LINE_2, \
               d.DESCRIPTION_LINE_3, \
               d.DESCRIPTION_LINE_4, \
               d.DESCRIPTION_ZIP_CODE, \
               d.DESCRIPTION_ZIP_CODE_PLUS4, \
               null as SCRUBBED_MasterItemID, \
               ' ' as SCRUBBED_address_line_1, \
               ' ' as SCRUBBED_address_line_2, \
               ' ' as SCRUBBED_city, \
               ' ' as SCRUBBED_state, \
               ' ' as SCRUBBED_us_zip, \
               ' ' as SCRUBBED_us_zip4, \
               ' ' as SCRUBBED_us_result_code, \
               null as SCRUBBED_us_numeric_result_code, \
               ' ' as SCRUBBED_us_result_code_desc \
               from {0}.{8} d \
               inner join {0}.{3} p on p.MasterItemID = d.MasterItemID \
               left join {1}.{4} ref on rtrim(d.line_of_business) = rtrim(ref.code) \
               where d.DESCRIPTION_USE_CODE in ('AI', 'CP', 'IN', 'NI') \
               and d.transactionyyyymm >= {9} and d.transactionyyyymm < {10} and d.policy_mod <= '59' and rtrim(d.line_of_business) not in ('ACV', 'AFV', 'AH', 'CPP', 'GL', 'WC') \
               and (substring(d.DESCRIPTION_LINE_1, 1, 3) <> 'LN#' and substring(d.DESCRIPTION_LINE_1, 1, 4) <> 'REF ') \
               and rtrim(d.DESCRIPTION_LINE_1) <> 'APT COMPLEX' ".format(v6_secr_data,dmact_data,v6_data,pinfo53k,amlob,pifaddr,commnt5k,driver5k,desc53k,prev_yyyymm,curr_yyyymm)
			   
    print("[INFO] Query Execution thru Spark Sql....")
    lgcyDF = spark.sql(lgcyQry)

    print("[INFO] Doing Window Partition OrderBy and Selecting Only Recent Records....")
    lgcyDF1 = lgcyDF.withColumn("MIID_CID_YYYYMM",substring(col("Derived_MasterItemID_Contact_ID"),1,6))
    wdw1 = Window.partitionBy("Derived_Customer_Name","Policy_Number","Derived_Contact_Role","DOB","Zip_Code")\
	             .orderBy(col("Derived_Customer_Name"),col("Derived_MasterItemID_Contact_ID").desc(),col("Derived_Contact_ID"),col("Account_Number"),col("Policy_Number"),col("Derived_Contact_Role"),col("DOB"),col("Zip_Code"),col("MIID_CID_YYYYMM").desc())
    lgcyDF2 = lgcyDF1.withColumn("rownum",row_number().over(wdw1)).filter(col("rownum") == 1).drop("MIID_CID_YYYYMM").drop("rownum")
	
    print("[INFO] Creating Invalid Chars List for City Check....")
    Chk_City_UDF = udf(Chk_City, StringType())
    print("[INFO] Creating New City Column by Nullify the City Names has invalid Chars....")										   
    lgcyDF3 = lgcyDF2.withColumn("New_City",Chk_City_UDF(col("DERIVED_city")))

    print("[INFO] Creating Valid States List....")
    valid_states = ['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA',
                'KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ',
                'NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT',
                'VA','WA','WV','WI','WY','DC']
    print("[INFO] Creating New State Column by Checking Valid State Codes....")										   
    lgcyDF4 = lgcyDF3.withColumn("New_State",when(col("DERIVED_state").isin(valid_states),col("DERIVED_state")).otherwise(None))
	
    print("[INFO] Creating Address Column....")
    lgcyDF5 = lgcyDF4.withColumn("Address",when(((length(trim(col("DERIVED_address_line_1"))) == 0) & (length(trim(col("New_City"))) == 0) & (length(trim(col("New_State"))) == 0)), 
                                           None).otherwise(concat_ws("",lit('"'),trim(col('DERIVED_address_line_1')),lit(", "),trim(col('New_City')),lit(", "),trim(col('New_State')),lit('"'))))

    print("[INFO] Filtering Records Which Doesn't Have Values in all the 6 Required Columns....")										   
    lgcyDF6 = lgcyDF5.filter(~(col('License_Number').isNull() & 
                               col('ID_Value').isNull() & 
                               col('DOB').isNull() & 
                               col('Phone').isNull() &
                               col('Email').isNull() &
                               col('Zip_Code').isNull()))

    print("[INFO] Filtering for Invalid Derived Customer Name....")
    lgcyDF7 = lgcyDF6.filter(~(trim(col("Derived_Customer_Name")).rlike('^[^A-Z]*$')))\
                     .filter(~(trim(col("Derived_Customer_Name")).like('%CONVERTED%')))\
                     .filter(~(trim(col("Derived_Customer_Name")).isin('CLAIMS EXPENSE')))\
                     .filter(~(trim(col("Derived_Customer_Name")).like('%UNKNOWN%')))\
					 .filter(~((substring(col("Derived_Customer_Name"),1,3) == 'UNK') |
                               (substring(col("Derived_Customer_Name"),1,4) == 'UNK ') |
                               (substring(col("Derived_Customer_Name"),1,5) == 'UNK1 ') |
                               (substring(col("Derived_Customer_Name"),1,5) == 'UNKN ') |
                               (substring(col("Derived_Customer_Name"),1,8) == 'UNKNOWN ') |
                               (substring(col("Derived_Customer_Name"),1,9) == 'UNKNOWN2 ')))

    print("[INFO] Filtering for Valid Numeric Zip Codes....")
    lgcyDF8 = lgcyDF7.filter((col("Zip_Code").cast('int').isNotNull()) & 
	                         (col("Zip_Code").cast('int') != 0))
	
    print("[INFO] Formatting Phone and Name Columns based on Given Rules....")										   
    lgcyDF9 = lgcyDF8.withColumn("New_Phone",trim(regexp_replace(col('Phone'),r'[^0-9\x20]','')))    
    lgcyDF10 = lgcyDF9.withColumn("New_Customer_Name",regexp_replace(col("Derived_Customer_Name"),"^\\&",""))

    print("[INFO] Applying Transformation's And Changing Name on Required Columns....")
    lgcyDFF = lgcyDF10.select(regexp_replace(trim(regexp_replace(col("New_Customer_Name"),r'[^A-Za-z0-9\x20\&]','')),"  "," "),
                             concat_ws("",lit('V6-'),col('Derived_Contact_ID')),
                             when(length(trim(col("Account_Number"))) == 0,None).otherwise(trim(col("Account_Number"))),
							 when(length(trim(col("Policy_Number"))) == 0,None).otherwise(trim(col("Policy_Number"))),
							 when(length(trim(col("Claim_ID"))) == 0,None).otherwise(trim(col("Claim_ID"))),
							 when(length(trim(col("Claim_Number"))) == 0,None).otherwise(trim(col("Claim_Number"))),
							 when(length(trim(col("Loss_Date"))) == 0,None).otherwise(trim(col("Loss_Date"))),
                             trim(col("Product")),
							 trim(col("Derived_Contact_Role")),
							 when(length(trim(col("DOB"))) == 0,None).otherwise(trim(col("DOB"))),
                             when(length(trim(col("License_Number"))) == 0,None).otherwise(trim(col("License_Number"))),
							 when(length(trim(col("ID_Value"))) == 0,None).otherwise(trim(col("ID_Value"))),
                             when((length(trim(col('New_Phone'))) == 7),
                               concat_ws("",lit('000'),lit('-'),substring(col('New_Phone'),1,3),lit('-'),substring(col('New_Phone'),4,4))).otherwise(when((length(trim(col('New_Phone'))) == 8),
                               concat_ws("",lit('00'),substring(col('New_Phone'),1,1),lit('-'),substring(col('New_Phone'),2,3),lit('-'),substring(col('New_Phone'),5,4))).otherwise(when((length(trim(col('New_Phone'))) == 9),
                               concat_ws("",lit('0'),substring(col('New_Phone'),1,2),lit('-'),substring(col('New_Phone'),3,3),lit('-'),substring(col('New_Phone'),6,4))).otherwise(when((length(trim(col('New_Phone'))) == 10),
                               concat_ws("",substring(col('New_Phone'),1,3),lit('-'),substring(col('New_Phone'),4,3),lit('-'),substring(col('New_Phone'),7,4))).otherwise(when((length(trim(col('New_Phone'))) == 11),
                               concat_ws("",substring(col('New_Phone'),2,3),lit('-'),substring(col('New_Phone'),5,3),lit('-'),substring(col('New_Phone'),8,4))).otherwise(None))))),
							 when(length(trim(col("Email"))) == 0,None).otherwise(trim(col("Email"))),
							 "Address",
							 trim(col("Zip_Code"))).toDF("Customer_Name",
                                              "Contact_ID",
                                              "Account_Number",
                                              "Policy_Number",
                                              "Claim_ID",
                                              "Claim_Number",
                                              "Loss_Date",
                                              "Product",
                                              "Contact_Role",
                                              "DOB",
                                              "License_Number",
                                              "ID_Value",
                                              "Phone",
                                              "Email",
                                              "Address",
                                              "Zip_Code")	
    
    # Create a unique identifier (Group By column) for the Customer by concatenating Name + DOB + Zip
    print("[INFO] Creating the Key Column with Name,DOB and Zip....")
    lgcy_fname = lgcyDFF.withColumn("Customer_Key", concat_ws(" ",col("Customer_Name"),col("DOB"),col("Zip_Code")))
    chk_lgcy_fname = lgcy_fname.count()
    if chk_lgcy_fname == 0:
       print("[INFO] There is NO New Contacts to Group and Write Step-I Output....")
    else:   
       # Group customer data by above created Group By column
       print("[INFO] Group by on Key Column and Creating a Collection of Customer Details....")
       lgcy_group = lgcy_fname.groupBy("Customer_Key","Customer_Name").agg(collect_set("Contact_ID").alias("Contact_ID"),
                                                                           collect_set("Account_Number").alias("Account_Number"),
                                                                           collect_set("Policy_Number").alias("Policy_Number"),
                                                                           collect_set("Claim_ID").alias("Claim_ID"),
                                                                           collect_set("Claim_Number").alias("Claim_Number"),
                                                                           collect_set("Loss_Date").alias("Loss_Date"),
                                                                           collect_set("Product").alias("Product"),
                                                                           collect_set("Contact_Role").alias("Contact_Role"),
                                                                           collect_set("DOB").alias("DOB"),
                                                                           collect_set("License_Number").alias("License_Number"), 
                                                                           collect_set("ID_Value").alias("ID_Value"),
                                                                           collect_set("Phone").alias("Phone"), 
                                                                           collect_set("Email").alias("Email"),
                                                                           collect_set("Address").alias("Address"),
                                                                           collect_set("Zip_Code").alias("Zip_Code")).orderBy("Customer_Name")
       
       print("[INFO] Group on Key, Account, Policy, Claim to Create Account Policy Claim field....")
       lgcyapc = lgcy_fname.select("Customer_Key","Customer_Name","Account_Number","Policy_Number","Claim_Number")
       lgcyapc.createOrReplaceTempView("mdm_lgcy_custapc")
       lgcyapc1 = spark.sql("select Customer_Key,Customer_Name,case when Account_Number is null then 'NA' else Account_Number end as Account_Number,case when Policy_Number is null then 'NA' else Policy_Number end as Policy_Number,collect_set(Claim_Number) as Claim_Numbers from mdm_lgcy_custapc group by Customer_Key,Customer_Name,Account_Number,Policy_Number")
       lgcyapc1.createOrReplaceTempView("mdm_lgcy_custapc1")	
       lgcyapc2 = spark.sql("select Customer_Key,Customer_Name,Account_Number,collect_set(struct(Policy_Number,Claim_Numbers)) as Policy_Claims from mdm_lgcy_custapc1 group by Customer_Key,Customer_Name,Account_Number")
       lgcyapc2.createOrReplaceTempView("mdm_lgcy_custapc2")
       lgcyapc3 = spark.sql("select Customer_Key as Customer_Key1,Customer_Name as Customer_Name1,collect_set(struct(Account_Number,Policy_Claims)) as Account_Policy_Claim from mdm_lgcy_custapc2 group by Customer_Key,Customer_Name")
       lgcyapc3.createOrReplaceTempView("mdm_lgcy_custapc3")
       lgcy_apc = spark.sql("select Customer_Key1,Customer_Name1,Account_Policy_Claim from mdm_lgcy_custapc3")
   
       print("[INFO] Joining the Customer Grouping with Acc_Pol_Clm Grouping....")
       lgcy_final = lgcy_group.join(lgcy_apc,(lgcy_group.Customer_Key == lgcy_apc.Customer_Key1) &
                                             (lgcy_group.Customer_Name == lgcy_apc.Customer_Name1)).drop(lgcy_apc.Customer_Key1).drop(lgcy_apc.Customer_Name1)                                                  	
   	
       print("[INFO] Writing LGCY Grouped Data to S3 for Next Step ML Lib Process....")
       # Write grouped customer data to S3
       lgcy_final.write.parquet(LGCY_Grouped_Data_Location)
       print("[INFO] Writing LGCY Acc_Pol_Clm Data to S3 for Next Day Accumulation Process....")
       lgcyapc_final = lgcyapc.dropDuplicates()
       lgcyapc_final.write.parquet(LGCY_APC_Data_Location)
	   
       #Insert the Max Update time for each of the source in transform mdm stats for incremental read in the Next Run 	
       print("[INFO] Inserting the Max yyyymm in Stats for next run....")
       sdata = [(run_name,ingestn_dttm,curr_yyyymm)]
       stat_df = spark.createDataFrame(sdata,["RUN_NAME","INGESTION_DTTM","TRAN_YYYYMM"])	
       stat_list = stat_df.toJSON().collect()
       stat_ld = [json.loads(sts) for sts in stat_list]
       mstatcoll.insert_many(stat_ld)
       
       print("[INFO] Step I - Completed writing of LGCY Grouped Data to S3....")
    spark.stop()