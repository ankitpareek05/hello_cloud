# Import all required libraries
from pyspark import SparkContext, SparkConf
from pyspark.sql import SparkSession, HiveContext, Row, Column
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.dataframe import *
from pyspark.sql.column import *
from pyspark.sql.window import *
from pyspark.ml import Pipeline, Model, PipelineModel
from pyspark.ml.feature import RegexTokenizer, Tokenizer, NGram, HashingTF, MinHashLSH
import datetime as dt
import pymongo, pandas, json, os, sys, string, uuid

# Main Module

if __name__ == "__main__":
   
    print("[INFO] Receiving Arguments from Script....")
    if len(sys.argv) != 4:
       print("Error usage: GWCC_GWPC_Cont2.py - Refer Script for number of parameters to be passed")
       sys.exit(-1)

    cc_pc_grp_data_loc = sys.argv[1]
    match_data_loc = sys.argv[2]
    golden_data_loc = sys.argv[3]
		
    # Setup required Batch variables
    print("[INFO] Setting up Batch variables....")
    Batch_Start_Time = dt.datetime.now()
    date_ext = Batch_Start_Time.strftime("%Y-%m-%d")

    print("[INFO] Spark Session Setup....")   
    spark = SparkSession.builder.appName("GWCC_GWPC_Cont2").enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    
    # Location to read combined Claims and Policy data
    CC_PC_Grouped_Data_Location = cc_pc_grp_data_loc+date_ext
    # Location to store/read potential fuzzy matches
    Match_Data_Location = match_data_loc+date_ext
    # Location to store final golden records
    Golden_Data_Location = golden_data_loc+date_ext
    
    # Read the data set from S3
    print("[INFO] Reading CC and PC Grouped Data from S3 for ML Lib Process for Fuzzy Match....")
    ccpc_group_fname = spark.read.parquet(CC_PC_Grouped_Data_Location)
    
    # Fuzzy Name match logic. This matches the names in the data set by grouping them into data sets starting with the same alphabet and digit. 
    # All fuzzy matches with a Levenshtein distance less than 1.0 will be considered for identity matching.
    print("[INFO] ML Pipeline Part that is Creating the Golden Record collection....")
    for x in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789':
        ccpc_names = ccpc_group_fname.filter(col("Customer_Key").like(x+'%')).select('Customer_Key',                                                                                          
                                                                                     'Customer_Name',
                                                                                     'Contact_ID',
                                                                                     'Account_Number',
                                                                                     'Policy_Number',
                                                                                     'Claim_ID',
                                                                                     'Claim_Number',
                                                                                     'Loss_Date',
                                                                                     'Product',
                                                                                     'Contact_Role',
                                                                                     'DOB',
                                                                                     'License_Number',
                                                                                     'ID_Value',
                                                                                     'Phone',
                                                                                     'Email',
                                                                                     'Address',
                                                                                     'Zip_Code',
																				     'Account_Policy_Claim')
        
        ccpc_names_min = ccpc_names.dropDuplicates()

        #Check if there is records filtered for the Alphabet (or) Number
		#If Not there, Skip the Pipeline fit Iteration for that Alphabet (or) Number
        chk_alpha_num = ccpc_names_min.count()
        if chk_alpha_num == 0:
           print("[INFO] Skipping pipeline As there is no records starts with Alpha/Number: {0}".format(x))
           continue
        
        # ML Pipeline that converts Customer_Name to Hash value and calculates the distance between them     
        pipeline = Pipeline(stages=[Tokenizer(inputCol="Customer_Key",outputCol="Tokens"),
                                    NGram(n=1,inputCol="Tokens",outputCol="ngrams"),
                                    HashingTF(inputCol="ngrams",outputCol="vectors"),
                                    MinHashLSH(inputCol="vectors",outputCol="lsh")
                                   ])
        model = pipeline.fit(ccpc_names_min)
        
        stored_hashed = model.transform(ccpc_names_min)
        landed_hashed = model.transform(ccpc_names_min)
        
        # Filtering strings that have a defined distance  
        # datasetA = stored_hashed; datasetB = landed_hashed
        
        
        # NOTE: "Distance" value in prod should be set to 1.0. Here for L3 it is set to 0.3
        ccpc_names_matches = model.stages[-1].approxSimilarityJoin(stored_hashed,landed_hashed,1.0,"Distance").select(col("datasetA.Customer_Key"),
                                                                                                                  col("datasetB.Customer_Key").alias("A_Customer_Key"),
                                                                                                                  col("datasetA.Customer_Name"), 
                                                                                                                  col("datasetB.Customer_Name").alias("Alias_Name"),
                                                                                                                  col("datasetA.Contact_ID"),
                                                                                                                  col("datasetB.Contact_ID").alias("A_Contact_ID"),
                                                                                                                  col("datasetA.Account_Number"),
                                                                                                                  col("datasetB.Account_Number").alias("A_Account_Number"),
                                                                                                                  col("datasetA.Policy_Number"),
                                                                                                                  col("datasetB.Policy_Number").alias("A_Policy_Number"),
                                                                                                                  col("datasetA.Claim_ID"),
                                                                                                                  col("datasetB.Claim_ID").alias("A_Claim_ID"),
                                                                                                                  col("datasetA.Claim_Number"),
                                                                                                                  col("datasetB.Claim_Number").alias("A_Claim_Number"),
                                                                                                                  col("datasetA.Loss_Date"),
                                                                                                                  col("datasetB.Loss_Date").alias("A_Loss_Date"),
                                                                                                                  col("datasetA.Product"),
                                                                                                                  col("datasetB.Product").alias("A_Product"),
                                                                                                                  col("datasetA.Contact_Role"),
                                                                                                                  col("datasetB.Contact_Role").alias("A_Contact_Role"),
                                                                                                                  col("datasetA.ID_Value"),
                                                                                                                  col("datasetB.ID_Value").alias("A_ID_Value"),
                                                                                                                  col("datasetA.DOB"),
                                                                                                                  col("datasetB.DOB").alias("A_DOB"),
                                                                                                                  col("datasetA.License_Number"),
                                                                                                                  col("datasetB.License_Number").alias("A_License_Number"),
                                                                                                                  col("datasetA.Phone"),
                                                                                                                  col("datasetB.Phone").alias("A_Phone"),
                                                                                                                  col("datasetA.Email"),
                                                                                                                  col("datasetB.Email").alias("A_Email"),
                                                                                                                  col("datasetA.Address"),
                                                                                                                  col("datasetB.Address").alias("A_Address"),
                                                                                                                  col("datasetA.Zip_Code"),
                                                                                                                  col("datasetB.Zip_Code").alias("A_Zip_Code"),
																												  col("datasetA.Account_Policy_Claim"),
																												  col("datasetB.Account_Policy_Claim").alias("A_Account_Policy_Claim"),
                                                                                                                  col("Distance"))
        
        # Filter out same name matches
        ccpc_names_verify = ccpc_names_matches.filter(col("Distance") > 0.0)
        
        
        # Assign match indicator (1 - True; 0 - False)
        ccpc_names_match_value = ccpc_names_verify.withColumn("ID_Value_M", 
                                                         when((size(col("ID_Value")) < 1) | (size(col("A_ID_Value")) < 1), 
                                                         "Unknown").otherwise(when(size(array_intersect(col('ID_Value'),col('A_ID_Value'))) < 1, 
                                                                             "0").otherwise("1")))
        ccpc_names_match_value = ccpc_names_match_value.withColumn("DOB_M", 
                                                         when((size(col("DOB")) < 1) | (size(col("A_DOB")) < 1), 
                                                         "Unknown").otherwise(when(size(array_intersect(col('DOB'),col('A_DOB'))) < 1, 
                                                                             "0").otherwise("1")))
        ccpc_names_match_value = ccpc_names_match_value.withColumn("License_Number_M", 
                                                         when((size(col("License_Number")) < 1) | (size(col("A_License_Number")) < 1), 
                                                         "Unknown").otherwise(when(size(array_intersect(col('License_Number'),col('A_License_Number'))) < 1, 
                                                                             "0").otherwise("1")))
        ccpc_names_match_value = ccpc_names_match_value.withColumn("Phone_M", 
                                                         when((size(col("Phone")) < 1) | (size(col("A_Phone")) < 1), 
                                                         "Unknown").otherwise(when(size(array_intersect(col('Phone'),col('A_Phone'))) < 1, 
                                                                             "0").otherwise("1")))
        ccpc_names_match_value = ccpc_names_match_value.withColumn("Email_M", 
                                                         when((size(col("Email")) < 1) | (size(col("A_Email")) < 1), 
                                                         "Unknown").otherwise(when(size(array_intersect(col('Email'),col('A_Email'))) < 1, 
                                                                             "0").otherwise("1")))
        ccpc_names_match_value = ccpc_names_match_value.withColumn("Zip_Code_M", 
                                                         when((size(col("Zip_Code")) < 1) | (size(col("A_Zip_Code")) < 1), 
                                                         "Unknown").otherwise(when(size(array_intersect(col('Zip_Code'),col('A_Zip_Code'))) < 1, 
                                                                             "0").otherwise("1")))
        ccpc_names_matches = ccpc_names_match_value.withColumn("Match",
                                                when(col("ID_Value_M") == 1,"1").otherwise(
													when(col("DOB_M") == 1,when((col("Zip_Code_M") == 1) | (col("Email_M") == 1), "1").otherwise("0")).otherwise(
												         when((col("ID_Value_M") == 0) & (col("DOB_M") == 0), 
														     when((col("Phone_M") == 1) | (col("Email_M") == 1), "1").otherwise("0"))
                                                        .otherwise("0"))))
        
        # Filter the customer_names that match
        ccpc_names_match_1 = ccpc_names_matches.filter(col("Match") == "1") 
        
        # Save the data to S3 (Data Lake) partitioned by data sets starting with a given alphabet or digit
        mpath = Match_Data_Location+'/alpha='+x
        ccpc_names_match_1.coalesce(1).write.parquet(mpath)
    
    print("[INFO] Reading Match Data for all Alpha and CC_PC Grouped Data....")
    ccpc_mynames = spark.read.parquet(Match_Data_Location)
    ccpc_group_fname_r = spark.read.parquet(CC_PC_Grouped_Data_Location)
    
    print("[INFO] Fuzzy Final to merge and remove, and create Golden record for Target....")	
    ccpc_stg1 = ccpc_mynames.withColumn("Customer_Final", 
                                    when(size(col("Contact_ID")) < size(col("A_Contact_ID")), 
                                    col("A_Customer_Key")).otherwise(col("Customer_Key")))
    
    ccpc_stg1 = ccpc_stg1.withColumn("Customer_Remove", 
                                    when(size(col("Contact_ID")) < size(col("A_Contact_ID")), 
                                    col("Customer_Key")).otherwise(col("A_Customer_Key")))
                                    
    ccpc_stg1 = ccpc_stg1.withColumn("Customer_Name_Final",
                                 when(size(col("Contact_ID")) < size(col("A_Contact_ID")), 
                                    col("Alias_Name")).otherwise(col("Customer_Name")))
    
    ccpc_remove = ccpc_stg1.select("Customer_Remove").distinct()
    
    ccpc_array_merge = ccpc_stg1.select("Customer_Final",
                                    "Distance",
                                    "Customer_Name_Final",
                                    array_sort(array(ccpc_stg1.Customer_Name,ccpc_stg1.Alias_Name)),
                                    flatten(array_sort(array(ccpc_stg1.Contact_ID,ccpc_stg1.Contact_ID))),
                                    array_union(ccpc_stg1.Account_Number,ccpc_stg1.A_Account_Number),
                                    array_union(ccpc_stg1.Policy_Number,ccpc_stg1.Policy_Number),
                                    array_union(ccpc_stg1.Claim_ID,ccpc_stg1.A_Claim_ID),
                                    array_union(ccpc_stg1.Claim_Number,ccpc_stg1.A_Claim_Number),
                                    array_union(ccpc_stg1.Loss_Date,ccpc_stg1.A_Loss_Date),
                                    array_union(ccpc_stg1.Product,ccpc_stg1.A_Product),
                                    array_union(ccpc_stg1.Contact_Role,ccpc_stg1.A_Contact_Role),
                                    array_union(ccpc_stg1.ID_Value,ccpc_stg1.A_ID_Value),
                                    array_union(ccpc_stg1.DOB,ccpc_stg1.A_DOB),
                                    array_union(ccpc_stg1.License_Number,ccpc_stg1.A_License_Number),
                                    array_union(ccpc_stg1.Phone,ccpc_stg1.A_Phone),
                                    array_union(ccpc_stg1.Email,ccpc_stg1.A_Email),
                                    array_union(ccpc_stg1.Address,ccpc_stg1.A_Address),
                                    array_union(ccpc_stg1.Zip_Code,ccpc_stg1.A_Zip_Code),
									array_union(ccpc_stg1.Account_Policy_Claim,ccpc_stg1.A_Account_Policy_Claim)).toDF("Customer_Key",
                                                                                                                       "Distance",
                                                                                                                       "Customer_Name",
                                                                                                                       "Alias_Name",
                                                                                                                       "Contact_ID",
                                                                                                                       "Account_Number",
                                                                                                                       "Policy_Number",
                                                                                                                       "Claim_ID",
                                                                                                                       "Claim_Number",
                                                                                                                       "Loss_Date",
                                                                                                                       "Product",
                                                                                                                       "Contact_Role",
                                                                                                                       "ID",
                                                                                                                       "DOB",
                                                                                                                       "License_Number",
                                                                                                                       "Phone",
                                                                                                                       "Email",
                                                                                                                       "Address",
                                                                                                                       "Zip_Code",
																													   "Account_Policy_Claim")  
       
    ccpc_fuzzy_final = ccpc_array_merge.groupBy("Customer_Key","Customer_Name").agg(array_distinct(flatten(collect_set("Alias_Name"))).alias("Alias_Name"),
                                                                            array_distinct(flatten(collect_set("Contact_ID"))).alias("Contact_ID"),
                                                                            array_distinct(flatten(collect_set("Account_Number"))).alias("Account_Number"),
                                                                            array_distinct(flatten(collect_set("Policy_Number"))).alias("Policy_Number"),
                                                                            array_distinct(flatten(collect_set("Claim_ID"))).alias("Claim_ID"),
                                                                            array_distinct(flatten(collect_set("Claim_Number"))).alias("Claim_Number"),
                                                                            array_distinct(flatten(collect_set("Loss_Date"))).alias("Loss_Date"),
                                                                            array_distinct(flatten(collect_set("Product"))).alias("Product"),
                                                                            array_distinct(flatten(collect_set("Contact_Role"))).alias("Contact_Role"),
                                                                            array_distinct(flatten(collect_set("DOB"))).alias("DOB"),
                                                                            array_distinct(flatten(collect_set("License_Number"))).alias("License_Number"),
                                                                            array_distinct(flatten(collect_set("ID"))).alias("ID_Value"),
                                                                            array_distinct(flatten(collect_set("Phone"))).alias("Phone"),
                                                                            array_distinct(flatten(collect_set("Email"))).alias("Email"),
                                                                            array_distinct(flatten(collect_set("Address"))).alias("Address"),
                                                                            array_distinct(flatten(collect_set("Zip_Code"))).alias("Zip_Code"),
																			array_distinct(flatten(collect_set("Account_Policy_Claim"))).alias("Account_Policy_Claim")) 
    
    ccpc_retain = ccpc_fuzzy_final.select("Customer_Key")
    
    ccpc_stg1 = ccpc_group_fname_r.join(ccpc_remove, 
                                        ccpc_group_fname_r.Customer_Key == ccpc_remove.Customer_Remove).drop(ccpc_remove.Customer_Remove)
    
    ccpc_stg2 = ccpc_group_fname_r.join(ccpc_retain, 
                                        ccpc_group_fname_r.Customer_Key == ccpc_retain.Customer_Key).drop(ccpc_retain.Customer_Key)
    
    ccpc_post_remove = ccpc_group_fname_r.subtract(ccpc_stg1)
    ccpc_post_retain = ccpc_post_remove.subtract(ccpc_stg2)
    
    ccpc_post_final = ccpc_post_retain.withColumn("Alias_Name", array(col("Customer_Name"))).select("Customer_Key",
                                                                                                    "Customer_Name",
                                                                                                    "Alias_Name",
                                                                                                    "Contact_ID",
                                                                                                    "Account_Number",
                                                                                                    "Policy_Number",
                                                                                                    "Claim_ID",
                                                                                                    "Claim_Number",
                                                                                                    "Loss_Date",
                                                                                                    "Product",
                                                                                                    "Contact_Role",
                                                                                                    "DOB",
                                                                                                    "License_Number",
                                                                                                    "ID_Value",
                                                                                                    "Phone",
                                                                                                    "Email",
                                                                                                    "Address",
                                                                                                    "Zip_Code",
																									"Account_Policy_Claim")
    
    ccpc_customer = ccpc_post_final.union(ccpc_fuzzy_final)
       
    print("[INFO] Writing Golden Record copy to S3 before Target Loading....")
    #Write the final golden output to S3
    ccpc_customer.coalesce(40).write.parquet(Golden_Data_Location)

    print("[INFO] Step II - Completed ML Lib Process creating Golden Record....")
    spark.stop()