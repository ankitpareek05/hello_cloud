#!/bin/bash
###############################################################################
#                          Common Functions                                   #
###############################################################################
function info() {
        if [ -z ${LOGFILE} ]; then
                echo -e "[INFO] $1"
        else
                echo -e "[INFO] $1"   >> ${LOGFILE}
        fi
}


function error() {
    echo -e "[ERROR] $1"
}


function warn() {
    echo -e "[WARN] $1"
}

function import_dependencies(){
    echo "Importing Dependencies"
    SCRIPT_PATH="$1"
    echo "Script Path is .. ${SCRIPT_PATH}"
    SCRIPT_HOME=`dirname $SCRIPT_PATH`

    # Set module, project, subject area home paths.
    PROJECT_HOME=`dirname ${MODULE_HOME}`
  

    # Load all environment properties files. Order Should not be changed.
    . ${PROJECT_HOME}/spec_files/project.env.properties
    . ${PROJECT_HOME}/spec_files/project.hive.properties
    . ${PROJECT_HOME}/spec_files/module.env.properties

}

# Check if file exist
function checkFileExist() {
    FILE_PATH=$1
    if [ -e $FILE_PATH ]
    then
        return 0
    else
        return 1
    fi
}

function readParameters() {
    info "Parsing args ..."
    for item in "$@"; do
        case $item in
        (*=*) eval $item;;
        esac
    done
    info "Done parsing args ..!!!"
}

function fn_execute_hive()
{
        info hive "$@"
        export HIVE_OUTPUT=`hive "$@" 2>>${LOGFILE}`
        info "hive_output:$HIVE_OUTPUT"
}

function fn_insert_stats_curation()
{
        TARGET_TABLE=$1
        LAYER_NAME=$2

        ##Start_time="`date +"%Y-%m-%d %H:%M:%S"`"

        query_s=`hive -S -e "INSERT INTO ${V_TRNS_DB}.CURATION_STATS
         select reflect('java.util.UUID', 'randomUUID'),'${LAYER_NAME}','${TARGET_TABLE}','${Start_time}',null,null,'RUNNING',null,null,null,'(LogFile: $LOGFILE)',null,null;"`

        fn_check_status_and_exit_Curation "${TARGET_TABLE}" "${LAYER_NAME}" "$?" "Failed adding a new entry with status running for ${LAYER_NAME} and  ${TARGET_TABLE}"
}


function fn_check_Success_status_and_exit_Curation()
{
        TARGET_TABLE=$1
        LAYER_NAME=$2
        Record_count=$3
        max_delta_value="$4"
        driver_table_name=$5
        delta_column=$6
        v_delta_column_value="$7"
        info "Start updating the running status to Successful"

        End_time="`date +"%Y-%m-%d %H:%M:%S"`"
        Time_taken=`TZ=UTC0 printf '%(%H:%M:%S)T\n' "$SECONDS"`

        info "Current instance is in running state for ${TARGET_TABLE}"
        fn_success_batch_curation $TARGET_TABLE $LAYER_NAME $Record_count "${max_delta_value}" ${driver_table_name} ${delta_column} "$v_delta_column_value"
		second_stats=$?
		if [ "${second_stats}" != 0 ]
                then
			info "Second Attempt to update SUCCESS stats ${TARGET_TABLE} table failed. Exiting"
			exit 1
		fi

}


function fn_check_status_and_exit_Curation()
{
        TARGET_TABLE=$1
        LAYER_NAME=$2
        EXIT_STATUS=$3
        ERROR_MSG=$4


if [ "${EXIT_STATUS}" != 0 ]
then
info "Current instance is in running state for ${TARGET_TABLE}"
fn_fail_batch_curation "${TARGET_TABLE}" "${LAYER_NAME}"
frst_atmpt=$?
info "First attempt status: $?"
        if [ $frst_atmpt -ne 0 ]
        then
        info "First Attempt to update Failed status in Curation_stats Failed for ${TARGET_TABLE}"
        fn_fail_batch_curation_retry "${TARGET_TABLE}" "${LAYER_NAME}"
                   if [ $? -ne 0 ]
                   then
                                        info "Failed to Enter Failed Message into Curation_stats Table"
                                        exit 1
                   fi
        fi

        info "Copying Log file from ${LOGFILE} to ${v_log_file_copy_bucket_path}/"
        info "Running aws s3 cp ${LOGFILE} ${v_log_file_copy_bucket_path}/"
        aws s3 cp ${LOGFILE} ${v_log_file_copy_bucket_path}/
        if [ $? -ne 0 ]
        then
                info "Failed to copying log file from ${LOGFILE} to ${v_log_file_copy_bucket_path}/"
        else
                info "Log file Successfully copied from ${LOGFILE} to ${v_log_file_copy_bucket_path}/"
        fi

exit $EXIT_STATUS
fi
}

function fn_success_batch_curation()
{
        TARGET_TABLE=$1
        LAYER_NAME=$2
        Record_count=$3
        max_delta_value="$4"
        driver_table_name=$5
        delta_column=$6
        v_delta_column_value="$7"
        info "Start updating the running status to Successful a"

        End_time="`date +"%Y-%m-%d %H:%M:%S"`"
        Time_taken=`TZ=UTC0 printf '%(%H:%M:%S)T\n' "$SECONDS"`

                info "Start marking the current running instance as SUCCESS into Stats table"

                ##`hive -S -e "UPDATE CURATION_STATS SET STATUS ='FAILED' WHERE layer_name='${LAYER_NAME}' and TABLE_NAME='${TARGET_TABLE}' and status='RUNNING'"`
        ##`hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS(layer_name,table_name,start_time,end_time,time_taken,status,source_driver_table,delta_column,delta_value,description,record_count,remarks) VALUES('${LAYER_NAME}','${TARGET_TABLE}','${Start_time}',null,null,'FAILED',null,null,null,'(LogFile: $LOGFILE)',null,null)"`
      hive_query=`hive -S -e "INSERT into TABLE ${V_TRNS_DB}.CURATION_STATS
           select reflect('java.util.UUID', 'randomUUID'),'${LAYER_NAME}','${TARGET_TABLE}','${Start_time}','${End_time}','${Time_taken}','SUCCESSFUL','${driver_table_name}','${delta_column}',trim('$max_delta_value'),'(LogFile: $LOGFILE)','${Record_count}',null;"`
           hive_stats=$?
    #  `hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS select * from ${V_TRNS_DB}.CURATION_STATS;"`
	   if [ "${hive_stats}" == 0 ]
	   then
                info "Marking of status from running to SUCCESS in to Stats table successfully done"
	   fi
return $hive_stats
}


function fn_fail_batch_curation()
{
                TARGET_TABLE=$1
                LAYER_NAME=$2


                info "Start marking the current running instance as failed into Stats table"

                ##`hive -S -e "UPDATE CURATION_STATS SET STATUS ='FAILED' WHERE layer_name='${LAYER_NAME}' and TABLE_NAME='${TARGET_TABLE}' and status='RUNNING'"`
        ##`hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS(layer_name,table_name,start_time,end_time,time_taken,status,source_driver_table,delta_column,delta_value,description,record_count,remarks) VALUES('${LAYER_NAME}','${TARGET_TABLE}','${Start_time}',null,null,'FAILED',null,null,null,'(LogFile: $LOGFILE)',null,null)"`
      hive_qry=`hive -S -e "INSERT into TABLE ${V_TRNS_DB}.CURATION_STATS
           select reflect('java.util.UUID', 'randomUUID'),'${LAYER_NAME}','${TARGET_TABLE}','${Start_time}',null,null,'FAILED',null,null,null,'(LogFile: $LOGFILE)',null,null;"`
      insert_stat=$?
    #  `hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS select * from ${V_TRNS_DB}.CURATION_STATS;"`
	   if [ "${insert_stat}" != 0 ]
	   then
                info "hive curation_stats: $insert_stat"
                info "Marking of status  to failed in to Stats table successfully done"
	   fi
return $insert_stat
}


function fn_fail_batch_curation_retry()
{
                TARGET_TABLE=$1
                LAYER_NAME=$2


                info "Start marking the current running instance as failed into Stats table"

                ##`hive -S -e "UPDATE CURATION_STATS SET STATUS ='FAILED' WHERE layer_name='${LAYER_NAME}' and TABLE_NAME='${TARGET_TABLE}' and status='RUNNING'"`
        ##`hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS(layer_name,table_name,start_time,end_time,time_taken,status,source_driver_table,delta_column,delta_value,description,record_count,remarks) VALUES('${LAYER_NAME}','${TARGET_TABLE}','${Start_time}',null,null,'FAILED',null,null,null,'(LogFile: $LOGFILE)',null,null)"`
       hive_qry=`hive -S -e "INSERT into TABLE ${V_TRNS_DB}.CURATION_STATS
           select reflect('java.util.UUID', 'randomUUID'),'${LAYER_NAME}','${TARGET_TABLE}','${Start_time}',null,null,'FAILED',null,null,null,'(LogFile: $LOGFILE)',null,null;"`
       exit_status=$?
    #  `hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS select * from ${V_TRNS_DB}.CURATION_STATS;"`
        
                        if [ "${exit_status}" != 0 ]
                        then
                          info "Hive query failed for checking status on ${TARGET_TABLE}"
                          info "Exit with $exit_status"
                        fi
return $exit_status						
}


function fn_update_current_status_curation()
{
        TARGET_TABLE=$1
        LAYER_NAME=$2
        Record_count=$3
        max_delta_value="$4"
        driver_table_name=$5
        delta_column=$6
        v_delta_column_value="$7"
        info "Start updating the running status to Successful b"

        info "Target Table:"$TARGET_TABLE
        info "Layer Name:"$LAYER_NAME
        info "Record count:"$Record_count
        info "Max Delta Value:"$max_delta_value
        End_time="`date +"%Y-%m-%d %H:%M:%S"`"
        Time_taken=`TZ=UTC0 printf '%(%H:%M:%S)T\n' "$SECONDS"`

        info "End_time:"$End_time
        info "INSERT into TABLE ${V_TRNS_DB}.CURATION_STATS select reflect('java.util.UUID', 'randomUUID'),'${LAYER_NAME}','${TARGET_TABLE}','${Start_time}','${End_time}','${Time_taken}','SUCCESSFUL','${driver_table_name}','${delta_column}',trim('$max_delta_value'),'(LogFile: $LOGFILE)','${Record_count}',null;"
       ## Update_current_status=`hive -S -e " UPDATE CURATION_STATS set layer_name='$LAYER_NAME',TABLE_NAME='$TARGET_TABLE',end_time='$End_time',time_taken='$Time_taken',status='SUCCESSFUL',record_count=$Record_count,source_driver_table='${driver_table_name}',delta_column='${delta_column}',delta_value=trim('$max_delta_value'),description='Previous delta value:$v_delta_column_value (LogFile: $LOGFILE)' where Status='RUNNING' and LAYER_NAME='$LAYER_NAME' and TABLE_NAME='${TARGET_TABLE
        hive_qry=`hive -S -e "INSERT into TABLE ${V_TRNS_DB}.CURATION_STATS
           select reflect('java.util.UUID', 'randomUUID'),'${LAYER_NAME}','${TARGET_TABLE}','${Start_time}','${End_time}','${Time_taken}','SUCCESSFUL','${driver_table_name}','${delta_column}',trim('$max_delta_value'),'(LogFile: $LOGFILE)','${Record_count}',null;"`
           hive_stats=$?
		   info "Curation_stats Insert Status: $hive_stats " 
		   if [ "${hive_stats}" != 0 ]
		   then
                fn_check_Success_status_and_exit_Curation $TARGET_TABLE $LAYER_NAME $Record_count "${max_delta_value}" ${driver_table_name} ${delta_column} "$v_delta_column_value"
           fi
#`hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS select * from ${V_TRNS_DB}.CURATION_STATS;"`

}

function fn_check_status_curation()
{
         TARGET_TABLE=$1
         LAYER_NAME=$2

        #query_string=`hive -S -e "SELECT COUNT(1) FROM ${V_TRNS_DB}.CURATION_STATS where layer_name='$LAYER_NAME' and table_name='$TARGET_TABLE' and status='RUNNING'"`
        query_string=`hive -e "SELECT COUNT(1) FROM ${V_TRNS_DB}.CURATION_STATS where layer_name='$LAYER_NAME' and table_name='$TARGET_TABLE' and status='RUNNING'"`
        exit_status=$?
    if [ "${exit_status}" != 0 ]
    then
      info "Hive query failed for checking status on ${TARGET_TABLE}"
      info "Exit with $exit_status"
      exit_status=1
    exit $exit_status
    fi
        count=${query_string}
  info "Displaying count: ${count}"
        if [ "${count}" != 0 ]
        then
          exit_status=1
          info "Exiting as the instance is already in running state for table :${TARGET_TABLE}"
          info "Exit with $exit_status"
          exit $exit_status
        fi
}

function fn_check_success_entry_curation()
{
         TARGET_TABLE=$1
         LAYER_NAME=$2

        query_string=`hive -S -e "SELECT COUNT(1) FROM ${V_TRNS_DB}.CURATION_STATS where layer_name='$LAYER_NAME' and table_name='$TARGET_TABLE' and status='SUCCESSFUL'"`
        count=${query_string}

        echo $count
        fn_check_status_and_exit_Curation "${TARGET_TABLE}" "${LAYER_NAME}" "$?" " Failed to check the successful entry for ${LAYER_NAME} ${TARGET_TABLE} in stats table"

}

function fn_run_hive_curation()
{
                V_TARGET_DATABASE=$1
                V_TARGET_TABLE=$2
                V_DELTA_COLUMN=$3
                V_DELTA_VALUE="$4"
                V_HIVE_SCRIPT=$5
                LAYER_NAME=$6
                TABLE_NAME_WITH_FEEDER=$7
                V_FEED_COL=$8
                FEED_SYS_NAME=$9

        info "Executing command:  hive --hiveconf:TARGET_DATABASE=$V_TARGET_DATABASE --hiveconf:TARGET_TABLE=$V_TARGET_TABLE --hiveconf:DELTA_COLUMN=$V_DELTA_COLUMN --hiveconf:DELTA_VALUE=$V_DELTA_VALUE --hiveconf:$V_FEED_COL=$FEED_SYS_NAME -f $V_HIVE_SCRIPT"

        fn_execute_hive --hiveconf TARGET_DATABASE="$V_TARGET_DATABASE" \
        --hiveconf TARGET_TABLE="$V_TARGET_TABLE" \
        --hiveconf DELTA_COLUMN="$V_DELTA_COLUMN" \
        --hiveconf DELTA_VALUE="$V_DELTA_VALUE" \
        --hiveconf V_FEED_COL="$V_FEED_COL" \
        --hiveconf FEED_SYS_NAME="$FEED_SYS_NAME" \
                -f $V_HIVE_SCRIPT
        fn_check_status_and_exit_Curation "${TABLE_NAME_WITH_FEEDER}" "${LAYER_NAME}" "$?" "Failed to run hive : ${LAYER_NAME} ${TABLE_NAME_WITH_FEEDER}"
}


###############################################################################
#                          Common Functions                                   #
###############################################################################
