
#Funtion to get the parameter file name ie: uat/dev/prod.
function getNamespaceFileForCurrentUser () {

	local HOST_NAME=`hostname -s`;
	if [ $HOST_NAME == "$DEV_ENV" ]; then
	    echo "namespace.dev.properties";
	elif [ $HOST_NAME == "$PROD_ENV" ]; then
	    echo "namespace.prod.properties";
	elif [ $HOST_NAME == "$UAT_ENV" ]; then
	    echo "namespace.uat.properties";
	else
	    echo "Parameter file is not defined for the host ${HOST_NAME}. Please check!!";
    fi

}
