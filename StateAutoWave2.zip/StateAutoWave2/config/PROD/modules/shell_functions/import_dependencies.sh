###############################################################################
#                          Dependency Resolutions                             #
###############################################################################

SCRIPT_HOME_CMN=$1

COMMON_HOME=`dirname ${SCRIPT_HOME_CMN}`
#COMMON_HOME=${SCRIPT_HOME_CMN}

echo "this is executing ${COMMON_HOME}"
. ${COMMON_HOME}/spec_files/default.env.properties
. ${COMMON_HOME}/modules/shell_functions/namespace_functions.sh

#Fetch Environment details
NAMESPACE_FILE=$(getNamespaceFileForCurrentUser)

#. ${COMMON_HOME_CMN}/coordinator_functions/bin/functions.sh
echo "[INFO] NAMESPACE SET AS : ${NAMESPACE_FILE}"

. ${COMMON_HOME}/spec_files/${NAMESPACE_FILE}
. ${COMMON_HOME}/modules/shell_functions/utility_functions.sh
