V_TABLE_NAME=$1
V_YAML_PATH=$2
V_GWPL_STG_DB=$3
V_GWCL_STG_DB=$4
V_GWCC_STG_DB=$5
V_GWBC_STG_DB=$6
V_LGCY_STG_DB=$7
V_TRANSFORMATION_DB=$8
V_LGCY_SABIR=$9
V_LGCY_DMACT="${10}"
V_LGCY_GAIN="${11}"
V_EDW_EXTERNAL="${12}"
V_DELTA_COLUMN_VALUE="${13}"
V_TEMP_DB="${14}"
echo "metrics:"
#echo "- ${V_YAML_PATH}/${V_TABLE_NAME}_metric.yaml"
echo "- ${V_TABLE_NAME}_metric.yaml"
echo "variables:"
echo " gwpl_stage_db: ${V_GWPL_STG_DB}"
echo " gwcl_stage_db: ${V_GWCL_STG_DB}"
echo " gwcc_stage_db: ${V_GWCC_STG_DB}"
echo " gwbc_stage_db: ${V_GWBC_STG_DB}"
echo " lgcy_stage_db: ${V_LGCY_STG_DB}"
echo " transform_db: ${V_TRANSFORMATION_DB}"
echo " lgcy_sabir_db: ${V_LGCY_SABIR}"
echo " lgcy_dmact_db: ${V_LGCY_DMACT}"
echo " lgcy_gain_db: ${V_LGCY_GAIN}"
echo " edw_ext_db: ${V_EDW_EXTERNAL}"
echo " delta_column_value: ${V_DELTA_COLUMN_VALUE}"
echo " temp_db: ${V_TEMP_DB}"
echo "output:"
echo "  hive:"
echo "explain: true"
echo "logLevel: INFO"
echo "appName: transform_${V_TABLE_NAME}"
