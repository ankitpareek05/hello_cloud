#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : TICO Dwelling Premium_extract.sh                                         #
#                                                                             #
# Description  : Script to generate TICO Dwelling Premium file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_ACCDT_YYYYMM=${ACCDT_YYYYMM}



if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [ -z "$V_ACCDT_YYYYMM" ]
then
info "Message : Accounting Date in YYYYMM format is not passed. Dynamically getting the range based on current date"
V_ACCDT_YYYYMM=`date -d"1 month ago" +"%Y%m"`
fi



V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_tico}"
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="TICO_DWELLING_PREMIUM_TX_""$V_ACCDT_YYYYMM"".txt"
V_SUFFIX="TYPE6"




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}_${V_SUFFIX}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}_${V_SUFFIX}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "The Accounting Year Month is $V_ACCDT_YYYYMM" 

info "Generating TICO DWELLING"

info "Connecting to ${V_TRNS_DB}"




hive -S -e"
set hive.strict.checks.cartesian.product=false;
select  lpad(stat_plan_name,1,'0'),lpad(suggestion_txt,1,'0'),lpad(accounting_date,2,'0'),lpad(record_type_code,2,'0'),lpad(policy_num,10,'0'),lpad(tico_term_code,1,'0'),lpad(eff_date,5,'0'),lpad(exp_date,3,'0'),lpad(place_code,5,'0'),lpad(rsv1,3,'0'),lpad((coalesce(case when insurance_amt='0001' then insurance_amt when insurance_amt='000J' then insurance_amt when insurance_amt='absolute0' then '0000' when insurance_amt>=0 then lpad(insurance_amt,4,'0') else lpad(concat(substr(insurance_amt,2,(length(insurance_amt)-2)),(case substr(insurance_amt,length(insurance_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),4,'0') end,'0001')),4,'0') as insurance_amt,lpad(fire_flex_code,3,'0'),lpad(tico_line_of_busn_code,2,'0') as tico_line_of_busn_code,lpad(comp_num,3,'0'),lpad(individual_optnl_credit_code,2,'0'), '0' ,lpad(prem_cert_reduction_code,1,'0'),lpad(policy_form_code,1,'0'),lpad(family_occupancy_cnt_code,1,'0'),lpad(occupancy_code,1,'0'),lpad(cons_cd,1,'0'),lpad(fire_cd,2,'0'),lpad(ppc_cd,1,'0'),lpad(deduct_01_type_code,1,'0'),lpad(deduct_02_type_code,1,'0'),lpad((case when prem_amt>0 then lpad(prem_amt,4,'0') when prem_amt=0 then case when prem_amt_orig<0 then case when abs(cast(extended_coverage_prem_amt as double))>0 then '000J' when abs(cast(allied_prem_credit_amt as double))>0 then '000J' else '000}' end when prem_amt_orig>0 then case when abs(cast(extended_coverage_prem_amt as double))>0 then '0001' when abs(cast(allied_prem_credit_amt as double))>0 then '0001'  else '0000' end else '0000' end  else lpad(concat(substr(prem_amt,2,(length(prem_amt)-2)),(case substr(prem_amt,length(prem_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),4,'0') end),4,'0') as prem_amt,lpad(prem_flex_pct_code,3,'0'),lpad(special_endorsement_code,1,'0'),
lpad((case when extended_coverage_prem_amt>0 then lpad(extended_coverage_prem_amt,4,'0') when extended_coverage_prem_amt=0 then case when extended_coverage_prem_amt_orig<0 then case when abs(cast(prem_amt as double))>0 then '000J' when abs(cast(allied_prem_credit_amt as double))>0 then '000J'  else '000}' end when extended_coverage_prem_amt_orig>0 then case when abs(cast(prem_amt as double))>0 then '0001' when abs(cast(allied_prem_credit_amt as double))>0 then '0001' else '0000' end else '0000' end else lpad(concat(substr(extended_coverage_prem_amt,2,(length(extended_coverage_prem_amt)-2)),(case substr(extended_coverage_prem_amt,length(extended_coverage_prem_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),4,'0') end),4,'0') as 
extended_coverage_prem_amt,lpad(tico_allied_line_of_busn_code,2,'0'), lpad((case when tico_line_of_busn_code='16' then '000' when pl_property_insur_amt='001' then pl_property_insur_amt when pl_property_insur_amt='00J' then pl_property_insur_amt when pl_property_insur_amt='absolute0' then '000' when pl_property_insur_amt>=0 then lpad(pl_property_insur_amt,3,'0') else lpad(concat(substr(pl_property_insur_amt,2,(length(pl_property_insur_amt)-2)),(case substr(pl_property_insur_amt,length(pl_property_insur_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),3,'0') end),3,'0') as pl_property_insur_amt,
lpad((case when allied_prem_credit_amt>0 then lpad(allied_prem_credit_amt,4,'0') when allied_prem_credit_amt=0  and tico_allied_line_of_busn_code in('26','28') then case when prem_amt>0 then '0001' when extended_coverage_prem_amt>0 then '0001' when prem_amt<0 then '000J' when extended_coverage_prem_amt<0 then '000J' end when allied_prem_credit_amt=0 then case when allied_prem_credit_amt_orig<0 then case when abs(cast(prem_amt as double))>0 then '000J' when abs(cast(extended_coverage_prem_amt as double))>0 then '000J'  else  '000}' end when allied_prem_credit_amt_orig>0 then case when abs(cast(prem_amt as double))>0 then '0001' when abs(cast(extended_coverage_prem_amt as double))>0 then '0001' else '0000' end else '0000' end  else lpad(concat(substr(allied_prem_credit_amt,2,(length(allied_prem_credit_amt)-2)),(case substr(allied_prem_credit_amt,length(allied_prem_credit_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),4,'0') end),4,'0') as
allied_prem_credit_amt, lpad(optional_credit_amt,3,'0'), lpad(roof_cover_code,1,'0'), lpad(roof_cover_credit_code,5,'0'), lpad(excl_cosmetic_roof_dmg_ind,1,'0'), rsrv2, lpad(zip_code,9,'0'), lpad(rpt_type_code,1,'0'),  lpad(optnl_cov_endorsement_code,8,'0'), lpad(optnl_cov_endorsement_code_amt,6,'0'),lpad(hoa_attached_ind,1,'0') ,lpad((case when deduct_01_amt>0 then lpad(deduct_01_amt,6,'0') when deduct_01_amt=0 then case when deduct_01_amt_orig<0 then '00000}' else '000000' end else lpad(concat(substr(deduct_01_amt,2,(length(deduct_01_amt)-2)),(case substr(deduct_01_amt,length(deduct_01_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),6,'0') end),6,'0') as deduct_01_amt,lpad((case when deduct_02_amt>0 then lpad(deduct_02_amt,6,'0') when deduct_02_amt=0 then case when deduct_02_amt_orig<0 then '00000}' else '000000' end else lpad(concat(substr(deduct_02_amt,2,(length(deduct_02_amt)-2)),(case substr(deduct_02_amt,length(deduct_02_amt),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)),6,'0') end),6,'0') as deduct_02_amt,  lpad(wind_cov,1,'0'), lpad(rsrv3,5,'0'), lpad(building_credit_code_code,2,'0'), lpad(tico_law_ordinance_cov_code,1,'0'), lpad(sprinkler_credit_ind,1,'0'), lpad(rsrv4,1,'0'), lpad(property_protection_ind,1,'0'), lpad(tenure_discount_code,1,'0'), lpad(tenure_discount_amt,2,'0'), lpad(replacement_cov_limit_ind,1,'0'), lpad(replace_cov_limit_disc_code,2,'0'), lpad(naics_code,5,'0') from( 



select distinct main.policy_period_join_Id,case when coverage_join_id='DPDW_Personal_Property_HOE' then 'D' else 'O' end as cov_type,'a' as coverage_join_id,lpad(coalesce(stat_plan_name,'0'),1,'0') as stat_plan_name, lpad(coalesce(suggestion_txt,'0'),1,'0') as suggestion_txt, lpad(concat(case when (substr(cast(accounting_date as varchar(25)),5,2))in('10') then '0' when (substr(cast(accounting_date as varchar(25)),5,2))in('11') then '-' when (substr(cast(accounting_date as varchar(25)),5,2))in('12') then '&' else substr(cast(accounting_date as varchar(25)),6,1) end , substr(cast(accounting_date as varchar(25)),4,1)) ,2,'0') as accounting_date, lpad(coalesce(main.record_type_code,'0'),2,'0') as record_type_code, rpad(coalesce(policy_num,'0'),10,'0') as policy_num,/*Pending*/ lpad(coalesce(tico_term_code,'0'),1,'0') as tico_term_code, concat(substr(main.eff_date,6,2),substr(main.eff_date,9,2),substr(main.eff_date,4,1)) as eff_date, concat(substr(main.exp_date,6,2),substr(main.exp_date,4,1)) as exp_date, lpad(coalesce(place_code,'0'),5,'0') as place_code, '000' as rsv1, case when coverage_join_id='DPDW_Personal_Property_HOE' then case when coalesce(cast(ins1.insurance_amt as decimal(18,2)),1499)<=1499 and coalesce(cast(ins1.insurance_amt as decimal(18,2)),1499)>0 then '0001' when  coalesce(cast(ins1.insurance_amt as decimal(18,2)),1499)>=-1499 and coalesce(cast(ins1.insurance_amt as decimal(18,2)),1499)<0 then '000J' when coalesce(cast(ins1.insurance_amt as decimal(18,2)),1499)=0 then 'absolute0'  else cast(cast(round(ins1.insurance_amt/1000) as integer) as varchar(100)) end else case when coalesce(cast(ins.insurance_amt as decimal(18,2)),1499)<=1499 and coalesce(cast(ins.insurance_amt as decimal(18,2)),1499)>0 then '0001' when  coalesce(cast(ins.insurance_amt as decimal(18,2)),1499)>=-1499 and coalesce(cast(ins.insurance_amt as decimal(18,2)),1499)<0 then '000J' when coalesce(cast(ins.insurance_amt as decimal(18,2)),1499)=0 then 'absolute0'  else cast(cast(round(ins.insurance_amt/1000) as integer) as varchar(100)) end end as insurance_amt, /*Pending*/ lpad(coalesce(fire_flex_code,'0'),3,'0') as fire_flex_code, lpad(coalesce(case when coverage_join_id='DPDW_Personal_Property_HOE' then b1.tico_line_of_busn_code else b.tico_line_of_busn_code end,'0'),2,'0') AS tico_line_of_busn_code, lpad(coalesce(ref.alt_code,'0'),3,'0') as comp_num, lpad(coalesce(individual_optnl_credit_code,'0'),2,'0') as individual_optnl_credit_code, lpad(coalesce(prem_srchg_claim_made_ind,'0'),1,'0') as prem_srchg_claim_made_ind, lpad(coalesce(prem_cert_reduction_code,'0'),1,'0') as prem_cert_reduction_code, lpad(coalesce(policy_form_code,'0'),1,'0') as policy_form_code, lpad(coalesce(family_occupancy_cnt_code,'0'),1,'0') as family_occupancy_cnt_code, lpad(coalesce(occupancy_code,'0'),1,'0') as occupancy_code, lpad(coalesce(ref_cons_cd.alt_code,'0'),1,'0') as cons_cd, lpad(coalesce(ref_fire_cd.alt_code,'00'),2,'0') as fire_cd, lpad(coalesce(iso_ppc_code,'0'),1,'0') as ppc_cd, lpad(coalesce(case when coverage_join_id='DPDW_Personal_Property_HOE' then ref_ded_cd.alt_code  else ref_ded_cd_a.alt_code end,'0'),1,'0') as deduct_01_type_code,lpad(coalesce(case when coverage_join_id='DPDW_Personal_Property_HOE' then ref_ded_cd2.alt_code else ref_ded_cd2_a.alt_code end ,'0'),1,'0') as deduct_02_type_code, /*Pending*/ cast(cast(round(case when coverage_join_id='DPDW_Personal_Property_HOE' then amt1.prem_amt else amt.prem_amt end)  as integer )as varchar(100)) as prem_amt,cast(case when coverage_join_id='DPDW_Personal_Property_HOE' then amt1.prem_amt else amt.prem_amt end as double) as prem_amt_orig,/*Pending*/ lpad(coalesce(prem_flex_pct_code,'0'),3,'0') as prem_flex_pct_code, lpad(coalesce(special_endorsement_code,'0'),1,'0') as special_endorsement_code, cast(cast(round(case when coverage_join_id='DPDW_Personal_Property_HOE' then amt1.extended_coverage_prem_amt else amt.extended_coverage_prem_amt end )  as integer )as varchar(100)) as extended_coverage_prem_amt,case when coverage_join_id='DPDW_Personal_Property_HOE' then amt1.extended_coverage_prem_amt  else amt.extended_coverage_prem_amt end as extended_coverage_prem_amt_orig, /*Pending*/ lpad(coalesce(case when coverage_join_id='DPDW_Personal_Property_HOE' then c1.tico_allied_line_of_busn_code else c.tico_allied_line_of_busn_code end,'0'),2,'0') as tico_allied_line_of_busn_code, case when coverage_join_id='DPDW_Personal_Property_HOE' then case when coalesce(cast(pl_ins1.pl_property_insur_amt as decimal(18,2)),1499)<=1499 and coalesce(cast(pl_ins1.pl_property_insur_amt as decimal(18,2)),1499)>0 then '001'  when coalesce(cast(pl_ins1.pl_property_insur_amt as decimal(18,2)),1499)>=-1499 and coalesce(cast(pl_ins1.pl_property_insur_amt as decimal(18,2)),1499)<0 then '00J' when coalesce(cast(pl_ins1.pl_property_insur_amt as decimal(18,2)),1499)=0 then 'absolute0' else cast(cast(round(pl_ins1.pl_property_insur_amt/1000)  as integer)as varchar(100)) end else case when coalesce(cast(pl_ins.pl_property_insur_amt as decimal(18,2)),1499)<=1499 and coalesce(cast(pl_ins.pl_property_insur_amt as decimal(18,2)),1499)>0 then '001'  when coalesce(cast(pl_ins.pl_property_insur_amt as decimal(18,2)),1499)>=-1499 and coalesce(cast(pl_ins.pl_property_insur_amt as decimal(18,2)),1499)<0 then '00J' when coalesce(cast(pl_ins.pl_property_insur_amt as decimal(18,2)),1499)=0 then 'absolute0' else cast(cast(round(pl_ins.pl_property_insur_amt/1000)   as integer)as varchar(100)) end  end as pl_property_insur_amt, /*Pending*/ cast(cast(round(case when coverage_join_id='DPDW_Personal_Property_HOE' then amt1.allied_prem_credit_amt else amt.allied_prem_credit_amt end )  as integer )as varchar(100)) as allied_prem_credit_amt,cast(case when coverage_join_id='DPDW_Personal_Property_HOE' then amt1.allied_prem_credit_amt else amt.allied_prem_credit_amt end as double) as allied_prem_credit_amt_orig, /*Pending*/ lpad(coalesce(optional_credit_amt,'100'),3,'0') as optional_credit_amt, lpad(coalesce(roof_cover_code,'0'),1,'0') as roof_cover_code, lpad(coalesce(roof_cover_credit_code,'0'),5,'0') as roof_cover_credit_code, lpad(coalesce(excl_cosmetic_roof_dmg_ind,'0'),1,'0') as excl_cosmetic_roof_dmg_ind, '0' as rsrv2, lpad(coalesce(zip_code,'0'),9,'0') as zip_code, lpad(coalesce(rpt_type_code,'0'),1,'0') as rpt_type_code, lpad(coalesce(optnl_cov_endorsement_code,'0'),8,'0') as optnl_cov_endorsement_code, lpad(coalesce(cast(cast(round(optnl_cov_endorsement_code_amt) as integer) as varchar(6)),'000000'),6,'0') as optnl_cov_endorsement_code_amt, lpad(coalesce(hoa_attached_ind,'0'),1,'0') as hoa_attached_ind, cast(cast(round(case when coverage_join_id='DPDW_Personal_Property_HOE' then main.deduct_01_amt else ded.deduct_01_amt end)  as integer )as varchar(100)) as deduct_01_amt,cast(case when coverage_join_id='DPDW_Personal_Property_HOE' then main.deduct_01_amt else ded.deduct_01_amt end as double) as deduct_01_amt_orig,/*Pending*/ cast(cast(round(case when coverage_join_id='DPDW_Personal_Property_HOE' then main.deduct_02_amt else ded.deduct_02_amt end)  as integer )as varchar(100)) as deduct_02_amt,cast(case when coverage_join_id='DPDW_Personal_Property_HOE' then main.deduct_02_amt else ded.deduct_02_amt end as double) as deduct_02_amt_orig,/*Pending*/ wind_coverage_ind as wind_cov, '00000' as rsrv3, building_credit_code_code, tico_law_ordinance_cov_code, sprinkler_credit_ind, '0' as rsrv4, property_protection_ind, tenure_discount_code, tenure_discount_amt, replacement_cov_limit_ind, replace_cov_limit_disc_code, naics_code from $V_TRNS_DB.tico_ho_df_prem_loss main left join $V_EDW_EXTERNAL.ent_ref_code ref on ref.alt_code_type_name='TICO-CO' and ref.code_type_name='UNDERWRITING-CO' and ref.group_code='TICO' and ref.code=main.tico_company_num left join $V_EDW_EXTERNAL.ent_ref_code ref_cons_cd on ref_cons_cd.alt_code_type_name='TICO-CONSTRCD' and ref_cons_cd.code_type_name='CONSTRUCTION_CD' and ref_cons_cd.group_code='TICO' and ref_cons_cd.code=main.construction_code left join $V_EDW_EXTERNAL.ent_ref_code ref_fire_cd on ref_fire_cd.alt_code_type_name='TICO-FIRECD' and ref_fire_cd.code_type_name='FIREPRT_CD' and ref_fire_cd.group_code='TICO' and ref_fire_cd.code=main.iso_ppc_new_split_class_code left join $V_EDW_EXTERNAL.ent_ref_code ref_ded_cd on ref_ded_cd.alt_code_type_name='TICO-DEDCD' and ref_ded_cd.code_type_name='DEDUCTIBLE_TYPE_CD' and ref_ded_cd.group_code='TICO' and ltrim(rtrim(ref_ded_cd.code))=ltrim(rtrim(main.deduct_01_type_code)) left join $V_EDW_EXTERNAL.ent_ref_code ref_ded_cd2 on ref_ded_cd2.alt_code_type_name='TICO-DEDCD' and ref_ded_cd2.code_type_name='DEDUCTIBLE_TYPE_CD' and ref_ded_cd2.group_code='TICO' and ltrim(rtrim(ref_ded_cd2.code))=ltrim(rtrim(main.deduct_02_type_code)) left join (select sum(cast(prem_amt as double)) as prem_amt,sum(cast(allied_prem_credit_amt as double)) as allied_prem_credit_amt,sum(cast(extended_coverage_prem_amt as double)) as extended_coverage_prem_amt,policy_period_join_id,record_type_code from (select distinct transaction_key,annual_statement_line_code,coverage_join_id,prem_amt,allied_prem_credit_amt,extended_coverage_prem_amt,policy_period_join_id,record_type_code from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')   and coalesce(coverage_join_id,'coverage') not in( 'DPDW_FoundationCov_HOE','DPDW_WaterDmg_HOE','HOWaterBkUpSumpHOE','DPDW_Personal_Property_HOE'))a  group by policy_period_join_id,record_type_code) amt on amt.policy_period_join_id=main.policy_period_join_id and amt.record_type_code=main.record_type_code left join (select sum(cast(prem_amt as double)) as prem_amt,sum(cast(allied_prem_credit_amt as double)) as allied_prem_credit_amt,sum(cast(extended_coverage_prem_amt as double)) as extended_coverage_prem_amt,policy_period_join_id,record_type_code from (select distinct transaction_key,annual_statement_line_code,coverage_join_id,prem_amt,allied_prem_credit_amt,extended_coverage_prem_amt,policy_period_join_id,record_type_code from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')  and coverage_join_id  in( 'DPDW_Personal_Property_HOE'))a  group by policy_period_join_id,record_type_code) amt1 on amt1.policy_period_join_id=main.policy_period_join_id and amt1.record_type_code=main.record_type_code  left join (select * from(select  tico_line_of_busn_code,row_number() over(partition by policy_period_join_id order by tico_line_of_busn_code desc) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')    and coverage_join_id  in( 'DPDW_Personal_Property_HOE'))a where a.rownum=1)b1 on b1.policy_period_join_id=main.policy_period_join_id left join (select * from(select  tico_allied_line_of_busn_code,row_number() over(partition by policy_period_join_id order by tico_allied_line_of_busn_code desc) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')   and coverage_join_id  in( 'DPDW_Personal_Property_HOE'))a where a.rownum=1)c1 on c1.policy_period_join_id=main.policy_period_join_id left join (select * from(select  pl_property_insur_amt,row_number() over(partition by policy_period_join_id order by pl_property_insur_amt ) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov') and coverage_join_id  in( 'DPDW_Personal_Property_HOE'))a where a.rownum=1)pl_ins1 on pl_ins1.policy_period_join_id=main.policy_period_join_id left join (select * from(select  insurance_amt,row_number() over(partition by policy_period_join_id order by insurance_amt ) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')  and coverage_join_id  in( 'DPDW_Personal_Property_HOE'))a where a.rownum=1)ins1 on ins1.policy_period_join_id=main.policy_period_join_id left join (select * from(select  tico_line_of_busn_code,row_number() over(partition by policy_period_join_id order by tico_line_of_busn_code desc) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')   and coverage_join_id not in( 'DPDW_FoundationCov_HOE','DPDW_WaterDmg_HOE','HOWaterBkUpSumpHOE','DPDW_Personal_Property_HOE'))a where a.rownum=1)b on b.policy_period_join_id=main.policy_period_join_id left join (select * from(select  tico_allied_line_of_busn_code,row_number() over(partition by policy_period_join_id order by tico_allied_line_of_busn_code desc) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')   and coalesce(coverage_join_id,'coverage') not in( 'DPDW_FoundationCov_HOE','DPDW_WaterDmg_HOE','HOWaterBkUpSumpHOE','DPDW_Personal_Property_HOE'))a where a.rownum=1)c on c.policy_period_join_id=main.policy_period_join_id left join (select * from(select  pl_property_insur_amt,row_number() over(partition by policy_period_join_id order by pl_property_insur_amt ) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')  and coalesce(coverage_join_id,'coverage') not in( 'DPDW_FoundationCov_HOE','DPDW_WaterDmg_HOE','HOWaterBkUpSumpHOE','DPDW_Personal_Property_HOE'))a where a.rownum=1)pl_ins on pl_ins.policy_period_join_id=main.policy_period_join_id left join (select * from(select  insurance_amt,row_number() over(partition by policy_period_join_id order by insurance_amt ) as rownum,policy_period_join_id from $V_TRNS_DB.tico_ho_df_prem_loss where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')  and coverage_join_id not in( 'DPDW_FoundationCov_HOE','DPDW_WaterDmg_HOE','HOWaterBkUpSumpHOE','DPDW_Personal_Property_HOE'))a where a.rownum=1)ins on ins.policy_period_join_id=main.policy_period_join_id left join (select distinct policy_period_join_Id,deduct_01_type_code,deduct_02_type_code,deduct_01_amt,deduct_02_amt from $V_TRNS_DB.tico_ho_df_prem_loss  where extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'peril') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov') and coverage_join_id='HOCovADwellingHOE' )ded on ded.policy_period_join_id=main.policy_period_join_id
left join $V_EDW_EXTERNAL.ent_ref_code ref_ded_cd_a on ref_ded_cd_a.alt_code_type_name='TICO-DEDCD' and ref_ded_cd_a.code_type_name='DEDUCTIBLE_TYPE_CD' and ref_ded_cd_a.group_code='TICO' and ltrim(rtrim(ref_ded_cd_a.code))=ltrim(rtrim(ded.deduct_01_type_code)) left join $V_EDW_EXTERNAL.ent_ref_code ref_ded_cd2_a on ref_ded_cd2_a.alt_code_type_name='TICO-DEDCD' and ref_ded_cd2_a.code_type_name='DEDUCTIBLE_TYPE_CD' and ref_ded_cd2_a.group_code='TICO' and ltrim(rtrim(ref_ded_cd2_a.code))=ltrim(rtrim(ded.deduct_02_type_code)) where main.extract_type_name='TICO-MNTH-DWLPREM' and coalesce(peril_type_code,'per') not in(/*'P3_THEFT',*/'P1_LIABILITY') and coalesce(coverage_category_code,'dflt') not in ('theftcov')  and coalesce(coverage_join_id,'coverage') not in( 'DPDW_FoundationCov_HOE','DPDW_WaterDmg_HOE','HOWaterBkUpSumpHOE'/*,'DPDW_Personal_Property_HOE'*/)
and  accounting_dateyyyymm='${V_ACCDT_YYYYMM}' and main.record_type_code = '06'


)a where ltrim(rtrim(a.tico_line_of_busn_code))<>'12' and (abs(cast(prem_amt_orig as double))>=0.5 or abs(cast(allied_prem_credit_amt_orig as double))>=0.5 or abs(cast(extended_coverage_prem_amt_orig as double))>=0.5)
/*where ltrim(rtrim(a.policy_num))='1000048705'*/ 
" | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "TICO Dwelling Premium file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  TICO Dwelling Premium file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "TICO Dwelling Premium Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : TICO Dwelling Premium Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
