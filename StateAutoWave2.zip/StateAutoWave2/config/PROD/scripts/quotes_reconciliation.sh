#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : quotes_reconciliation.sh                                     #
# Description  : Script to get the counts from  Quotes tables                 #
# Author       : State Auto                                                   #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}
#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}
V_Quotes_DB="transform_plquotes"

	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
echo "Getting table counts"

query_string[0]="Hi All, Folllowing are the statistics for the PL Quote tables loaded on $(date +'%Y/%m/%d')"
##############################################################################################################################################################
QUOTES_NEWBUSCNT=`hive -S -e "SELECT count(*) FROM ${V_Quotes_DB}.new_business_count"`
query_string[1]="New Business Count: ${QUOTES_NEWBUSCNT}" 
   info "New Business Count: ${QUOTES_NEWBUSCNT}" >> ${v_Log}
##############################################################################################################################################################
quotes_pcCNT=`hive -S -e "SELECT count(*) FROM ${V_Quotes_DB}.quotes_pc"`
query_string[2]="quotes_pc: ${quotes_pcCNT}" 
   info "quotes_pc: ${quotes_pcCNT}" >> ${v_Log}
##############################################################################################################################################################
QUOTES_PCLTECNT=`hive -S -e "SELECT count(*) FROM ${V_Quotes_DB}.quotes_pclite"`
query_string[3]="quotes pclite: ${QUOTES_PCLTECNT}" 
   info "quotes_pclite: ${QUOTES_PCLTECNT}" >> ${v_Log}
##############################################################################################################################################################
QUOTES_PCAGG=`hive -S -e "SELECT count(*) FROM ${V_Quotes_DB}.quotes_pcagg"`
query_string[4]="quotes pcagg: ${QUOTES_PCAGG}" 
   info "quotes pcagg: ${QUOTES_PCAGG}" >> ${v_Log}
##############################################################################################################################################################
QUOTES_ALLCNT=`hive -S -e "SELECT count(*) FROM ${V_Quotes_DB}.quotes_all"`
query_string[5]="quotes all: ${QUOTES_ALLCNT}" 
   info "quotes all: ${QUOTES_ALLCNT}"  >> ${v_Log}
   
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "New Cluster Email alert for PL Quote Tables Load - $(date +'%Y/%m/%d')" edlakerun@stateauto.com
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Completed Sucessfully" >>  ${v_Log} 2>&1
   exit 0
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1