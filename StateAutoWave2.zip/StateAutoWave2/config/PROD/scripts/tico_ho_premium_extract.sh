#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : TICO_HO_PREMIUM_EXTRACT.sh                                         #
#                                                                             #
# Description  : Script to generate TICO HO Premium file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}


###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_ACCDT_YYYYMM=${ACCDT_YYYYMM}



if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]] 
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [ -z "$V_ACCDT_YYYYMM" ]
then
info "Message : Accounting Date in YYYYMM format is not passed. Dynamically getting the range based on current date"
V_ACCDT_YYYYMM=`date -d"1 month ago" +"%Y%m"`
fi


info "Message : The Accounting Year Month is $V_ACCDT_YYYYMM"



V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_tico}"
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="TICO_HO_PREMIUM_TX_""$V_ACCDT_YYYYMM"".txt"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "The Accounting Year Month is $V_ACCDT_YYYYMM" 

info "Generating TICO HO Premium file"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
with already_correct as (select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id from
(
select
 
stat_plan_name
,suggestion_txt
,case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date
,record_type_code
,policy_num
,tico_term_code
,concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),9,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_dt
,concat(substr(cast(src_tab.exp_date as string),6,2),substr(cast(src_tab.exp_date as string),4,1)) as exp_dt
,place_code
,cast(cast(round(cast(insurance_amt as double) / 1000) as integer) as string) as insurance_amt_1
,fire_flex_code
,tico_line_of_busn_code
,tico_co.alt_code
,individual_optnl_credit_code
,prem_srchg_claim_made_ind
,prem_cert_reduction_code
,policy_form_code
,family_occupancy_cnt_code
,occupancy_code
,tico_constr.alt_code as construction_code
,case when tico_ppc.alt_code is not null then tico_ppc.alt_code
else '00'
end  as iso_ppc_new_split_class_code
,iso_ppc_code
,case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
      when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else '0'
end as deduct_01_type_code	
,case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528') THEN '7' when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else '0'
end as deduct_02_type_code	 
,prem_amt
,prem_flex_pct_code
,special_endorsement_code
,extended_coverage_prem_amt
,tico_allied_line_of_busn_code
,pl_property_insur_amt
,allied_prem_credit_amt
,optional_credit_amt
,roof_cover_code
,roof_cover_credit_code
,roof_instl_year
,excl_cosmetic_roof_dmg_ind
,zip_code
,rpt_type_code
,optnl_cov_endorsement_code
,cast(optnl_cov_endorsement_code_amt as decimal (6,0)) as optnl_cov_endorsement_code_amt
,hoa_attached_ind,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then 0 when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '0' else cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) end as ded_01_amt,
case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7' else cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) end as ded_02_amt,
case when wind_coverage_ind='1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '1' else '0' end as wind_coverage_ind
,building_credit_code_code
,tico_law_ordinance_cov_code
,sprinkler_credit_ind
,property_protection_ind
,tenure_discount_code
,tenure_discount_amt
,replacement_cov_limit_ind
,replace_cov_limit_disc_code
,naics_code
,policy_period_join_id


from $V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO')tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-FIRECD')tico_ppc
on src_tab.iso_ppc_new_split_class_code=tico_ppc.code
where extract_type_name='TICO-MNTH-HOPREM'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
and cast (prem_amt as double) <=0  and record_type_code!='06' /*and policy_num='1000296077'*/
)sq
group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b where prem_amt >= -9999 group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code
)a




union all

select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id from
(
select
 
stat_plan_name
,suggestion_txt
,case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date
,record_type_code
,policy_num
,tico_term_code
,concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),9,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_dt
,concat(substr(cast(src_tab.exp_date as string),6,2),substr(cast(src_tab.exp_date as string),4,1)) as exp_dt
,place_code
,cast(cast(round(cast(insurance_amt as double) / 1000) as integer) as string) as insurance_amt_1
,fire_flex_code
,tico_line_of_busn_code
,tico_co.alt_code
,individual_optnl_credit_code
,prem_srchg_claim_made_ind
,prem_cert_reduction_code
,policy_form_code
,family_occupancy_cnt_code
,occupancy_code
,tico_constr.alt_code as construction_code
,case when tico_ppc.alt_code is not null then tico_ppc.alt_code
else '00'
end  as iso_ppc_new_split_class_code
,iso_ppc_code
,case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
      when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else '0'
end as deduct_01_type_code	
,case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528') THEN '7' when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else '0'
end as deduct_02_type_code	 
,prem_amt
,prem_flex_pct_code
,special_endorsement_code
,extended_coverage_prem_amt
,tico_allied_line_of_busn_code
,pl_property_insur_amt
,allied_prem_credit_amt
,optional_credit_amt
,roof_cover_code
,roof_cover_credit_code
,roof_instl_year
,excl_cosmetic_roof_dmg_ind
,zip_code
,rpt_type_code
,optnl_cov_endorsement_code
,cast(optnl_cov_endorsement_code_amt as decimal (6,0)) as optnl_cov_endorsement_code_amt
,hoa_attached_ind,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then 0 when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '0' else cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) end as ded_01_amt,
case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7' else cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) end as ded_02_amt,
case when wind_coverage_ind='1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '1' else '0' end as wind_coverage_ind
,building_credit_code_code
,tico_law_ordinance_cov_code
,sprinkler_credit_ind
,property_protection_ind
,tenure_discount_code
,tenure_discount_amt
,replacement_cov_limit_ind
,replace_cov_limit_disc_code
,naics_code
,policy_period_join_id


from $V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO')tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-FIRECD')tico_ppc
on src_tab.iso_ppc_new_split_class_code=tico_ppc.code
where extract_type_name='TICO-MNTH-HOPREM'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
and cast (prem_amt as double) > 0  and record_type_code!='06' /*and policy_num='1000296077'*/
)sq
group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b where prem_amt <= 9999 group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code
)a

union all


select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id from
(
select
 
stat_plan_name
,suggestion_txt
,case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date
,record_type_code
,policy_num
,tico_term_code
,concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),9,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_dt
,concat(substr(cast(src_tab.exp_date as string),6,2),substr(cast(src_tab.exp_date as string),4,1)) as exp_dt
,place_code
,cast(cast(round(cast(insurance_amt as double) / 1000) as integer) as string) as insurance_amt_1
,fire_flex_code
,tico_line_of_busn_code
,tico_co.alt_code
,individual_optnl_credit_code
,prem_srchg_claim_made_ind
,prem_cert_reduction_code
,policy_form_code
,family_occupancy_cnt_code
,occupancy_code
,tico_constr.alt_code as construction_code
,case when tico_ppc.alt_code is not null then tico_ppc.alt_code
else '00'
end  as iso_ppc_new_split_class_code
,iso_ppc_code
,case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
      when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else '0'
end as deduct_01_type_code	
,case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528') THEN '7' when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else '0'
end as deduct_02_type_code	 
,prem_amt
,prem_flex_pct_code
,special_endorsement_code
,extended_coverage_prem_amt
,tico_allied_line_of_busn_code
,pl_property_insur_amt
,allied_prem_credit_amt
,optional_credit_amt
,roof_cover_code
,roof_cover_credit_code
,roof_instl_year
,excl_cosmetic_roof_dmg_ind
,zip_code
,rpt_type_code
,optnl_cov_endorsement_code
,cast(optnl_cov_endorsement_code_amt as decimal (6,0)) as optnl_cov_endorsement_code_amt
,hoa_attached_ind,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then 0 when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '0' else cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) end as ded_01_amt,
case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7' else cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) end as ded_02_amt,
case when wind_coverage_ind='1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '1' else '0' end as wind_coverage_ind
,building_credit_code_code
,tico_law_ordinance_cov_code
,sprinkler_credit_ind
,property_protection_ind
,tenure_discount_code
,tenure_discount_amt
,replacement_cov_limit_ind
,replace_cov_limit_disc_code
,naics_code
,policy_period_join_id


from $V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO')tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-FIRECD')tico_ppc
on src_tab.iso_ppc_new_split_class_code=tico_ppc.code
where extract_type_name='TICO-MNTH-HOPREM'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
and record_type_code='06' /*and policy_num='1000296077'*/
)sq
group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b where prem_amt between -9999 and 9999 group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code
)a ) select * from already_correct 
" >> /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"

		
if [ $? == 0 ]

then 

hive -S -e"
with positivepremamtnot06 as (select distinct * from(
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id
from ( 
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id from
(
select
 
stat_plan_name
,suggestion_txt
,case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date
,record_type_code
,policy_num
,tico_term_code
,concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),9,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_dt
,concat(substr(cast(src_tab.exp_date as string),6,2),substr(cast(src_tab.exp_date as string),4,1)) as exp_dt
,place_code
,cast(cast(round(cast(insurance_amt as double) / 1000) as integer) as string) as insurance_amt_1
,fire_flex_code
,tico_line_of_busn_code
,tico_co.alt_code
,individual_optnl_credit_code
,prem_srchg_claim_made_ind
,prem_cert_reduction_code
,policy_form_code
,family_occupancy_cnt_code
,occupancy_code
,tico_constr.alt_code as construction_code
,case when tico_ppc.alt_code is not null then tico_ppc.alt_code
else '00'
end  as iso_ppc_new_split_class_code
,iso_ppc_code
,case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
      when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else '0'
end as deduct_01_type_code	
,case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528') THEN '7' when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else '0'
end as deduct_02_type_code	 
,prem_amt
,prem_flex_pct_code
,special_endorsement_code
,extended_coverage_prem_amt
,tico_allied_line_of_busn_code
,pl_property_insur_amt
,allied_prem_credit_amt
,optional_credit_amt
,roof_cover_code
,roof_cover_credit_code
,roof_instl_year
,excl_cosmetic_roof_dmg_ind
,zip_code
,rpt_type_code
,optnl_cov_endorsement_code
,cast(optnl_cov_endorsement_code_amt as decimal (6,0)) as optnl_cov_endorsement_code_amt
,hoa_attached_ind,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then 0 when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '0' else cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) end as ded_01_amt,
case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7' else cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) end as ded_02_amt,
case when wind_coverage_ind='1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '1' else '0' end as wind_coverage_ind
,building_credit_code_code
,tico_law_ordinance_cov_code
,sprinkler_credit_ind
,property_protection_ind
,tenure_discount_code
,tenure_discount_amt
,replacement_cov_limit_ind
,replace_cov_limit_disc_code
,naics_code
,policy_period_join_id


from $V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO')tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-FIRECD')tico_ppc
on src_tab.iso_ppc_new_split_class_code=tico_ppc.code
where extract_type_name='TICO-MNTH-HOPREM'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
and cast (prem_amt as double) > 0  and record_type_code!='06' /*and policy_num='1000296077'*/
)sq
group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b where prem_amt > 9999 group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code
)a),
positivepremamtnot06_final as (select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from positivepremamtnot06 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b


union all

select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
prem_amt-9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from positivepremamtnot06 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b )
select * from positivepremamtnot06_final
" >> /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"

else 

info "ERROR : Extract file generation failed !!";

fi

if [ $? == 0 ]

then 

hive -S -e"
with negativepremamtnot06 as (select distinct * from(
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id
from ( 
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id from
(
select
 
stat_plan_name
,suggestion_txt
,case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date
,record_type_code
,policy_num
,tico_term_code
,concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),9,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_dt
,concat(substr(cast(src_tab.exp_date as string),6,2),substr(cast(src_tab.exp_date as string),4,1)) as exp_dt
,place_code
,cast(cast(round(cast(insurance_amt as double) / 1000) as integer) as string) as insurance_amt_1
,fire_flex_code
,tico_line_of_busn_code
,tico_co.alt_code
,individual_optnl_credit_code
,prem_srchg_claim_made_ind
,prem_cert_reduction_code
,policy_form_code
,family_occupancy_cnt_code
,occupancy_code
,tico_constr.alt_code as construction_code
,case when tico_ppc.alt_code is not null then tico_ppc.alt_code
else '00'
end  as iso_ppc_new_split_class_code
,iso_ppc_code
,case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
      when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else '0'
end as deduct_01_type_code	
,case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528') THEN '7' when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else '0'
end as deduct_02_type_code	 
,prem_amt
,prem_flex_pct_code
,special_endorsement_code
,extended_coverage_prem_amt
,tico_allied_line_of_busn_code
,pl_property_insur_amt
,allied_prem_credit_amt
,optional_credit_amt
,roof_cover_code
,roof_cover_credit_code
,roof_instl_year
,excl_cosmetic_roof_dmg_ind
,zip_code
,rpt_type_code
,optnl_cov_endorsement_code
,cast(optnl_cov_endorsement_code_amt as decimal (6,0)) as optnl_cov_endorsement_code_amt
,hoa_attached_ind,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then 0 when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '0' else cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) end as ded_01_amt,
case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7' else cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) end as ded_02_amt,
case when wind_coverage_ind='1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '1' else '0' end as wind_coverage_ind
,building_credit_code_code
,tico_law_ordinance_cov_code
,sprinkler_credit_ind
,property_protection_ind
,tenure_discount_code
,tenure_discount_amt
,replacement_cov_limit_ind
,replace_cov_limit_disc_code
,naics_code
,policy_period_join_id


from $V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO')tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-FIRECD')tico_ppc
on src_tab.iso_ppc_new_split_class_code=tico_ppc.code
where extract_type_name='TICO-MNTH-HOPREM'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
and cast (prem_amt as double) <= 0  and record_type_code!='06' /*and policy_num='1000296077'*/
)sq
group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b where prem_amt <= -9999 group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code
)a),
negativepremamtnot06_final as (select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
-9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from negativepremamtnot06 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b


union all

select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
prem_amt+9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from negativepremamtnot06 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b )
select * from negativepremamtnot06_final
" >> /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"

else 

info "ERROR : Extract file generation failed !!";

fi

if [ $? == 0 ]

then 

hive -S -e"
with totalpremamt06 as (select distinct * from(
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id
from ( 
select MIN(stat_plan_name) as stat_plan_name,
MIN(suggestion_txt) as suggestion_txt,
MIN(accounting_date) as accounting_date,
MIN(record_type_code) as record_type_code,
MIN(policy_num) as policy_num,
MIN(tico_term_code) as tico_term_code,
MIN(eff_dt) as eff_dt,
MIN(exp_dt) as exp_dt,
MIN(place_code) as place_code,
MIN(insurance_amt_1) as insurance_amt_1,
MIN(fire_flex_code) as fire_flex_code,
MIN(tico_line_of_busn_code) as tico_line_of_busn_code,
MIN(alt_code) as alt_code,
MIN(individual_optnl_credit_code) as individual_optnl_credit_code,
MIN(prem_srchg_claim_made_ind) as prem_srchg_claim_made_ind,
MIN(prem_cert_reduction_code) as prem_cert_reduction_code,
MIN(policy_form_code) as policy_form_code,
MIN(family_occupancy_cnt_code) as family_occupancy_cnt_code,
MIN(occupancy_code) as occupancy_code,
MIN(construction_code) as construction_code,
MIN(iso_ppc_new_split_class_code) as iso_ppc_new_split_class_code,
MIN(iso_ppc_code) as iso_ppc_code,
MIN(deduct_01_type_code) as deduct_01_type_code,
MIN(deduct_02_type_code) as deduct_02_type_code,
cast (round(sum(cast (prem_amt as double))) as integer) as prem_amt,
MIN(prem_flex_pct_code) as prem_flex_pct_code,
MIN(special_endorsement_code) as special_endorsement_code,
MIN(optional_credit_amt) as optional_credit_amt,
MIN(excl_cosmetic_roof_dmg_ind) as excl_cosmetic_roof_dmg_ind,
MIN(zip_code) as zip_code,
MIN(rpt_type_code) as rpt_type_code,
MIN(optnl_cov_endorsement_code) as optnl_cov_endorsement_code,
MIN(optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
MIN(hoa_attached_ind) as hoa_attached_ind,
MIN(ded_01_amt) as ded_01_amt,
MIN(ded_02_amt) as ded_02_amt,
MIN(wind_coverage_ind) as wind_coverage_ind,
MIN(building_credit_code_code) as building_credit_code_code,
MIN(tico_law_ordinance_cov_code) as tico_law_ordinance_cov_code,
MIN(sprinkler_credit_ind) as sprinkler_credit_ind,
MIN(property_protection_ind) as property_protection_ind,
MIN(tenure_discount_code) as tenure_discount_code,
MIN(tenure_discount_amt) as tenure_discount_amt,
MIN(replacement_cov_limit_ind) as replacement_cov_limit_ind,
MIN(replace_cov_limit_disc_code) as replace_cov_limit_disc_code,
MIN(naics_code) as naics_code,
MIN(policy_period_join_id) as policy_period_join_id from
(
select
 
stat_plan_name
,suggestion_txt
,case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date
,record_type_code
,policy_num
,tico_term_code
,concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),9,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_dt
,concat(substr(cast(src_tab.exp_date as string),6,2),substr(cast(src_tab.exp_date as string),4,1)) as exp_dt
,place_code
,cast(cast(round(cast(insurance_amt as double) / 1000) as integer) as string) as insurance_amt_1
,fire_flex_code
,tico_line_of_busn_code
,tico_co.alt_code
,individual_optnl_credit_code
,prem_srchg_claim_made_ind
,prem_cert_reduction_code
,policy_form_code
,family_occupancy_cnt_code
,occupancy_code
,tico_constr.alt_code as construction_code
,case when tico_ppc.alt_code is not null then tico_ppc.alt_code
else '00'
end  as iso_ppc_new_split_class_code
,iso_ppc_code
,case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
      when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else '0'
end as deduct_01_type_code	
,case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528') THEN '7' when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else '0'
end as deduct_02_type_code	 
,prem_amt
,prem_flex_pct_code
,special_endorsement_code
,extended_coverage_prem_amt
,tico_allied_line_of_busn_code
,pl_property_insur_amt
,allied_prem_credit_amt
,optional_credit_amt
,roof_cover_code
,roof_cover_credit_code
,roof_instl_year
,excl_cosmetic_roof_dmg_ind
,zip_code
,rpt_type_code
,optnl_cov_endorsement_code
,cast(optnl_cov_endorsement_code_amt as decimal (6,0)) as optnl_cov_endorsement_code_amt
,hoa_attached_ind,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then 0 when wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '0' else cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) end as ded_01_amt,
case when policy_form_code in ('H','J') and wind_coverage_ind = '1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '7' else cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) end as ded_02_amt,
case when wind_coverage_ind='1' and substring(place_code,1,3) IN ('007','008','039','040','057','058','061','062','071','072','167','168','245','246','261','262','273','274','321','322','355','356','391','392','409','410','489','490','512','515','522','526','528')  THEN '1' else '0' end as wind_coverage_ind
,building_credit_code_code
,tico_law_ordinance_cov_code
,sprinkler_credit_ind
,property_protection_ind
,tenure_discount_code
,tenure_discount_amt
,replacement_cov_limit_ind
,replace_cov_limit_disc_code
,naics_code
,policy_period_join_id


from $V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO')tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-FIRECD')tico_ppc
on src_tab.iso_ppc_new_split_class_code=tico_ppc.code
where extract_type_name='TICO-MNTH-HOPREM'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
and record_type_code='06' /*and policy_num='1000296077'*/
)sq
group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b where prem_amt not between -9999 and 9999 group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code
)a),
totalpremamt06_final as (select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
-9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from totalpremamt06 where prem_amt < 0 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b


union all

select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
prem_amt+9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from totalpremamt06 where prem_amt < 0 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b
union all
select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from totalpremamt06 where prem_amt > 0 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b


union all

select distinct * from(
select
concat(
lpad(case when MIN(stat_plan_name)='' or MIN(stat_plan_name) is null then '0' else MIN(stat_plan_name) end,1,'0'),
lpad(case when MIN(suggestion_txt)='' or MIN(suggestion_txt) is null then '0' else MIN(suggestion_txt) end,1,'0'),
lpad(case when MIN(accounting_date)='' or MIN(accounting_date) is null then '00' else MIN(accounting_date) end,2,'0'),
lpad(case when MIN(record_type_code)='' or MIN(record_type_code) is null then '00' else MIN(record_type_code) end,2,'0'),
lpad(case when MIN(policy_num)='' or MIN(policy_num) is null then '0000000000' else MIN(policy_num) end,10,'0'),
lpad(case when MIN(tico_term_code)='' or MIN(tico_term_code) is null then '0' else MIN(tico_term_code) end,1,'0'),
lpad(case when MIN(eff_dt)='' or MIN(eff_dt) is null then '00000' else MIN(eff_dt) end,5,'0'),
lpad(case when MIN(exp_dt)='' or MIN(exp_dt) is null then '000' else MIN(exp_dt) end,3,'0'),
lpad(case when MIN(place_code)='' or MIN(place_code) is null then '00000' else MIN(place_code) end,5,'0'),
'000',
lpad(case when MIN(insurance_amt_1)='' or MIN(insurance_amt_1) is null then '0000' else
MIN(
case when cast(insurance_amt_1 as double) < 0 then
concat(
substr(insurance_amt_1,2,length(insurance_amt_1)-2),
 CASE substr(insurance_amt_1,length(insurance_amt_1),length(insurance_amt_1)+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
) 
else insurance_amt_1
end)
end,4,'0'),
lpad(case when MIN(fire_flex_code)='' or MIN(fire_flex_code) is null then '000' else MIN(fire_flex_code) end,3,'0'),
lpad(case when MIN(tico_line_of_busn_code)='' or MIN(tico_line_of_busn_code) is null then '00' else MIN(tico_line_of_busn_code) end,2,'0'),
lpad(case when MIN(alt_code)='' or MIN(alt_code) is null or MIN(alt_code)='NA' then '000' else MIN(alt_code) end,3,'0'),
lpad(case when MIN(individual_optnl_credit_code)='' or MIN(individual_optnl_credit_code) is null then '00' else MIN(individual_optnl_credit_code) end,2,'0'),
lpad(case when MIN(prem_srchg_claim_made_ind)='' or MIN(prem_srchg_claim_made_ind) is null then '0' else MIN(prem_srchg_claim_made_ind) end,1,'0'),
lpad(case when MIN(prem_cert_reduction_code)='' or MIN(prem_cert_reduction_code) is null then '0' else MIN(prem_cert_reduction_code) end,1,'0'),
lpad(case when MIN(policy_form_code)='' or MIN(policy_form_code) is null then '0' else MIN(policy_form_code) end,1,'0'),
lpad(case when MIN(family_occupancy_cnt_code)='' or MIN(family_occupancy_cnt_code) is null then '0' else MIN(family_occupancy_cnt_code) end,1,'0'),
lpad(case when MIN(occupancy_code)='' or MIN(occupancy_code) is null then '0' else MIN(occupancy_code) end,1,'0'),
lpad(case when MIN(construction_code)='' or MIN(construction_code) is null then '0' else MIN(construction_code) end,1,'0'),
lpad(case when MIN(iso_ppc_new_split_class_code)='' or MIN(iso_ppc_new_split_class_code) is null then '00' else MIN(iso_ppc_new_split_class_code) end,2,'0'),
lpad(case when MIN(iso_ppc_code)='' or MIN(iso_ppc_code) is null then '0' else MIN(iso_ppc_code) end,1,'0'),
MIN(deduct_01_type_code),
MIN(deduct_02_type_code),
lpad(case when MIN(prem_amt)='' or MIN(prem_amt) is null then '0000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))) -2),

CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)

else

cast (cast (round(sum(cast (prem_amt as double))) as integer) as string) end
end,4,'0'),

lpad(case when MIN(prem_flex_pct_code)='' or MIN(prem_flex_pct_code) is null then '000' else MIN(prem_flex_pct_code) end,3,'0'),
lpad(case when MIN(special_endorsement_code)='' or MIN(special_endorsement_code) is null then '0' else MIN(special_endorsement_code) end,1,'0'),
'0000000000000',
lpad(case when MIN(optional_credit_amt)='' or MIN(optional_credit_amt) is null then '000' else MIN(optional_credit_amt) end,3,'0'),
'0',
'00000',
lpad(case when MIN(excl_cosmetic_roof_dmg_ind)='' or MIN(excl_cosmetic_roof_dmg_ind) is null then '0' else MIN(excl_cosmetic_roof_dmg_ind) end,1,'0'),
'0',
lpad(case when MIN(zip_code)='' or MIN(zip_code) is null then '000000000' else MIN(zip_code) end,9,'0'),
lpad(case when MIN(rpt_type_code)='' or MIN(rpt_type_code) is null then '0' else MIN(rpt_type_code) end,1,'0'),
rpad(case when MIN(optnl_cov_endorsement_code)='' or MIN(optnl_cov_endorsement_code) is null then '00000000' else MIN(optnl_cov_endorsement_code) end,8,'0'),
lpad(case when MIN(optnl_cov_endorsement_code_amt)='' or MIN(optnl_cov_endorsement_code_amt) is null then '000000' else MIN(optnl_cov_endorsement_code_amt) end,6,'0'),
lpad(case when MIN(hoa_attached_ind)='' or MIN(hoa_attached_ind) is null then '0' else MIN(hoa_attached_ind) end,1,'0'),
lpad(case when MIN(ded_01_amt)='' or MIN(ded_01_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_01_amt as double)) as integer) as string) ) end,6,'0'),
lpad(case when MIN(ded_02_amt)='' or MIN(ded_02_amt) is null then '000000' else MIN(cast(cast(round(cast(ded_02_amt as double)) as integer) as string)) end,6,'0'),
lpad(case when MIN(wind_coverage_ind)='' or MIN(wind_coverage_ind) is null then '0' else MIN(wind_coverage_ind) end,1,'0'),
'00000',
lpad(case when MIN(building_credit_code_code)='' or MIN(building_credit_code_code) is null then '00' else MIN(building_credit_code_code) end,2,'0'),
lpad(case when MIN(tico_law_ordinance_cov_code)='' or MIN(tico_law_ordinance_cov_code) is null then '0' else MIN(tico_law_ordinance_cov_code) end,1,'0'),
lpad(case when MIN(sprinkler_credit_ind)='' or MIN(sprinkler_credit_ind) is null then '0' else MIN(sprinkler_credit_ind) end,1,'0'),
'0',
lpad(case when MIN(property_protection_ind)='' or MIN(property_protection_ind) is null then '0' else MIN(property_protection_ind) end,1,'0'),
lpad(case when MIN(tenure_discount_code)='' or MIN(tenure_discount_code) is null then '0' else MIN(tenure_discount_code) end,1,'0'),
lpad(case when MIN(tenure_discount_amt)='' or MIN(tenure_discount_amt) is null then '00' else MIN(tenure_discount_amt) end,2,'0'),
lpad(case when MIN(replacement_cov_limit_ind)='' or MIN(replacement_cov_limit_ind) is null then '0' else MIN(tenure_discount_amt) end,1,'0'),
lpad(case when MIN(replace_cov_limit_disc_code)='' or MIN(replace_cov_limit_disc_code) is null then '00' else MIN(replace_cov_limit_disc_code) end,2,'0'),
lpad(case when MIN(naics_code)='' or MIN(naics_code) is null then '00000' else MIN(naics_code) end,5,'0'),
'~',
MIN(policy_period_join_id)
)
from ( 
select stat_plan_name,
suggestion_txt,
accounting_date,
record_type_code,
policy_num,
tico_term_code,
eff_dt,
exp_dt,
place_code,
insurance_amt_1,
fire_flex_code,
tico_line_of_busn_code,
alt_code,
individual_optnl_credit_code,
prem_srchg_claim_made_ind,
prem_cert_reduction_code,
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
deduct_01_type_code,
deduct_02_type_code,
prem_amt-9999 as prem_amt,
prem_flex_pct_code,
special_endorsement_code,
optional_credit_amt,
excl_cosmetic_roof_dmg_ind,
zip_code,
rpt_type_code,
optnl_cov_endorsement_code,
optnl_cov_endorsement_code_amt,
hoa_attached_ind,
ded_01_amt,
ded_02_amt,
wind_coverage_ind,
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code,
policy_period_join_id from totalpremamt06 where prem_amt > 0 ) a group by policy_period_join_id,accounting_date,record_type_code,optnl_cov_endorsement_code ) b) 
select * from totalpremamt06_final
" >> /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"

else 

info "ERROR : Extract file generation failed !!";

fi

if [ $? == 0 ]

then info "TICO HO Premium file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

cat /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}" | cut -d~ -f1 > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"

if [ $? == 0 ]

then rm /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"

fi


info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "TICO HO Premium file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
