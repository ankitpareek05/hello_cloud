#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : populate_table.sh                                            #
#                                                                             #
# Description  : Script to populate the data from stage to Transformation/    #
#		 Curation Layer	                                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1

#########Remove the feeder system from the hive table name####

START_time="`date +"%Y-%m-%d %H:%M:%S"`"
export Start_time=$START_time

	info "Running  spark submit for transformation layer"
	spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.sql.broadcastTimeout=30000 --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --master yarn --deploy-mode client --driver-memory 10G --executor-memory 50G --executor-cores 10 --conf spark.driver.maxResultSize=5G --conf spark.sql.crossJoin.enabled=true --conf spark.sql.shuffle.partitions=800 --class com.curation.Curation ${JAR_PATH}/datalake_transform-assembly-2.0.0.jar -c ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml  >> ${v_Log} 2>&1
	   
status=$?
	if [ $status -ne 0 ]
        	then
        	        info "spark submit failed"
					exit 1
	else
        	info "Status : $status"
			info "Load completed successfully!!!!!" >>  ${v_Log} 2>&1
			exit 0
	fi

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1


