#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : agency_reconciliation.sh                                     #
#                                                                             #
# Description  : Script to reconcile agency data from stage to Transformation #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1

echo "Starting spark submit"


spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --master yarn --deploy-mode client --num-executors 6 --driver-memory 3G --executor-memory 36G --executor-cores 6 --class com.curation.Curation /home/hadoop/transform/jars/curation_retro-1.0-SNAPSHOT-jar-with-dependencies.jar -c ${YAML_PATH}/transform_agency_transform_reconc.yaml >> ${v_Log} 2>&1

#status=$?
#if [ $status -ne 0 ]
#   info "spark submit failed, exiting"
#   exit 1
#else
   info "Spark successfully completed">> ${v_Log} 
   echo "Spark successfully completed" >> ${v_Log} 
  
##############################################################################################################################################################
CRT_UPD_TS=$(date "+%Y-%m-%d %T.%3N")
  
hive -e "INSERT INTO ${V_TRNS_DB}.transform_reconc_hist select cast('$CRT_UPD_TS' as timestamp) as extractdate,* from ${V_TRNS_DB}.transform_reconc where source ='AGENCY';"
if [[ ${?} -eq 0 ]] ; then
info "insert is successful for the table transform_reconc_hist"
else
info "insert is failed for the table transform_reconc_hist"
fi
##############################################################################################################################################################
##############################################################################################################################################################
src_agency=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='agency' and system = 'SOURCE'"`
tgt_agency=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='agency' and system = 'TARGET'"`

if [ $src_agency != $tgt_agency ]
then
   info "Agency count not matching"
   query_string[0]="Agency count not matching" 
   flag="failed"
else
   info "Agency count matching" >>  ${v_Log} 2>&1
   query_string[0]="Agency count matching" 
   flag="success"
fi
#############################################
src_agency_hierarchy=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='agency_hierarchy' and system = 'SOURCE'"`
tgt_agency_hierarchy=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='agency_hierarchy' and system = 'TARGET'"`

if [ $src_agency_hierarchy != $tgt_agency_hierarchy ]
then
   info "Agency hierarchy count not matching"
   query_string[1]="Agency hierarchy count not matching" 
   flag="failed"
else
   info "Agency hierarchy count matching" >>  ${v_Log} 2>&1
   query_string[1]="Agency hierarchy count matching" 
   flag="success"
fi
#############################################
echo $flag  >>  ${v_Log} 2>&1

if [ $flag = 'success' ]
then
	for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email Success for New account Agency Tranform Reconciliation" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com;
   info "Email Sent successfully" >> ${v_Log} 2>&1
   info "Processing completed successfully" >> ${v_Log} 2>&1
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for New account Agency Tranform Reconciliation" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Failed!!!!!" >>  ${v_Log} 2>&1
   exit 0
fi
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
