#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : populate_curation.sh                                         #
#                                                                             #
# Description  : Script to populate the data from stage to Transformation/    #
#		 Curation Layer	                                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

echo "Starting spark submit"

#v_delta_column_value=`hive -S -e "SELECT delta_value FROM ${V_TRNS_DB}.CURATION_STATS where layer_name='$LAYER_NAME' and table_name='$TARGET_TABLE' and status='SUCCESSFUL' order by delta_value desc limit 1"`

spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --master yarn --deploy-mode cluster --num-executors 10 --driver-memory 30G --executor-memory 30G --executor-cores 5 --conf spark.executor.memoryOverhead=3g --name transform_${V_TARGET_TABLE} --files /home/hadoop/transform/yaml/*.yaml,/etc/spark/conf/hive-site.xml --class com.curation.Curation /home/hadoop/transform/jars/datalake_transform-assembly-2.0.0.jar -c transform_${V_TARGET_TABLE}.yaml >> ${v_Log} 2>&1

#status=$?
#if [ $status -ne 0 ]
#   info "spark submit failed, exiting"
#   exit 1
#else
   info "Spark successfully completed">> ${v_Log} 
   echo "Spark successfully completed" >> ${v_Log} 
  

##############################################################################################################################################################   
#`hive -S -e "INSERT INTO ${V_TRNS_DB}.transform_reconc_hist select current_timestamp,* from ${V_TRNS_DB}.transform_reconc where source ='LGCY'"`

CRT_UPD_TS=$(date "+%Y-%m-%d %T.%3N")
  
hive -e "INSERT INTO ${V_TRNS_DB}.transform_reconc_hist select cast('$CRT_UPD_TS' as timestamp) as extractdate,* from ${V_TRNS_DB}.transform_reconc where  source ='LGCY';"
if [[ ${?} -eq 0 ]] ; then
info "insert is successful for the table transform_reconc_hist"
else
info "insert is failed for the table transform_reconc_hist"
fi
##############################################################################################################################################################

src_wel2_prem_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='wel2_prem_eom' and system = 'SOURCE'"`
tgt_wel2_prem_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='wel2_prem_eom' and system = 'TARGET'"`
if [ $src_wel2_prem_eom -ne $tgt_wel2_prem_eom ]
then
   info "wel2 prem eom count not matching"
   query_string[0]="wel2 prem eom count not matching" 
   flag_1="failed"
else
   info "wel2 prem eom count matching" ${v_Log} 
   echo "wel2 prem eom count matching" >> ${v_Log} 
   flag_1="success"
fi
#############################################
src_lgcy_prem_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_prem_eom' and system = 'SOURCE'"`
tgt_lgcy_prem_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_prem_eom' and system = 'TARGET'"`
if [ $src_lgcy_prem_eom -ne $tgt_lgcy_prem_eom ]
then
   info "lgcy prem eom count not matching"
   query_string[1]="lgcy prem eom count not matching" 
   flag_2="failed"
else
   info "lgcy prem eom count matching" >>  ${v_Log} 2>&1
   flag_2="success"
fi
#############################################
src_wel2_loss_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='wel2_loss_eom' and system = 'SOURCE'"`
tgt_wel2_loss_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='wel2_loss_eom' and system = 'TARGET'"`
if [ $src_wel2_loss_eom -ne $tgt_wel2_loss_eom ]
then
   info "wel2 loss eom count not matching"
   query_string[2]="wel2 loss eom count not matching" 
   flag_3="failed"
else
   info "wel2 loss eom count matching" >>  ${v_Log} 2>&1
   flag_3="success"
fi
#############################################
src_lgcy_policy_inforce_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_policy_inforce_eom' and system = 'SOURCE'"`
tgt_lgcy_policy_inforce_eom=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_policy_inforce_eom' and system = 'TARGET'"`
if [ $src_lgcy_policy_inforce_eom -ne $tgt_lgcy_policy_inforce_eom ]
then
   info "lgcy policy inforce eom count not matching"
   query_string[3]="lgcy policy inforce eom count not matching" 
   flag_4="failed"
else
   info "lgcy policy inforce eom count matching" >>  ${v_Log} 2>&1
   flag_4="success"
fi
#############################################
src_lgcy_loss_exposure_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_loss_exposure_common' and system = 'SOURCE'"`
tgt_lgcy_loss_exposure_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_loss_exposure_common' and system = 'TARGET'"`
if [ $src_lgcy_loss_exposure_common -ne $tgt_lgcy_loss_exposure_common ]
then
   info "lgcy loss exposure common count not matching"
   query_string[4]="lgcy loss exposure common count not matching" 
   flag_5="failed"
else
   info "lgcy loss exposure common count matching" >>  ${v_Log} 2>&1
   flag_5="success"
fi
#############################################
src_coverage_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='coverage_common' and system = 'SOURCE'"`
tgt_coverage_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='coverage_common' and system = 'TARGET'"`
if [ $src_coverage_common -ne $tgt_coverage_common ]
then
   info "coverage common count not matching"
   query_string[5]="coverage common count not matching" 
   flag_6="failed"
else
   info "coverage common count matching" >>  ${v_Log} 2>&1
   flag_6="success"
fi
#############################################
src_lgcy_claim_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_claim_common' and system = 'SOURCE'"`
tgt_lgcy_claim_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_claim_common' and system = 'TARGET'"`
if [ $src_lgcy_claim_common -ne $tgt_lgcy_claim_common ]
then
   info "lgcy claim common not matching"
   query_string[6]="lgcy claim common count not matching" 
   flag_7="failed"
else
   info "lgcy claim common count matching" >>  ${v_Log} 2>&1
   flag_7="success"
fi
#############################################
src_lgcy_policy_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_policy_common' and system = 'SOURCE'"`
tgt_lgcy_policy_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='lgcy_policy_common' and system = 'TARGET'"`
if [ $src_lgcy_policy_common -ne $tgt_lgcy_policy_common ]
then
   info "lgcy policy common not matching"
   query_string[7]="lgcy policy common count not matching" 
   flag_8="failed"
else
   info "lgcy policy common count matching" >>  ${v_Log} 2>&1
   flag_8="success"
fi
#############################################
if  ( [ $flag_1 == "success" ] && [ $flag_2 == 'success' ] && [ $flag_3 = 'success' ] && [ $flag_4 = 'success' ] && [ $flag_5 = 'success' ] && [ $flag_6 = 'success' ] && [ $flag_7 = 'success' ] && [ $flag_8 = 'success' ] )
then
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email Success for new account Legacy" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com,shijas.km@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing completed successfully" >>  ${v_Log} 2>&1
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for new account Legacy" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com,shijas.km@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Failed" >>  ${v_Log} 2>&1
   exit 1
fi
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
