#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO PASP No Fault Prem extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO PASP No Fault Prem file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/PASP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="PASP_AUTO_PREM_NOFAULT_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO PASP No Fault Prem"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
with mcca as 
(select policy_num,sum(cast (nofault_prem_amt as decimal(19,2))) as prem from ${transform_db}.iso_pasp_auto where iso_extract_type_name='PASP-PREM'  and state_code ='21' and coverage_join_id is null group by policy_num)
,prem_trans as (
select policy_num,transaction_key,cost_key,prem_Amt,count() over (partition by policy_num order by policy_num) as cnt from(
select distinct policy_num,transaction_key,cost_key,cast (nofault_prem_amt as decimal(19,2)) prem_Amt from ${transform_db}.iso_pasp_auto where iso_extract_type_name='PASP-PREM' and state_code ='21' and coverage_join_id is not null and policy_num in (select policy_num from mcca) )q)
, merged_trans as 
(select prem_trans.policy_num,transaction_key,cost_key,prem_Amt+prem/cnt as merged_prem from prem_trans,mcca where prem_trans.policy_num = mcca.policy_num)
,iso_pasp_auto_new as (
select  accounting_date , iso_pasp_auto.policy_num , cast(merged_prem as varchar(255)) nofault_prem_amt,policy_join_id , iso_extract_type_name ,iso_pasp_auto.transaction_key , iso_pasp_auto.cost_key 
from ${transform_db}.iso_pasp_auto join merged_trans on
iso_pasp_auto.transaction_key = merged_trans.transaction_key and iso_pasp_auto.cost_key = merged_trans.cost_key and iso_extract_type_name='PASP-PREM' 
union all
select  accounting_date , iso_pasp_auto.policy_num , nofault_prem_amt , policy_join_id , iso_extract_type_name, iso_pasp_auto.transaction_key , iso_pasp_auto.cost_key
from ${transform_db}.iso_pasp_auto
left join (select distinct policy_num from merged_trans)merged_trans on merged_trans.policy_num=iso_pasp_auto.policy_num 
where iso_extract_type_name='PASP-PREM' and merged_trans.policy_num is null)
,no_fault_prem as 
(select policy_num,policy_join_id,transaction_key,cost_key,sum(cast(nofault_prem_amt as decimal(19,2))) as nofault_prem_amt1,cast(round(sum(cast(nofault_prem_amt as decimal(19,2)))) as integer) as final_prem_amt from (
select distinct policy_num,policy_join_id,transaction_key,cost_key,nofault_prem_amt,date_format(accounting_date,'%Y%m') accounting_date from iso_pasp_auto_new where iso_extract_type_name='PASP-PREM' ) new
group by policy_num,policy_join_id,transaction_key,cost_key)
select lpad(coalesce(ISO_PASP_Auto.Statistical_Plan_ind_code,' '),1,' ') as Statistical_Plan_ind_code,
lpad(coalesce(ISO_PASP_Auto.ISO_Transaction_Type_code,' '),1,' ') as ISO_Transaction_Type_code,
'  ' as Reserved_01,
lpad(coalesce(refcomp.alt_code,'    '),4,' ') as company_num,
lpad(coalesce(ISO_PASP_Auto.Record_type_code,' '),1,' ') as Record_type_code,
concat(substr(cast(accounting_date as varchar(255)),5,2),substr(cast(accounting_date as varchar(255)),1,4)) as accounting_date,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.Inception_date as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.Inception_date as varchar(25)),1,4)),'      '),6,' ') as Inception_date,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.transaction_eff_date as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.transaction_eff_date as varchar(25)),9,2),substr(cast(ISO_PASP_Auto.transaction_eff_date as varchar(25)),1,4)),'        '),8,' ') as transaction_eff_date,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.transaction_exp_date as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.transaction_exp_date as varchar(25)),9,2),substr(cast(ISO_PASP_Auto.transaction_exp_date as varchar(25)),1,4)),'        '),8,' ') as transaction_exp_date,
lpad(coalesce(cast(ISO_PASP_Auto.state_code as varchar(2)),'  '),2,' ') as state_code,
case when ISO_PASP_Auto.state_code ='03' then '   ' else case when ltrim(rtrim(ISO_PASP_Auto.Territory_code))='' or ISO_PASP_Auto.Territory_code is null then '   ' else lpad(ISO_PASP_Auto.Territory_code,3,'0') end end as territory_code,
case when ISO_PASP_Auto.state_code ='03' then '     ' when lpad(coalesce(ISO_PASP_Auto.Territory_code,'   '),3,'0')='050' then '     ' else lpad(coalesce(substr(ISO_PASP_Auto.Zip_code,1,5),'     '),5,' ') end as zip_code,
'    ' as Reserved_03,
lpad(coalesce(ISO_PASP_Auto.busn_type_code,' '),1,' ') as Type_of_Business_Code,
lpad(coalesce(cast(ISO_PASP_Auto.Policy_Type_code as varchar(2)),'  '),2,' ') as Type_of_Policy_Code,
' ' as Reserved_04,
case when lkp.misc_classcd is not null or ltrim(rtrim(lkp.misc_classcd))!='' then lpad(coalesce(lkp.misc_classcd,'000000'),6,'0') else concat(lpad(coalesce(lkp.CLASSIF_CD_14,'0000'),4,'0'),lpad(coalesce(lkp.CLASSIF_CD_56,'00'),2,'0')) end as Classif_code,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.Vehicle_Motorcycle_cnt_code,' '),1,' ') end as Vehicle_Motorcycle_cnt_code,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.Vehicle_W_Youthful_Cnt_code,'0'),1,'0') end as Vehicle_W_Youthful_Cnt_code,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.Operators_cnt,' '),1,' ') end as Operators_cnt,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.vehicle_operator_cnt,' '),1,' ') end as Number_of_Operators_of_Vehicle,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.principal_operator_code,' '),1,' ') end as Principal_Operator_code,
case when ISO_PASP_Auto.state_code ='03' then '        ' else lpad(coalesce(ISO_PASP_Auto.Age,'        '),8,' ') end as Age,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.Gender_code,' '),1,' ') end as Gender_code,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.Marital_Status_code,' '),1,' ') end as Marital_Status_code,
case when ISO_PASP_Auto.state_code ='03' then ' ' else lpad(coalesce(ISO_PASP_Auto.Vehicle_Use_code,' '),1,' ') end as Vehicle_Use_code,
'   ' as Reserved_05,
case when ISO_PASP_Auto.state_code ='03' then '  ' else case when (ISO_PASP_Auto.Estimated_Annual_Mileage is null or ltrim(rtrim(ISO_PASP_Auto.Estimated_Annual_Mileage))='') then '99' else lpad(coalesce(ISO_PASP_Auto.Estimated_Annual_Mileage,'00'),2,'0') end end as Estimated_Annual_Mileage,
lpad(coalesce(ISO_PASP_Auto.Persistency,'      '),6,' ') as Persistency,
' ' as Reserved_06,
lpad(coalesce(ISO_PASP_Auto.Driver_Licensed_date_code,'      '),6,' ') as Driver_Licensed_date_code,
lpad(coalesce(ISO_PASP_Auto.Traffic_Conviction_cnt,'  '),2,' ') as Traffic_Conviction_cnt,
/*lpad(coalesce(ISO_PASP_Auto.Traffic_Convict_Major_cnt,'00'),2,' ')*/ '00' as Traffic_Convict_Major_cnt,
case when ISO_PASP_Auto.state_code ='03' then '  ' else lpad(coalesce(ISO_PASP_Auto.Traffic_Convict_Minor_cnt,'00'),2,'0') end as Traffic_Convict_Minor_cnt,
lpad(coalesce(ISO_PASP_Auto.Chrgbl_AtFault_Accident_Cnt,'  '),2,' ') as Chrgbl_AtFault_Accident_Cnt,
case when ISO_PASP_Auto.state_code ='03' then '  ' else lpad(coalesce(ISO_PASP_Auto.AtFault_Accident_BI_cnt,'00'),2,'0') end as AtFault_Accident_BI_cnt,
case when ISO_PASP_Auto.state_code ='03' then '  ' else lpad(coalesce(ISO_PASP_Auto.Chrgbl_AtFlt_Accdnt_PD_Cnt,'00'),2,'0') end as Chrgbl_AtFlt_Accdnt_PD_Cnt,
lpad(coalesce(ISO_PASP_Auto.Good_Driver_Discount_code,' '),1,' ') as Good_Driver_Discount_code,
lpad(coalesce(ISO_PASP_Auto.Driver_Traing_Discount_code,' '),1,' ') as Driver_Traing_Discount_code,
lpad(coalesce(ISO_PASP_Auto.Good_Student_Discount_Code,' '),1,' ') as Good_Student_Discount_Code,
lpad(coalesce(ISO_PASP_Auto.Defensive_Driver_Discnt_Code,' '),1,' ') as Defensive_Driver_Discnt_Code,
lpad(coalesce(ISO_PASP_Auto.AntiLock_Brake_Discnt_Code,' '),1,' ') as AntiLock_Brake_Discnt_Code,
' ' as Multi_car_Discount_code,
'   ' as Reserved_07,
lpad(coalesce(ISO_PASP_Auto.Rate_Level_ind_code,' '),1,' ') as Rate_Level_ind_code,
lpad(coalesce(ISO_PASP_Auto.Point_Forgiveness_code,' '),1,' ') as Point_Forgiveness_code,
lpad(coalesce(ISO_PASP_Auto.Daytime_Lights_Discnt_Code,' '),1,' ') as Daytime_Lights_Discnt_Code,
lpad(coalesce(ISO_PASP_Auto.Model_Year_code,'    '),4,' ') as Model_Year_code,
rpad(coalesce(ISO_PASP_Auto.vin,'                 '),17,' ') as Vin,
lpad(coalesce(ISO_PASP_Auto.Policy_num,'                    '),20,'0') as Policy_num,
'                              ' as Reserved_08,
'   ' as Reserved_09,
' ' as Reserved_10,
lpad(coalesce(ISO_PASP_Auto.AtFault_BI_Sec_Addl_Drv_cnt,'  '),2,' ') as AtFault_BI_Sec_Addl_Drv_cnt,
lpad(coalesce(ISO_PASP_Auto.Chrgbl_AtFlt_PD_sec_drvr_Cnt,'  '),2,' ') as Chrgbl_AtFlt_PD_sec_drvr_Cnt,
lpad(coalesce(ISO_PASP_Auto.Frst_Addl_Drv_PRNCPL_OPRTR_Cd,' '),1,' ') as Frst_Addl_Drv_PRNCPL_OPRTR_Cd,
lpad(coalesce(ISO_PASP_Auto.Sec_Addl_Drv_PRNCPL_OPRTR_Cd,' '),1,' ') as Sec_Addl_Drv_PRNCPL_OPRTR_Cd,
lpad(coalesce(ISO_PASP_Auto.ISO_PASP_Subline_Code,'   '),3,' ') as ISO_PASP_Subline_Code,
'  ' as Reserved_10_1,
case when ISO_PASP_Auto.state_code ='45' then '   ' else lpad(lpad(coalesce(case when lkp.NF_COV_CODE='NA' then '00' else lkp.NF_COV_CODE end,'00'),2,'0'),3,' ') end as NoFault_Coverage_Code,
lpad(coalesce(ISO_PASP_Auto.Coordinat_NoFault_Benefit_Code,'  '),2,' ') as Coordinat_NoFault_Benefit_Code,
lpad(coalesce(ISO_PASP_Auto.NoFault_Deductible_Type_Code,'  '),2,' ') as NoFault_Deductible_Type_Code,
' ' as Reserved_11,
lpad(coalesce(case when lkp.NF_DED_AMT='NA' then '' else lkp.NF_DED_AMT end,'    '),4,' ') as NoFault_deduct_amt,
lpad(coalesce(ISO_PASP_Auto.NoFault_classif_code,'  '),2,' ') as NoFault_classif_code,
lpad(coalesce(ISO_PASP_Auto.NoFault_CoPayment_Type_code,' '),1,' ') as NoFault_CoPayment_Type_code,
lpad(coalesce(ISO_PASP_Auto.NoFault_CoPayment_amt,'   '),3,' ') as NoFault_CoPayment_amt,
'                               ' as Reserved_12,
case when ISO_PASP_Auto.state_code ='03' then ' ' when ltrim(rtrim(upper(ISO_PASP_Auto.vehicle_type_code))) = ltrim(rtrim(upper('motorCycle'))) then lpad(coalesce(ISO_PASP_Auto.Passive_Restraint_code,' '),1,' ')  when (ISO_PASP_Auto.Passive_Restraint_code is null or ltrim(rtrim(ISO_PASP_Auto.Passive_Restraint_code))='') then '1' else lpad(coalesce(ISO_PASP_Auto.Passive_Restraint_code,' '),1,' ') end as Passive_Restraint_code,
' ' as Reserved_13,
case when ISO_PASP_Auto.state_code ='22' then ' 1' when ISO_PASP_Auto.ISO_PASP_Subline_Code='504' then lpad(st_exception.State_Exception_code,2,' ') else lpad(coalesce(ISO_PASP_Auto.State_Exception_code,'  '),2,' ') end as State_Exception_code,
'        ' as Reserved_14,
lpad(coalesce(ISO_PASP_Auto.AtFault_BI_Frst_Addl_Drv_cnt,'  '),2,' ') as AtFault_BI_Frst_Addl_Drv_cnt,
lpad(coalesce(ISO_PASP_Auto.AtFault_PD_Frst_Addl_Drvr_cnt,'  '),2,' ') as AtFault_PD_Frst_Addl_Drvr_cnt,
lpad(coalesce(ISO_PASP_Auto.Frst_Addl_Drv_Licensed_Dt_Cd,'      '),6,' ') as Frst_Addl_Drv_Licensed_Dt_Cd,
lpad(coalesce(ISO_PASP_Auto.Sec_Addl_Drv_Licensd_Dt_Cd,'      '),6,' ') as Sec_Addl_Drv_Licensd_Dt_Cd,
lpad(coalesce(ISO_PASP_Auto.ELGBL_Point_Frst_Addl_Drv_Code,'  '),2,' ') as ELGBL_Point_Frst_Addl_Drv_Code,
lpad(coalesce(ISO_PASP_Auto.ELGBL_Points_Sec_Addl_Drv_Code,'  '),2,' ') as ELGBL_Points_Sec_Addl_Drv_Code,
lpad(coalesce(ISO_PASP_Auto.Frst_Addl_Drv_Pnt_Frgv_Code,' '),1,' ') as Frst_Addl_Drv_Pnt_Frgv_Code,
lpad(coalesce(ISO_PASP_Auto.Sec_Addl_Drv_Pnt_Frgv_Code,' '),1,' ') as Sec_Addl_Drv_Pnt_Frgv_Code,
' ' as Reserved_15,
lpad(case when ISO_PASP_Auto.nofault_prem_amt< 0 then
concat(substr(cast(ISO_PASP_Auto.nofault_prem_amt as string),2,length(cast(ISO_PASP_Auto.nofault_prem_amt as string))-2),
case substr(cast(ISO_PASP_Auto.nofault_prem_amt as string),length(cast(ISO_PASP_Auto.nofault_prem_amt as string)),
length(cast(ISO_PASP_Auto.nofault_prem_amt as string))+1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end
)
when ISO_PASP_Auto.nofault_prem_amt> 0 then
case when substr(cast(ISO_PASP_Auto.nofault_prem_amt as string),1,1)='+'then
concat(
substr(cast(ISO_PASP_Auto.nofault_prem_amt as string),2,length(cast(ISO_PASP_Auto.nofault_prem_amt as string))-2),
case substr(cast(ISO_PASP_Auto.nofault_prem_amt as string),length(cast(ISO_PASP_Auto.nofault_prem_amt as string)),length(cast(ISO_PASP_Auto.nofault_prem_amt as string))+1)
when '0' then '{'
when '1' then 'A'
when '2' then 'B'
when '3' then 'C'
when '4' then 'D'
when '5' then 'E'
when '6' then 'F'
when '7' then 'G'
when '8' then 'H'
when '9' then 'I'
end ) else cast(ISO_PASP_Auto.nofault_prem_amt as string) end else '00000000' end ,8,'0') as nofault_prem_amt,
lpad(coalesce(ISO_PASP_Auto.Annual_Statement_Line_code,'   '),3,' ') as Annual_Statement_Line_code
from 
(
select 
new.Policy_num,new.policy_join_id,new.Transaction_key,new.Cost_key,
new.Statistical_Plan_ind_code,
new.ISO_Transaction_Type_code,
new.company_num,
new.Record_type_code,
new.accounting_date,
new.Inception_date,
new.transaction_eff_date,
new.transaction_exp_date,
new.state_code,
new.territory_code as territory_code,
new.zip_code as zip_code,
new.busn_type_code,
new.Policy_Type_code,
new.Vehicle_Motorcycle_cnt_code as Vehicle_Motorcycle_cnt_code,
new.Vehicle_W_Youthful_Cnt_code as Vehicle_W_Youthful_Cnt_code,
new.Operators_cnt as Operators_cnt,
new.vehicle_operator_cnt as vehicle_operator_cnt,
new.principal_operator_code as principal_operator_code,
new.Age as Age,
new.Gender_code as Gender_code,
new.Marital_Status_code as Marital_Status_code,
new.Vehicle_Use_code as Vehicle_Use_code,
new.Estimated_Annual_Mileage as Estimated_Annual_Mileage,
case when new.state_code ='03' then null else new.Persistency end as Persistency,
case when new.state_code ='03' then null else new.Driver_Licensed_date_code end as Driver_Licensed_date_code,
case when new.state_code ='03' then null else new.Traffic_Conviction_cnt end as Traffic_Conviction_cnt,
case when new.state_code ='03' then null else new.Traffic_Convict_Major_cnt end as Traffic_Convict_Major_cnt,
case when new.state_code ='03' then null else new.Traffic_Convict_Minor_cnt end as Traffic_Convict_Minor_cnt,
case when new.state_code ='03' then null else new.Chrgbl_AtFault_Accident_Cnt end as Chrgbl_AtFault_Accident_Cnt,
case when new.state_code ='03' then null else new.AtFault_Accident_BI_cnt end as AtFault_Accident_BI_cnt,
case when new.state_code ='03' then null else new.Chrgbl_AtFlt_Accdnt_PD_Cnt end as Chrgbl_AtFlt_Accdnt_PD_Cnt,
case when new.state_code ='03' then null else new.Good_Driver_Discount_code end as Good_Driver_Discount_code,
case when new.state_code ='03' then null else new.Driver_Traing_Discount_code end as Driver_Traing_Discount_code,
case when new.state_code ='03' then null else new.Good_Student_Discount_Code end as Good_Student_Discount_Code,
case when new.state_code ='03' then null else new.Defensive_Driver_Discnt_Code end as Defensive_Driver_Discnt_Code,
case when new.state_code ='03' then null else new.AntiLock_Brake_Discnt_Code end as AntiLock_Brake_Discnt_Code,
case when new.state_code ='03' then null else new.Rate_Level_ind_code end as Rate_Level_ind_code,
case when new.state_code ='03' then null else new.Point_Forgiveness_code end as Point_Forgiveness_code,
case when new.state_code ='03' then null else new.Daytime_Lights_Discnt_Code end as Daytime_Lights_Discnt_Code,
case when new.state_code ='03' then null else new.Model_Year_code end as Model_Year_code,
case when new.state_code ='03' then null else new.Vin end as Vin,
case when new.state_code ='03' then null else new.AtFault_BI_Sec_Addl_Drv_cnt end as AtFault_BI_Sec_Addl_Drv_cnt,
case when new.state_code ='03' then null else new.Chrgbl_AtFlt_PD_sec_drvr_Cnt end as Chrgbl_AtFlt_PD_sec_drvr_Cnt,
case when new.state_code ='03' then null else new.Frst_Addl_Drv_PRNCPL_OPRTR_Cd end as Frst_Addl_Drv_PRNCPL_OPRTR_Cd,
case when new.state_code ='03' then null else new.Sec_Addl_Drv_PRNCPL_OPRTR_Cd end as Sec_Addl_Drv_PRNCPL_OPRTR_Cd,
new.ISO_PASP_Subline_Code,
case when new.state_code ='03' then null else new.NoFault_Coverage_Code end as NoFault_Coverage_Code,
case when new.state_code ='03' then null else new.Coordinat_NoFault_Benefit_Code end as Coordinat_NoFault_Benefit_Code,
case when new.state_code ='03' then null else new.NoFault_Deductible_Type_Code end as NoFault_Deductible_Type_Code,
case when new.state_code ='03' then null else new.NoFault_deduct_amt end as NoFault_deduct_amt,
case when new.state_code ='03' then null else new.NoFault_classif_code end as NoFault_classif_code,
case when new.state_code ='03' then null else new.NoFault_CoPayment_Type_code end as NoFault_CoPayment_Type_code,
case when new.state_code ='03' then null else new.NoFault_CoPayment_amt end as NoFault_CoPayment_amt,
case when new.state_code ='03' then null else new.Passive_Restraint_code end as Passive_Restraint_code,
case when new.state_code ='03' then null else new.State_Exception_code end as State_Exception_code,
case when new.state_code ='03' then null else new.AtFault_BI_Frst_Addl_Drv_cnt end as AtFault_BI_Frst_Addl_Drv_cnt,
case when new.state_code ='03' then null else new.AtFault_PD_Frst_Addl_Drvr_cnt end as AtFault_PD_Frst_Addl_Drvr_cnt,
case when new.state_code ='03' then null else new.Frst_Addl_Drv_Licensed_Dt_Cd end as Frst_Addl_Drv_Licensed_Dt_Cd,
case when new.state_code ='03' then null else new.Sec_Addl_Drv_Licensd_Dt_Cd end as Sec_Addl_Drv_Licensd_Dt_Cd,
case when new.state_code ='03' then null else new.ELGBL_Point_Frst_Addl_Drv_Code end as ELGBL_Point_Frst_Addl_Drv_Code,
case when new.state_code ='03' then null else new.ELGBL_Points_Sec_Addl_Drv_Code end as ELGBL_Points_Sec_Addl_Drv_Code,
case when new.state_code ='03' then null else new.Frst_Addl_Drv_Pnt_Frgv_Code end as Frst_Addl_Drv_Pnt_Frgv_Code,
case when new.state_code ='03' then null else new.Sec_Addl_Drv_Pnt_Frgv_Code end as Sec_Addl_Drv_Pnt_Frgv_Code,
no_fault_prem.final_prem_amt as nofault_prem_amt,
new.vehicle_type_code,
new.Annual_Statement_Line_code
from (
select  
Policy_num,policy_join_id,Transaction_key,Cost_key,
max(Statistical_Plan_ind_code) as Statistical_Plan_ind_code,
max(ISO_Transaction_Type_code) as ISO_Transaction_Type_code,
max(company_num) as company_num,
max(Record_type_code) as Record_type_code,
max(create_dateyyyymm) as accounting_date,
max(Inception_date) as Inception_date,
max(transaction_eff_date) as transaction_eff_date,
max(transaction_exp_date) as transaction_exp_date,
max(state_code) as state_code,
max(territory_code) as territory_code,
max(zip_code) as zip_code,
max(busn_type_code) as busn_type_code,
max(Policy_Type_code) as Policy_Type_code,
max(Vehicle_Motorcycle_cnt_code) as Vehicle_Motorcycle_cnt_code,
max(Vehicle_W_Youthful_Cnt_code) as Vehicle_W_Youthful_Cnt_code,
max(Operators_cnt) as Operators_cnt,
max(vehicle_operator_cnt) as vehicle_operator_cnt,
max(principal_operator_code) as principal_operator_code,
max(Age) as Age,
max(Gender_code) as Gender_code,
max(Marital_Status_code) as Marital_Status_code,
max(Vehicle_Use_code) as Vehicle_Use_code,
max(Estimated_Annual_Mileage) as Estimated_Annual_Mileage,
max(Persistency) as Persistency,
max(Driver_Licensed_date_code) as Driver_Licensed_date_code,
max(Traffic_Conviction_cnt) as Traffic_Conviction_cnt,
max(Traffic_Convict_Major_cnt) as Traffic_Convict_Major_cnt,
max(Traffic_Convict_Minor_cnt) as Traffic_Convict_Minor_cnt,
max(Chrgbl_AtFault_Accident_Cnt) as Chrgbl_AtFault_Accident_Cnt,
max(AtFault_Accident_BI_cnt) as AtFault_Accident_BI_cnt,
max(Chrgbl_AtFlt_Accdnt_PD_Cnt) as Chrgbl_AtFlt_Accdnt_PD_Cnt,
max(Good_Driver_Discount_code) as Good_Driver_Discount_code,
max(Driver_Traing_Discount_code) as Driver_Traing_Discount_code,
max(Good_Student_Discount_Code) as Good_Student_Discount_Code,
max(Defensive_Driver_Discnt_Code) as Defensive_Driver_Discnt_Code,
max(AntiLock_Brake_Discnt_Code) as AntiLock_Brake_Discnt_Code,
max(Rate_Level_ind_code) as Rate_Level_ind_code,
max(Point_Forgiveness_code) as Point_Forgiveness_code,
max(Daytime_Lights_Discnt_Code) as Daytime_Lights_Discnt_Code,
max(Model_Year_code) as Model_Year_code,
max(Vin) as Vin,
max(AtFault_BI_Sec_Addl_Drv_cnt) as AtFault_BI_Sec_Addl_Drv_cnt,
max(Chrgbl_AtFlt_PD_sec_drvr_Cnt) as Chrgbl_AtFlt_PD_sec_drvr_Cnt,
max(Frst_Addl_Drv_PRNCPL_OPRTR_Cd) as Frst_Addl_Drv_PRNCPL_OPRTR_Cd,
max(Sec_Addl_Drv_PRNCPL_OPRTR_Cd) as Sec_Addl_Drv_PRNCPL_OPRTR_Cd,
max(ISO_PASP_Subline_Code) as ISO_PASP_Subline_Code,
max(NoFault_Coverage_Code) as NoFault_Coverage_Code,
max(Coordinat_NoFault_Benefit_Code) as Coordinat_NoFault_Benefit_Code,
max(NoFault_Deductible_Type_Code) as NoFault_Deductible_Type_Code,
max(NoFault_deduct_amt) as NoFault_deduct_amt,
max(NoFault_classif_code) as NoFault_classif_code,
max(NoFault_CoPayment_Type_code) as NoFault_CoPayment_Type_code,
max(NoFault_CoPayment_amt) as NoFault_CoPayment_amt,
max(Passive_Restraint_code) as Passive_Restraint_code,
max(vehicle_type_code) as vehicle_type_code,
max(State_Exception_code) as State_Exception_code,
max(AtFault_BI_Frst_Addl_Drv_cnt) as AtFault_BI_Frst_Addl_Drv_cnt,
max(AtFault_PD_Frst_Addl_Drvr_cnt) as AtFault_PD_Frst_Addl_Drvr_cnt,
max(Frst_Addl_Drv_Licensed_Dt_Cd) as Frst_Addl_Drv_Licensed_Dt_Cd,
max(Sec_Addl_Drv_Licensd_Dt_Cd) as Sec_Addl_Drv_Licensd_Dt_Cd,
max(ELGBL_Point_Frst_Addl_Drv_Code) as ELGBL_Point_Frst_Addl_Drv_Code,
max(ELGBL_Points_Sec_Addl_Drv_Code) as ELGBL_Points_Sec_Addl_Drv_Code,
max(Frst_Addl_Drv_Pnt_Frgv_Code) as Frst_Addl_Drv_Pnt_Frgv_Code,
max(Sec_Addl_Drv_Pnt_Frgv_Code) as Sec_Addl_Drv_Pnt_Frgv_Code,
max(nofault_prem_amt) as nofault_prem_amt,
max(Annual_Statement_Line_code) as Annual_Statement_Line_code
from ${transform_db}.iso_pasp_auto
where source_system_code='PREM' /*and policy_num='1000264562'*/
group by policy_num, policy_join_id,Transaction_key,Cost_key
) new
inner join no_fault_prem on new.policy_num = no_fault_prem.policy_num and new.policy_join_id = no_fault_prem.policy_join_id and new.Transaction_key = no_fault_prem.Transaction_key and new.Cost_key = no_fault_prem.Cost_key)
ISO_PASP_Auto
left join ${edw_ext_db}.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code = ISO_PASP_Auto.company_num
left join ${transform_db}.prem_iso_pasp_auto_resulting_codes lkp on ISO_PASP_Auto.policy_num = lkp.policy_num and ISO_PASP_Auto.policy_join_id = lkp.policy_join_id and ISO_PASP_Auto.Transaction_key = lkp.Transaction_key and ISO_PASP_Auto.Cost_key = lkp.Cost_key
left join (select distinct policy_num, case when cvrg_cnt = 1 then case when coverage_join_id = 'PAIncomeLossBenefCov' then '3' else '2' end when cvrg_cnt = 2 then '1' end as state_Exception_code from (select policy_num,coverage_join_id,count(coverage_join_id) over (partition by policy_num order by 1) as cvrg_Cnt from ( select distinct policy_num,gwpc_prem_trans_Detail.coverage_join_id from ${transform_db}.gwpc_prem_trans_Detail,${transform_db}.iso_pasp_auto where gwpc_prem_trans_Detail.policy_period_join_id= iso_pasp_auto.policy_join_id and iso_pasp_auto.source_system_code='PREM' and gwpc_prem_trans_Detail.coverage_join_id in ('PAIncomeLossBenefCov','PAMedPayCov') )q1)q) st_exception on ISO_PASP_Auto.policy_num = st_exception.policy_num
where ISO_PASP_Auto.nofault_prem_amt !=0;
 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"

if [ $? == 0 ]

then info "ISO PASP No Fault Prem file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO PASP No Fault Prem file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO PASP No Fault Prem Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO PASP No Fault Prem Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
