#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : gwpl_trans_reconcilation.sh                                  #
#                                                                             #
# Description  : Script to reconcile  the data from stage to Transformation   #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
# Log File Details
mkdir -p ${v_tmp_path_curation}
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
info "log:${v_Log}"
echo "Log file path :${v_Log}" 2>&1

echo "Starting spark submit"

spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --master yarn --deploy-mode client --num-executors 10 --driver-memory 3G --executor-memory 30g --executor-cores 5 --conf spark.executor.memoryOverhead=3g --conf spark.sql.crossJoin.enabled=true --name "gwpl_transform_recon" --class com.curation.Curation /home/hadoop/transform/jars/datalake_transform-assembly-2.0.0.jar -c ${YAML_PATH}/transform_gwpl_transform_reconc.yaml >> ${v_Log} 2>&1

status=$?
if [ $status -ne 0 ]
    then
 		    info "spark submit failed for GWPL Tranform Reconciliation">> ${v_Log} 2>&1
        echo mail -s "Spark Submit Failed New account GWPL Tranform Reconciliation" edlakerun@stateauto.com;
        info "Email Sent successfully" >> ${v_Log} 2>&1
			  exit 1
        ### EXIT HERE due to spark submit issue!
    else
 		    info "Spark successfully completed" >> ${v_Log} 2>&1
fi
   
###########################################################################################################################################################
CRT_UPD_TS=$(date "+%Y-%m-%d %T.%3N")
  
hive -e "INSERT INTO ${V_TRNS_DB}.transform_reconc_hist select cast('$CRT_UPD_TS' as timestamp) as extractdate,* from ${V_TRNS_DB}.transform_reconc;"
if [[ ${?} -eq 0 ]] ; then
info "insert is successful for the table transform_reconc_hist"
else
info "insert is failed for the table transform_reconc_hist"
fi
###########################################################################################################################################################
src_gwpl_account=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_account' and system = 'SOURCE'"`
tgt_gwpl_account=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_account' and system = 'TARGET'"`
if [ $src_gwpl_account != $tgt_gwpl_account ]
then
   info "ERR: gwpl account count not matching" >> ${v_Log} 2>&1
   query_string[0]="ERR: gwpl account count not matching"  
   flag_1="failed"
else
   info "gwpl account count matching" >> ${v_Log} 2>&1
   query_string[0]="gwpl account count is matching"
   flag_1="success" 
fi
#############################################
src_policy_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_policy_common' and system = 'SOURCE'"`
tgt_policy_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_policy_common' and system = 'TARGET'"`
if [ $src_policy_common != $tgt_policy_common ]
then
   info "ERR: gwpl_policy common count not matching" >> ${v_Log} 2>&1
   query_string[1]="ERR: gwpl policy common count not matching" 
   flag_2="failed"
else
   info "gwpl policy common count matching" >> ${v_Log} 2>&1
   query_string[1]="gwpl policy common count is matching" 
   flag_2="success"
fi
#############################################
src_gwpl_prem_trans_detail=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_prem_trans_detail' and system = 'SOURCE'"`
tgt_gwpl_prem_trans_detail=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_prem_trans_detail' and system = 'TARGET'"`
src_gwpl_prem_trans_detail_amnt=`hive -S -e "SELECT tran_amount  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_prem_trans_detail' and system = 'SOURCE'"`
tgt_gwpl_prem_trans_detail_amnt=`hive -S -e "SELECT tran_amount  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_prem_trans_detail' and system = 'TARGET'"`
if [ $src_gwpl_prem_trans_detail != $tgt_gwpl_prem_trans_detail -o $src_gwpl_prem_trans_detail_amnt != $tgt_gwpl_prem_trans_detail_amnt ]
then
   info "ERR: gwpl prem trans detail count or amount not matching" >> ${v_Log} 2>&1
   query_string[2]="ERR: gwpl prem trans detail count or amount not matching" 
   flag_3="failed"
else
   info "gwpl prem trans detail count and amount are matching" >> ${v_Log} 2>&1
   query_string[2]="gwpl prem trans detail count and amount are matching" 
   flag_3="success"
fi
#############################################
#src_coverage_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_coverage_common' and system = 'SOURCE'"`
#tgt_coverage_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_coverage_common' and system = 'TARGET'"`
#if [ $src_coverage_common -ne $tgt_coverage_common ]
#then
#   info "ERR: gwpl coverage common count is not matching" >> ${v_Log} 2>&1
#   query_string[3]="ERR: gwpl coverage common count is not matching" 
#   flag_4="failed"
#else
#   info "gwpl coverage common count is matching" >> ${v_Log} 2>&1
#   query_string[3]="gwpl coverage common count is matching" 
#   flag_4="success"
#fi
#############################################
src_gwpl_earned_prem=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_earned_prem' and system = 'SOURCE'"`
tgt_gwpl_earned_prem=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_earned_prem' and system = 'TARGET'"`
src_gwpl_earned_prem_amnt=`hive -S -e "SELECT tran_amount  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_earned_prem' and system = 'SOURCE'"`
tgt_gwpl_earned_prem_amnt=`hive -S -e "SELECT tran_amount  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwpl_earned_prem' and system = 'TARGET'"`
if [ $src_gwpl_earned_prem != $tgt_gwpl_earned_prem -o $src_gwpl_earned_prem_amnt != $tgt_gwpl_earned_prem_amnt ]
then
   info "ERR: gwpl earned prem count or amount not matching" >> ${v_Log} 2>&1
   query_string[3]="ERR: gwpl earned prem count or amount not matching" 
   flag_4="failed"
else
   info "gwpl earned prem count and amount are matching" >> ${v_Log} 2>&1
   query_string[3]="gwpl earned prem count and amount are matching" 
   flag_4="success"
fi
#############################################
if  ( [ $flag_1 == "success" ] && [ $flag_2 == 'success' ] && [ $flag_3 = 'success' ] && [ $flag_4 = 'success' ] )
then
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email Success for New account GWPL Tranform Reconciliation" edlakerun@stateauto.com;
   info "Email Sent successfully" >> ${v_Log} 2>&1
   info "Processing completed successfully" >> ${v_Log} 2>&1
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for New account GWPL Tranform Reconciliation" edlakerun@stateauto.com;
   info "Email Sent successfully" >> ${v_Log} 2>&1
   info "Processing Failed" >> ${v_Log} 2>&1
   exit 1
fi
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
