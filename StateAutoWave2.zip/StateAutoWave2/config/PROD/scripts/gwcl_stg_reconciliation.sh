#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : gwcl_stg_reconciliation.sh                                   #
#                                                                             #
# Description  : Script to reconcile gwcl source with staging                 #
#                Curation Layer                                                       #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`
LOG_PATH="$SCRIPT_HOME/../logs"
JAR_PATH="$SCRIPT_HOME/../jars"
CONFIG_PATH="$SCRIPT_HOME/../spec_files"


info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
configfile=$CONFIG_PATH/gwcl_stg_connection.cfg
V_STG_DB=`grep -w "stg_hive_db" $configfile | cut -d"=" -f2`
echo ${V_STG_DB}
V_TRNS_DB=`grep -w "transform_hive_db" $configfile | cut -d"=" -f2`
echo ${V_TRNS_DB}
V_STG_RECON_DB=`grep -w "result_db" $configfile | cut -d"=" -f2`
echo ${V_STG_RECON_DB}
V_MAIL_ID=`grep -w "email_id" $configfile | cut -d"=" -f2`
echo ${V_MAIL_ID}

#All the path are mentioned in the Namespace properties
	# Log File Details
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${LOG_PATH}/gwcl_staging_recon_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
info "log:${v_Log}"
echo "Log file path :${v_Log}" 2>&1

. $SCRIPT_HOME/insert_load_cycle.sh GWCL STAGE 1 >>  ${v_Log} 2>&1


#spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --conf spark.driver.maxResultSize=5G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode client --num-executors 4 --driver-memory 5G --executor-memory 36G --executor-cores 4 --class com.curation.Curation /home/hadoop/curation/stgRecon-1.0-SNAPSHOT-jar-with-dependencies.jar -c ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml >> ${v_Log} 2>&1

spark-submit --conf spark.dynamicAllocation.enabled=true  --conf spark.driver.maxResultSize=5G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode client --jars /home/hadoop/processed/jars/sqljdbc42.jar --driver-memory 5G --executor-memory 20G --executor-cores 5 --conf spark.sql.broadcastTimeout=30000000 --conf spark.sql.autoBroadcastJoinThreshold=-1 --name "gwcl_staging_recon" --class staging.recon.StagingReconDriver ${JAR_PATH}/datalake_staging_recon-assembly-2.0.0.jar GWCL ${CONFIG_PATH}/gwcl_stg_connection.cfg  >> ${v_Log} 2>&1

status=$?
if [ $status -ne 0 ]
    then
                    info "spark submit failed for GWCL stage recon">> ${v_Log}
        echo mail -s "Spark Submit Failed GWCL Staging Reconciliation" edlakerun@stateauto.com,itsupport@stateauto.com;
        info "Email Sent successfully"  >> ${v_Log}
                          exit 1
    else
                    echo "Spark successfully completed" >> ${v_Log}
fi

##[CHANGE : Upon successful load and IN BALANCE ]
#. /home/hadoop/curation/scripts/insert_load_cycle.sh GWCL STAGE 3

##############################################################################################################################################################
##[CHANGE : recon table name changed to stg_recon. Take confirmation on hist load]
#`hive -S -e "INSERT INTO ${V_TRNS_DB}.stg_recon_hist select * from ${V_TRNS_DB}.stg_recon"`
##############################################################################################################################################################
#PC_DUP_CHECK=`hive -S -e "SELECT count(*) FROM ${V_TRNS_DB}.stg_reconc where source = 'Policy_COUNT'"`
#if [ $PC_DUP_CHECK -ne 0 ]
#then
#  info "GWCL staging tables have duplicates"
#  query_string[0]="GWCL staging tables have duplicates"
#   flag_0="failed"
#else
 #  info "GWCL policy tables have no duplicates" ${v_Log}
  # echo "GWCL policy tables have no duplicates" >> ${v_Log}
 #  flag_0="success"
#fi
#############################################
GWsrc_inforce_BP7BusinessOwners=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_INFORCE_BP7BusinessOwners'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_inforce_BP7BusinessOwners=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_INFORCE_BP7BusinessOwners'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_inforce_BP7BusinessOwners != $DLsrc_inforce_BP7BusinessOwners ]
then
   info "TOTAL INFORCE BP7BusinessOwners count not matching" >>  ${v_Log} 2>&1
   query_string[1]="TOTAL INFORCE BP7BusinessOwners count not matching"
   flag_1="failed"
else
   info "TOTAL INFORCE BP7BusinessOwners count matching" >>  ${v_Log} 2>&1
   flag_1="success"
fi
#############################################
GWsrc_INFORCE_CA7CommAuto=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_INFORCE_CA7CommAuto'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_CA7CommAuto=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_INFORCE_CA7CommAuto'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_INFORCE_CA7CommAuto != $DLsrc_INFORCE_CA7CommAuto ]
then
   info "TOTAL INFORCE CA7CommAuto count not matching" >>  ${v_Log} 2>&1
   query_string[2]="TOTAL INFORCE CA7CommAuto count not matching"
   flag_2="failed"
else
   info "TOTAL INFORCE CA7CommAuto count matching" >>  ${v_Log} 2>&1
   flag_2="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_INFORCE_CUCommercialUmbrella'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_INFORCE_CUCommercialUmbrella'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_INFORCE_UCommercialUmbrella != $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "TOTAL INFORCE UCommercialUmbrella count not matching" >>  ${v_Log} 2>&1
   query_string[3]="TOTAL INFORCE UCommercialUmbrella count not matching"
   flag_3="failed"
else
   info "TOTAL INFORCE UCommercialUmbrella count matching" >>  ${v_Log} 2>&1
   flag_3="success"
fi
#############################################
GWsrc_EXPIRED=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_EXPIRED'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_EXPIRED=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_EXPIRED'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_EXPIRED != $DLsrc_EXPIRED ]
then
   info "TOTAL EXPIRED count not matching" >>  ${v_Log} 2>&1
   query_string[4]="TOTAL EXPIRED count not matching"
   flag_4="failed"
else
   info "TOTAL EXPIRED count matching" >>  ${v_Log} 2>&1
   flag_4="success"
fi
#############################################
GWsrc_CANCELLED=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_CANCELLED'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_CANCELLED=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='TOTAL_CANCELLED'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_CANCELLED != $DLsrc_CANCELLED ]
then
   info "TOTAL CANCELLED count not matching" >>  ${v_Log} 2>&1
   query_string[5]="TOTAL CANCELLED count not matching"
   flag_5="failed"
else
   info "TOTAL CANCELLED count matching" >>  ${v_Log} 2>&1
   flag_5="success"
fi
#############################################
GWsrc_CA_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='YTD_CA_PREM'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_CA_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='YTD_CA_PREM'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_CA_PREM != $DLsrc_CA_PREM ]
then
   info "YTD CA PREM count not matching" >>  ${v_Log} 2>&1
   query_string[6]="YTD CA PREM count not matching"
   flag_6="failed"
else
   info "YTD CA PREM count matching" >>  ${v_Log} 2>&1
   flag_6="success"
fi
#############################################
GWsrc_BOP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='YTD_BOP_PREM'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_BOP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='YTD_BOP_PREM'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_BOP_PREM != $DLsrc_BOP_PREM ]
then
   info "YTD BOP PREM count not matching" >>  ${v_Log} 2>&1
   query_string[7]="YTD BOP PREM count not matching"
   flag_7="failed"
else
   info "YTD BOP PREM count matching" >>  ${v_Log} 2>&1
   flag_7="success"
fi
#############################################
GWsrc_CUP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='YTD_CUP_PREM'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_CUP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='YTD_CUP_PREM'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_CUP_PREM != $DLsrc_CUP_PREM ]
then
   info "YTD CUP PREM count not matching" >>  ${v_Log} 2>&1
   query_string[8]="YTD CUP PREM count not matching"
   flag_8="failed"
else
   info "YTD CUP PREM count matching" >>  ${v_Log} 2>&1
   flag_8="success"
fi
#############################################
GWsrc_ALL_CA_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='ALL_CA_PREM'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_ALL_CA_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='ALL_CA_PREM'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_ALL_CA_PREM != $DLsrc_ALL_CA_PREM ]
then
   info "ALL CA PREM count not matching" >>  ${v_Log} 2>&1
   query_string[9]="ALL CA PREM count not matching"
   flag_9="failed"
else
   info "ALL CA PREM count matching" >>  ${v_Log} 2>&1
   flag_9="success"
fi
#############################################
GWsrc_ALL_BOP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='ALL_BOP_PREM'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_ALL_BOP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='ALL_BOP_PREM'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_ALL_BOP_PREM != $DLsrc_ALL_BOP_PREM ]
then
   info "ALL BOP PREM count not matching" >>  ${v_Log} 2>&1
   query_string[10]="ALL BOP PREM count not matching"
   flag_10="failed"
else
   info "ALL BOP PREM count matching" >>  ${v_Log} 2>&1
   flag_10="success"
fi
#############################################
GWsrc_ALL_CUP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id   FROM ${V_TRNS_DB}.stg_recon where auditentity='ALL_CUP_PREM'  and source_system_code='GWCL' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_ALL_CUP_PREM=`hive -S -e "select cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM ${V_TRNS_DB}.stg_recon where auditentity='ALL_CUP_PREM'  and source_system_code='GWCL' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCL' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`

if [ $GWsrc_ALL_CUP_PREM != $DLsrc_ALL_CUP_PREM ]
then
   info "ALL CUP PREM count not matching" >>  ${v_Log} 2>&1
   query_string[11]="ALL CUP PREM count not matching"
   flag_11="failed"
else
   info "ALL CUP PREM count matching" >>  ${v_Log} 2>&1
   flag_11="success"
fi
`hive -S -e "INSERT INTO ${V_TRNS_DB}.stg_recon_hist  select * from ${V_TRNS_DB}.stg_recon"`
#############################################

if  (  [ $flag_1 = "success" ] && [ $flag_2 = 'success' ] && [ $flag_3 = 'success' ] && [ $flag_4 = 'success' ] && [ $flag_5 = 'success' ] && [ $flag_6 = "success" ] && [ $flag_7 = 'success' ] && [ $flag_8 = 'success' ] && [ $flag_9 = 'success' ] && [ $flag_10 = 'success' ] && [ $flag_11 = 'success' ] )
then
   info "Processing completed successfully" >>  ${v_Log} 2>&1
. $SCRIPT_HOME/insert_load_cycle.sh GWCL STAGE 3 >>  ${v_Log} 2>&1
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for GWCL Staging Reconciliation" edlakerun@stateauto.com;
#echo "$MAIL" | mail -s "Email alert for GWCL Staging Reconciliation" sunny.kumar@stateauto.com
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Failed" >>  ${v_Log} 2>&1
#. $SCRIPT_HOME/insert_load_cycle.sh GWCL STAGE 2 >>  ${v_Log} 2>&1
   exit 1
fi
###############################################################################
#                                   END                                       #
###############################################################################
