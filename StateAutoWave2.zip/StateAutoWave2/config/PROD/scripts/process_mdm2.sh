#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : process_mdm2.sh (GWCC_GWPC_Cont2.py)                         #
#                                                                             #
# Description  : Read CC,PC Grouped Data from S3 and Write Golden Data to S3  #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################  
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}
 
###############################################################################

Run_Time=$(date +"%Y-%m-%d %H:%M:%S")
Run_Date=$(date +"%Y-%m-%d")
echo "Run_Time: " ${Run_Time}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"

## Parameters passed to py file executed from a given path thru Spark-Submit Command ##
cc_pc_grp_data_loc="s3://sa-l4-datalake-processed-secure/mdm/cc_pc_group/"
match_data_loc="s3://sa-l4-datalake-processed-secure/mdm/match_data/"
golden_data_loc="s3://sa-l4-datalake-processed-secure/mdm/golden_data/date="

SRC_PATH="/home/hadoop/transform/mdm"
Target="Customer360_StepII"

## Layer Name Check for Log File Creation Path ##
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
     # Log File Details
     mkdir -p ${v_tmp_path_serving}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_serving}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
else
     # Log File Details
     mkdir -p ${v_tmp_path_curation}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_curation}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
fi

echo "In-case of an error in Step-II, Deleting Today's Incomplete Step-II Output Folders for Re-Run" >> ${v_Log}
hdfs dfs -rm -r ${match_data_loc}${Run_Date}/
hdfs dfs -rm -r ${golden_data_loc}${Run_Date}/

echo "Check Today's Step-I Output present or not to Start Step-II" >> ${v_Log}
$(hdfs dfs -test -d ${cc_pc_grp_data_loc}${Run_Date})

if [ $? != 0 ]
then
   echo "[INFO] MDM Step-I Output for Today's Date NOT EXISTS to Read" >> ${v_Log}
else
   echo "[INFO] MDM Step-I Output for Today's Date EXISTS and Processing Starts" >> ${v_Log}

   echo "Spark Submit to Read CC_PC Grouped Customer Data from S3, process and Write Golden Data to S3" >> ${v_Log}
   spark-submit --conf spark.dynamicAllocation.enabled=true --master yarn --deploy-mode client --num-executors 17 --driver-memory 3G --executor-memory 51G --executor-cores 16 ${SRC_PATH}/GWCC_GWPC_Cont2.py ${cc_pc_grp_data_loc} ${match_data_loc} ${golden_data_loc} >> ${v_Log} 2>&1
  
   if [ $? == 0 ]
   then
      csv_sucs_msg="MDM Write Golden Data to S3 - Completed for ${Run_Date}"
      #echo -e "${csv_sucs_msg} | mail -s "MDM Write Golden Data to S3 - Completed" -aFrom:${MAIL_FROM} ${MAIL_TO};
      echo -e "${csv_sucs_msg}" >> ${v_Log}
      info "MDM Step-II Completed and Email Sent successfully"  >> ${v_Log} 
   else
      csv_fail_msg="MDM Write Golden Data to S3 - Failed for ${Run_Date}"
      #echo "${csv_fail_msg}" | mail -s "MDM Write Golden Data to S3 - Failed" -aFrom:${MAIL_FROM} ${MAIL_TO};
      echo "${csv_fail_msg}" >> ${v_Log}
      info "MDM Step-II Failed and Email Sent"  >> ${v_Log}
      exit 1 	  
   fi
fi
echo "[INFO] Script Ends Here...." >> ${v_Log}
  
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1            
