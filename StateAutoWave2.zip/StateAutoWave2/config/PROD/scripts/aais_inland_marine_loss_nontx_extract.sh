#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : aais_inland_marine_loss_non_tx_extract.sh                                      #
#                                                                             #
# Description  : Script to generate AAIS file with Inland Marine Loss - Non-TX details 			  #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="AAIS_INLANDMARINE_LOSS_NON-TX_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"
V_S3_PATH="${v_serving_bucket_path}"'/AAIS/'




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating AAIS Loss for Inland Marines extract Non-TX"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

#frame the final query for extract
V_EXTRACT_SQL="
with aais_class_codes as (
	select distinct lower(refclass.code) as class_code, alt_code
	from $V_EDW_EXTERNAL.ent_ref_code refclass 
	where refclass.group_code = 'AAIS' and refclass.code_type_name = 'CLASS_CD' 
),
aais_im_loss_non_tx as (
	select
		aimpl.aais_line_of_insurance_code,
		aimpl.accounting_date,
		case when reftrans.alt_code = '2' then substring(aimpl.accounting_date, 5, 2) || substring(aimpl.accounting_date, 3, 2) else date_format(cast('${V_TO_DATE}' as date), 'MMYY') end as accounting_date_mmyy,
		aimpl.company_code,
		refcomp.alt_code as company_num,
		aimpl.state_code,
		refstatecode.alt_code as state_num,
		aimpl.county_code,
		nvl(aimpl.reserved_1, '') as reserved_1,
		aimpl.territory_code,
		aimpl.transaction_code,
		reftrans.alt_code as trans_num,
		aimpl.loss_amt,
		case 
			cast(cast(aimpl.loss_amt as decimal(19,2)) * 100 as int) % 10
			when 0 then 
				case 
					when aimpl.loss_amt < 0 then '}' 
					when aimpl.loss_amt >= 0 then '0' 
				end
			when -1 then 'J'
			when -2 then 'K'
			when -3 then 'L'
			when -4 then 'M'
			when -5 then 'N'
			when -6 then 'O'
			when -7 then 'P'
			when -8 then 'Q'
			when -9 then 'R'
			else cast(cast(aimpl.loss_amt as decimal(19,2)) * 100 as int) % 10
		end as loss_amt_sign_code,
		cast(cast(cast(abs(aimpl.loss_amt) as decimal(19,2)) * 100 as int) / 10 as int) as loss_amt_code,
		aimpl.aais_claim_cnt,
		case cast(aimpl.aais_claim_cnt as integer)
		when 1 then '00001'
		when -1 then '0000J'
		else '00000'
		end as claim_cnt,
		aimpl.annual_statement_line_code,
		aimpl.program_class_code,
		aimpl.policy_form_code,
		nvl(aimpl.reserved_2, '') as reserved_2,
		aimpl.terrorism_ind,
		aimpl.prop_damage_cov_limit_amt,
		lpad(cast(round(aimpl.prop_damage_cov_limit_amt, -3) / 1000 as int), 5, '0') as prop_damage_cov_limit_amt_code,
		aimpl.deduct_type_code,
		aimpl.deduct_amt,
		nvl(aimpl.reserved_3, '') as reserved_3,
		aimpl.class_code,
		aimpl.coverage_code,
		case 
		when aimpl.class_code is null or refclass.alt_code is null or aimpl.class_code='' then 
			case 
			when aimpl.coverage_code = 'HOSchedPersPropHOE' then '237' 
			when aimpl.coverage_code in ('HOWTRPhyDmgTrailer','HOWTRWatercraft','HOWTRBoat','HOWTREmergency','HOWTRNav50') then '039' 
			end
		else
			refclass.alt_code
		end as derived_class_code,
		nvl(aimpl.reserved_4, '') as reserved_4,
		aimpl.construction_code,
		nvl(refcons.alt_code, '00') as derived_construction_code,
		aimpl.fire_protection_code,
		nvl(reffire.alt_code, '00') as derived_fire_code,
		nvl(aimpl.reserved_5, '') as reserved_5,
		aimpl.policy_type_code,
		nvl(aimpl.reserved_6, '') as reserved_6,
		aimpl.package_ind,
		nvl(aimpl.reserved_7, '') as reserved_7,
		nvl(aimpl.pool_code, '') as pool_code,
		aimpl.cause_of_loss_code,
		refloss.alt_code as loss_cause_code,
		nvl(aimpl.reserved_8, '') as reserved_8,
		aimpl.accident_date,
		date_format(aimpl.accident_date, 'MMddYY') as accident_date_mmddyy,
		nvl(aimpl.zip_5_code, '') as zip_5_code,
		nvl(aimpl.zip_4_suffix_code, '') as zip_4_suffix_code,
		nvl(aimpl.reserved_9, '') as reserved_9,
		aimpl.claim_num,
		split(aimpl.claim_num, '-') as claim_num_split,
		aimpl.claim_seq_num,
		nvl(aimpl.company_use, '') as company_use
	from ${V_TRNS_DB}.aais_inland_marine_prem_loss aimpl
	left join $V_EDW_EXTERNAL.ent_ref_code refstatecode on refstatecode.group_code = 'LGCY' and refstatecode.alt_code_type_name = 'STATE-NUM' 
		and refstatecode.code_type_name='STATE-CD' and lower(refstatecode.code) = lower(aimpl.state_code)
	left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'AAIS' and refcomp.alt_code_type_name = 'AAIS-CO' 
		and refcomp.code_type_name='UNDERWRITING-CO' and lower(refcomp.code) = lower(aimpl.company_code)
	left join $V_EDW_EXTERNAL.ent_ref_code reftrans on reftrans.group_code = 'AAIS' and reftrans.alt_code_type_name = 'AAIS -TRNSCTNCD' 
		and reftrans.code_type_name='TRNSCTN_CD' and lower(reftrans.code) = lower(aimpl.transaction_code)
	left join $V_EDW_EXTERNAL.ent_ref_code refloss on refloss.group_code = 'AAIS' and refloss.alt_code_type_name = 'AAIS-LOSSCD' 
		and refloss.code_type_name='LOSS_CD' and lower(refloss.code) = lower(aimpl.cause_of_loss_code)
	left join aais_class_codes refclass on lower(refclass.class_code) = translate(lower(aimpl.class_code), ' ', '')
	left join $V_EDW_EXTERNAL.ent_ref_code refcons  on refcons.alt_code_type_name = 'AAIS-CONSTRCD' and refcons.code_type_name = 'CONSTRUCTION_CD' 
		and refcons.group_code = 'AAIS' and lower(refcons.code) = lower(aimpl.construction_code) 
	left join $V_EDW_EXTERNAL.ent_ref_code reffire on reffire.alt_code_type_name = 'AAIS-FIRECD' and reffire.code_type_name = 'FIREPRT_CD' 
		and reffire.group_code = 'AAIS' and lower(reffire.Code) = case when length(aimpl.fire_protection_code) = 1 then lower(lpad(aimpl.fire_protection_code, 2, '0')) else lower(aimpl.fire_protection_code) end
	where aais_extract_type_name = 'LOSS' and cast(loss_amt as decimal(18,2))<>0
	and cast(aimpl.accounting_date as integer) between cast(date_format(cast('${V_FROM_DATE}' as date), 'YYYYMMdd') as integer) and cast(date_format(cast('${V_TO_DATE}' as date), 'YYYYMMdd') as integer)
),
aais_im_loss_nontx_layout as (
	select trans_num,
		lpad(aais_line_of_insurance_code, 2, ' ')
		|| lpad(accounting_date_mmyy, 4, ' ')
		|| lpad(company_num, 4, ' ')
		|| lpad(state_num, 2, ' ')
		|| lpad(county_code, 3, ' ')
		|| lpad(reserved_1, 1, ' ')
		|| lpad(territory_code, 3, ' ')
		|| lpad(trans_num, 1, ' ')
		|| lpad(loss_amt_code || loss_amt_sign_code, 10, '0')
		|| lpad(claim_cnt, 5, ' ')
		|| lpad(annual_statement_line_code, 3, ' ')
		|| lpad(program_class_code, 1, ' ')
		|| lpad(policy_form_code, 2, ' ')
		|| lpad(reserved_2, 3, ' ')
		|| lpad(terrorism_ind, 1, ' ')
		|| lpad(prop_damage_cov_limit_amt_code, 5, '0')
		|| lpad(deduct_type_code, 1, ' ')
		|| lpad(deduct_amt, 2, ' ')
		|| lpad(reserved_3, 1, ' ')
		|| lpad(coalesce(derived_class_code,'   '), 3, ' ')
		|| lpad(reserved_4, 2, ' ')
		|| lpad(case when derived_class_code in ('235', '236', '237', '079', '081', '084') then derived_construction_code else '00' end, 2, '0')
		|| lpad(case when derived_class_code in ('235', '236', '237', '079', '081', '084') then derived_fire_code else '00' end, 2, '0')
		|| lpad(reserved_5, 19, ' ')
		|| lpad(policy_type_code, 1, ' ')
		|| lpad(reserved_6, 1, ' ')
		|| lpad(package_ind, 1, ' ')
		|| lpad(reserved_7, 6, ' ')
		|| lpad(pool_code, 1, ' ')
		|| lpad(loss_cause_code, 2, ' ')
		|| lpad(reserved_8, 1, ' ')
		|| lpad(accident_date_mmddyy, 6, ' ')
		|| lpad(zip_5_code, 5, ' ')
		|| lpad(zip_4_suffix_code, 4, ' ')
		|| lpad(reserved_9, 16, ' ')
		|| lpad(substring(claim_num_split[1], -6) || claim_num_split[2], 12, ' ')
		|| lpad(claim_seq_num, 2, ' ')
		|| lpad(company_use, 10, ' ') as layout
	from
		aais_im_loss_non_tx 
	order by trans_num
)
select layout from aais_im_loss_nontx_layout"

info "Query for file extraction: $V_EXTRACT_SQL"

#execute the query and write the output to a file
hive -S -e "${V_EXTRACT_SQL}" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "AAIS Loss for Inland Marine Non-TX Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : AAIS Loss for Inland Marine Non-TX Extract file - ${V_FILE_NAME} generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH} - aws s3 cp /home/hadoop/ISO_Extracts/${V_FILE_NAME} ${V_S3_PATH}";

#copy the file from local to s3 folder
aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}"

if [ $? == 0 ]

then info "AAIS Loss for Inland Marine Non-TX Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : AAIS Loss for Inland Marine Non-TX Extract file - ${V_FILE_NAME} upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
