bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO PLSP HO Prem extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO PLSP HO Prem file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../../shell_functions/bin/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi

fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/PLSP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="PLSP_HO_PREM_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"

#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
# Log File Details
mkdir -p ${v_tmp_path_serving}
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
info "log:${v_Log}"
echo "Log file path :${v_Log}" 2>&1

else
# Log File Details
mkdir -p ${v_tmp_path_curation}
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
info "log:${v_Log}"
echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO PLSP HO Prem"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

hive -S -e"
set hive.strict.checks.cartesian.product=false;
select 
company_num, iso_transaction_type_code, accounting_date, inception_mth, inception_year, transaction_eff_mth, transaction_eff_year, transaction_exp_mth, transaction_exp_year, alt_code, territory_code, ho_home_busn_cls_cd, annual_statement_line_code, ho_subline, ho_exp_cd, RF1, ho_form_cd, ho_no_of_fmly_cd, ho_ord_or_law_cd, ho_status_code, ho_wind_ded_size_cd, ho_construction_cd, ho_protection_class_cd, ho_mold_damage_coverage, RF2,ho_theft_ded_size_cd, ho_type_of_ded_cd, ho_fire_ded_size_cd, iso_construction_year_code, envirmnt_impair_cov_s1_code, envirmnt_impair_cov_s2_code, condo_alter_lib_lmt_code, ho_policy_program_code, ho_covc_percent_amt, green_upgrd_ind_code, ho_cov_liab_lmt_cd, ho_roof_loss_settlement_code, exposure_amt, bceg_classification_code, ho_protective_devices_code, RF3, mobilehome_endorsement_id, tie_down, RF4, ho_st_exp_ind1, RF5, zip_code, RF6, ho_st_exp_ind2, ho_st_exp_ind3, iso_wind_hail_cov_ind_code, ho_loss_hstry_cd, iso_roof_instl_year_code, ho_risk_ind_1, ho_risk_ind_2, RF7, company_program_excpt_ind,statistical_plan_ind_code,RF8, prem_amt, RF9, policy_num, RF10
from (select rpad(coalesce(ho_prem_final.company_num,''),4,' ') as company_num,
'1' as iso_transaction_type_code,
lpad(coalesce(concat((case
when (substr(cast(accounting_date as varchar(25)),6,2)) in ('01','02','03') then '3' 
when (substr(cast(accounting_date as varchar(25)),6,2)) in ('04','05','06') then '6'
when (substr(cast(accounting_date as varchar(25)),6,2)) in ('07','08','09') then '9'
when (substr(cast(accounting_date as varchar(25)),6,2)) in ('10','11','12') then '&'
end),(substr(cast(accounting_date as varchar(25)),4,1))),'  '),2,' ') as accounting_date,
coalesce((case when (substr(cast(ho_prem_final.inception_date as varchar(25)),6,2))='10' then '0' when (substr(cast(ho_prem_final.inception_date as varchar(25)),6,2))='11' then '-' when (substr(cast(ho_prem_final.inception_date as varchar(25)),6,2))='12' then '&' else substr(cast(ho_prem_final.inception_date as varchar(25)),7,1) end),' ') as inception_mth ,
lpad(substr(cast(ho_prem_final.inception_date as varchar(25)),3,2),2,' ') as inception_year,
coalesce((case when (substr(cast(ho_prem_final.transaction_eff_date as varchar(25)),6,2))='10' then '0' when (substr(cast(ho_prem_final.transaction_eff_date as varchar(25)),6,2))='11' then '-' when (substr(cast(ho_prem_final.transaction_eff_date as varchar(25)),6,2))='12' then '&' else substr(cast(ho_prem_final.transaction_eff_date as varchar(25)),7,1) end),' ') as transaction_eff_mth ,
coalesce(substr(cast(ho_prem_final.transaction_eff_date as varchar(25)),3,2),' ') as transaction_eff_year,
coalesce((case when (substr(cast(ho_prem_final.transaction_exp_date as varchar(25)),6,2))='10' then '0' when (substr(cast(ho_prem_final.transaction_exp_date as varchar(25)),6,2))='11' then '-' when (substr(cast(ho_prem_final.transaction_exp_date as varchar(25)),6,2))='12' then '&' else substr(cast(ho_prem_final.transaction_exp_date as varchar(25)),7,1) end), ' ') as transaction_exp_mth ,
lpad(substr(cast(ho_prem_final.transaction_exp_date as varchar(25)),3,2),2,' ') as transaction_exp_year,
lpad(coalesce(cast(ho_prem_final.state_code as varchar(2)),''),2,' ') as alt_code,
lpad(coalesce(ho_prem_final.territory_code,''),3,' ') as territory_code,
lpad(coalesce(ho_prem_final.ho_home_busn_cls_cd,''),2,' ') as ho_home_busn_cls_cd,
lpad(coalesce(ho_prem_final.annual_statement_line_code,''),3,'0') as annual_statement_line_code,
lpad(coalesce(ho_prem_final.ho_subline,''),3,' ') as ho_subline,
lpad(coalesce(ho_prem_final.ho_exp_cd,''),1,' ') as ho_exp_cd,
' ' as RF1,
lpad(coalesce(ho_prem_final.ho_form_cd,' '),1,' ') as ho_form_cd,
lpad(coalesce(ho_prem_final.ho_no_of_fmly_cd,' '),1,' ') as ho_no_of_fmly_cd,
lpad(coalesce(ho_prem_final.ho_ord_or_law_cd,' '),1,' ') as ho_ord_or_law_cd,
lpad(coalesce(ho_prem_final.ho_status_code,' '),1,' ') as ho_status_code,
lpad(coalesce(ho_prem_final.ho_wind_ded_size_cd,''),2,' ') as ho_wind_ded_size_cd,
lpad(coalesce(ho_prem_final.ho_construction_cd,''),1,' ') as ho_construction_cd,
lpad(coalesce(ho_prem_final.ho_protection_class_cd,''),2,' ') as ho_protection_class_cd,
/*lpad(coalesce(ho_prem_final.ho_mold_damage_coverage,' '),1,' ')*/ '1' as ho_mold_damage_coverage,
' ' as RF2,
lpad(coalesce(ho_prem_final.ho_theft_ded_size_cd,''),1,' ') as ho_theft_ded_size_cd,
lpad(coalesce(ho_prem_final.ho_type_of_ded_cd,''),1,' ') as ho_type_of_ded_cd,
lpad(coalesce(ho_prem_final.ho_fire_ded_size_cd,''),2,' ') as ho_fire_ded_size_cd,
lpad(coalesce(ho_prem_final.iso_construction_year_code,''),2,' ') as iso_construction_year_code,
lpad(coalesce(ho_prem_final.envirmnt_impair_cov_s1_code,''),1,' ') as envirmnt_impair_cov_s1_code,
lpad(coalesce(ho_prem_final.envirmnt_impair_cov_s2_code,''),1,' ') as envirmnt_impair_cov_s2_code,
lpad(coalesce(ho_prem_final.condo_alter_lib_lmt_code,' '),1,' ') as condo_alter_lib_lmt_code,
lpad(coalesce(ho_prem_final.ho_policy_program_code,''),1,' ') as ho_policy_program_code,
lpad(coalesce(ho_prem_final.ho_covc_percent_amt,''),1,' ') as ho_covc_percent_amt,
' ' as green_upgrd_ind_code,
lpad(coalesce(ho_prem_final.ho_cov_liab_lmt_cd,''),1,' ') as ho_cov_liab_lmt_cd,
lpad(coalesce(ho_prem_final.ho_roof_loss_settlement_code,''),1,' ') as ho_roof_loss_settlement_code,
lpad(coalesce(ho_prem_final.exposure_amt,'0'),4,'0') as exposure_amt,
lpad(coalesce(ho_prem_final.bceg_classification_code,''),2,' ') as bceg_classification_code,
lpad(coalesce(ho_prem_final.ho_protective_devices_code,''),2,'0') as ho_protective_devices_code,
lpad('   ',3,' ') as RF3,
lpad(coalesce(ho_prem_final.mobilehome_endorsement_id,''),1,' ') as mobilehome_endorsement_id,
lpad(coalesce(ho_prem_final.tie_down,''),1,' ') as tie_down,
' ' as RF4,
lpad(coalesce(ho_prem_final.ho_st_exp_ind1,''),1,' ') as ho_st_exp_ind1,
' ' as RF5,
lpad(coalesce(ho_prem_final.zip_code,''),5,' ') as zip_code,
lpad('    ',4,' ') as RF6,
lpad(coalesce(ho_prem_final.ho_st_exp_ind2,''),1,' ') as ho_st_exp_ind2,
lpad(coalesce(ho_prem_final.ho_st_exp_ind3,''),1,' ') as ho_st_exp_ind3,
lpad(coalesce(ho_prem_final.iso_wind_hail_cov_ind_code,''),1,' ') as iso_wind_hail_cov_ind_code,
lpad(coalesce(ho_prem_final.ho_loss_hstry_cd,''),1,' ') as ho_loss_hstry_cd,
lpad(coalesce(ho_prem_final.iso_roof_instl_year_code,''),2,' ') as iso_roof_instl_year_code,
lpad(coalesce(ho_prem_final.ho_risk_ind_1,''),1,' ') as ho_risk_ind_1,
lpad(coalesce(ho_prem_final.ho_risk_ind_2,''),1,' ') as ho_risk_ind_2,
lpad('  ',2,' ') as RF7,
lpad(coalesce(ho_prem_final.company_program_excpt_ind,''),2,' ') as company_program_excpt_ind,
lpad(coalesce(ho_prem_final.statistical_plan_ind_code,''),1,' ') as statistical_plan_ind_code,
' ' as RF8,
/* lpad(cast(concat(cast(cast(abs(round(cast(prem_amt as decimal(19,2)), 0)) / 10 as integer) as varchar(255)),cast((case when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=0 then '0' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer) < 0 then '}'  when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer) >= 0 then '0' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-1 then 'J' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-2 then 'K' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-3 then 'L' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-4 then 'M' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-5 then 'N' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-6 then 'O' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-7 then 'P' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)=-8 then 'Q' when cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer)-9 then 'R' else cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as integer) end) as varchar(255))) as varchar(255)),8,'0') as prem_amt, */
lpad(cast(abs(round(cast(prem_amt as decimal(19,2)), 0)) / 10 as int) || (case cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as int) when 0 then case when prem_amt < 0 then '}'  when prem_amt >= 0 then '0' end when -1 then 'J' when -2 then 'K' when -3 then 'L' when -4 then 'M' when -5 then 'N' when -6 then 'O' when -7 then 'P' when -8 then 'Q' when -9 then 'R' else cast(round(cast(prem_amt as decimal(19,2)), 0) % 10 as int) end),8,'0') as prem_amt,
lpad('              ',14,' ') as RF9,
lpad(coalesce(ho_prem_final.policy_num,''),13,'0') as policy_num,
lpad('                    ',20,' ') as RF10
from ${transform_db}.hoprem_iso_ho_df_prem_loss ho_prem_final
)ho_prem_outer where prem_amt != '00000000' and prem_amt != '0000000}';
 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"

if [ $? == 0 ]

then info "ISO PLSP HO Prem file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO PLSP HO Prem file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO PLSP HO Prem Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO PLSP HO Prem Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
