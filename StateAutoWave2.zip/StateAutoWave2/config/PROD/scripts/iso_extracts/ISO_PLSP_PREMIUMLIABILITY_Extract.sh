#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO_PLSP_PREMIUMLIABILITY No Fault Prem extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO_PLSP_PREMIUMLIABILITY No Fault Prem file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../../shell_functions/bin/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/PLSP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="ISO_PLSP_PREMIUMLIABILITY_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO_PLSP_PREMIUMLIABILITY No Fault Prem"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
select distinct * from (
select concat(
lpad(case when MIN(COMP_NUM)= '' or MIN(COMP_NUM) is null then '    ' else MIN(COMP_NUM) end,4,'    '),
'1',
lpad(case when MIN(accounting_date_mm)='' or MIN(accounting_date_mm) is null then ' ' else MIN(accounting_date_mm) end,1,' '),
lpad(case when MIN(accounting_date_year)='' or MIN(accounting_date_year) is null then ' ' else MIN(accounting_date_year) end,1,' '),
lpad(case when MIN(inception_date_mm)= '' or MIN(inception_date_mm)is null then ' ' else MIN(inception_date_mm) end,1,' '),
lpad(case when MIN(inception_date_year)= '' or MIN(inception_date_year)is null then '  ' else MIN(inception_date_year) end,2,'  '),
lpad(case when MIN(transaction_eff_date_mm)= '' or MIN(transaction_eff_date_mm)is null then ' ' else MIN(transaction_eff_date_mm) end,1,' '),
lpad(case when MIN(transaction_eff_date_year)= '' or MIN(transaction_eff_date_year)is null then '  ' else MIN(transaction_eff_date_year) end,2,'  '),
lpad(case when MIN(Transaction_Exp_Date_mm)= '' or MIN(Transaction_Exp_Date_mm)is null then ' ' else MIN(Transaction_Exp_Date_mm) end,1,' '),
lpad(case when MIN(Transaction_Exp_Date_year)= '' or MIN(Transaction_Exp_Date_year)is null then '  ' else MIN(Transaction_Exp_Date_year) end,2,'  '),
lpad(case when MIN(state_code)= '' or MIN(state_code)is null then '  ' else MIN(state_code) end,2,'  '),
' ',
lpad(case when MIN(territory_code)= '' or MIN(territory_code)is null then '  ' else MIN(territory_code) end,2,'  '),
'  ',
lpad(case when MIN(annual_statement_line_code)= '' or MIN(annual_statement_line_code)is null then '   ' else MIN(annual_statement_line_code) end,3,'  '),
'480',
' ',
lpad(case when MIN(lkp.envirmnt_impair_cov_code)= '' or MIN(lkp.envirmnt_impair_cov_code)is null then ' ' else MIN(lkp.envirmnt_impair_cov_code) end,1,' '),
lpad(case when MIN(lkp.mold_damage_coverage_code)= '' or MIN(lkp.mold_damage_coverage_code)is null then ' ' else MIN(lkp.mold_damage_coverage_code) end,1,' '),
lpad(case when MIN(lkp.pup_undrlyg_ho_pl_limit_code)= '' or MIN(lkp.pup_undrlyg_ho_pl_limit_code)is null then ' ' else MIN(lkp.pup_undrlyg_ho_pl_limit_code) end,1,' '),
lpad(case when MIN(lkp.pup_undrlyg_BIl_limit_code)= '' or MIN(lkp.pup_undrlyg_BIl_limit_code)is null then ' ' else MIN(lkp.pup_undrlyg_BIl_limit_code) end,1,' '),
lpad(case when MIN(lkp.pup_undrlyg_ho_pl_plcy_code)= '' or MIN(lkp.pup_undrlyg_ho_pl_plcy_code)is null then '  ' else MIN(lkp.pup_undrlyg_ho_pl_plcy_code) end,2,'  '),
lpad(case when MIN(lkp.pup_undrlyg_auto_plcy_code)= '' or MIN(lkp.pup_undrlyg_auto_plcy_code)is null then '  ' else MIN(lkp.pup_undrlyg_auto_plcy_code) end,2,'  '),
' ',
lpad(case when MIN(lkp.pup_risk_profile_code)= '' or MIN(lkp.pup_risk_profile_code)is null then '     ' else MIN(lkp.pup_risk_profile_code) end,5,'     '),
'  ',   
lpad(case when MIN(lkp.classif_code)= '' or MIN(lkp.classif_code)is null then '   ' else MIN(lkp.classif_code) end,3,'   '),
lpad(case when MIN(lkp.pup_endorsement_ind_code)= '' or MIN(lkp.pup_endorsement_ind_code)is null then '  ' else MIN(lkp.pup_endorsement_ind_code) end,2,'  '),
'   ',
lpad(case when MIN(lkp.liability_limit_code)= '' or MIN(lkp.liability_limit_code)is null then ' ' else MIN(lkp.liability_limit_code) end,1,' '),
lpad(case when MIN(lkp.pup_um_liability_limit_code)= '' or MIN(lkp.pup_um_liability_limit_code)is null then ' ' else MIN(lkp.pup_um_liability_limit_code) end,1,' '),
'1',
' ',
lpad(case when MIN(exposure)= '' or MIN(exposure)is null then '  ' else MIN(exposure) end,2,'  '),
'         ',
' ', 
lpad(case when MIN(lkp.State_Exception_Ind_code)= '' or MIN(lkp.State_Exception_Ind_code)is null then ' ' else MIN(lkp.State_Exception_Ind_code) end,1,' '),
' ',
lpad(case when MIN(zip_code)= '' or MIN(zip_code) is null then '     ' else MIN(zip_code) end,5,'     '),
'              ',
'10', 
'9',
' ',
lpad(case when MIN(prem_amt) = '' or MIN(prem_amt) is null then '00000000' else
case when cast (round(sum(cast (prem_amt as double))) as integer) < 0 then
concat(
substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as varchar(255)),
2, (length (cast (cast (round(sum(cast (prem_amt as double))) as integer) as varchar(255)))) -2),
CASE substr(cast (cast (round(sum(cast (prem_amt as double))) as integer) as varchar(255)),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as varchar(255))),length(cast (cast (round(sum(cast (prem_amt as double))) as integer) as varchar(255)))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END

)
else
cast (cast (round(sum(cast (prem_amt as double))) as integer) as varchar(255)) end
end,8,'000000000'),
'              ',
rpad(inner_pl_liab.prem_record_id,13,' '),
'                    '
)

from 
(
SELECT pl_co.alt_code AS COMP_NUM,
         iso_transaction_type_code,
         /*accounting_date,*/
        
    CASE
    WHEN cast(substring(cast(accounting_date AS varchar(255)),6,2) AS integer) < 10 THEN
    substring(cast(accounting_date AS varchar(255)),7,1)
    WHEN substring(cast(accounting_date AS varchar(255)),6,2) = '10' THEN
    '0'
    WHEN substring(cast(accounting_date AS varchar(255)),6,2) = '11' THEN
    '-'
    WHEN substring(cast(accounting_date AS varchar(255)),6,2) = '12' THEN
    '&'
    END AS accounting_date_mm, substring(cast(accounting_date as varchar(255)),4,1) AS accounting_date_year,
    CASE
    WHEN cast(substring(cast(inception_date AS varchar(255)),6,2) AS integer) < 10 THEN
    substring(cast(inception_date AS varchar(255)),7,1)
    WHEN substring(cast(inception_date AS varchar(255)),6,2) = '10' THEN
    '0'
    WHEN substring(cast(inception_date AS varchar(255)),6,2) = '11' THEN
    '-'
    WHEN substring(cast(inception_date AS varchar(255)),6,2) = '12' THEN
    '&'
    END AS inception_date_mm, substring(cast(inception_date as varchar(255)),3,2) AS inception_date_year,
    CASE
    WHEN cast(substring(cast(transaction_eff_date AS varchar(255)),6,2) AS integer) < 10 THEN
    substring(cast(transaction_eff_date AS varchar(255)),7,1)
    WHEN substring(cast(transaction_eff_date AS varchar(255)),6,2) = '10' THEN
    '0'
    WHEN substring(cast(transaction_eff_date AS varchar(255)),6,2) = '11' THEN
    '-'
    WHEN substring(cast(transaction_eff_date AS varchar(255)),6,2) = '12' THEN
    '&'
    END AS transaction_eff_date_mm, substring(cast(transaction_eff_date as varchar(255)),3,2) AS transaction_eff_date_year,
    CASE
    WHEN cast(substring(cast(Transaction_Exp_Date AS varchar(255)),6,2) AS integer) < 10 THEN
    substring(cast(Transaction_Exp_Date AS varchar(255)),7,1)
    WHEN substring(cast(Transaction_Exp_Date AS varchar(255)),6,2) = '10' THEN
    '0'
    WHEN substring(cast(Transaction_Exp_Date AS varchar(255)),6,2) = '11' THEN
    '-'
    WHEN substring(cast(Transaction_Exp_Date AS varchar(255)),6,2) = '12' THEN
    '&'
    END AS Transaction_Exp_Date_mm, substring(cast(Transaction_Exp_Date as varchar(255)),3,2) AS Transaction_Exp_Date_year, st_code.code as state_code,  territory_code,  annual_statement_line_code, 480 as subline_of_busn_code, case when src_tab.line_of_busn_name = 'PersonalUmbrella' then envirmnt_impair_cov_code else ' ' end as envirmnt_impair_cov_code, mold_damage_coverage_code, case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_undrlyg_ho_pl_limit_code else ' ' end as pup_undrlyg_ho_pl_limit_code , case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_undrlyg_BIl_limit_code else ' ' end as pup_undrlyg_BIl_limit_code,  case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_undrlyg_ho_pl_plcy_code else ' ' end as pup_undrlyg_ho_pl_plcy_code, case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_undrlyg_auto_plcy_code else ' ' end as pup_undrlyg_auto_plcy_code,  case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_risk_profile_code else '     ' end as pup_risk_profile_code,   classif_code, case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_endorsement_ind_code else '  ' end as pup_endorsement_ind_code,  case when src_tab.line_of_busn_name = 'PersonalUmbrella' then liability_limit_code else ' ' end as liability_limit_code, case when src_tab.line_of_busn_name = 'PersonalUmbrella' then pup_um_liability_limit_code else ' ' end as pup_um_liability_limit_code, 1 AS pup_selfinsur_retention_code,  exposure, State_Exception_Ind_code,  zip_code, 10 AS company_program_excpt_ind, 9 AS statistical_plan_ind_code,  prem_amt,  prem_record_id,  Policy_Join_id
/*transaction_eff_date,
Transaction_Exp_Date*/
FROM ${V_TRNS_DB}.iso_pl_liability_prem_loss src_tab
LEFT JOIN $V_LGCY_DMACT.ref_am_risk_State st_code on src_tab.state_code = st_code.stateabbrev  
LEFT JOIN 
    (SELECT * FROM $V_EDW_EXTERNAL.ent_ref_code WHERE alt_code_type_name='ISO-CO' AND group_code='ISO' AND code_type_Name ='UNDERWRITING-CO') pl_co     ON src_tab.company_num=pl_co.code ) inner_pl_liab
LEFT JOIN (SELECT MAX(pl_eic) as envirmnt_impair_cov_code, MAX(pl_mold_damage_cd) as mold_damage_coverage_code, MAX(pl_umb_attach_pt_ho) as pup_undrlyg_ho_pl_limit_code, MAX(pl_umb_attach_pt_ppa) as pup_undrlyg_BIl_limit_code, MAX(pl_umb_ul_policy_ind) as pup_undrlyg_ho_pl_plcy_code, MAX(pl_umb_ul_auto_policy_ind) as pup_undrlyg_auto_plcy_code, MAX(pl_umb_risk_profile) as pup_risk_profile_code, MAX(pl_classification_cd) as classif_code, MAX(pl_umb_endorse_ind) as pup_endorsement_ind_code, MAX(pl_umb_um_uim_ind) as pup_um_liability_limit_code, MAX(pl_liability_lmt_ind) as liability_limit_code, MAX(pl_st_exception_ind) as State_Exception_Ind_code, Policy_Join_id, prem_record_id from ${V_TRNS_DB}.liabilitypremium_iso_pl_liability_prem_loss_resulting_codes group by Policy_Join_id, prem_record_id) lkp
on inner_pl_liab.prem_record_id=lkp.prem_record_id and inner_pl_liab.Policy_Join_id=lkp.Policy_Join_id
group by inner_pl_liab.Policy_Join_id, inner_pl_liab.prem_record_id) base;

 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"

if [ $? == 0 ]

then info "ISO_PLSP_PREMIUMLIABILITY No Fault Prem file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO_PLSP_PREMIUMLIABILITY No Fault Prem file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO_PLSP_PREMIUMLIABILITY No Fault Prem Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO_PLSP_PREMIUMLIABILITY No Fault Prem Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
