#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO PASP Auto Paid Loss_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO PASP Auto Paid Loss file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../../shell_functions/bin/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/PASP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="PASP_Liability_Premium_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO PLSP Homeowners Paid Loss"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

hive -S -e"
set hive.strict.checks.cartesian.product=false;
 select iso_pasp_auto_liability.Statistical_Plan_Ind_Code as Statistical_Plan_ind_code, iso_pasp_auto_liability.ISO_Transaction_type_code as ISO_Transaction_Type_code, '  ' as Reserved_01, lpad(coalesce(refcomp.alt_code,'    '),4,' ') as company_num, lpad(coalesce(iso_pasp_auto_liability.Record_Type_code,' '),1,' ') as Record_type_code, lpad(coalesce(concat(lpad(substr(cast(iso_pasp_auto_liability.accounting_date as varchar(25)),6,2),2,0),lpad(substr(cast(iso_pasp_auto_liability.accounting_date as varchar(25)),1,4),4,0)),'      '),6,' ') as accounting_date, lpad(coalesce(concat(lpad(substr(cast(iso_pasp_auto_liability.Inception_date as varchar(25)),6,2),2,0),lpad(substr(cast(iso_pasp_auto_liability.Inception_date as varchar(25)),1,4),4,0)),'      '),6,' ') as Inception_date, lpad(coalesce(concat(lpad(substr(cast(iso_pasp_auto_liability.Transaction_eff_date as varchar(25)),6,2),2,0),lpad(substr(cast(iso_pasp_auto_liability.Transaction_eff_date as varchar(25)),9,2),2,0),lpad(substr(cast(iso_pasp_auto_liability.Transaction_eff_date as varchar(25)),1,4),4,0)),'        '),8,' ') as Transaction_eff_date, lpad(coalesce(concat(lpad(substr(cast(iso_pasp_auto_liability.Transaction_exp_date as varchar(25)),6,2),2,0),lpad(substr(cast(iso_pasp_auto_liability.Transaction_exp_date as varchar(25)),9,2),2,0),lpad(substr(cast(iso_pasp_auto_liability.Transaction_exp_date as varchar(25)),1,4),4,0)),'        '),8,' ') as Transaction_exp_date, lpad(coalesce(cast(st_code.alt_code as varchar(2)),'  '),2,' ') as state_code, CASE WHEN iso_pasp_auto_liability.state_code in ('PA','GA') THEN lpad(coalesce(iso_pasp_auto_liability.Territory_code,'000'),3,'0') WHEN iso_pasp_auto_liability.state_code ='CT' THEN lpad(coalesce(ter_code.alt_code,'000'),3,'0') else '   '  END as Territory_code, lpad(coalesce(substr(iso_pasp_auto_liability.Zip_code,1,5),'     '),5,' ') as zip_code, '    ' as reserve02,coalesce(iso_pasp_auto_liability.Busn_type_code,' '),lpad(coalesce(iso_pasp_auto_liability.Policy_type_code,'  '),2,' ') as Policy_type_code,' ' as reserve03, 
 
 
coalesce(case WHEN iso_pasp_auto_liability.coverage_join_id='PATotDisability' THEN '903000' WHEN iso_pasp_auto_liability.coverage_join_id='PAAutoDthBenefitsCov' THEN '904000' WHEN iso_pasp_auto_liability.coverage_join_id='PAPropDmgLiabBybck' THEN '926600' WHEN iso_pasp_auto_liability.coverage_join_id='PAExtNonOwnLmtCov' AND iso_pasp_auto_liability.coverage_term_value_code='NIP' THEN '902100' WHEN iso_pasp_auto_liability.coverage_join_id='PAExtNonOwnLmtCov' AND iso_pasp_auto_liability.coverage_term_value_code='NIFMPL' THEN '902200' WHEN iso_pasp_auto_liability.coverage_join_id='PAExtNonOwnLmtCov' AND iso_pasp_auto_liability.coverage_term_value_code='NINP' THEN '902300' WHEN iso_pasp_auto_liability.coverage_join_id='PAExtNonOwnLmtCov' AND iso_pasp_auto_liability.coverage_term_value_code='NIFMWOPL' THEN '902400' WHEN iso_pasp_auto_liability.coverage_join_id='PAExtNonOwnLmtCov' AND iso_pasp_auto_liability.coverage_term_value_code='NIF' THEN '902500' WHEN iso_pasp_auto_liability.coverage_join_id='PAExtNonOwnLmtCov' AND iso_pasp_auto_liability.coverage_term_value_code='NIFMFE' THEN '902600'
WHEN state_code='NC' then
 case when  iso_pasp_auto_liability.vehicle_type_code='motorCycle' then
  CASE WHEN iso_pasp_auto_liability.engine_size_name BETWEEN 0 AND 499 THEN '951300' WHEN iso_pasp_auto_liability.engine_size_name BETWEEN 500 AND 1249 THEN '951400' WHEN iso_pasp_auto_liability.engine_size_name BETWEEN 12500 AND 1499 THEN '951500' WHEN iso_pasp_auto_liability.engine_size_name >=1500 THEN '951600' END
     WHEN iso_pasp_auto_liability.vehicle_type_code not in ( 'auto', 'motorCycle') then
  CASE WHEN iso_pasp_auto_liability.engine_size_name BETWEEN 0 AND 499 THEN '967100' WHEN iso_pasp_auto_liability.engine_size_name BETWEEN 500 AND 1249 THEN '967200' WHEN iso_pasp_auto_liability.engine_size_name BETWEEN 12500 AND 1499 THEN '967300' WHEN iso_pasp_auto_liability.engine_size_name >=1500 THEN '967400' END
 end
 
when iso_pasp_auto_liability.vehicle_type_code = 'auto' then lpad(concat(lpad(coalesce(lkp.CLASSIF_CD_14,'    '),4,' '),lpad(coalesce(lkp.CLASSIF_CD_56,'  '),2,'0')),6,' ') 
 else  lpad(coalesce(lkp.CLASSIF_CD_MISC,lpad(concat(lpad(coalesce(lkp.CLASSIF_CD_14,'    '),4,' '),lpad(coalesce(lkp.CLASSIF_CD_56,'  '),2,'0')),6,' ') ),6,' ') END,'      ') as Classif_code ,

 lpad(coalesce(iso_pasp_auto_liability.Vehicle_Motorcycle_cnt_code,' '),1,' '),lpad(coalesce(iso_pasp_auto_liability.Vehicle_w_youthful_cnt_code,'0' ),1,' '),lpad(coalesce(iso_pasp_auto_liability.policy_operators_cnt,' '),1,' '),lpad(coalesce(iso_pasp_auto_liability.Vehicle_operator_cnt,' '),1,' '),lpad(coalesce(iso_pasp_auto_liability.Principal_operator_code,' '),1,' '), coalesce(iso_pasp_auto_liability.birth_date,'        ') as birth_date,
 lpad(coalesce(iso_pasp_auto_liability.Gender_code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Marital_status_code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Vehicle_use_code,' '),1,' ')
 ,'  ' ,' ' as Drive_days_code,
 lpad(round(cast(lpad(coalesce(case when iso_pasp_auto_liability.estimated_annual_mileage % 1000 >= 500 then iso_pasp_auto_liability.estimated_annual_mileage+500 else iso_pasp_auto_liability.estimated_annual_mileage end, 0)/1000 ,2, '0') as integer)),2,0) as Estimated_annual_mileage,
 lpad(coalesce(iso_pasp_auto_liability.Persistency_month_year,'     '),6,'0') as Persistency_month_date,
 ' ' as Vehicle_performance_code,
lpad(coalesce(iso_pasp_auto_liability.Driver_licensed_date_code,'999999'),6,'0')   as Driver_licensed_date_code,'  ' , lpad(coalesce(iso_pasp_auto_liability.Traffic_Convict_Major_cnt,'00'),2,'0') as Traffic_Convict_Major_cnt  , lpad(coalesce(iso_pasp_auto_liability.Traffic_Convict_Minor_cnt,'00'),2,'0') as Traffic_Convict_Minor_cnt,
 '  ' as Chrgbl_AtFault_Accident_Cnt, 
 lpad(coalesce(iso_pasp_auto_liability.AtFault_Accident_BI_cnt,'00'),2,'0') as AtFault_Accident_BI_cnt,
 lpad(coalesce(iso_pasp_auto_liability.Chrgbl_AtFlt_Accdnt_PD_Cnt,'00'),2,'0') as Chrgbl_AtFlt_Accdnt_PD_Cnt,
 lpad(coalesce(iso_pasp_auto_liability.Good_Driver_Discount_code,' '),1,' '),
 CASE WHEN iso_pasp_auto_liability.Classif_code like '9%' THEN lpad(coalesce(iso_pasp_auto_liability.Driver_Traing_Discount_code,' '),1,' ') ELSE ' ' END,
 ' ' as Good_Student_Discount_code,
 lpad(coalesce(iso_pasp_auto_liability.Defensive_Driver_Discnt_Code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.AntiLock_Brake_Discnt_Code, ' '),1,' '),
 ' ' as Multi_car_Discount_code,
 lpad(coalesce(iso_pasp_auto_liability.Multi_policy_code, ' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.rated_operator_usage_pct,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Smoker_status_code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Rate_Level_ind_code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Point_Forgiveness_code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Daytime_Lights_Discnt_Code,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Model_Year_code,'    '),4,' ') as Model_Year_code,
 rpad(coalesce(iso_pasp_auto_liability.VIN,'                 '),17,' ') as VIN,
 lpad(coalesce(iso_pasp_auto_liability.Policy_num,'0'),20,'0') as Policy_num,
 lpad('B',30,' ') as reserve04, '  ' as reserve05,
 coalesce(Per_Plcy_Ind_Code,' '),' ' as reserve06,
 lpad(coalesce(iso_pasp_auto_liability.atfault_bi_sec_addl_drv_cnt,' '),2,' ') as atfault_bi_sec_addl_drv_cnt,
 lpad(coalesce(iso_pasp_auto_liability.atfault_pd_sec_addl_drv_cnt,' '),2,' ') as atfault_pd_sec_addl_drv_cnt,
 lpad(coalesce(iso_pasp_auto_liability.Frst_Addl_Drv_prncpl_Oprtr_Cd,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.Sec_Addl_Drv_prncpl_Oprtr_Cd,' '),1,' '),
 lpad(coalesce(iso_pasp_auto_liability.ISO_PASP_Subline_Code,'   '),3,' ') as ISO_PASP_Subline_Code,
 '  ' as reserve07,
 coalesce(iso_pasp_auto_liability.Limit_Id_code,' '),
CASE when concat(iso_pasp_auto_liability.ISO_PASP_Subline_Code,iso_pasp_auto_liability.Limit_Id_code) in ('5011','5051','5081','5111','5131','5031','5071','5101','5042','5022','5062','5092','5122') then '    ' else lpad(coalesce(cast(round(iso_pasp_auto_liability.Claim_BI_Liability_Limit_Amt) as integer),'    ' ),4,'0') END as Claim_BI_Liability_Limit_Amt,
 CASE when concat(iso_pasp_auto_liability.ISO_PASP_Subline_Code,iso_pasp_auto_liability.Limit_Id_code) in ('5042','5022','5062','5092','5122') then '    ' else lpad(coalesce(cast(round(iso_pasp_auto_liability.occurrence_bi_liability_limit_amt) as integer),'    ' ),4,'0') END as Occurance_BI_Liability_Limit_Amt,
'   ' as reserve08,
lpad(coalesce(cast(round(iso_pasp_auto_liability.claim_bi_deduct_amt) as integer),'    ' ),4,'0') as claim_bi_deduct_amt,
' ' as reserve09,lpad(coalesce(cast(round(iso_pasp_auto_liability.occurrence_bi_deduct_amt) as integer),'    ' ),4,'0') as occurrence_bi_deduct_amt,
CASE when concat(iso_pasp_auto_liability.ISO_PASP_Subline_Code,iso_pasp_auto_liability.Limit_Id_code) in ('5012','5052','5082','5112','5132','5011','5051','5081','5111','5131','5031','5071','5101','5042') then '    ' else 
lpad(coalesce(cast(round(iso_pasp_auto_liability.PD_Liab_Limit_amt) as integer),'    '),4,'0') END as PD_Liab_Limit_amt,
' ' as reserve10,lpad(coalesce(cast(iso_pasp_auto_liability.PD_Deductible_Amt as integer),'    ' ),4,'0') as PD_Deductible_Amt,
CASE when concat(iso_pasp_auto_liability.ISO_PASP_Subline_Code,iso_pasp_auto_liability.Limit_Id_code) in ('5012','5052','5082','5112','5132','5011','5051','5081','5111','5131','5031','5071','5101','5022','5062','5092','5122') then '    ' else 
lpad(coalesce(cast(round(iso_pasp_auto_liability.medical_pay_limit_amt) as integer),'    ' ),4,'0') END as medical_pay_limit_amt,
' ' as reserve11,
lpad(coalesce(cast(round(iso_pasp_auto_liability.Medical_Pay_Deduct_Amt) as integer),'    ' ),4,'0') as Medical_Pay_Deduct_Amt,
 '          ' as reserve12,
 lpad(coalesce(iso_pasp_auto_liability.Passive_Restraint_code,'1'),1,'1'),
 ' ' as reserve13,
 case when iso_pasp_auto_liability.state_code in ('CT','GA','MD') then lpad(coalesce(lkp.State_Exception_code,'  '),2,' ') else  lpad(coalesce(iso_pasp_auto_liability.State_Exception_code,'  '),2,' ') END as State_Exception_code,
 '  ' as reserve14,
 lpad(coalesce(iso_pasp_auto_liability.Traffic_convct_opr2_majr_cnt,'  '),2,' ') as Traffic_convct_opr2_majr_cnt,
 lpad(coalesce(iso_pasp_auto_liability.Traffic_convct_opr2_minr_cnt,'  '),2,' ') as Traffic_convct_opr2_minr_cnt,
 '  ' as reserve15,
 lpad(coalesce(iso_pasp_auto_liability.atfault_bi_frst_addl_drv_cnt,'  '),2,' ') as atfault_bi_frst_addl_drv_cnt,
 lpad(coalesce(iso_pasp_auto_liability.AtFault_PD_Frst_Addl_Drv_Cnt,'  '),2,' ') as AtFault_PD_Frst_Addl_Drv_Cnt,
 lpad(coalesce(iso_pasp_auto_liability.Frst_Addl_Drv_Licensd_Dt_Cd,'      '),6,' ') as Frst_Addl_Drv_Licensd_Dt_Cd,
 lpad(coalesce(iso_pasp_auto_liability.Sec_Addl_Drv_Licensd_Dt_Cd,'      '),6,' ') as Sec_Addl_Drv_Licensd_Dt_Cd,
 lpad(coalesce(iso_pasp_auto_liability.elgbl_point_addl_drv1_code,'  '),2,' ') as elgbl_point_addl_drv1_code,
 lpad(coalesce(iso_pasp_auto_liability.elgbl_point_addl_drv2_code,'  '),2,' ') as elgbl_point_addl_drv2_code,
 lpad(coalesce(iso_pasp_auto_liability.frst_addl_drv_pnt_frgv_code,' '),1,' ') as frst_addl_drv_pnt_frgv_code,
 lpad(coalesce(iso_pasp_auto_liability.Sec_Addl_Drv_Pnt_Frgv_Code,' '),1,' ') as Sec_Addl_Drv_Pnt_Frgv_Code,
 ' ' as reserve16,
 lpad(coalesce(case when cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer)< 0 then concat(substr(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string),2,length(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string))-2), case substr(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string),length(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string)), length(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string))+1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end ) when cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer)> 0 then case when substr(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string),1,1)='+'then concat( substr(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string),2,length(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string))-2), case substr(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string),length(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string)),length(cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string))+1) when '0' then '{' when '1' then 'A' when '2' then 'B' when '3' then 'C' when '4' then 'D' when '5' then 'E' when '6' then 'F' when '7' then 'G' when '8' then 'H' when '9' then 'I' end ) else cast(cast(round(cast(iso_pasp_auto_liability.premium_amt as decimal(20,4))) as integer) as string) end else '00000000' end,'        ') ,8,'0') as Premium_amt,
lpad(coalesce(iso_pasp_auto_liability.annual_statement_line_code,'   '),3,' ') as annual_statement_line_code from 
(
select 
iso_pasp_auto_liability.Policy_num,iso_pasp_auto_liability.policy_join_id,iso_pasp_auto_liability.Transaction_key,iso_pasp_auto_liability.Cost_key,iso_pasp_auto_liability.Traffic_convct_opr2_minr_cnt,
iso_pasp_auto_liability.AtFault_PD_Frst_Addl_Drv_Cnt,
iso_pasp_auto_liability.Classif_code,
iso_pasp_auto_liability.coverage_term_value_code,
iso_pasp_auto_liability.engine_size_name,
iso_pasp_auto_liability.Traffic_convct_opr2_majr_cnt,
iso_pasp_auto_liability.Claim_BI_Liability_Limit_Amt,
iso_pasp_auto_liability.vehicle_type_code,
iso_pasp_auto_liability.occurrence_bi_liability_limit_amt,
iso_pasp_auto_liability.claim_bi_deduct_amt,
iso_pasp_auto_liability.occurrence_bi_deduct_amt,
iso_pasp_auto_liability.PD_Liab_Limit_amt,
iso_pasp_auto_liability.PD_Deductible_Amt,
iso_pasp_auto_liability.medical_pay_limit_amt,
iso_pasp_auto_liability.Medical_Pay_Deduct_Amt,
iso_pasp_auto_liability.Limit_Id_code,
iso_pasp_auto_liability.Per_Plcy_Ind_Code,
iso_pasp_auto_liability.Smoker_status_code,
iso_pasp_auto_liability.rated_operator_usage_pct,
iso_pasp_auto_liability.Vehicle_performance_code,
iso_pasp_auto_liability.Multi_policy_code,
iso_pasp_auto_liability.Good_Student_Discount_code,
iso_pasp_auto_liability.policy_operators_cnt,
iso_pasp_auto_liability.vehicle_operator_cnt,
iso_pasp_auto_liability.Statistical_Plan_ind_code,
iso_pasp_auto_liability.ISO_Transaction_Type_code,
iso_pasp_auto_liability.company_num,
iso_pasp_auto_liability.Record_type_code,
iso_pasp_auto_liability.accounting_date,
iso_pasp_auto_liability.Inception_date,
iso_pasp_auto_liability.transaction_eff_date,
iso_pasp_auto_liability.transaction_exp_date,
iso_pasp_auto_liability.state_code,
iso_pasp_auto_liability.territory_code,
iso_pasp_auto_liability.zip_code,
iso_pasp_auto_liability.busn_type_code,
iso_pasp_auto_liability.Policy_Type_code,
iso_pasp_auto_liability.Vehicle_Motorcycle_cnt_code,
iso_pasp_auto_liability.Vehicle_W_Youthful_Cnt_code,
iso_pasp_auto_liability.principal_operator_code,
iso_pasp_auto_liability.birth_date,
iso_pasp_auto_liability.Gender_code,
iso_pasp_auto_liability.Marital_Status_code,
iso_pasp_auto_liability.Vehicle_Use_code,
iso_pasp_auto_liability.Estimated_Annual_Mileage,
iso_pasp_auto_liability.Persistency_month_year,
iso_pasp_auto_liability.Driver_Licensed_date_code,
iso_pasp_auto_liability.Traffic_Conviction_cnt,
iso_pasp_auto_liability.Traffic_Convict_Major_cnt,
iso_pasp_auto_liability.Traffic_Convict_Minor_cnt,
iso_pasp_auto_liability.Chrgbl_AtFault_Accident_Cnt,
iso_pasp_auto_liability.AtFault_Accident_BI_cnt,
iso_pasp_auto_liability.Chrgbl_AtFlt_Accdnt_PD_Cnt,
iso_pasp_auto_liability.Good_Driver_Discount_code,
iso_pasp_auto_liability.Driver_Traing_Discount_code,
iso_pasp_auto_liability.Defensive_Driver_Discnt_Code,
iso_pasp_auto_liability.AntiLock_Brake_Discnt_Code,
iso_pasp_auto_liability.Rate_Level_ind_code,
iso_pasp_auto_liability.Point_Forgiveness_code,
iso_pasp_auto_liability.Daytime_Lights_Discnt_Code,
iso_pasp_auto_liability.Model_Year_code,
iso_pasp_auto_liability.Vin,
iso_pasp_auto_liability.AtFault_BI_Sec_Addl_Drv_cnt,
iso_pasp_auto_liability.atfault_pd_sec_addl_drv_cnt,
iso_pasp_auto_liability.Frst_Addl_Drv_PRNCPL_OPRTR_Cd,
iso_pasp_auto_liability.Sec_Addl_Drv_PRNCPL_OPRTR_Cd,
iso_pasp_auto_liability.ISO_PASP_Subline_Code,
iso_pasp_auto_liability.coverage_join_id,
iso_pasp_auto_liability.Passive_Restraint_code,
iso_pasp_auto_liability.State_Exception_code,
iso_pasp_auto_liability.AtFault_BI_Frst_Addl_Drv_cnt,
iso_pasp_auto_liability.Frst_Addl_Drv_Licensd_Dt_Cd,
iso_pasp_auto_liability.Sec_Addl_Drv_Licensd_Dt_Cd,
iso_pasp_auto_liability.elgbl_point_addl_drv1_code,
iso_pasp_auto_liability.elgbl_point_addl_drv2_code,
iso_pasp_auto_liability.Frst_Addl_Drv_Pnt_Frgv_Code,
iso_pasp_auto_liability.Sec_Addl_Drv_Pnt_Frgv_Code,
premamt.premium_amt as premium_amt,
iso_pasp_auto_liability.Annual_Statement_Line_code,
iso_pasp_auto_liability.source_system_code,iso_pasp_auto_liability.create_dateyyyymm

from 
( 
select  
Policy_num,policy_period_join_id as policy_join_id  ,Transaction_key,Cost_key,
max(vehicle_type_code) as vehicle_type_code,
max(Classif_code) as Classif_code,
max(engine_size_name) as engine_size_name,
max(elgbl_point_addl_drv2_code) as elgbl_point_addl_drv2_code,
max(elgbl_point_addl_drv1_code) as elgbl_point_addl_drv1_code,
max(Frst_Addl_Drv_Licensd_Dt_Cd) as Frst_Addl_Drv_Licensd_Dt_Cd,
max(AtFault_PD_Frst_Addl_Drv_Cnt) as AtFault_PD_Frst_Addl_Drv_Cnt,
max(Traffic_convct_opr2_minr_cnt) as Traffic_convct_opr2_minr_cnt,
max(Traffic_convct_opr2_majr_cnt) as Traffic_convct_opr2_majr_cnt,
max(State_Exception_code) as State_Exception_code,
max(Claim_BI_Liability_Limit_Amt) as Claim_BI_Liability_Limit_Amt,
max(occurrence_bi_liability_limit_amt) as occurrence_bi_liability_limit_amt,
max(claim_bi_deduct_amt) as claim_bi_deduct_amt,
max(occurrence_bi_deduct_amt) as occurrence_bi_deduct_amt,
max(PD_Liab_Limit_amt) as PD_Liab_Limit_amt,
max(PD_Deductible_Amt) as PD_Deductible_Amt,
max(medical_pay_limit_amt) as medical_pay_limit_amt,
max(Medical_Pay_Deduct_Amt) as Medical_Pay_Deduct_Amt,
max(Limit_Id_code) as Limit_Id_code,
max(atfault_pd_sec_addl_drv_cnt) as atfault_pd_sec_addl_drv_cnt,
max(Per_Plcy_Ind_Code) as Per_Plcy_Ind_Code,
max(Smoker_status_code) as Smoker_status_code,
max(rated_operator_usage_pct) as rated_operator_usage_pct,
max(Multi_policy_code) as Multi_policy_code,
max(Good_Student_Discount_code) as Good_Student_Discount_code,
max(Vehicle_performance_code) as Vehicle_performance_code,
max(Persistency_month_year) as Persistency_month_year,
max(policy_operators_cnt) as policy_operators_cnt,
max(vehicle_operator_cnt) as vehicle_operator_cnt,
max(Statistical_Plan_ind_code) as Statistical_Plan_ind_code,
max(ISO_Transaction_Type_code) as ISO_Transaction_Type_code,
max(company_num) as company_num,
max(Record_type_code) as Record_type_code,
max(create_dateyyyymm) as accounting_date,
max(Inception_date) as Inception_date,
max(transaction_eff_date) as transaction_eff_date,
max(transaction_exp_date) as transaction_exp_date,
max(state_code) as state_code,
max(territory_code) as territory_code,
max(zip_code) as zip_code,
max(busn_type_code) as busn_type_code,
max(Policy_Type_code) as Policy_Type_code,
max(Vehicle_Motorcycle_cnt_code) as Vehicle_Motorcycle_cnt_code,
max(Vehicle_W_Youthful_Cnt_code) as Vehicle_W_Youthful_Cnt_code,
max(principal_operator_code) as principal_operator_code,
max(birth_date) as birth_date,
max(Gender_code) as Gender_code,
max(Marital_Status_code) as Marital_Status_code,
max(Vehicle_Use_code) as Vehicle_Use_code,
max(Estimated_Annual_Mileage) as Estimated_Annual_Mileage,
max(Driver_Licensed_date_code) as Driver_Licensed_date_code,
max(Traffic_Conviction_cnt) as Traffic_Conviction_cnt,
max(Traffic_Conviction_Major_cnt) as Traffic_Convict_Major_cnt,
max(Traffic_Conviction_Minor_cnt) as Traffic_Convict_Minor_cnt,
max(Chrgbl_AtFault_Accident_Cnt) as Chrgbl_AtFault_Accident_Cnt,
max(AtFault_Accident_BI_cnt) as AtFault_Accident_BI_cnt,
max(Chrgbl_AtFlt_Accdnt_PD_Cnt) as Chrgbl_AtFlt_Accdnt_PD_Cnt,
max(Good_Driver_Discount_code) as Good_Driver_Discount_code,
max(Driver_Traing_Discount_code) as Driver_Traing_Discount_code,
max(Defensive_Driver_Discnt_Code) as Defensive_Driver_Discnt_Code,
max(AntiLock_Brake_Discnt_Code) as AntiLock_Brake_Discnt_Code,
max(Rate_Level_ind_code) as Rate_Level_ind_code,
max(Point_Forgiveness_code) as Point_Forgiveness_code,
max(Daytime_Lights_Discnt_Code) as Daytime_Lights_Discnt_Code,
max(Model_Year_code) as Model_Year_code,
max(Vin) as Vin,
max(AtFault_BI_Sec_Addl_Drv_cnt) as AtFault_BI_Sec_Addl_Drv_cnt,
max(Frst_Addl_Drv_PRNCPL_OPRTR_Cd) as Frst_Addl_Drv_PRNCPL_OPRTR_Cd,
max(Sec_Addl_Drv_PRNCPL_OPRTR_Cd) as Sec_Addl_Drv_PRNCPL_OPRTR_Cd,
max(ISO_PASP_Subline_Code) as ISO_PASP_Subline_Code,
max(Passive_Restraint_code) as Passive_Restraint_code,
max(AtFault_BI_Frst_Addl_Drv_cnt) as AtFault_BI_Frst_Addl_Drv_cnt,
max(Sec_Addl_Drv_Licensd_Dt_Cd) as Sec_Addl_Drv_Licensd_Dt_Cd,
max(Frst_Addl_Drv_Pnt_Frgv_Code) as Frst_Addl_Drv_Pnt_Frgv_Code,
max(Sec_Addl_Drv_Pnt_Frgv_Code) as Sec_Addl_Drv_Pnt_Frgv_Code,
max(Annual_Statement_Line_code) as Annual_Statement_Line_code,
max(coverage_join_identifier) as coverage_join_id,
max(coverage_term_value_code) as coverage_term_value_code,
Max(source_system_code) as source_system_code,max(create_dateyyyymm) as create_dateyyyymm
from $V_TRNS_DB.iso_pasp_auto_liability
where source_system_code='Liability' 
group by policy_num, policy_period_join_id,Transaction_key,Cost_key
) iso_pasp_auto_liability 
left join (select policy_num, policy_join_id,Transaction_key,Cost_key, cast(round(sum(cast(premium_amt as decimal(20,4)))) as integer) as premium_amt
from (select distinct policy_num, policy_period_join_id as policy_join_id,Transaction_key,Cost_key,premium_amt
from $V_TRNS_DB.iso_pasp_auto_liability where source_system_code='Liability')new1
group by policy_num, policy_join_id,Transaction_key,Cost_key) premamt on iso_pasp_auto_liability.policy_num = premamt.policy_num and iso_pasp_auto_liability.policy_join_id = premamt.policy_join_id and iso_pasp_auto_liability.Transaction_key = premamt.Transaction_key and iso_pasp_auto_liability.Cost_key = premamt.Cost_key
)iso_pasp_auto_liability
left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code_type_Name = 'UNDERWRITING-CO' and refcomp.code = iso_pasp_auto_liability.company_num left join $V_EDW_EXTERNAL.ent_ref_code st_code on st_code.code=iso_pasp_auto_liability.state_code and st_code.code_type_Name ='STATE-CD' and st_code.alt_code_type_name='STATE-NUM' left join $V_EDW_EXTERNAL.ent_ref_code ter_code on upper(ter_code.code_desc)=upper(iso_pasp_auto_liability.territory_code)  and ter_code.alt_code_type_name='ISO-CT-TOWN-CD' left join $V_TRNS_DB.liab_iso_pasp_auto_resulting_codes lkp on iso_pasp_auto_liability.policy_num = lkp.policy_num and iso_pasp_auto_liability.policy_join_id = lkp.policy_join_id and iso_pasp_auto_liability.Transaction_key = lkp.Transaction_key and iso_pasp_auto_liability.Cost_key = lkp.Cost_key where iso_pasp_auto_liability.source_system_code='Liability' and iso_pasp_auto_liability.Premium_amt <>0   ;
 " | sed 's/[\t]//g' > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO PASP Auto Liability file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO PASP Liability file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO PASP Liability Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO PASP Liability Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
