#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_CA_prem_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_iso}"'CA/Premium/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="PDPG3566.D""$V_DATE_PART"".T""$V_TIME_PART"".Q""$V_CURR_QTR""_Premium_CA.out"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO CA Premium file"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

echo "Company_Number|Transaction_Type|Accounting_Date|Inception_Date|Transaction_Effective_Date|Transaction_Expiration_Date|RiskState|Territory_Code|Type_of_Policy_Code|Annual_Statement_Line_of_Business|Commercial_Stat_Plan_Subline_Code|Classification_Code|Limits_Identifier|RF1|PIP_Limit_Code|Coverage_Code|PIP_Deductible_Code|RF2|RF3|PIP_Rating_Basis_Code|Limits_Codes|RF4|Liability_Deductible_Code|Number_of_Powered_Vehicles_on_the_Policy|State_Exception_Code|Ant-Theft_Device_Code|Extended_Business_Income_Number_of_Days_Code|Value_Per_Rating_Unit_Code|Driver_Record_Surcharges|Price_Bracket_Code|Garage_and_Auto_Dealers_Aggregate_Limit_Indicator_Field|Mechanical_Lift_Indicator_Code|RF5|Zone_Rating_Zone|Endorsement_Indicator_Code|Ride_Sharing_Arrangements_Indicator|Business_Interruption_Exposure_Code|Per_Occurrence_Limit|RF6|RF7|RF8|Rating_Identification_Code|RF9|Deductible_Amount|Zip_Code|No_Fault_Limit|Per_Claimant_Limit|RF10|Transaction_Effective_Day|Transaction_Expiration_Day|MGA_Indicator|Terrorism_Coverage_code|Schedule_Rating_Modification|Exposure|Exposure_Unit|Rating_Modification_Factor|Loss_Cost_Multiplier|Rate_Departure_Factor|Transaction_ID|Other_Than_Collision_Premium_Amount|Bodily_Injury_Premium_Amount|Premium_Amount|RF11|Property_Damage_Premium_Amount|Collision_Premium_Amount|NAICS_Code|Standard_Industrial_Classification_Code|Premium_Record_Identification|Company_Use|Risk_Address|City|AddressState" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";


hive -S -e"
select 
NVL(Company_num,''),
NVL(Iso_transaction_type_code,''),
NVL(from_unixtime(unix_timestamp(accounting_date ,'yyyy-MM-dd'), 'yyyyMM'),''),
NVL(from_unixtime(unix_timestamp(inception_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
NVL(from_unixtime(unix_timestamp(transaction_eff_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
NVL(from_unixtime(unix_timestamp(transaction_exp_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
NVL(Risk_State_code,''),
NVL(Territory_code,''),
NVL(Iso_Policy_Type_code,''),
NVL(Annual_Statement_Line_code,''),
NVL(Iso_csp_subline_code,''),
NVL(Iso_classification_Code,''),
NVL(Limits_id_code,''),
'' as RF1,
NVL(PIP_Limit_code,''),
NVL(Coverage_code,''),
NVL(PIP_deduct_code,''),
'' as RF2,
'' as RF3,
NVL(PIP_rating_basis_code,''),
NVL(Limits_code,''),
'' as RF4,
NVL(Liability_deduct_code,''),
NVL(Powered_Vehicle_cnt,''),
NVL(Iso_state_exception_code,''),
NVL(Anti_theft_device_code,''),
NVL(Vehicle_Age_Income_Days_code,''),
NVL(Value_Per_Rating_Unit_code,''),
NVL(Driver_Record_surcharge_amt,''),
NVL(Price_Bracket_code,''),
NVL(Garage_Dealer_Limit_code,''),
NVL(Mechanical_lift_ind,''),
'' as RF5,
NVL(Zone_rating_code,''),
NVL(Endorsement_ind_code,''),
NVL(Ride_sharing_ind,''),
NVL(busn_intrptn_Exposure_code,''),
NVL(Occurrence_Limit,''),
'' as RF6,
'' as RF7,
'' as RF8,
NVL(Rating_identification_code,''),
'' as RF9,
NVL(deduct_amt,''),
NVL(Zip_5_code,''),
NVL(No_Fault_limit,''),
NVL(Per_Claimant_Limit,''),
'' as RF10,
NVL(Transaction_eff_Day,''),
NVL(Transaction_exp_Day,''),
NVL(MGA_ind,''),
NVL(Terrorism_Coverage_code,''),
NVL(Schedule_Rating_Modification,''),
NVL(Exposure_amt,''),
NVL(Exposure_Unit_code,''),
NVL(Rating_Modification_Factor,''),
NVL(loss_Cost_Multiplier,''),
NVL(Rate_Departure_Factor,''),
NVL(Transaction_id_code,''),
NVL(OTC_prem_amt,''),
NVL(Bodily_Injury_prem_amt,''),
NVL(prem_amt,''),
'' as RF11,
NVL(Property_Damage_prem_amt,''),
NVL(Collision_prem_amt,''),
NVL(NAICS_code,''),
NVL(Standard_Industry_Class_code,''),
NVL(Policy_num,''),
NVL(Positions_For_Company_Use,''),
NVL(Risk_addr_Lines,''),
NVL(City_name,''),
NVL(State_code,'')
FROM $V_TRNS_DB.ISO_CA_PREM
WHERE
cast(accounting_date AS date) BETWEEN '${V_FROM_DATE}' AND '${V_TO_DATE}'" | sed 's/[\t]/|/g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO CA Premium file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO CA Premium Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
