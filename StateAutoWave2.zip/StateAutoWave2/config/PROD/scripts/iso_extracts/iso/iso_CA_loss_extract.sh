#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_CA_loss_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_iso}"'CA/Loss/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="PDPG3566.D""$V_DATE_PART"".T""$V_TIME_PART"".Q""$V_CURR_QTR""_Loss_CA.out"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO CA Loss"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

echo "Company_Number|Transaction_Type|Accounting_Date|Inception_Date|Loss_Date|MGA_Indicator|RiskState|Territory_Code|Type_of_Policy_Code|Annual_Statement_Line_of_Business|Commercial_Stat_Plan_Subline_Code|Classification_Code|RF1|Limits_Identifier|Limits_Codes|PIP_Limit_Code|Coverage_Code|RF2|PIP_Deductible_Code|RF3|Liability_Deductible_Code|RF4|RF5|State_Exception_Code|PIP_Rating_Basis_Code|RF6|Ant-Theft_Device_Code|AccidentState|Extended_Business_Income_Number_of_Days_Code|Value_Per_Rating_Unit_Code|Mechanical_Lift_Indicator_Code|Stated_Amount_Identifier|Age_Code|RF7|Zone_Rating_Zone|Endorsement_Indicator_Code|Ride_Sharing_Arrangements_Indicator|RF8|Number_of_Powered_Vehicles_on_the_Policy|Price_Bracket_Code|Business_Interruption_Exposure_Code|Driver_Record_Surcharges|Transaction_ID|Rating_Identification_Code|RF9|Deductible_Amount|Zip_Code|RF10|Type_of_Loss|Claim_Count|Standard_Industrial_Classification_Code|Terrorism_Coverage_Code|Per_Occurrence_Limit|RF11|Per_Claimant_Limit|No_Fault_Limit|RF12|NAICS_Code|Loss_Amount|Loss_Record_Identifer|Claim_ID|Premium_Record_Identification|Company_Use|Risk_Address|City" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";


hive -S -e"
select 
nvl(company_num,''),
nvl(iso_transaction_type_code,''),
nvl(from_unixtime(unix_timestamp(accounting_date ,'yyyy-MM-dd'), 'yyyyMM'),''),
nvl(from_unixtime(unix_timestamp(inception_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(from_unixtime(unix_timestamp(loss_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(mga_ind,''),
nvl(risk_state_code,''),
nvl(territory_code,''),
nvl(iso_policy_type_code,''),
nvl(annual_statement_line_code,''),
nvl(iso_csp_subline_code,''),
nvl(iso_classification_code,''),
'' as RF1,
nvl(limits_id_code,''),
nvl(limits_code,''),
nvl(pip_limit_code,''),
nvl(coverage_code,''),
'' as RF2,
nvl(pip_deduct_code,''),
'' as RF3,
nvl(liability_deduct_code,''),
'' as RF4,
'' as RF5,
nvl(iso_state_exception_code,''),
nvl(pip_rating_basis_code,''),
'' as RF6,
nvl(anti_theft_device_code,''),
nvl(accident_state_code,''),
nvl(vehicle_year,''),
nvl(value_per_rating_unit_code,''),
nvl(mechanical_lift_ind,''),
nvl(vehicle_manufacture_year,''),
nvl(vehicle_manufacture_year,''),
'' as RF7,
nvl(zone_rating_code,''),
nvl(endorsement_ind_code,''),
nvl(ride_sharing_ind,''),
'' as RF8,
nvl(powered_vehicle_cnt,''),
nvl(price_bracket_code,''),
nvl(busn_intrptn_exposure_code,''),
nvl(driver_record_surcharge_amt,''),
nvl(transaction_id_code,''),
nvl(rating_identification_code,''),
'' as RF9,
nvl(deduct_txt_amt,''),
nvl(zip_code,''),
'' as RF10,
nvl(bureau_cause_of_loss_code,''),
nvl(claim_cnt,''),
nvl(standard_industry_class_code,''),
nvl(terrorism_coverage_code,''),
nvl(occurrence_limit,''),
'' as RF11,
nvl(per_claimant_limit,''),
nvl(no_fault_limit,''),
'' as RF12,
nvl(naics_code,''),
nvl(loss_amt,''),
nvl(claim_num,''),
nvl(claim_exposure_seq_num,''),
nvl(policy_num,''),
nvl(positions_for_company_use,''),
nvl(risk_addr_lines,''),
nvl(city_name,'')
FROM $V_TRNS_DB.ISO_CA_LOSS
WHERE
cast(accounting_date AS date) BETWEEN '${V_FROM_DATE}' AND '${V_TO_DATE}'" | sed 's/[\t]/|/g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO CA Loss file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR :  ISO CA Loss Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO CA Loss Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO CA Loss Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
