#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : TICO_HO_Paid_Loss_EXTRACT.sh                                         #
#                                                                             #
# Description  : Script to generate TICO HO Paid Loss file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_ACCDT_YYYYMM=${ACCDT_YYYYMM}



if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]] 
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [ -z "$V_ACCDT_YYYYMM" ]
then
info "Message : Accounting Date in YYYYMM format is not passed. Dynamically getting the range based on current date"
V_ACCDT_YYYYMM=`date -d"1 month ago" +"%Y%m"`
fi


info "Message : The Accounting Year Month is $V_ACCDT_YYYYMM"



V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_tico}"
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="TICO_HO_Paid_Loss_TX_""$V_ACCDT_YYYYMM"".txt"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "The Accounting Year Month is $V_ACCDT_YYYYMM" 

info "Generating TICO HO Paid Loss TX file"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
select concat (
lpad(case when stat_plan_name='' or stat_plan_name is null then '0' else stat_plan_name end,1,' '),
'0',
lpad(case when accounting_date='' or accounting_date is null then '00' else accounting_date end,2,' '),
'00',
lpad(case when policy_num='' or policy_num is null then '0000000000' else policy_num end,10,' '),
'0',
lpad(case when accident_date='' or accident_date is null then '00000' else accident_date end,5,' '),
lpad(case when eff_date='' or eff_date is null then '000' else eff_date end,3,' '),
lpad(case when place_code='' or place_code is null then '00000' else place_code end,5,' '),
lpad(case when loss_type_code='' or loss_type_code is null then '0' else loss_type_code end,1,' '),
'00',
lpad(case when insurance_amt='' or insurance_amt is null then '0000' else insurance_amt end,4,'0'),
lpad(case when fire_flex_code='' or fire_flex_code is null then '000' else fire_flex_code end,3,' '),
lpad(case when tico_line_of_busn_code='' or tico_line_of_busn_code is null then '00' else tico_line_of_busn_code end,2,' '),
lpad(case when tico_company_num='' or tico_company_num is null then '000' else tico_company_num end,3,' '), 
'0000',
lpad(case when policy_form_code='' or policy_form_code is null then '0' else policy_form_code end,1,' '),
lpad(case when family_occupancy_cnt_code='' or family_occupancy_cnt_code is null then '0' else family_occupancy_cnt_code end,1,' '),
lpad(case when occupancy_code='' or occupancy_code is null then '0' else occupancy_code end,1,' '),
lpad(case when construction_code='' or construction_code is null then '0' else construction_code end,1,' '),
lpad(case when iso_ppc_new_split_class_code='' or iso_ppc_new_split_class_code is null then '00' else iso_ppc_new_split_class_code end,2,' '),
lpad(case when iso_ppc_code='' or iso_ppc_code is null then '0' else iso_ppc_code end,1,' '),
lpad(case when deduct_01_type_code='' or deduct_01_type_code is null then '0' else deduct_01_type_code end,1,' '),
lpad(case when deduct_02_type_code='' or deduct_02_type_code is null then '0' else deduct_02_type_code end,1,' '),
lpad(case when ho_loss_type_code='' or ho_loss_type_code is null then '0' else ho_loss_type_code end,1,' '),
'0',
lpad(case when claim_cnt='' or claim_cnt is null then '0' else claim_cnt end,1,' '),
lpad(case when loss_amt='' or loss_amt is null then '000000' else loss_amt end,6,'0'),
lpad(case when zip_code='' or zip_code is null then '000000000' else zip_code end,9,' '),
'000000',
'0',
lpad(case when roof_cover_credit_code='' or roof_cover_credit_code is null then '0' else roof_cover_credit_code end,1,' '),
lpad(case when roof_instl_year='' or roof_instl_year is null then '0000' else roof_instl_year end,4,' '),
lpad(case when excl_cosmetic_roof_dmg_ind='' or excl_cosmetic_roof_dmg_ind is null then '0' else excl_cosmetic_roof_dmg_ind end,1,' '),
lpad(case when bureau_cause_of_loss_code='' or bureau_cause_of_loss_code is null then '00' else bureau_cause_of_loss_code end,2,'0'),
lpad(case when acv_roof_endorsemint_ind='' or acv_roof_endorsemint_ind is null then '0' else acv_roof_endorsemint_ind end,1,' '),
lpad(case when acv_less_replacement_cost='' or acv_less_replacement_cost is null then '00000' else acv_less_replacement_cost end,5,' '),
'00',
lpad(case when rpt_type_code='' or rpt_type_code is null then '0' else rpt_type_code end,1,' '),
lpad(case when optnl_cov_endorsement_code='' or optnl_cov_endorsement_code is null then '00000000' else optnl_cov_endorsement_code end,8,' '),
lpad(case when optnl_cov_endorsement_code_amt='' or optnl_cov_endorsement_code_amt is null then '000000' else optnl_cov_endorsement_code_amt end,6,' '),
lpad(case when hoa_attached_ind='' or hoa_attached_ind is null then '0' else hoa_attached_ind end,1,' '),
lpad(case when ded_01_amt='' or ded_01_amt is null then '000000' else cast(cast(round(cast(ded_01_amt as double)) as integer) as string)  end,6,'0'),
lpad(case when ded_02_amt='' or ded_02_amt is null then '000000' else cast(cast(round(cast(ded_02_amt as double)) as integer) as string) end,6,'0'),
lpad(case when wind_coverage_ind='' or wind_coverage_ind is null then '0' else wind_coverage_ind end,1,' '),
'00000',
lpad(case when building_credit_code_code='' or building_credit_code_code is null then '00' else building_credit_code_code end,2,' '),
lpad(case when tico_law_ordinance_cov_code='' or tico_law_ordinance_cov_code is null then '0' else tico_law_ordinance_cov_code end,1,' '),
lpad(case when sprinkler_credit_ind='' or sprinkler_credit_ind is null then '0' else sprinkler_credit_ind end,1,' '),
'0',
lpad(case when property_protection_ind='' or property_protection_ind is null then '0' else property_protection_ind end,1,' '),
lpad(case when tenure_discount_code='' or tenure_discount_code is null then '0' else tenure_discount_code end,1,' '),
lpad(case when tenure_discount_amt='' or tenure_discount_amt is null then '00' else tenure_discount_amt end,2,' '),
lpad(case when replacement_cov_limit_ind='' or replacement_cov_limit_ind is null then '0' else replacement_cov_limit_ind end,1,' '),
lpad(case when replace_cov_limit_disc_code='' or replace_cov_limit_disc_code is null then '00' else replace_cov_limit_disc_code end,2,' '),
lpad(case when naics_code='' or naics_code is null then '00000' else naics_code end,5,' ') ) 
from 
(select stat_plan_name, 
'0', 
case when substr(cast(accounting_date as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
when substr(cast(accounting_date as string),6,2) ='10' then concat('0',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(accounting_date as string),7,1),substr(cast(accounting_date as string),4,1))
end as accounting_date,
'  ',
policy_num,
'0',
concat(substr(cast(accident_date as string),6,2),substr(cast(accident_date as string),9,2),substr(cast(accident_date as string),4,1)) as accident_date,
concat(substr(cast(src_tab.eff_date as string),6,2),substr(cast(src_tab.eff_date as string),4,1)) as eff_date,
place_code,
loss_type_code,
'00',
/*lpad(case when insurance_amt='' or insurance_amt is null then '0000' else
case when cast (round(cast (insurance_amt as double)) as integer) < 0 then
concat(
substr(cast (cast (round(cast (insurance_amt as double)) as integer) as string),
2, (length (cast (cast (round(cast (insurance_amt as double)) as integer) as string))) -2),
CASE substr(cast (cast (round(cast (insurance_amt as double)) as integer) as string),length(cast (cast (round(cast (insurance_amt as double)) as integer) as string)),length(cast (cast (round(cast (insurance_amt as double)) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
)
else
cast (cast (round(cast (insurance_amt as double)) as integer) as string) end
end,4,'0') as insurance_amt*/lpad(coalesce(case when substr(cast(cast(round(cast(insurance_amt as decimal(18,0)),-3)/1000 as decimal(18,0)) as varchar(20)),1,1)='-' then concat(substr(cast(cast(round(cast(insurance_amt as decimal(18,0)),-3)/1000 as decimal(18,0)) as varchar(20)),2,(length(cast(cast(round(cast(insurance_amt as decimal(18,0)),-3)/1000 as decimal(18,0)) as varchar(20)))-2)),(case substr(cast(cast(round(cast(insurance_amt as decimal(18,0)),-3)/1000 as decimal(18,0)) as varchar(20)),length(cast(cast(round(cast(insurance_amt as decimal(18,0)),-3)/1000 as decimal(18,0)) as varchar(20))),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)) else cast(cast(round(cast(insurance_amt as decimal(18,0)),-3)/1000 as decimal(18,0)) as varchar(20)) end,'0000'),4,'0') as insurance_amt,
fire_flex_code,
tico_line_of_busn_code,
lpad(case when tico_co.alt_code='' or tico_co.alt_code is null or tico_co.alt_code='NA' then '000' else tico_co.alt_code end,3,' ') as tico_company_num, 
'0000',
policy_form_code,
family_occupancy_cnt_code,
occupancy_code,
tico_constr.alt_code as construction_code,
iso_ppc_new_split_class_code,
iso_ppc_code,
case when policy_form_code in ('H','J') or policy_form_code in ('h','j') then '0'
     when coalesce(ded.alt_code,ded1.alt_code) is not null then coalesce(ded.alt_code,ded1.alt_code)
     when cast(deduct_01_type_code as integer) > 10 and cast(deduct_01_type_code as integer) < 100 and ded.alt_code is null then '9'
     else ' '
end as deduct_01_type_code	
,case when coalesce(ded2.alt_code,ded3.alt_code) is not null then coalesce(ded2.alt_code,ded3.alt_code)
     when cast(deduct_02_type_code as double) > 10 and cast(deduct_02_type_code as double) < 100 and ded2.alt_code is null then '9'
     else ' '
end as deduct_02_type_code,	 
ho_loss_type_code,
'0',
case when claim_cnt = 1 then '1'
when claim_cnt = -1 then 'J' 
when claim_cnt = 0 then '0' end as claim_cnt,
/*lpad(case when loss_amt='' or loss_amt is null then '0000' else
case when cast (round(cast (loss_amt as double)) as integer) < 0 then
concat(
substr(cast (cast (round(cast (loss_amt as double)) as integer) as string),
2, (length (cast (cast (round(cast (loss_amt as double)) as integer) as string))) -2),
CASE substr(cast (cast (round(cast (loss_amt as double)) as integer) as string),length(cast (cast (round(cast (loss_amt as double)) as integer) as string)),length(cast (cast (round(cast (loss_amt as double)) as integer) as string))+1) 
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
)
else
cast (cast (round(cast (loss_amt as double)) as integer) as string) end
end,4,'0') as loss_amt*/lpad(coalesce(case when substr(cast(cast(loss_amt as decimal(18,0)) as varchar(20)),1,1)='-' then concat(substr(cast(cast(loss_amt as decimal(18,0)) as varchar(20)),2,(length(cast(cast(loss_amt as decimal(18,0)) as varchar(20)))-2)),(case substr(cast(cast(loss_amt as decimal(18,0)) as varchar(20)),length(cast(cast(loss_amt as decimal(18,0)) as varchar(20))),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)) else cast(cast(loss_amt as decimal(18,0)) as varchar(20)) end,'000000'),6,'0') as loss_amt,
zip_code,
'000000',
'0',
roof_cover_code,
roof_cover_credit_code,
roof_instl_year,
excl_cosmetic_roof_dmg_ind,
case when (bclc.alt_code='' or bclc.alt_code is NULL or bclc.alt_code='NA' ) then '00' when length(bclc.alt_code)=1 then concat('0',bclc.alt_code) else bclc.alt_code end as bureau_cause_of_loss_code,
acv_roof_endorsemint_ind,
acv_less_replacement_cost,
'00',
rpt_type_code,
optnl_cov_endorsement_code,
concat('00',optnl_cov_endorsement_code_amt) as optnl_cov_endorsement_code_amt,
hoa_attached_ind,
cast(cast(round(cast(deduct_01_amt as double)) as integer) as string) as ded_01_amt,
cast(cast(round(cast(deduct_02_amt as double)) as integer) as string) as ded_02_amt,
wind_coverage_ind,
'00000',
building_credit_code_code,
tico_law_ordinance_cov_code,
sprinkler_credit_ind,
'0',
property_protection_ind,
tenure_discount_code,
tenure_discount_amt,
replacement_cov_limit_ind,
replace_cov_limit_disc_code,
naics_code 
from 
$V_TRNS_DB.tico_ho_df_prem_loss src_tab
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name='TICO-CO') tico_co on src_tab.tico_company_num=tico_co.code
left join
(select * from $V_EDW_EXTERNAL.ent_ref_code where  alt_code_type_name = 'TICO-CONSTRCD')tico_constr
on src_tab.construction_code=tico_constr.code
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded on ded.ded_cd= (case when src_tab.deduct_01_type_code='' then 0.00 else cast (cast (src_tab.deduct_01_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded1 on ded1.ded_cd = src_tab.deduct_01_type_code and src_tab.deduct_01_type_code= 'WindHailExcl'
left join
(select alt_code,cast(cast(code as double) as decimal(18,2)) as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code not in ('>10 and <100','WindHailExcl')
) ded2 on ded2.ded_cd= (case when src_tab.deduct_02_type_code='' then 0.00 else cast (cast (src_tab.deduct_02_type_code as double) as decimal(18,2))end)
left join
(select alt_code,code as ded_cd from $V_EDW_EXTERNAL.ent_ref_code 
where  alt_code_type_name = 'TICO-DEDCD' and code in ('WindHailExcl')
) ded3 on ded3.ded_cd = src_tab.deduct_02_type_code and src_tab.deduct_02_type_code= 'WindHailExcl'
left join 
(select distinct alt_code,code from $V_EDW_EXTERNAL.ent_ref_code where alt_code_type_name='TICO-COL' and code_type_name='LOSS-COL' and group_code='TICO' ) bclc on bclc.code=src_tab.bureau_cause_of_loss_code
where extract_type_name='TICO-MNTH-HOLOSS'
and accounting_dateyyyymm=$V_ACCDT_YYYYMM
) q
" >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "TICO HO Paid Loss file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "TICO HO Paid Loss TX file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
