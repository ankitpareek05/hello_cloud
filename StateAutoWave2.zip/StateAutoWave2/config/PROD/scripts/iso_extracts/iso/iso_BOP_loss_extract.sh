#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_BOP_loss_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_iso}"'BOP/Loss/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="PDPG3566.D""$V_DATE_PART"".T""$V_TIME_PART"".Q""$V_CURR_QTR""_Loss_BOP.out"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO BOP Loss"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

echo "CompanyNumber|TransactionTypeCode|AccountingDateMonthYear|InceptionDateMonthYear|LossDate|MGAIndicator|StateCode|TerritoryCode|TypeofPolicyCode|AnnualStatementLineofBusinessCode|CommercialStatisticalPlanSublineCode|ClassificationCode|CoverageCode|RF1|RatingIdentificationCode|ConstructionCode|PublicProtectionCode|DeductibleAmount|TerrorismCoverageCode|RF2|WindCoverageDeductID|BCEG|RatingBasisCode|StateExceptionIndicatorCode|RatingModifierCode|BusinessIncomeExtraExpenseLimitCode|LiabilityCoverageIndicator|LiabilityLimit|TransactionID|RF3|LiabilityFormCode|EntryintoClaimsMadeMonthYear|ReceiptofClaimsNotice|LiabilityExposureIndicator|RF4|MoldDamageCoverageCode|TypeofLossCode|ClaimCount|ZipCode|LessorOCCRiskID|RF5|RF6|StateExceptionIndicatorCodeII|Exposure|ZIPCode1|BusinessInterOffPremExposure|GreenUpgradeUnderlyingBusinessExposure|YearofConstructionCode|RF7|LossAmount|LossRecordIdOccurrenceID|ClaimID|PremiumRecordID|RF8|Address|City|State|ZipCode2|MedicalLiabilityLimit|MA_LeadEndorsementException|MA_ResidentFuelException|MD_LeadHazardException|AL_MetalRoofException|AL_WindCertException|SC_WindMitException" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";


hive -S -e"
select 
nvl(company_num,''),
nvl(iso_transaction_type_code,''),
nvl(from_unixtime(unix_timestamp(accounting_date ,'yyyy-MM-dd'), 'yyyyMM'),''),
nvl(from_unixtime(unix_timestamp(inception_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(from_unixtime(unix_timestamp(loss_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(mga_indicator,''),
nvl(risk_state_code,''),
nvl(territory_code,''),
nvl(iso_policy_type_code,''),
nvl(annual_statement_line_code,''),
nvl(iso_csp_subline_code,''),
nvl(iso_classif_code,''),
nvl(coverage_code,''),
'' as RF1,
nvl(risk_identification_code,''),
nvl(construction_code,''),
nvl(public_protection_code,''),
nvl(deduct_amt,''),
nvl(terrorism_coverage_code,''),
'' as RF2,
nvl(wind_coverage_deduct_code,''),
nvl(bceg_classification_code,''),
nvl(rating_basis_code_txt,''),
nvl(state_exception_01_code,''),
nvl(rating_modifier_code,''),
nvl(biee_limit_code,''),
nvl(liability_form_ind,''),
nvl(liability_limit_amt,''),
nvl(iso_transaction_id_code,''),
'' as RF3,
nvl(liability_form_coverage_code,''),
nvl(claims_made_start_dttm,''),
nvl(report_dttm,''),
nvl(liability_exposure_ind_code,''),
'' as RF4,
nvl(mold_damage_coverage_code,''),
nvl(bureau_cause_of_loss_code,''),
nvl(paid_claim_cnt,''),
nvl(zip_5_code,''),
nvl(lessor_occ_risk_code,''),
'' as RF5,
'' as Rf6,
nvl(state_exception_02_code,''),
nvl(exposure_basis_or_limit_code,''),
nvl(zip_4_code,''),
nvl(off_prems_intrptn_limit_code,''),
nvl(green_upgd_undrlyg_expsr_amt,''),
nvl(construction_year,''),
'' as RF7,
nvl(loss_amt,''),
nvl(claim_num,''),
nvl(claim_id,''),
nvl(policy_num,''),
'' as RF8,
nvl(risk_addr_lines,''),
nvl(city_name,''),
nvl(state_code,''),
nvl(zip_code,''),
nvl(medical_liability_limit_amt,''),
nvl(ma_lead_exception_code,''),
nvl(ma_fuel_tank_exception_code,''),
nvl(md_lead_hazrd_exception_code,''),
nvl(al_metal_roof_type_code,''),
nvl(al_wind_hail_cert_type_code,''),
nvl(sc_wind_loss_mit_disc_factor,'')
FROM $V_TRNS_DB.ISO_BOP_LOSS
WHERE
cast(accounting_date AS date) BETWEEN '${V_FROM_DATE}' AND '${V_TO_DATE}'" | sed 's/[\t]/|/g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO BOP Loss file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR :  ISO BOP Loss Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO BOP Loss Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO BOP Loss Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
