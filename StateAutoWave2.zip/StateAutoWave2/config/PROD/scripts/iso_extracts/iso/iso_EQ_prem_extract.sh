#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_EQ_prem_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]] 
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi
fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_iso}"'EQ/Premium/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="PDPG3566.D""$V_DATE_PART"".T""$V_TIME_PART"".Q""$V_CURR_QTR""_Premium_EQ.out"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO EQ Premium file"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

echo "Company_num|Trans_type|ACCTG_DT|INCEPTION_DT|TRANS_EFF_DT|TRANS_EXP_DT|State_Cd|Territory_Cd|Pol_Type_Cd|ASLOB|CSP_Subline_Cd|Classification_cd|EQ_Cov_Type_Cd|EQ_Attachment_Ind|EQ_Coverage_CD|EQ_Risk_Identification_Cd|Const_Code|RF1|Deductible|Rate_Grade|Bldng_Ht_Code|RF2|EQ_SubLimit_Expsr|RF3|Zipcode|RF4|RFExpansion|Expsr_base_Ind|Exposure|RF5|Loss_Cost_Multiplier|BCEG_Classification_Code|Prem_amt|RF6|RF7|SIC_Code|Premium_Record_ID|Company_Use|riskAddress|CityInternal|State_code|Zipcode1" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";


hive -S -e"
select 
nvl(company_num,''),
nvl(iso_transaction_type_code,''),
nvl(from_unixtime(unix_timestamp(accounting_date ,'yyyy-MM-dd'), 'yyyyMM'),''),
nvl(from_unixtime(unix_timestamp(inception_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(from_unixtime(unix_timestamp(transaction_eff_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(from_unixtime(unix_timestamp(transaction_exp_date ,'yyyy-MM-dd'), 'MM/dd/yyyy HH:MM:SS'),''),
nvl(risk_state_code,''),
nvl(territory_code,''),
nvl(iso_policy_type_code,''),
nvl(annual_statement_line_code,''),
nvl(iso_csp_subline_code,''),
nvl(iso_classification_code,''),
nvl(iso_earthquake_coverage_code,''),
nvl(earthquake_attachment_ind,''),
nvl(coverage_code,''),
nvl(earthquake_risk_id_code,''),
nvl(construction_code,''),
'' as RF1,
nvl(deduct_code,''),
nvl(rate_grade_code,''),
nvl(building_height_code,''),
'' as RF2,
nvl(earthquake_sublimit_expsr_amt,''),
'' as RF3,
nvl(substr(zip_code,1,5),''),
'' as RF4,
nvl(reserved_expansion_of_expsr,''),
nvl(exposure_base_ind_code,''),
nvl(exposure_amt,''),
'' as RF5,
nvl(loss_cost_multiplier,''),
nvl(bceg_classification_code,''),
nvl(prem_amt,''),
'' as Rf6,
'' as RF7,
nvl(standard_industry_class_code,''),
nvl(policy_num,''),
nvl(positions_for_company_use,''),
nvl(risk_addr_lines,''),
nvl(city_name,''),
nvl(state_code,''),
nvl(zip_code,'')
FROM $V_TRNS_DB.ISO_EARTHQUAKE_PREM
WHERE
cast(accounting_date AS date) BETWEEN '${V_FROM_DATE}' AND '${V_TO_DATE}'" | sed 's/[\t]/|/g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO EQ Premium file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO EQ Premium Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
