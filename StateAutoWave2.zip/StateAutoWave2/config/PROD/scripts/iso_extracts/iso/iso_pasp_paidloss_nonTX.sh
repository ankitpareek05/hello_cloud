#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO PASP Auto Paid Loss_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO PASP Auto Paid Loss file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR} 

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/PASP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="PASP_AUTO_LOSS_PAID_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO PLSP Homeowners Paid Loss"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
select lpad(coalesce(ISO_PASP_Auto.Statistical_Plan_ind_code,' '),1,' ') as Statistical_Plan_ind_code,
lpad(coalesce(ISO_PASP_Auto.ISO_Transaction_Type_code,' '),1,' ') as ISO_Transaction_Type_code,
'  ' as Reserved_01,
lpad(coalesce(refcomp.alt_code,'    '),4,' ') as company_num,
lpad(coalesce(ISO_PASP_Auto.Record_type_code,' '),1,' ') as Record_type_code,
concat(substr(cast('${V_TO_DATE}' as string), 1, 4), substr(cast('${V_TO_DATE}' as string), 6, 2)) as accounting_date,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.Inception_date as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.Inception_date as varchar(25)),1,4)),'      '),6,' ') as Inception_date,
'        ' as Reserved_02,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.Loss_date as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.Loss_date as varchar(25)),9,2),substr(cast(ISO_PASP_Auto.Loss_date as varchar(25)),1,4)),'        '),8,' ') as Loss_date,
lpad(coalesce(cast(st_code.alt_code as varchar(2)),'  '),2,' ') as state_code,
lpad(coalesce(ISO_PASP_Auto.Territory_code,'   '),3,' ') as territory_code,
lpad(coalesce(substr(ISO_PASP_Auto.Zip_code,1,5),'     '),5,' ') as zip_code,
'    ' as Reserved_03,
ISO_PASP_Auto.busn_type_code as Type_of_Business_Code,
ISO_PASP_Auto.policy_type_code as Type_of_Policy_Code,
' ' as Reserved_04,
concat(lpad(coalesce(lkp.CLASSIF_CD_14,'    '),4,' '),lpad(coalesce(lkp.CLASSIF_CD_56,'  '),2,' ')) as Classif_code,
lpad(coalesce(ISO_PASP_Auto.Vehicle_Motorcycle_cnt_code,' '),1,' ') as Vehicle_Motorcycle_cnt_code,
lpad(coalesce(ISO_PASP_Auto.Vehicle_W_Youthful_Cnt_code,' '),1,' ') as Vehicle_W_Youthful_Cnt_code,
lpad(coalesce(ISO_PASP_Auto.Operators_cnt,' '),1,' ') as Operators_cnt,
' ' as Number_of_Operators_of_Vehicle,
lpad(coalesce(ISO_PASP_Auto.Principal_Operator_code,' '),1,' ') as Principal_Operator_code,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.Age as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.Age as varchar(25)),9,2),substr(cast(ISO_PASP_Auto.Age as varchar(25)),1,4)),'        '),8,' ') as Age,
lpad(coalesce(ISO_PASP_Auto.Gender_code,' '),1,' ') as Gender_code,
lpad(coalesce(ISO_PASP_Auto.Marital_Status_code,' '),1,' ') as Marital_Status_code,
lpad(coalesce(ISO_PASP_Auto.Vehicle_Use_code,' '),1,' ') as Vehicle_Use_code,
'   ' as Reserved_05,
lpad(coalesce(ISO_PASP_Auto.Estimated_Annual_Mileage,'00'),2,'0') as Estimated_Annual_Mileage,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.Persistency as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.Persistency as varchar(25)),1,4)),'      '),6,' ') as Persistency,
' ' as Reserved_06,
lpad(coalesce(concat(substr(cast(ISO_PASP_Auto.Driver_Licensed_date_code as varchar(25)),6,2),substr(cast(ISO_PASP_Auto.Driver_Licensed_date_code as varchar(25)),1,4)),'      '),6,' ') as Driver_Licensed_date_code,
lpad(coalesce(ISO_PASP_Auto.Traffic_Conviction_cnt,'00'),2,'0') as Traffic_Conviction_cnt,
lpad(coalesce(ISO_PASP_Auto.Traffic_Convict_Major_cnt,'00'),2,'0') as Traffic_Convict_Major_cnt,
lpad(coalesce(ISO_PASP_Auto.Traffic_Convict_Minor_cnt,'00'),2,'0') as Traffic_Convict_Minor_cnt,
lpad(coalesce(ISO_PASP_Auto.Chrgbl_AtFault_Accident_Cnt,'00'),2,'0') as Chrgbl_AtFault_Accident_Cnt,
lpad(coalesce(ISO_PASP_Auto.AtFault_Accident_BI_cnt,'00'),2,'0') as AtFault_Accident_BI_cnt,
lpad(coalesce(ISO_PASP_Auto.Chrgbl_AtFlt_Accdnt_PD_Cnt,'00'),2,'0') as Chrgbl_AtFlt_Accdnt_PD_Cnt,
lpad(coalesce(ISO_PASP_Auto.Good_Driver_Discount_code,' '),1,' ') as Good_Driver_Discount_code,
lpad(coalesce(ISO_PASP_Auto.Driver_Traing_Discount_code,' '),1,' ') as Driver_Traing_Discount_code,
' ' as Good_Student_Discount_Code,
lpad(coalesce(ISO_PASP_Auto.Defensive_Driver_Discnt_Code,' '),1,' ') as Defensive_Driver_Discnt_Code,
lpad(coalesce(ISO_PASP_Auto.AntiLock_Brake_Discnt_Code,' '),1,' ') as AntiLock_Brake_Discnt_Code,
' ' as Multi_car_Discount_code,
'   ' as Reserved_07,
lpad(coalesce(ISO_PASP_Auto.Rate_Level_ind_code,' '),1,' ') as Rate_Level_ind_code,
lpad(coalesce(ISO_PASP_Auto.Point_Forgiveness_code,' '),1,' ') as Point_Forgiveness_code,
lpad(coalesce(ISO_PASP_Auto.Daytime_Lights_Discnt_Code,' '),1,' ') as Daytime_Lights_Discnt_Code,
lpad(coalesce(ISO_PASP_Auto.Model_Year_code,'    '),4,' ') as Model_Year_code,
rpad(coalesce(ISO_PASP_Auto.vin,'                 '),17,' ') as Vin	,
lpad(coalesce(ISO_PASP_Auto.Policy_num,'                    '),20,' ') as Policy_num,
'                              ' as Reserved_08,
lpad(coalesce(cast(acc_st_code.alt_code as varchar(2)),'  '),2,' ') as Loss_Location_State_code,
' ' as Reserved_09,
' ' as Reserved_10,
lpad(coalesce(ISO_PASP_Auto.AtFault_BI_Sec_Addl_Drv_cnt,'00'),2,'0') as AtFault_BI_Sec_Addl_Drv_cnt,
lpad(coalesce(ISO_PASP_Auto.Chrgbl_AtFlt_PD_sec_drvr_Cnt,'00'),2,'0') as Chrgbl_AtFlt_PD_sec_drvr_Cnt,
lpad(coalesce(ISO_PASP_Auto.Frst_Addl_Drv_PRNCPL_OPRTR_Cd,' '),1,' ') as Frst_Addl_Drv_PRNCPL_OPRTR_Cd,
lpad(coalesce(ISO_PASP_Auto.Sec_Addl_Drv_PRNCPL_OPRTR_Cd,' '),1,' ') as Sec_Addl_Drv_PRNCPL_OPRTR_Cd,
lpad(coalesce(ISO_PASP_Auto.ISO_PASP_Subline_Code,'   '),3,' ') as ISO_PASP_Subline_Code,
lpad(coalesce(ISO_PASP_Auto.Bureau_Cause_of_Loss_code,'  '),2,' ') as Bureau_Cause_of_Loss_code,
lpad(coalesce(lkp.NF_COV_CODE,'   '),3,' ') as NoFault_Coverage_Code,
lpad(coalesce(ISO_PASP_Auto.Coordinat_NoFault_Benefit_Code,'  '),2,' ') as Coordinat_NoFault_Benefit_Code,
lpad(coalesce(ISO_PASP_Auto.NoFault_Deductible_Type_Code,'  '),2,' ') as NoFault_Deductible_Type_Code,
' ' as Reserved_11,
lpad(coalesce(lkp.NF_DED_AMT,'    '),4,' ') as NoFault_deduct_amt,
lpad(coalesce(ISO_PASP_Auto.NoFault_classif_code,'  '),2,' ') as NoFault_classif_code,
lpad(coalesce(ISO_PASP_Auto.NoFault_CoPayment_Type_code,' '),1,' ') as NoFault_CoPayment_Type_code,
lpad(coalesce(ISO_PASP_Auto.NoFault_CoPayment_amt,'   '),3,' ') as NoFault_CoPayment_amt,
'           ' as Reserved_12,
lpad(coalesce(ISO_PASP_Auto.Claim_num,'                    '),20,' ') as Claim_num,
lpad(coalesce(ISO_PASP_Auto.Passive_Restraint_code,' '),1,' ') as Passive_Restraint_code,
' ' as Reserved_13,
lpad(coalesce(ISO_PASP_Auto.State_Exception_code,'  '),2,' ') as State_Exception_code,
'        ' as Reserved_14,
lpad(coalesce(ISO_PASP_Auto.AtFault_BI_Frst_Addl_Drv_cnt,'00'),2,'0') as AtFault_BI_Frst_Addl_Drv_cnt,
lpad(coalesce(ISO_PASP_Auto.AtFault_PD_Frst_Addl_Drvr_cnt,'00'),2,'0') as AtFault_PD_Frst_Addl_Drvr_cnt,
lpad(coalesce(ISO_PASP_Auto.Frst_Addl_Drv_Licensed_Dt_Cd,'      '),6,' ') as Frst_Addl_Drv_Licensed_Dt_Cd,
lpad(coalesce(ISO_PASP_Auto.Sec_Addl_Drv_Licensd_Dt_Cd,'      '),6,' ') as Sec_Addl_Drv_Licensd_Dt_Cd,
lpad(coalesce(ISO_PASP_Auto.ELGBL_Point_Frst_Addl_Drv_Code,'  '),2,' ') as ELGBL_Point_Frst_Addl_Drv_Code,
lpad(coalesce(ISO_PASP_Auto.ELGBL_Points_Sec_Addl_Drv_Code,'  '),2,' ') as ELGBL_Points_Sec_Addl_Drv_Code,
lpad(coalesce(ISO_PASP_Auto.Frst_Addl_Drv_Pnt_Frgv_Code,' '),1,' ') as Frst_Addl_Drv_Pnt_Frgv_Code,
lpad(coalesce(ISO_PASP_Auto.Sec_Addl_Drv_Pnt_Frgv_Code,' '),1,' ') as Sec_Addl_Drv_Pnt_Frgv_Code,
Claim_cnt as Claim_cnt,
lpad(case when substr(cast(cast(loss_amt as decimal(18,0)) as varchar(20)),1,1)='-' then concat(substr(cast(cast(loss_amt as decimal(18,0)) as varchar(20)),2,(length(cast(cast(loss_amt as decimal(18,0)) as varchar(20)))-2)),(case substr(cast(cast(loss_amt as decimal(18,0)) as varchar(20)),length(cast(cast(loss_amt as decimal(18,0)) as varchar(20))),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)) else cast(cast(loss_amt as decimal(18,0)) as varchar(20)) end,8,'0') as loss_amt,
lpad(coalesce(ISO_PASP_Auto.Annual_Statement_Line_code,'   '),3,' ') as Annual_Statement_Line_code
from $V_TRNS_DB.ISO_PASP_Auto ISO_PASP_Auto
left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code = ISO_PASP_Auto.company_num
left join $V_EDW_EXTERNAL.ent_ref_code st_code on st_code.code=ISO_PASP_Auto.state_code
left join $V_EDW_EXTERNAL.ent_ref_code acc_st_code on acc_st_code.code=ISO_PASP_Auto.Loss_Location_State_code
left join $V_TRNS_DB.paidloss_iso_pasp_auto_resulting_codes lkp on ISO_PASP_Auto.policy_num = lkp.policy_num and ISO_PASP_Auto.policy_join_id = lkp.policy_join_id and ISO_PASP_Auto.Transaction_key = lkp.Transaction_key and ISO_PASP_Auto.Cost_key = lkp.Cost_key
where ISO_PASP_Auto.source_system_code='PAIDLOSS'
and ISO_PASP_Auto.create_dateyyyymm >= cast(concat(substr(cast('${V_FROM_DATE}' as string), 1, 4), substr(cast('${V_FROM_DATE}' as string), 6, 2)) as int) 
and ISO_PASP_Auto.create_dateyyyymm <= cast(concat(substr(cast('${V_TO_DATE}' as string), 1, 4), substr(cast('${V_TO_DATE}' as string), 6, 2)) as int) ;
 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO PASP Auto Paid Loss file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO PASP Auto Paid Loss file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO PASP Auto Paid Loss Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO PASP Auto Paid Loss Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
