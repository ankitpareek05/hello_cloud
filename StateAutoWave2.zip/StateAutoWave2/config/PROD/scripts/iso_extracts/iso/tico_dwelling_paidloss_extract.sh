#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : TICO Dwelling PaidLoss.sh                                         #
#                                                                             #
# Description  : Script to generate TICO Dwelling Premium file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}  

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_ACCDT_YYYYMM=${ACCDT_YYYYMM}



if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [ -z "$V_ACCDT_YYYYMM" ]
then
info "Message : Accounting Date in YYYYMM format is not passed. Dynamically getting the range based on current date"
V_ACCDT_YYYYMM=`date -d"1 month ago" +"%Y%m"`
fi



V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path_tico}"
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`

V_FILE_NAME="TICO_DW_Paid_Loss_TX_""$V_ACCDT_YYYYMM"".txt"





#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
         # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
        # Log File Details
        mkdir -p ${v_tmp_path_curation}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "The Accounting Year Month is $V_ACCDT_YYYYMM"

info "Generating TICO DWELLING PAIDLOSS"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
select
   distinct 
   lpad(stat_plan_name, 1, '0'),
   lpad(rsv1, 1, '0'),
   lpad(accounting_date, 2, '0'),
   lpad(rsv2, 2, '0'),
   lpad(policy_num, 10, '0'),
   lpad(rsv3, 1, '0'),
   lpad(accident_date, 5, '0'),
   lpad(eff_date, 3, '0'),
   lpad(place_code, 5, '0'),
   lpad(loss_type_code, 1, '0'),
   lpad(rsv4, 2, '0'),
lpad(insurance_amt, 4, '0'), lpad(fire_flex_code, 3, '0'), lpad(tico_line_of_busn_code, 2, '0'), lpad(comp_num, 3, '0'), lpad(rsv5, 4, '0'), lpad(policy_form_code, 1, '0'), lpad(family_occupancy_cnt_code, 1, '0'), lpad(occupancy_code, 1, '0'), lpad(construction_code , 1, '0'), lpad(iso_ppc_new_split_class_code, 2, '0'), lpad(iso_ppc_code, 1, '0'), lpad(deduct_01_type_code, 1, '0'), lpad(deduct_02_type_code, 1, '0'), lpad(rsv6, 2, '0'), lpad(claim_cnt, 1, '0') , lpad(loss_amt, 6, '0'), lpad(zip_code, 9, '0'), lpad(rsv7, 6, '0'), lpad(roof_cover_code, 1, '0'), lpad(roof_cover_credit_code, 5, '0'), lpad(excl_cosmetic_roof_dmg_ind, 1, '0'), lpad(bureau_cause_of_loss_code, 2, '0'), lpad(acv_roof_endorsemint_ind, 1, '0'), lpad(acv_less_replacement_cost, 5, '0'), lpad(rsv8, 2, '0'), lpad(rpt_type_code, 1, '0'), rpad(optnl_cov_endorsement_code, 8, '0'), lpad(optnl_cov_endorsement_code_amt, 6, '0'), lpad(hoa_attached_ind, 1, '0'), lpad((
   case
      when
         cast(deduct_01_amt as double) > 0 
      then
         lpad(deduct_01_amt, 6, '0') 
      when
         cast(deduct_01_amt as double) = 0 
      then
         case
            when
               cast(deduct_01_amt as double) < 0 
            then
               '00000}'
            else
               '000000'
         end
         else
            lpad(concat(substr(deduct_01_amt, 2, 
            (
               length(deduct_01_amt) - 2 
            )
), 
            (
               case
                  substr(deduct_01_amt, length(deduct_01_amt), 1) 
                  when
                     '0'
                  then
                     '}'
                  when
                     '1'
                  then
                     'J'
                  when
                     '2'
                  then
                     'K'
                  when
                     '3'
                  then
                     'L'
                  when
                     '4'
                  then
                     'M'
                  when
                     '5'
                  then
                     'N'
                  when
                     '6'
                  then
                     'O'
                  when
                     '7'
                  then
                     'P'
                  when
                     '8'
                  then
                     'Q'
                  when
                     '9'
                  then
                     'R'
               end
            )
), 6, '0') 
   end
), 6, '0') as deduct_01_amt, lpad((
   case
      when
         cast(deduct_02_amt as double) > 0 
      then
         lpad(deduct_02_amt, 6, '0') 
      when
         cast(deduct_02_amt as double) = 0 
      then
         case
            when
               cast(deduct_02_amt as double) < 0 
            then
               '00000}'
            else
               '000000'
         end
         else
            lpad(concat(substr(deduct_02_amt, 2, 
            (
               length(deduct_02_amt) - 2 
            )
), 
            (
               case
                  substr(deduct_02_amt, length(deduct_02_amt), 1) 
                  when
                     '0'
                  then
                     '}'
                  when
                     '1'
                  then
                     'J'
                  when
                     '2'
                  then
                     'K'
                  when
                     '3'
                  then
                     'L'
                  when
                     '4'
                  then
                     'M'
                  when
                     '5'
                  then
                     'N'
                  when
                     '6'
                  then
                     'O'
                  when
                     '7'
                  then
                     'P'
                  when
                     '8'
                  then
                     'Q'
                  when
                     '9'
                  then
                     'R'
               end
            )
), 6, '0') 
   end
), 6, '0') as deduct_02_amt, lpad(wind_coverage_ind, 1, '0'), lpad(rsv9, 5, '0'), lpad(building_credit_code_code, 2, '0'), lpad(tico_law_ordinance_cov_code, 1, '0'), lpad(sprinkler_credit_ind, 1, '0'), lpad(rsv10, 1, '0'), lpad(property_protection_ind, 1, '0'), lpad(tenure_discount_code, 1, '0'), lpad(tenure_discount_amt, 2, '0'), lpad(replacement_cov_limit_ind, 1, '0'), lpad(replace_cov_limit_disc_code, 2, '0'), lpad(naics_code, 5, '0') 
from
   (
      select
		 distinct 
         lpad(coalesce(stat_plan_name, '0'), 1, '0') as stat_plan_name,
         '0' as rsv1,
         lpad(concat(
         case
            when
               (
                  substr(cast(accounting_date as varchar(25)), 5, 2) 
               )
               in 
               (
                  '10'
               )
            then
               '0'
            when
               (
                  substr(cast(accounting_date as varchar(25)), 5, 2) 
               )
               in 
               (
                  '11'
               )
            then
               '-' 
            when
               (
                  substr(cast(accounting_date as varchar(25)), 5, 2) 
               )
               in 
               (
                  '12'
               )
            then
               '&' 
            else
               substr(cast(accounting_date as varchar(25)), 6, 1) 
         end
, substr(cast(accounting_date as varchar(25)), 4, 1)) , 2, '0') as accounting_date, '00' as rsv2, rpad(coalesce(policy_num, '0'), 10, '0') as policy_num, '0' as rsv3, concat(substr(main.accident_date, 6, 2), substr(main.accident_date, 9, 2), substr(main.accident_date, 4, 1)) as accident_date, concat(substr(cast(main.eff_date as varchar(25)), 6, 2), substr(cast(main.eff_date as varchar(25)), 4, 1)) as eff_date, lpad(coalesce(place_code, '0'), 5, '0') as place_code, lpad(coalesce(loss_type_code, '0'), 1, '0') as loss_type_code, '00' as rsv4, lpad(case when insurance_amt='' or insurance_amt is null then '0000' else
case when cast (round(cast (insurance_amt as double)) as integer) < 0 then
concat(
substr(cast (cast (round(cast (insurance_amt as double)) as integer) as string),
2, (length (cast (cast (round(cast (insurance_amt as double)) as integer) as string))) -2),
CASE substr(cast (cast (round(cast (insurance_amt as double)) as integer) as string),length(cast (cast (round(cast (insurance_amt as double)) as integer) as string)),length(cast (cast (round(cast (insurance_amt as double)) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
)
else
cast (cast (round(cast (insurance_amt as double)/1000) as integer) as string) end
end,4,'0') as insurance_amt, lpad(coalesce(fire_flex_code, '0'), 3, '0') as fire_flex_code, lpad(coalesce(ref.alt_code, '0'), 2, '0') as tico_line_of_busn_code, lpad(coalesce(ref_comp_num.alt_code, '0'), 3, '0') as comp_num, '0000' as rsv5, lpad(coalesce(policy_form_code, '0'), 1, '0') as policy_form_code, lpad(coalesce(family_occupancy_cnt_code, '0'), 1, '0') as family_occupancy_cnt_code, lpad(coalesce(occupancy_code, '0'), 1, '0') as occupancy_code, lpad(coalesce(ref_cons_cd.alt_code, '0'), 1, '0') as construction_code, lpad(coalesce(ref_ppc.alt_code, '0'), 2, '0') as iso_ppc_new_split_class_code, lpad(coalesce(iso_ppc_code, '0'), 1, '0') as iso_ppc_code, lpad(coalesce(ref_ded_cd.alt_code, '0'), 1, '0') as deduct_01_type_code, lpad(coalesce(ref_ded_cd2.alt_code, '0'), 1, '0') as deduct_02_type_code, '00' as rsv6, 
         case
            when
               coalesce(cast(main.claim_cnt as decimal(18, 2)), 1) = 1 
            then
               '1'
            when
               coalesce(cast(main.claim_cnt as decimal(18, 2)), 1) = - 1 
            then
               'j'
            else
               '0'
         end
         as claim_cnt, lpad(case when loss_amt='' or loss_amt is null then '0000' else
case when cast (round(cast (loss_amt as double)) as integer) < 0 then
concat(
substr(cast (cast (round(cast (loss_amt as double)) as integer) as string),
2, (length (cast (cast (round(cast (loss_amt as double)) as integer) as string))) -2),
CASE substr(cast (cast (round(cast (loss_amt as double)) as integer) as string),length(cast (cast (round(cast (loss_amt as double)) as integer) as string)),length(cast (cast (round(cast (loss_amt as double)) as integer) as string))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END
)
else
cast (cast (round(cast (loss_amt as double)) as integer) as string) end
end,6,'0') as loss_amt, lpad(coalesce(zip_code, '0'), 9, '0') as zip_code, '000000' as rsv7, lpad(coalesce(roof_cover_code, '0'), 1, '0') as roof_cover_code, lpad(coalesce(roof_cover_credit_code, '0'), 5, '0') as roof_cover_credit_code, lpad(coalesce(excl_cosmetic_roof_dmg_ind, '0'), 1, '0') as excl_cosmetic_roof_dmg_ind, lpad(coalesce(ref_bur_loss_cd.alt_code, '0'), 2, '0') as bureau_cause_of_loss_code, lpad(coalesce(acv_roof_endorsemint_ind, '0'), 1, '0') as acv_roof_endorsemint_ind, lpad(coalesce(acv_less_replacement_cost, '0'), 5, '0') as acv_less_replacement_cost, '00' as rsv8, lpad(coalesce(rpt_type_code, '0'), 1, '0') as rpt_type_code, rpad(coalesce(optnl_cov_endorsement_code, '0'), 8, '0') as optnl_cov_endorsement_code, lpad(coalesce(optnl_cov_endorsement_code_amt, '000000'), 6, '0') as optnl_cov_endorsement_code_amt, lpad(coalesce(hoa_attached_ind, '0'), 1, '0') as hoa_attached_ind,cast(cast(round(main.deduct_01_amt)  as integer )as varchar(100)) as deduct_01_amt,cast(cast(round(main.deduct_02_amt)  as integer )as varchar(100)) as deduct_02_amt, wind_coverage_ind as wind_coverage_ind, '00000' as rsv9, building_credit_code_code, tico_law_ordinance_cov_code, sprinkler_credit_ind, '0' as rsv10, property_protection_ind, tenure_discount_code, tenure_discount_amt, replacement_cov_limit_ind, replace_cov_limit_disc_code, naics_code 
      from
         ${V_TRNS_DB}.tico_ho_df_prem_loss main 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref 
            on ref.alt_code_type_name = 'TICO-LOB'
            and ref.code_type_name = 'LOSS-LOB'
            and ref.group_code = 'TICO'
            and ltrim(rtrim(ref.code)) = main.tico_line_of_busn_code 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref_comp_num 
            on ref_comp_num.alt_code_type_name = 'TICO-CO'
            and ref_comp_num.code_type_name = 'UNDERWRITING-CO'
            and ref_comp_num.group_code = 'TICO'
            and ltrim(rtrim(ref_comp_num.code)) = main.tico_company_num 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref_cons_cd 
            on ref_cons_cd.alt_code_type_name = 'TICO-CONSTRCD'
            and ref_cons_cd.code_type_name = 'CONSTRUCTION_CD'
            and ref_cons_cd.group_code = 'TICO'
            and ltrim(rtrim(ref_cons_cd.code)) = main.construction_code 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref_ppc 
            on ref_ppc.alt_code_type_name = 'TICO-FIRECD'
            and ref_ppc.code_type_name = 'FIREPRT_CD'
            and ref_ppc.group_code = 'TICO'
            and ltrim(rtrim(ref_ppc.code)) = main.iso_ppc_new_split_class_code 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref_ded_cd 
            on ref_ded_cd.alt_code_type_name = 'TICO-DEDCD'
            and ref_ded_cd.code_type_name = 'DEDUCTIBLE_TYPE_CD'
            and ref_ded_cd.group_code = 'TICO'
            and ltrim(rtrim(ref_ded_cd.code)) = main.deduct_01_type_code 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref_ded_cd2 
            on ref_ded_cd2.alt_code_type_name = 'TICO-DEDCD'
            and ref_ded_cd2.code_type_name = 'DEDUCTIBLE_TYPE_CD'
            and ref_ded_cd2.group_code = 'TICO'
            and ltrim(rtrim(ref_ded_cd2.code)) = main.deduct_02_type_code 
         left join
            ${V_EDW_EXTERNAL}.ent_ref_code ref_bur_loss_cd 
            on ref_bur_loss_cd.alt_code_type_name = 'TICO-COL'
            and ref_bur_loss_cd.code_type_name = 'LOSS-COL'
            and ref_bur_loss_cd.group_code = 'TICO'
            and ltrim(rtrim(ref_bur_loss_cd.code)) = main.bureau_cause_of_loss_code 
      where
         main.extract_type_name = 'TICO-MNTH-DW-PLOSS'
		 and cast(loss_amt as decimal(18, 2)) <> 0 
         and  accounting_dateyyyymm='${V_ACCDT_YYYYMM}'
   )
   q
 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"

if [ $? == 0 ]

then info "TICO Dwelling PaidLoss file - ${V_FILE_NAME} is generated successfully";

else

info "ERROR :  TICO Dwelling PaidLoss file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}"

if [ $? == 0 ]

then info "TICO Dwelling PaidLoss Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else

info "ERROR : TICO Dwelling PaidLoss Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1

