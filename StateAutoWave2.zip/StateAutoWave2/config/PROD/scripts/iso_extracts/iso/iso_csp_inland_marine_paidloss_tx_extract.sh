#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_csp_inland_marine_paidloss_tx_extract.sh                                      #
#                                                                             #
# Description  : Script to generate ISO file with Inland Marine - TX details 			  #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
. /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_FILE_NAME="ISO_PERS_IM_CSP_MISC_PAID_LOSS_TX""_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"
V_S3_PATH="${v_serving_bucket_path_iso}"'ISO-CSP_MISC/'




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating ISO Paid loss for Inland Marines extract"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

#frame the final query for extract
V_EXTRACT_SQL="
with iso_csp_class_codes as (
	select distinct lower(refclass.code) as class_code, alt_code
	from ${V_EDW_EXTERNAL}.ent_ref_code refclass 
	where refclass.group_code = 'ISO' and refclass.alt_code_type_name in ('ISO-SCHPROPTL-CLASSCD', 'ISO-SCHPROP-CLASSCD') and refclass.code_type_name = 'CLASS_CD' 
),
iso_csp_im_paid_loss_tx as (
	select
		icimt.company_num,
		nvl(refcomp.alt_code, '') as company_code,
		icimt.iso_transaction_type_code,
		icimt.accounting_date,
		cast(date_format(cast('${V_TO_DATE}' as date), 'y') % 10 as int) as accounting_date_year_code, 
		case 
			cast(date_format(cast('${V_TO_DATE}' as date), 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(cast('${V_TO_DATE}' as date), 'M'), 10) as int) 
		end as accounting_date_month_code,
		icimt.inception_date,
		cast(date_format(icimt.inception_date, 'yy') as int) as inception_date_year_code,
		case 
			cast(date_format(icimt.inception_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(icimt.inception_date, 'M'), 10) as int)
		end as inception_date_month_code,
		icimt.loss_occurrence_date,
			case 
				cast(date_format(icimt.loss_occurrence_date, 'M') as int) 
				when 12 then '&' 
				when 11 then '-' 
				else cast(mod(date_format(icimt.loss_occurrence_date, 'M'), 10) as int) 
			end as loss_occurrence_date_month_code,
		date_format(icimt.loss_occurrence_date, 'YYdd') as loss_occurrence_date_yydd,
		icimt.mga_ind,
		icimt.state_code,
		icimt.reserve1,
		icimt.reserve2,
		icimt.annual_statement_line_code,
		icimt.iso_csp_subline_code,
		icimt.classif_code,
		icimt.coverage_code,
		case when icimt.classif_code='209' then '209'
			when icimt.coverage_code in ('HOSpecComputerCovHOE', 'HOWTRPhyDmgTrailer', 'HOWTREmergency', 'HOWTRNavBahama', 'HOWTRNav50', 'HOWTRBoat', 'HOWTRWatercraft') then '209'
			when icimt.coverage_code in ('HOSchedPersPropHOE', 'HOBlktPersPropHOE') then iccc.alt_code
		end as class_code,
		icimt.reserve3,
		icimt.reserve4,
		icimt.form_code,
		icimt.reserve5,
		icimt.transaction_id,
		case when icimt.claim_cost_category_code in ('salvage_ext', 'subrogation_ext') then '55' else '99' end as transaction_id_code,
		icimt.contract_bond_type_code,
		icimt.reserve6,
		icimt.small_busn_ind,
		icimt.expedited_underwriting_prgm,
		icimt.reserve7,
		icimt.bureau_cause_of_loss_code,
		refloss.alt_code as loss_cause_code,
		icimt.iso_claim_cnt,
		case cast(icimt.iso_claim_cnt as integer) when 1 then '1' when -1 then 'J' else '0' end as claim_cnt,
		icimt.reserve8,
		icimt.loss_amt,
		case 
			cast(round(cast(icimt.loss_amt as decimal(19,2)), 0) % 10 as int)
			when 0 then 
				case 
					when icimt.loss_amt < 0 then '}' 
					when icimt.loss_amt >= 0 then '0' 
				end
			when -1 then 'J'
			when -2 then 'K'
			when -3 then 'L'
			when -4 then 'M'
			when -5 then 'N'
			when -6 then 'O'
			when -7 then 'P'
			when -8 then 'Q'
			when -9 then 'R'
			else cast(round(cast(icimt.loss_amt as decimal(19,2)), 0) % 10 as int)
		end as loss_amt_sign_code,
		cast(abs(round(cast(icimt.loss_amt as decimal(19,2)), 0)) / 10 as int) as loss_amt_code,
		icimt.occurence_id,
		split(icimt.occurence_id, '-') as claim_num_split,
		icimt.claim_seq_num,
		icimt.policy_num,
		case when length(icimt.policy_num) > 13 then substring(icimt.policy_num, -13) else icimt.policy_num end as policy_number,
		icimt.positions_for_company_use
	from 
		${V_TRNS_DB}.iso_csp_inland_marine_tx icimt
		left join ${V_EDW_EXTERNAL}.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code = icimt.company_num
		left join iso_csp_class_codes iccc on iccc.class_code = translate(lower(icimt.classif_code), ' ', '')
		left join ${V_EDW_EXTERNAL}.ent_ref_code refloss on refloss.group_code = 'ISO' and refloss.alt_code_type_name = 'ISO-LOC-CD' 
			and refloss.code_type_name='LOSS_CD' and lower(refloss.code) = lower(icimt.bureau_cause_of_loss_code)
	where 
		icimt.iso_extract_type_name = 'IM-Paid-Loss'
		and icimt.extract_type = 'PAIDLOSS'
		and cast(icimt.accounting_date as date) between cast('${V_FROM_DATE}' as date) and cast('${V_TO_DATE}' as date)
),
iso_csp_im_paid_loss_tx_layout as (
	select
		lpad(company_code, 4, ' ')
		|| lpad(iso_transaction_type_code, 1, ' ')
		|| lpad(accounting_date_month_code || accounting_date_year_code, 2, ' ')
		|| lpad(inception_date_month_code || inception_date_year_code, 3, ' ')
		|| lpad(loss_occurrence_date_month_code || loss_occurrence_date_yydd, 5, ' ')
		|| lpad(mga_ind, 1, ' ')
		|| lpad(state_code, 2, ' ')
		|| lpad(reserve1, 3, ' ')
		|| lpad(reserve2, 2, ' ')
		|| lpad(annual_statement_line_code, 3, ' ')
		|| lpad(iso_csp_subline_code, 3, ' ')
		|| lpad(nvl(class_code, ''), 3, ' ')
		|| lpad(reserve3, 3, ' ')
		|| lpad(reserve4, 3, ' ')
		|| lpad(form_code, 2, ' ')
		|| lpad(reserve5, 16, ' ')
		|| lpad(transaction_id_code, 2, ' ')
		|| lpad(contract_bond_type_code, 1, ' ')
		|| lpad(reserve6, 1, ' ')
		|| lpad(small_busn_ind, 1, ' ')
		|| lpad(expedited_underwriting_prgm, 1, ' ')
		|| lpad(reserve7, 7, ' ')
		|| lpad(loss_cause_code, 2, ' ')
		|| lpad(claim_cnt, 1, ' ')
		|| lpad(reserve8, 23, ' ')
		|| lpad(loss_amt_code || loss_amt_sign_code, 8, '0')
		|| lpad(substring(claim_num_split[1], -6) || claim_num_split[2], 12, ' ')
		|| lpad(claim_seq_num, 2, ' ')
		|| rpad(policy_number, 13, ' ')
		|| lpad(positions_for_company_use, 20, ' ')
	from 
		iso_csp_im_paid_loss_tx
)
select * from iso_csp_im_paid_loss_tx_layout"

info "Query for file extraction: $V_EXTRACT_SQL"

#execute the query and write the output to a file
hive -S -e "${V_EXTRACT_SQL}" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO Paid loss for Inland Marine TX Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : ISO Paid loss for Inland Marine TX Extract file - ${V_FILE_NAME} generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH} - aws s3 cp /home/hadoop/ISO_Extracts/${V_FILE_NAME} ${V_S3_PATH}";

#copy the file from local to s3 folder
aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}"

if [ $? == 0 ]

then info "ISO Paid loss for Inland Marine TX Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO Paid loss for Inland Marine TX Extract file - ${V_FILE_NAME} upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
