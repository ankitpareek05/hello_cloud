#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_extract.sh                                               #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table #
#                from transformation layer                                    #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_FILE_NAME="ISO_CUP_PREMIUM_TX_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"
V_S3_PATH="${v_serving_bucket_path_iso}"'CommercialUmbrella/Premium/'




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating ISO TX Extract file"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

hive -S -e "SELECT DISTINCT concat(
    rpad(
	case when ref_comp.alt_code is NULL or ref_comp.alt_code='' or trans.company_num is NULL or trans.company_num='' then ' '
	else ref_comp.alt_code
	end,4,' '), 
	rpad(
	case when cast(iso_transaction_type_code AS STRING) is NULL or cast(iso_transaction_type_code AS STRING)='' then ' '
	else cast(iso_transaction_type_code AS STRING) end
	,1,' '), 
	rpad(case
    WHEN substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(accounting_date AS STRING),4,1))
    WHEN substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(accounting_date AS STRING),4,1))
    ELSE concat(substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) AS STRING),7,1),substr(cast(accounting_date AS STRING),4,1)) end,2,' '),
	rpad(case
    WHEN substr(cast(inception_date AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(inception_date AS STRING),3,2))
    WHEN substr(cast(inception_date AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(inception_date AS STRING),3,2))
    ELSE concat(substr(cast(inception_date AS STRING),7,1),substr(cast(inception_date AS STRING),3,2)) end,3,' '), 
	rpad(case
    WHEN substr(cast(transaction_eff_date AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(transaction_eff_date AS STRING),3,2))
    WHEN substr(cast(transaction_eff_date AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(transaction_eff_date AS STRING),3,2))
    ELSE concat(substr(cast(transaction_eff_date AS STRING),7,1),substr(cast(transaction_eff_date AS STRING),3,2)) end,3,' '), 
	rpad(case
    WHEN substr(cast(transaction_exp_date AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(transaction_exp_date AS STRING),3,2))
    WHEN substr(cast(transaction_exp_date AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(transaction_exp_date AS STRING),3,2))
    ELSE concat(substr(cast(transaction_exp_date AS STRING),7,1),substr(cast(transaction_exp_date AS STRING),3,2)) end,3,' '), 
	lpad(case
    WHEN risk_state_code='' OR risk_state_code is NULL THEN ' '
	WHEN st.alt_code is NULL then ' '
    ELSE cast(st.alt_code AS STRING)
    END ,2,'0'), 
	rpad(case WHEN territory_code=''
        OR territory_code is NULL THEN ' '
    ELSE territory_code end,3,' '), 
	rpad(
	case when cast(iso_policy_type_code AS STRING) is NULL or cast(iso_policy_type_code AS STRING)='' then ' '
	else cast(iso_policy_type_code AS STRING)
	end
	,2,' '), 
	rpad(
	case when cast(annual_statement_line_code AS STRING) is NULL or cast(annual_statement_line_code AS STRING)='' then ' '
	else cast(annual_statement_line_code AS STRING)
	end
	,3,' '), 
	rpad(
	case when cast(iso_csp_subline_code AS STRING) is NULL or cast(iso_csp_subline_code AS STRING)='' then ' '
	else cast(iso_csp_subline_code AS STRING)
	end
	,3,' '), 
	rpad(
	case when cast(iso_classification_code AS STRING) is NULL or cast(iso_classification_code AS STRING)='' then ' '
	else cast(iso_classification_code AS STRING)
	end
	,5,' '), 
	rpad(case
    WHEN iso_state_exception_code='' or iso_state_exception_code is null THEN ' '
    ELSE iso_state_exception_code end,1,' '), 
	rpad(
	case when cast(limits_ind AS STRING)='' or cast(limits_ind AS STRING) is NULL then ' '
	else cast(limits_ind AS STRING)
	end
	,1,' '), 
	rpad(case
    WHEN cast(bodily_injury_limit_amt AS STRING)= ''
    OR bodily_injury_limit_amt is NULL THEN ' '
    WHEN agg_limit.alt_code is NOT NULL THEN
    agg_limit.alt_code
    WHEN bodily_injury_limit_amt=4000000 THEN
    '23'
    WHEN bodily_injury_limit_amt=8000000 THEN
    '25'
    ELSE ' '
    END ,2,' '), 
	rpad(case
    WHEN cast(property_damage_limit_amt AS STRING)= ''
        OR property_damage_limit_amt is NULL THEN ' '
    ELSE property_damage_limit_amt
    END ,2,' '), 
	coalesce(case
    WHEN trans.retention_amt > 10000000 THEN
    '93'
    ELSE ret_amt.alt_code end,' '), 
	rpad(case
    WHEN cast(property_damage_deduct_code AS STRING)=''
        OR property_damage_deduct_code is NULL THEN ' '
    ELSE cast(property_damage_deduct_code AS STRING)
    END ,2,' '),
    CASE
    WHEN coverage_code=''
        OR coverage_code is NULL THEN ' '
    ELSE coverage_code end, 
	rpad(case
    WHEN risk_identification_code=''
        OR risk_identification_code is NULL THEN ' '
    ELSE risk_identification_code end,1,' '), 
	rpad(case
    WHEN claims_made_year_month=''
        OR claims_made_year_month is NULL THEN ' '
    ELSE claims_made_year_month end,3,' '), 
	lpad(case
    WHEN cast(policy_aggregate_limit_amt AS STRING)= ''
        OR policy_aggregate_limit_amt is NULL THEN ' '
    ELSE cast(cast((policy_aggregate_limit_amt/1000) AS Integer) AS STRING)
    END ,6,'0'), 
	rpad(case
    WHEN terrorism_coverage_code = ''
        OR terrorism_coverage_code is NULL THEN ' '
    ELSE terrorism_coverage_code
    END ,1,' '), 
	rpad(case
    WHEN cast(job_type_code AS STRING)= '' OR job_type_code is NULL THEN ' '
	WHEN trans_type.alt_code is NULL OR trans_type.alt_code ='' then ' '
    ELSE trans_type.alt_code
    END ,2,' '), 
	rpad(case
    WHEN rating_identification_code=''
    OR rating_identification_code is NULL THEN ' '
    ELSE rating_identification_code end,1,' '), ' ', 
	rpad(case
    WHEN cast(deduct_amt AS STRING)= ''
    OR deduct_amt is NULL THEN ' '
    ELSE cast(deduct_amt AS STRING)
    END ,5,' '), 
	lpad(case
    WHEN cast(policy_occurrence_limit_amt AS STRING)= ''
    OR policy_occurrence_limit_amt is NULL THEN ' '
    ELSE cast(cast((policy_occurrence_limit_amt/1000) AS Integer) AS STRING)
    END ,6,'0'), 
	lpad(case
    WHEN cast(transaction_eff_day AS STRING)= ''
    OR transaction_eff_day is NULL THEN ' '
    ELSE cast(transaction_eff_day AS STRING)
    END ,2,'0'), lpad(case
    WHEN cast(transaction_exp_day AS STRING)= ''
    OR transaction_exp_day is NULL THEN ' '
    ELSE cast(transaction_exp_day AS STRING)
    END ,2,'0'), 
	rpad(case
    WHEN mga_ind='' OR mga_ind is NULL THEN ' '
    ELSE mga_ind end,1,' '), 
	rpad(case
    WHEN exposure_ind_code=''
    OR exposure_ind_code is NULL THEN ' '
    ELSE exposure_ind_code end,1,' '), 
	rpad(case
    WHEN schedule_rating_modifier=''
    OR schedule_rating_modifier is NULL THEN ' '
    ELSE schedule_rating_modifier end,3,' '), 
	rpad(case
    WHEN exposure=''
    OR exposure is NULL THEN ' '
    ELSE exposure end,7,' '), 
	rpad(case
    WHEN rating_modifier=''
    OR rating_modifier is NULL THEN ' '
    ELSE rating_modifier end,3,' '), 
	rpad(case
    WHEN loss_cost_multiplier=''
    OR loss_cost_multiplier is NULL THEN ' '
    ELSE loss_cost_multiplier end,3,' '), 
	rpad(case
    WHEN endorsement_id_code=''
    OR endorsement_id_code is NULL THEN ' '
    ELSE endorsement_id_code end,1,' '), ' ', 
	lpad(
    CASE
    WHEN bodily_injury_prem_amt < 0 THEN
    concat( substr(cast(bodily_injury_prem_amt AS STRING),2,length(cast(bodily_injury_prem_amt AS STRING))-2),
    CASE substr(cast(bodily_injury_prem_amt AS STRING),length(cast(bodily_injury_prem_amt AS STRING)),length(cast(bodily_injury_prem_amt AS STRING))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END )
    WHEN bodily_injury_prem_amt > 0 THEN
    concat( substr(cast(bodily_injury_prem_amt AS STRING),1,length(cast(bodily_injury_prem_amt AS STRING))-1),
    CASE substr(cast(bodily_injury_prem_amt AS STRING),length(cast(bodily_injury_prem_amt AS STRING)),length(cast(bodily_injury_prem_amt AS STRING))+1)
    WHEN '0' THEN
    '{'
    WHEN '1' THEN
    'A'
    WHEN '2' THEN
    'B'
    WHEN '3' THEN
    'C'
    WHEN '4' THEN
    'D'
    WHEN '5' THEN
    'E'
    WHEN '6' THEN
    'F'
    WHEN '7' THEN
    'G'
    WHEN '8' THEN
    'H'
    WHEN '9' THEN
    'I'
    END )
	else '00000000'
    END ,8,'0'),rpad(case
    WHEN cast(property_damage_prem_amt AS STRING)= '' OR property_damage_prem_amt is NULL THEN ' '
    ELSE cast(property_damage_prem_amt AS STRING)
    END ,9,' '),
    rpad(case WHEN cast(standard_industrial_classifi AS STRING)= '' OR standard_industrial_classifi is NULL THEN ' '
    ELSE cast(standard_industrial_classifi AS STRING)
    END ,4,' '),
	' ',
    rpad(case
    WHEN policy_num=''
    OR policy_num is NULL THEN ' '
    ELSE policy_num end,33,' ') )
FROM $V_TRNS_DB.iso_cup_prem trans

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code ref_comp ON  ref_comp.group_code='ISO' and ref_comp.alt_code_type_name='ISO-CO' and ref_comp.code=trans.company_num

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code agg_limit ON  agg_limit.group_code='ISO' and agg_limit.alt_code_type_name='ISO_CUP_LIAB_LMT_CODE' and agg_limit.code=cast(trans.bodily_injury_limit_amt AS STRING)

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code ret_amt ON  ret_amt.group_code='ISO' and ret_amt.alt_code_type_name='ISO_CUP_UMB_ATT_PNT_CODE' and ret_amt.code=cast(trans.retention_amt AS STRING) 

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code trans_type ON  trans_type.group_code='ISO' and trans_type.alt_code_type_name='ISO_CUP_TRANS_ID' and trans.job_type_code=trans_type.code

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code st ON  st.alt_code_type_name='STATE-NUM' and st.code_type_name='STATE-CD' and st.code=trans.risk_state_code

WHERE risk_state_code='TX'
        AND cast(accounting_date AS date)
    BETWEEN '${V_FROM_DATE}'
        AND '${V_TO_DATE}'" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO TX Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO TX Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
