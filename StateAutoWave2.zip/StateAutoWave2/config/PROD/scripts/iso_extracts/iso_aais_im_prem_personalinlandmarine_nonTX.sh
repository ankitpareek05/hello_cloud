#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : AAIS_INLAND_MARINE_NON_TX_extract.sh                                         #
#                                                                             #
# Description  : Script to generate AAIS INLAND MARINE NON TX file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/AAIS/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="AAIS_INLANDMARINE_PREMIUM_NON-TX_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO AAIS PREM"

info "Connecting to ${V_TRNS_DB}, ${V_EDW_EXTERNAL}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
	select
	   rpad(aais_line_of_insurance_code, 2, ' '),
	   rpad(d.accounting_date, 4, ' '),
	   rpad(company_code, 4, ' '),
	   rpad(state_code, 2, ' '),
	   rpad(county_code, 3, ' '),
	   rpad(reserved_1, 1, ' '),
	   rpad(territory_code, 3, ' '),
	   rpad(transaction_code, 1, ' '),
	   lpad( 
	   case
		  when
			 prem_amount < 0 
		  then
			 concat( substr(cast(prem_amount as string), 2, length(cast(prem_amount as string)) - 2), 
			 case
				substr(cast(prem_amount as string), length(cast(prem_amount as string)), length(cast(prem_amount as string)) + 1) 
				when
				   '0' 
				then
				   '}' 
				when
				   '1' 
				then
				   'J' 
				when
				   '2' 
				then
				   'K' 
				when
				   '3' 
				then
				   'L' 
				when
				   '4' 
				then
				   'M' 
				when
				   '5' 
				then
				   'N' 
				when
				   '6' 
				then
				   'O' 
				when
				   '7' 
				then
				   'P' 
				when
				   '8' 
				then
				   'Q' 
				when
				   '9' 
				then
				   'R' 
			 end
	) 
		  when
			 prem_amount > 0 
		  then
			 case
				when
				   substr(cast(prem_amount as string), 1, 1) = '+'
				then
				   concat( substr(cast(prem_amount as string), 2, length(cast(prem_amount as string)) - 2), 
				   case
					  substr(cast(prem_amount as string), length(cast(prem_amount as string)), length(cast(prem_amount as string)) + 1) 
					  when
						 '0' 
					  then
						 '{' 
					  when
						 '1' 
					  then
						 'A' 
					  when
						 '2' 
					  then
						 'B' 
					  when
						 '3' 
					  then
						 'C' 
					  when
						 '4' 
					  then
						 'D' 
					  when
						 '5' 
					  then
						 'E' 
					  when
						 '6' 
					  then
						 'F' 
					  when
						 '7' 
					  then
						 'G' 
					  when
						 '8' 
					  then
						 'H' 
					  when
						 '9' 
					  then
						 'I' 
				   end
	) 
				else
				   cast(prem_amount as string) 
			 end
			 else
				'00000000' 
	   end
	, 10, '0') as prem_amt1, rpad(exposure_amt, 5, ' '), rpad(annual_statement_line_code, 3, ' '), rpad(program_class_code, 1, ' '), rpad(policy_form_code, 2, ' '), rpad(reserved_2, 3, ' '), rpad(terrorism_ind, 1, ' '), 
	   case
		  when
			 prop_damage_cov_limit_amt >= 0 
		  then
			 case
				when
				   prop_damage_cov_limit_amt = 0 
				then
				   '00000' 
				when
				   prop_damage_cov_limit_amt <= 1500 
				then
				   '00001' 
				when
				   cast(substr(cast(prop_damage_cov_limit_amt as string), length(cast(prop_damage_cov_limit_amt as string)) - 2, length(cast(prop_damage_cov_limit_amt as string))) as bigint) > 500 
				then
				   lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 1, length(cast(prop_damage_cov_limit_amt as string)) - 3) as bigint) + 1) as string), 5, '0') 
				else
				   lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 1, length(cast(prop_damage_cov_limit_amt as string)) - 3) as bigint)) as string), 5, '0') 
			 end
			 else
				case
				   when
					  prop_damage_cov_limit_amt > - 1500 
					  and prop_damage_cov_limit_amt < 0 
				   then
					  '00001' 
				   when
					  cast(substr(cast(prop_damage_cov_limit_amt as string), length(cast(prop_damage_cov_limit_amt as string)) - 2, length(cast(prop_damage_cov_limit_amt as string))) as bigint) >= 500 
				   then
					  lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 2, length(cast(prop_damage_cov_limit_amt as string)) - 4) as bigint) + 1) as string), 5, '0') 
				   else
					  lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 2, length(cast(prop_damage_cov_limit_amt as string)) - 4) as bigint)) as string), 5, '0') 
				end
	   end
	   as prop_damage_cov_limit_amt1, rpad(deduct_type_code, 1, ' '), rpad(deduct_amt, 2, ' '), rpad(reserved_3, 1, ' '), rpad(d.class_code, 3, ' '), rpad(reserved_4, 2, ' '), rpad(construction_code, 2, ' '), rpad(fire_protection_code, 2, ' '), rpad(reserved_5, 19, ' '), rpad(policy_type_code, 1, ' '), rpad(reserved_6, 1, ' '), rpad(package_ind, 1, ' '), rpad(reserved_7, 6, ' '), rpad(pool_code, 1, ' '), rpad(case when term_months_num='00' then '01' else term_months_num end, 2, ' '), rpad(reserved_8, 7, ' '), rpad(zip_5_code, 5, ' '), rpad(zip_4_suffix_code, 4, ' '), rpad(reserved_9, 16, ' '), rpad(d.policy_num, 14, ' ') as policy_num, '          '
	from
	   (
		  select distinct
			 aais_line_of_insurance_code,
			 d.accounting_date,
			 company_code,
			 state_code,
			 county_code,
			 reserved_1,
			 territory_code,
			 transaction_code,
			 case
				when
				   substring(cast(amounts1.prem_amount as varchar(255)), 1, 1) = '-' 
				then
				   '0000J' 
				else
				   '00001' 
			 end
			 as exposure_amt,d.job_num, annual_statement_line_code, program_class_code, policy_form_code, reserved_2, terrorism_ind, deduct_type_code, reserved_3, d.class_code, reserved_4, construction_code, fire_protection_code, reserved_5, policy_type_code, reserved_6, package_ind, reserved_7, pool_code, term_months_num, reserved_8, zip_5_code, zip_4_suffix_code, reserved_9, d.policy_num, cast((amounts1.prem_amount * 100) as decimal(10, 0)) as prem_amount, cast(amounts1.prop_damage_cov_limit_amt as decimal(10, 0)) as prop_damage_cov_limit_amt, deduct_amt, amounts1.r 
		  from
			 (
				select
				   aais_line_of_insurance_code,
				   accounting_date,
				   company_code,
				   state_code,
				   county_code,
				   reserved_1,
				   territory_code,
				   transaction_code,
				   exposure_amt,
				   annual_statement_line_code,
				   program_class_code,
				   policy_form_code,
				   reserved_2,
				   terrorism_ind,
				   prop_damage_cov_limit_amt,
				   prem_amt,
				   deduct_type_code,
				   reserved_3,
				   class_code,
				   reserved_4,
				   construction_code,
				   fire_protection_code,
				   reserved_5,
				   policy_type_code,
				   reserved_6,
				   package_ind,
				   reserved_7,
				   pool_code,
				   term_months_num,
				   reserved_8,
				   zip_5_code,
				   zip_4_suffix_code,
				   reserved_9,
				   policy_num,
				   deduct_amt ,job_num
				from
				   (
					  select
						 aais_line_of_insurance_code,
						 accounting_date,
						 company_code,
						 state_code,
						 county_code,
						 reserved_1,
						 territory_code,
						 transaction_code,
						 prop_damage_cov_limit_amt,
						 prem_amt,
						 exposure_amt,
						 annual_statement_line_code,
						 program_class_code,
						 policy_form_code,
						 reserved_2,
						 terrorism_ind,
						 deduct_type_code,
						 reserved_3,
						 class_code,
						 reserved_4,
						 construction_code,
						 fire_protection_code,
						 reserved_5,
						 policy_type_code,
						 reserved_6,
						 package_ind,
						 reserved_7,
						 pool_code,
						 term_months_num,
						 reserved_8,
						 zip_5_code,
						 zip_4_suffix_code,
						 reserved_9,
						 policy_num,
						 deduct_amt,job_num,
						 row_number() over (partition by policy_num, accounting_date, class_code,job_num
					  order by
						 policy_num,job_num desc) rn 
					  from
						 (
							select
							   aais_line_of_insurance_code,
							   accounting_date,
							   company_code,
							   state_code,
							   county_code,
							   reserved_1,
							   territory_code,
							   transaction_code,
							   prem_amt,
							   exposure_amt,
							   annual_statement_line_code,
							   program_class_code,
							   policy_form_code,
							   reserved_2,
							   terrorism_ind,
							   prop_damage_cov_limit_amt,
							   deduct_type_code,
							   reserved_3,
							   class_code_var as class_code,
							   reserved_4,
							   case
								  when
									 (
										class_code = 'HearingAids' 
										or class_code = 'FineArts' 
										or class_code = 'Fine Arts'
									 )
									 or 
									 (
										class_code_var = '235' 
										or class_code_var = '236' 
										or class_code_var = '237' 
										or class_code_var = 'Personal Property Floaters' 
										or class_code_var = '079' 
										or class_code_var = '081' 
										or class_code_var = '084' 
										or class_code_var = 'Fine Arts'
									 )
								  then
									 lkp_construction.alt_Code 
								  else
									 '00' 
							   end
							   as construction_code, 
							   case
								  when
									 (
										class_code = 'HearingAids' 
										or class_code = 'FineArts' 
										or class_code = 'Fine Arts'
									 )
									 or 
									 (
										class_code_var = '235' 
										or class_code_var = '236' 
										or class_code_var = '237' 
										or class_code_var = 'Personal Property Floaters' 
										or class_code_var = '079' 
										or class_code_var = '081' 
										or class_code_var = '084' 
										or class_code_var = 'Fine Arts'
									 )
								  then
									 lkp_fp.alt_Code 
								  else
									 '00' 
							   end
							   as fire_protection_code, reserved_5, policy_type_code, reserved_6, package_ind, reserved_7, pool_code, term_months_num, reserved_8, zip_5_code, zip_4_suffix_code, reserved_9, policy_num, coverage_code, deduct_amt, job_num 
							from
							   (
								  select
									 aais_line_of_insurance_code,
									 accounting_date,
									 lkp_company.alt_code as company_code,
									 upper(lkp_company.alt_code) as upper_company_code,
									 lkp_state.alt_code as state_code,
									 upper(lkp_state.alt_code) as upper_state_code,
									 county_code,
									 reserved_1,
									 territory_code,
									 transaction_code,
									 prem_amt,
									 exposure_amt,
									 annual_statement_line_code,
									 program_class_code,
									 policy_form_code,
									 reserved_2,
									 terrorism_ind,
									 prop_damage_cov_limit_amt,
									 deduct_type_code,
									 reserved_3,
									 case
										/*when class_code='053' then class_code*/
										when
										   (
											  coverage_code = 'HOSchedPersPropHOE' 
											  or coverage_code = 'HOBlktPersPropHOE' 
											  or coverage_code = 'HOSpecComputerCovHOE' 
											  or coverage_code = 'HOWTRPhyDmgTrailer'
											  or coverage_code = 'HOWTRWatercraft' 
											  or coverage_code = 'HOWTRBoat' 
											  or coverage_code = 'HOWTREmergency' 
											  or coverage_code = 'HOWTRNav50'
										   )
										   and class_code is not null 
										then
										   case
											  when
												 lkp_class.alt_code is null 
												 or lkp_class.alt_code = '' 
											  then
												 '039' 
											  else
												 lkp_Class.alt_Code 
										   end
										   else
											  '039' 
									 end
									 as class_code_var, class_code, upper_class_code, reserved_4, construction_code, upper_construction_code, fire_protection_code, upper_fire_protection_code, reserved_5, policy_type_code, reserved_6, package_ind, reserved_7, pool_code, term_months_num, reserved_8, zip_5_code, zip_4_suffix_code, reserved_9, policy_num, coverage_code , deduct_amt, job_num 
								  from
									 (
										select
										   aais_line_of_insurance_code,
										   accounting_date,
										   upper(company_code) as upper_company_code,
										   upper(state_code) as upper_state_code,
										   county_code,
										   reserved_1,
										   territory_code,
										   transaction_code,
										   prem_amt,
										   exposure_amt,
										   annual_statement_line_code,
										   program_class_code,
										   policy_form_code,
										   reserved_2,
										   terrorism_ind,
										   prop_damage_cov_limit_amt,
										   deduct_type_code,
										   deduct_amt,
										   reserved_3,
										   class_code,
										   upper(class_code) as upper_class_code,
										   reserved_4,
										   construction_code,
										   upper(construction_code) as upper_construction_code,
										   fire_protection_code,
										   upper(fire_protection_code) as upper_fire_protection_code,
										   reserved_5,
										   policy_type_code,
										   reserved_6,
										   package_ind,
										   reserved_7,
										   pool_code,
										   term_months_num,
										   reserved_8,
										   case
											  when
												 zip_5_code is null 
											  then
												 '00000' 
											  else
												 substring(zip_5_code, 1, 5) 
										   end
										   as zip_5_code, zip_4_suffix_code, reserved_9, policy_num, coverage_code, job_num 
										from
										   $V_TRNS_DB.AAIS_Inland_Marine_Prem_Loss 
										where
										   aais_extract_type_name = 'PREMIUM' 
										   and cast(accounting_date as int) >= cast(concat(substr(cast('${V_FROM_DATE}' as string), 6, 2), substr(cast('${V_FROM_DATE}' as string), 3, 2)) as int) 
										   and cast(accounting_date as int) <= cast(concat(substr(cast('${V_TO_DATE}' as string), 6, 2), substr(cast('${V_TO_DATE}' as string), 3, 2)) as int) 
										   and 
										   (
											  cast(prem_amt as decimal(18, 2)) <> 0 
											  or cast(prop_damage_cov_limit_amt as double) <> 0
										   )
										   and 
										   (
											  coverage_code = 'HOSchedPersPropHOE' 
											  or coverage_code = 'HOBlktPersPropHOE' 
											  or coverage_code = 'HOSpecComputerCovHOE'
										   )
									 )
									 aais 
									 left join
										$V_EDW_EXTERNAL.ent_ref_code lkp_company 
										on lkp_company.alt_code_type_name = 'AAIS-CO' 
										and lkp_company.code_type_name = 'UNDERWRITING-CO' 
										and lkp_company.group_code = 'AAIS' 
										and upper(lkp_company.Code) = aais.upper_company_code 
									 left join
										$V_EDW_EXTERNAL.ent_ref_code lkp_state 
										on lkp_state.alt_code_type_name = 'STATE-NUM' 
										and lkp_state.code_type_name = 'STATE-CD' 
										and lkp_state.group_code = 'LGCY' 
										and upper(lkp_state.Code) = aais.upper_state_code 
									 left join
										$V_EDW_EXTERNAL.ent_ref_code lkp_class 
										on lkp_class.alt_code_type_name = 'AAIS-SCHPROP-CLASSCD' 
										and lkp_class.code_type_name = 'CLASS_CD' 
										and lkp_class.group_code = 'AAIS' 
										and replace(upper(lkp_class.Code), ' ', '') = replace(aais.upper_class_code, ' ', '') 
							   )
							   a 
							   left join
								  $V_EDW_EXTERNAL.ent_ref_code lkp_construction 
								  on lkp_construction.alt_code_type_name = 'AAIS-CONSTRCD' 
								  and lkp_construction.code_type_name = 'CONSTRUCTION_CD' 
								  and lkp_construction.group_code = 'AAIS' 
								  and upper(lkp_construction.Code) = a.upper_construction_code 
							   left join
								  $V_EDW_EXTERNAL.ent_ref_code lkp_fp 
								  on lkp_fp.alt_code_type_name = 'AAIS-FIRECD' 
								  and lkp_fp.code_type_name = 'FIREPRT_CD' 
								  and lkp_fp.group_code = 'AAIS' 
								  and upper(lkp_fp.Code) = a.upper_fire_protection_code 
						 )
						 b 
				   )
				   c 
				where
				   c.rn = 1 
			 )
			 d 
			 left join
				(
				   select
					  a.policy_num,
					  a.accounting_date,
					  a.class_code,
					  a.job_num,
					  case
						 when
							a.prem_amount <> 0 
							and a.prop_damage_cov_limit_amt = 0 
						 then
							cast(b.prem_amt as decimal(18, 2)) 
						 else
							a.prem_amount 
					  end
					  as prem_amount, 
					  case
						 when
							a.prem_amount <> 0 
							and a.prop_damage_cov_limit_amt = 0 
						 then
							cast(b.prop_damage_cov_limit_amt as double) 
						 else
							a.prop_damage_cov_limit_amt 
					  end
					  as prop_damage_cov_limit_amt, 
					  case
						 when
							a.prem_amount <> 0 
							and a.prop_damage_cov_limit_amt = 0 
						 then
							b.r 
						 else
							a.r 
					  end
					  as r 
				   from
					  (
						 select
							policy_num,
							accounting_date,
							class_code,
							job_num,
							sum(cast(prem_amount as decimal(18, 2))) as prem_amount,
							sum(cast(prop_damage_cov_limit_amt as double)) as prop_damage_cov_limit_amt,
							row_number() over (partition by accounting_date 
						 order by
							accounting_date, policy_num) as r 
						 from
							(
							   select
								  policy_num,
								  accounting_date,
								  coverage_code,
								  job_num,
								  case
									 /*when class_code='053' then class_code*/
									 when
										(
										   coverage_code = 'HOSchedPersPropHOE' 
										   or coverage_code = 'HOBlktPersPropHOE' 
										   or coverage_code = 'HOSpecComputerCovHOE' 
										   or coverage_code = 'HOWTRPhyDmgTrailer' 
										   or coverage_code = 'HOWTRWatercraft' 
										   or coverage_code = 'HOWTRBoat' 
										   or coverage_code = 'HOWTREmergency' 
										   or coverage_code = 'HOWTRNav50' 
										)
										and class_code is not null 
									 then
										case
										   when
											  lkp_class.alt_code is null 
											  or lkp_class.alt_code = '' 
										   then
											  '039' 
										   else
											  lkp_Class.alt_Code 
										end
										else
										   '039' 
								  end
								  as class_code , prem_amount, prop_damage_cov_limit_amt 
							   from
								  (
									 select
										policy_num,
										accounting_date,
										coverage_code,
										class_code,
										upper(class_code) as upper_class_code,
										prem_amt as prem_amount,
										prop_damage_cov_limit_amt ,job_num
									 from
										$V_TRNS_DB.AAIS_Inland_Marine_Prem_Loss 
									 where
										aais_extract_type_name = 'PREMIUM' 
										and coverage_code in 
										(
										   'HOSchedPersPropHOE',
										   'HOBlktPersPropHOE',
										   'HOSpecComputerCovHOE' 
										)
										and cast(accounting_date as int) >= cast(concat(substr(cast('${V_FROM_DATE}' as string), 6, 2), substr(cast('${V_FROM_DATE}' as string), 3, 2)) as int) 
										and cast(accounting_date as int) <= cast(concat(substr(cast('${V_TO_DATE}' as string), 6, 2), substr(cast('${V_TO_DATE}' as string), 3, 2)) as int) 
										and 
										(
										   cast(prem_amt as decimal(18, 2)) <> 0 
										   or cast(prop_damage_cov_limit_amt as double) <> 0 
										)
								  )
								  aais 
								  left join
									 $V_EDW_EXTERNAL.ent_ref_code lkp_class 
									 on lkp_class.alt_code_type_name = 'AAIS-SCHPROP-CLASSCD' 
									 and lkp_class.code_type_name = 'CLASS_CD' 
									 and lkp_class.group_code = 'AAIS' 
									 and replace(upper(lkp_class.Code), ' ', '') = replace(aais.upper_class_code, ' ', '') 
							)
							a 
						 group by
							policy_num,
							accounting_date,
							class_code,
							job_num
					  )
					  a 
					  left join
						 (
							select
							   prem_amt,
							   prop_damage_cov_limit_amt,
							   policy_num,job_num,
							   case
								  when
									 (
										coverage_code = 'HOSchedPersPropHOE' 
										or coverage_code = 'HOBlktPersPropHOE' 
										or coverage_code = 'HOSpecComputerCovHOE' 
										or coverage_code = 'HOWTRPhyDmgTrailer' 
										or coverage_code = 'HOWTRWatercraft' 
										or coverage_code = 'HOWTRBoat' 
										or coverage_code = 'HOWTREmergency' 
										or coverage_code = 'HOWTRNav50' 
									 )
									 and class_code is not null 
								  then
									 case
										when
										   lkp_class.alt_code is null 
										   or lkp_class.alt_code = '' 
										then
										   '039' 
										else
										   lkp_Class.alt_Code 
									 end
									 else
										'039' 
							   end
							   as class_code, accounting_date, row_number() over (partition by accounting_date 
							order by
							   accounting_date, policy_num) as r 
							from
							   $V_TRNS_DB.AAIS_Inland_Marine_Prem_Loss AAIS 
							   left join
								  $V_EDW_EXTERNAL.ent_ref_code lkp_class 
								  on lkp_class.alt_code_type_name = 'AAIS-SCHPROP-CLASSCD' 
								  and lkp_class.code_type_name = 'CLASS_CD' 
								  and lkp_class.group_code = 'AAIS' 
								  and replace(upper(lkp_class.Code), ' ', '') = replace(upper(aais.class_code), ' ', '') 
							where
							   aais_extract_type_name = 'PREMIUM' 
							   and cast(accounting_date as int) >= cast(concat(substr(cast('${V_FROM_DATE}' as string), 6, 2), substr(cast('${V_FROM_DATE}' as string), 3, 2)) as int) 
							   and cast(accounting_date as int) <= cast(concat(substr(cast('${V_TO_DATE}' as string), 6, 2), substr(cast('${V_TO_DATE}' as string), 3, 2)) as int) 
						 )
						 b 
						 on a.policy_num = b.policy_num 
						 and a.accounting_date = b.accounting_date 
						 and a.class_code = b.class_code 
						 and a.job_num=b.job_num
				)
				amounts1 
				on d.policy_num = amounts1.policy_num 
				and d.accounting_date = amounts1.accounting_date 
				and d.class_code = amounts1.class_code 
				and d.job_num = amounts1.job_num 
	   )
	   d 
	where
	   (
		  prem_amount <> 0 
		  and prop_damage_cov_limit_amt <> 0
	   )
	union all
	select
	   rpad(aais_line_of_insurance_code, 2, ' '),
	   rpad(accounting_date, 4, ' '),
	   rpad(company_code, 4, ' '),
	   rpad(state_code, 2, ' '),
	   rpad(county_code, 3, ' '),
	   rpad(reserved_1, 1, ' '),
	   rpad(territory_code, 3, ' '),
	   rpad(transaction_code, 1, ' '),
	   lpad( 
	   case
		  when
			 prem_amount < 0 
		  then
			 concat( substr(cast(prem_amount as string), 2, length(cast(prem_amount as string)) - 2), 
			 case
				substr(cast(prem_amount as string), length(cast(prem_amount as string)), length(cast(prem_amount as string)) + 1) 
				when
				   '0' 
				then
				   '}' 
				when
				   '1' 
				then
				   'J' 
				when
				   '2' 
				then
				   'K' 
				when
				   '3' 
				then
				   'L' 
				when
				   '4' 
				then
				   'M' 
				when
				   '5' 
				then
				   'N' 
				when
				   '6' 
				then
				   'O' 
				when
				   '7' 
				then
				   'P' 
				when
				   '8' 
				then
				   'Q' 
				when
				   '9' 
				then
				   'R' 
			 end
	) 
		  when
			 prem_amount > 0 
		  then
			 case
				when
				   substr(cast(prem_amount as string), 1, 1) = '+'
				then
				   concat( substr(cast(prem_amount as string), 2, length(cast(prem_amount as string)) - 2), 
				   case
					  substr(cast(prem_amount as string), length(cast(prem_amount as string)), length(cast(prem_amount as string)) + 1) 
					  when
						 '0' 
					  then
						 '{' 
					  when
						 '1' 
					  then
						 'A' 
					  when
						 '2' 
					  then
						 'B' 
					  when
						 '3' 
					  then
						 'C' 
					  when
						 '4' 
					  then
						 'D' 
					  when
						 '5' 
					  then
						 'E' 
					  when
						 '6' 
					  then
						 'F' 
					  when
						 '7' 
					  then
						 'G' 
					  when
						 '8' 
					  then
						 'H' 
					  when
						 '9' 
					  then
						 'I' 
				   end
	) 
				else
				   cast(prem_amount as string) 
			 end
			 else
				'00000000' 
	   end
	, 10, '0') as prem_amt1, rpad(exposure_amt, 5, ' '), rpad(annual_statement_line_code, 3, ' '), rpad(program_class_code, 1, ' '), rpad(policy_form_code, 2, ' '), rpad(reserved_2, 3, ' '), rpad(terrorism_ind, 1, ' '), 
	   case
		  when
			 prop_damage_cov_limit_amt >= 0 
		  then
			 case
				when
				   prop_damage_cov_limit_amt = 0 
				then
				   '00000' 
				when
				   prop_damage_cov_limit_amt <= 1500 
				then
				   '00001' 
				when
				   cast(substr(cast(prop_damage_cov_limit_amt as string), length(cast(prop_damage_cov_limit_amt as string)) - 2, length(cast(prop_damage_cov_limit_amt as string))) as bigint) >= 500 
				then
				   lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 1, length(cast(prop_damage_cov_limit_amt as string)) - 3) as bigint) + 1) as string), 5, '0') 
				else
				   lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 1, length(cast(prop_damage_cov_limit_amt as string)) - 3) as bigint)) as string), 5, '0') 
			 end
			 else
				case
				   when
					  prop_damage_cov_limit_amt > - 1500 
					  and prop_damage_cov_limit_amt < 0 
				   then
					  '00001' 
				   when
					  cast(substr(cast(prop_damage_cov_limit_amt as string), length(cast(prop_damage_cov_limit_amt as string)) - 2, length(cast(prop_damage_cov_limit_amt as string))) as bigint) >= 500 
				   then
					  lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 2, length(cast(prop_damage_cov_limit_amt as string)) - 4) as bigint) + 1) as string), 5, '0') 
				   else
					  lpad(cast((cast(substr(cast(prop_damage_cov_limit_amt as string), 2, length(cast(prop_damage_cov_limit_amt as string)) - 4) as bigint)) as string), 5, '0') 
				end
	   end
	   as prop_damage_cov_limit_amt1, rpad(deduct_type_code, 1, ' '), rpad(deduct_amt, 2, ' '), rpad(reserved_3, 1, ' '), rpad(class_code, 3, ' '), rpad(reserved_4, 2, ' '), rpad(construction_code, 2, ' '), rpad(fire_protection_code, 2, ' '), rpad(reserved_5, 19, ' '), rpad(policy_type_code, 1, ' '), rpad(reserved_6, 1, ' '), rpad(package_ind, 1, ' '), rpad(reserved_7, 6, ' '), rpad(pool_code, 1, ' '), rpad(case when term_months_num='00' then '01' else term_months_num end, 2, ' '), rpad(reserved_8, 7, ' '), rpad(zip_5_code, 5, ' '), rpad(zip_4_suffix_code, 4, ' '), rpad(reserved_9, 16, ' '), rpad(d.policy_num, 14, ' ') as policy_num, '          '
	from
	   (
		  select distinct
			 aais_line_of_insurance_code,
			 accounting_date,
			 company_code,
			 state_code,
			 county_code,
			 reserved_1,
			 territory_code,
			 transaction_code,
			 cast(prem_amt as decimal(18, 2)) * 100 as prem_amount,
			 exposure_amt,
			 annual_statement_line_code,
			 program_class_code,
			 policy_form_code,
			 reserved_2,
			 terrorism_ind,
			 cast(prop_damage_cov_limit_amt as decimal(10, 0)) as prop_damage_cov_limit_amt,
			 deduct_type_code,
			 reserved_3,
			 class_code_var as class_code,
			 reserved_4,
			 case
				when
				   (
					  class_code = 'HearingAids' 
					  or class_code = 'FineArts' 
					  or class_code = 'Fine Arts'
				   )
				   or 
				   (
					  class_code_var = '235' 
					  or class_code_var = '236' 
					  or class_code_var = '237' 
					  or class_code_var = 'Personal Property Floaters' 
					  or class_code_var = '079' 
					  or class_code_var = '081' 
					  or class_code_var = '084' 
					  or class_code_var = 'Fine Arts'
				   )
				then
				   lkp_construction.alt_Code 
				else
				   '00' 
			 end
			 as construction_code, 
			 case
				when
				   (
					  class_code = 'HearingAids' 
					  or class_code = 'FineArts' 
					  or class_code = 'Fine Arts'
				   )
				   or 
				   (
					  class_code_var = '235' 
					  or class_code_var = '236' 
					  or class_code_var = '237' 
					  or class_code_var = 'Personal Property Floaters' 
					  or class_code_var = '079' 
					  or class_code_var = '081' 
					  or class_code_var = '084' 
					  or class_code_var = 'Fine Arts'
				   )
				then
				   lkp_fp.alt_Code 
				else
				   '00' 
			 end
			 as fire_protection_code, reserved_5, policy_type_code, reserved_6, package_ind, reserved_7, pool_code, term_months_num, reserved_8, zip_5_code, zip_4_suffix_code, reserved_9, policy_num, coverage_code, deduct_amt, r 
		  from
			 (
				select
				   aais_line_of_insurance_code,
				   accounting_date,
				   lkp_company.alt_code as company_code,
				   upper(lkp_company.alt_code) as upper_company_code,
				   lkp_state.alt_code as state_code,
				   upper(lkp_state.alt_code) as upper_state_code,
				   county_code,
				   reserved_1,
				   territory_code,
				   transaction_code,
				   prem_amt,
				   exposure_amt,
				   annual_statement_line_code,
				   program_class_code,
				   policy_form_code,
				   reserved_2,
				   terrorism_ind,
				   prop_damage_cov_limit_amt,
				   deduct_type_code,
				   reserved_3,
				   case
					  /*when class_code='053' then class_code*/
					  when
						 (
							coverage_code = 'HOSchedPersPropHOE' 
							or coverage_code = 'HOBlktPersPropHOE' 
							or coverage_code = 'HOSpecComputerCovHOE' 
							or coverage_code = 'HOWTRPhyDmgTrailer'
							or coverage_code = 'HOWTRWatercraft' 
							or coverage_code = 'HOWTRBoat' 
							or coverage_code = 'HOWTREmergency' 
							or coverage_code = 'HOWTRNav50'
						 )
						 and class_code is not null 
					  then
						 case
							when
							   lkp_class.alt_code is null 
							   or lkp_class.alt_code = '' 
							then
							   '039' 
							else
							   lkp_Class.alt_Code 
						 end
						 else
							'039' 
				   end
				   as class_code_var, class_code, upper_class_code, reserved_4, construction_code, upper_construction_code, fire_protection_code, upper_fire_protection_code, reserved_5, policy_type_code, reserved_6, package_ind, reserved_7, pool_code, term_months_num, reserved_8, zip_5_code, zip_4_suffix_code, reserved_9, policy_num, coverage_code , deduct_amt, r 
				from
				   (
					  select
						 aais_line_of_insurance_code,
						 accounting_date,
						 upper(company_code) as upper_company_code,
						 upper(state_code) as upper_state_code,
						 county_code,
						 reserved_1,
						 territory_code,
						 transaction_code,
						 prem_amt,
						 exposure_amt,
						 annual_statement_line_code,
						 program_class_code,
						 policy_form_code,
						 reserved_2,
						 terrorism_ind,
						 prop_damage_cov_limit_amt,
						 deduct_type_code,
						 deduct_amt,
						 reserved_3,
						 class_code,
						 upper(class_code) as upper_class_code,
						 reserved_4,
						 construction_code,
						 upper(construction_code) as upper_construction_code,
						 fire_protection_code,
						 upper(fire_protection_code) as upper_fire_protection_code,
						 reserved_5,
						 policy_type_code,
						 reserved_6,
						 package_ind,
						 reserved_7,
						 pool_code,
						 term_months_num,
						 reserved_8,
						 case
							when
							   zip_5_code is null 
							then
							   '00000' 
							else
							   substring(zip_5_code, 1, 5) 
						 end
						 as zip_5_code, zip_4_suffix_code, reserved_9, policy_num, coverage_code, row_number() over (partition by accounting_date 
					  order by
						 accounting_date, policy_num) as r 
					  from
						 $V_TRNS_DB.AAIS_Inland_Marine_Prem_Loss 
					  where
						 aais_extract_type_name = 'PREMIUM' 
						 and cast(accounting_date as int) >= cast(concat(substr(cast('${V_FROM_DATE}' as string), 6, 2), substr(cast('${V_FROM_DATE}' as string), 3, 2)) as int) 
						 and cast(accounting_date as int) <= cast(concat(substr(cast('${V_TO_DATE}' as string), 6, 2), substr(cast('${V_TO_DATE}' as string), 3, 2)) as int) 
						 and 
						 (
							cast(prem_amt as decimal(18, 2)) <> 0 
							or cast(prop_damage_cov_limit_amt as decimal(18, 2)) <> 0
						 )
						 and 
						 (
							coverage_code = 'HOWTRPhyDmgTrailer'
							or coverage_code = 'HOWTRWatercraft' 
							or coverage_code = 'HOWTRBoat' 
							or coverage_code = 'HOWTREmergency' 
							or coverage_code = 'HOWTRNav50'
						 )
				   )
				   aais 
				   left join
					  $V_EDW_EXTERNAL.ent_ref_code lkp_company 
					  on lkp_company.alt_code_type_name = 'AAIS-CO' 
					  and lkp_company.code_type_name = 'UNDERWRITING-CO' 
					  and lkp_company.group_code = 'AAIS' 
					  and upper(lkp_company.Code) = aais.upper_company_code 
				   left join
					  $V_EDW_EXTERNAL.ent_ref_code lkp_state 
					  on lkp_state.alt_code_type_name = 'STATE-NUM' 
					  and lkp_state.code_type_name = 'STATE-CD' 
					  and lkp_state.group_code = 'LGCY' 
					  and upper(lkp_state.Code) = aais.upper_state_code 
				   left join
					  $V_EDW_EXTERNAL.ent_ref_code lkp_class 
					  on lkp_class.alt_code_type_name = 'AAIS-WTRCRFT-CLASSCD' 
					  and lkp_class.code_type_name = 'CLASS_CD' 
					  and lkp_class.group_code = 'AAIS' 
					  and replace(upper(lkp_class.Code), ' ', '') = replace(aais.upper_class_code, ' ', '') 
			 )
			 a 
			 left join
				$V_EDW_EXTERNAL.ent_ref_code lkp_construction 
				on lkp_construction.alt_code_type_name = 'AAIS-CONSTRCD' 
				and lkp_construction.code_type_name = 'CONSTRUCTION_CD' 
				and lkp_construction.group_code = 'AAIS' 
				and upper(lkp_construction.Code) = a.upper_construction_code 
			 left join
				$V_EDW_EXTERNAL.ent_ref_code lkp_fp 
				on lkp_fp.alt_code_type_name = 'AAIS-FIRECD' 
				and lkp_fp.code_type_name = 'FIREPRT_CD' 
				and lkp_fp.group_code = 'AAIS' 
				and upper(lkp_fp.Code) = a.upper_fire_protection_code 
	   )
	   d 	where
	   (
		  prem_amount <> 0 
		  and prop_damage_cov_limit_amt <> 0
	   );
 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO AAIS Prem file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR :  ISO AAIS Prem Extract file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO AAIS Prem Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO AAIS Prem Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
