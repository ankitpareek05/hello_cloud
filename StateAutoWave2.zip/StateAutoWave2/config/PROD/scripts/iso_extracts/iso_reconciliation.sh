#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_reconciliation.sh                                        #
#                                                                             #
# Description  : Script to do the reconciliation                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#recipient_email_id=anoop.np@stateauto.com,Praveen.KaniyamparambilPrakasan@StateAuto.com,jaikumar.manickarajendran@stateauto.com,mala.dhavidhu@stateauto.com
recipient_email_id=$MAIL_TO

#V_FROM_DATE='2018-07-01'
#V_TO_DATE='2018-09-30'

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_PRCS_NAME=${PROCESS_NAME}
V_ADHOC_LOAD=${ADHOC_LOAD}
V_START_DTE=${START_DTE}
V_END_DTE=${END_DTE}
info "PRCS_NAME: ${V_PRCS_NAME}"

if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]] || [[ -z "$V_PRCS_NAME" ]] || [[ -z "$V_ADHOC_LOAD" ]]
then
	info "Message : The parameter passed with the script are empty"
	info "Warning : Please pass the correct parameter"
	exit 1
fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
	mkdir -p ${v_tmp_path_serving}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_serving}/recon_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/_recon_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

##############################################################################################################################################################

V_CURR_QTR=`hive -S -e "select quarter(cast(CURRENT_DATE() as date))"`
info "CURR_QTR - ${V_CURR_QTR}" 

if [ $V_ADHOC_LOAD == 'Y' ]
then
if [[ -z "$V_START_DTE" ]] || [[ -z "$V_END_DTE" ]]
then
	info "Message : The parameter passed with the script are empty"
	info "Warning : Please pass the date parameters when running for adhoc load"
	exit 1
fi
	V_FROM_DATE=$V_START_DTE
	V_TO_DATE=$V_END_DTE
elif [ $V_ADHOC_LOAD == 'N' ]
then
	if [ $V_CURR_QTR == 1 ]
	then
		V_FROM_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))-1||'-10-01'"`
		V_TO_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))-1||'-12-31'"`
	elif [ $V_CURR_QTR == 2 ]
	then
		V_FROM_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))||'-01-01'"`
		V_TO_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))||'-03-31'"`
	elif [ $V_CURR_QTR == 3 ]
	then
		V_FROM_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))||'-04-01'"`
		V_TO_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))||'-06-30'"`
	elif [ $V_CURR_QTR == 4 ]
	then
		V_FROM_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))||'-07-01'"`
		V_TO_DATE=`hive -S -e "select year(cast(CURRENT_DATE() as date))||'-09-30'"`
	fi
fi
#V_FROM_DATE='2018-07-01'
#V_TO_DATE='2018-09-30'

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

V_START_DATE=`hive -S -e "select cast('${V_FROM_DATE}' as date)"`
V_END_DATE=`hive -S -e "select cast('${V_TO_DATE}' as date)"`

V_REC_START_DATE=`hive -S -e "select from_unixtime(unix_timestamp(cast('${V_FROM_DATE}' as date)),'yyyyMM')"`
V_REC_END_DATE=`hive -S -e "select from_unixtime(unix_timestamp(cast('${V_TO_DATE}' as date)),'yyyyMM')"`

V_YRQTR=`hive -S -e "select year(cast('${V_TO_DATE}' as date))||'Q'||quarter(cast('${V_TO_DATE}' as date))"`

info "START DATE - ${V_START_DATE} - End Date: ${V_END_DATE}" 
info "REC START_DATE - ${V_REC_START_DATE} - REC End Date: ${V_REC_END_DATE}" 

if [ $V_PRCS_NAME == 'TXPREM' ]
then
	info "TX Premium process:${V_PRCS_NAME}"
	info "Variable Value V_TRNS_DB: ${V_TRNS_DB}"
	
	extract_query=`hive -S -e "SELECT sum(bodily_injury_prem_amt) as Total_Amt FROM ${V_TRNS_DB}.iso_cup_prem where risk_state_code = 'TX' and cast(accounting_date as date) between '${V_START_DATE}' and '${V_END_DATE}'"` 
	info "Extract Amount:${extract_query}"
	
	recon_query=`hive -S -e "SELECT cast(sum(pt.transaction_amt) as integer) as MTD_PremTransAmt FROM ${V_TRNS_DB}.gwpc_prem_trans_detail pt JOIN ${V_TRNS_DB}.policy_common pc ON pt.policy_period_join_id = pc.policy_period_join_id WHERE pc.line_of_busn_code = 'CUCommercialUmbrella' and pt.charge_pattern_type_code = 'Premium' and pc.primary_risk_state_code = 'TX' and SUBSTRING(CAST(pt.accounting_date_key as varchar(20)),1,6) between '${V_REC_START_DATE}' and '${V_REC_END_DATE}'"`
	info "Recon Query Amount:${recon_query}"
	
	email_content="TX Premium - Extract Amount: ${extract_query}, Recon Amount: ${recon_query}"
	email_subject="ISO Reconciliation Job for TX Premium - ${V_YRQTR}"
	
elif [ $V_PRCS_NAME == 'NONTXPREM' ]
then
	info "Non TX Premium process:${V_PRCS_NAME}"
	info "Variable Value V_TRNS_DB: ${V_TRNS_DB}"
	
	extract_query=`hive -S -e "SELECT sum(bodily_injury_prem_amt) as Total_Amt FROM ${V_TRNS_DB}.iso_cup_prem where risk_state_code <> 'TX' and cast(accounting_date as date) between '${V_START_DATE}' and '${V_END_DATE}'"`
	info "Extract Amount:${extract_query}"
	
	recon_query=`hive -S -e "SELECT cast(sum(pt.transaction_amt) as integer) as MTD_PremTransAmt FROM ${V_TRNS_DB}.gwpc_prem_trans_detail pt JOIN ${V_TRNS_DB}.policy_common pc ON pt.policy_period_join_id = pc.policy_period_join_id WHERE pc.line_of_busn_code = 'CUCommercialUmbrella' and pt.charge_pattern_type_code = 'Premium' and pc.primary_risk_state_code <> 'TX' and SUBSTRING(CAST(pt.accounting_date_key as varchar(20)),1,6) between '${V_REC_START_DATE}' and '${V_REC_END_DATE}'"`
	info "Recon Query Amount:${recon_query}"
	
	email_content="Non TX Premium - Extract Amount: ${extract_query}, Recon Amount: ${recon_query}"
	email_subject="ISO Reconciliation Job for NON TX Premium - ${V_YRQTR}"
fi

extract_amount=${extract_query}
info "Extract_Amount:${extract_amount}"

recon_amount=${recon_query}
info "recon_amount:${recon_amount}"

if [ "$extract_amount" == "$recon_amount" ];
then
	echo "$email_content"|mail -s "${email_subject} - SUCCESS" $recipient_email_id;
	info "Amounts are matching"
else
	echo "$email_content"|mail -s "${email_subject} - FAILURE" $recipient_email_id;
	info "Amounts are not matching"
fi

info "Email Sent successfully"

info "Processing completed successfully!!!!!" >>  ${v_Log} 2>&1

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
