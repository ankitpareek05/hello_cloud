#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO PLSP Homeowners Paid Loss_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO PLSP Homeowners Paid Loss file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../../shell_functions/bin/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/PLSP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="PLSP_HOMEOWNERS_LOSS_OUT_Q""$V_CURR_QTR""$V_CURR_YEAR""_""$V_EPOC_DATE"".TXT"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO PLSP Homeowners Paid Loss"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
select * from ( select company_num, iso_transaction_type_code, accounting_date, inception_date, loss_date, r1, state_code, territory_code, ho_home_busn_cls_cd, annual_statement_line_code, ho_subline, ho_exp_cd, r2, ho_form_cd, ho_no_of_fmly_cd, ho_ord_or_law_cd, ho_status_code, ho_wind_ded_size_cd, ho_construction_cd, ho_protection_class_cd, ho_mold_damage_coverage, r3, ho_theft_ded_size_cd, ho_type_of_ded_cd, ho_fire_ded_size_cd, iso_construction_year_code, envirmnt_impair_cov_s1_code, envirmnt_impair_cov_s2_code, condo_alter_lib_lmt_code, ho_policy_program_code, ho_covc_percent_amt, green_upgrd_ind_code, ho_cov_liab_lmt_cd, ho_roof_loss_settlement_code, coalesce( case when exposure_amt > 9998500 then '9999' else lpad(cast(round((exposure_amt / 1000), 0) as bigint), 4, '0') end , '0000') as exposure_amt , bceg_classification_code, ho_protective_devices_code, HO_LOSS_CAUSE_CD, r5, mobilehome_endorsement_id, tie_down, r6, ho_st_exp_ind1, case when iso_claim_cnt=0 then '0' when iso_claim_cnt=1 then '1' when iso_claim_cnt='-1' then 'J' end as iso_claim_cnt , zip_code, r7, ho_st_exp_ind2, ho_st_exp_ind3, iso_wind_hail_cov_ind_code, ho_loss_hstry_cd, iso_roof_instl_year_code, ho_risk_ind_1, ho_risk_ind_2, r8, company_program_excpt_ind, statistical_plan_ind_code, r9, lpad( case when loss_amt < 0 then concat( substr(cast(loss_amt as varchar(255)), 2, length(cast(loss_amt as varchar(255))) - 2), case substr(cast(loss_amt as varchar(255)), length(cast(loss_amt as varchar(255))), length(cast(loss_amt as varchar(255))) + 1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end ) when loss_amt > 0 then case when substr(cast(loss_amt as varchar(255)), 1, 1) = '+' then concat( substr(cast(loss_amt as varchar(255)), 2, length(cast(loss_amt as varchar(255))) - 2), case substr(cast(loss_amt as varchar(255)), length(cast(loss_amt as varchar(255))), length(cast(loss_amt as varchar(255))) + 1) when '0' then '{' when '1' then 'A' when '2' then 'B' when '3' then 'C' when '4' then 'D' when '5' then 'E' when '6' then 'F' when '7' then 'G' when '8' then 'H' when '9' then 'I' end ) else cast(loss_amt as varchar(255)) end else '00000000' end , 8, '0') as loss_amt, loss_record_id, policy_num, r10 from ( select company_num, iso_transaction_type_code, accounting_date, inception_date, loss_date, r1, state_code, territory_code, ho_home_busn_cls_cd, annual_statement_line_code, ho_subline, min(ho_exp_cd) as ho_exp_cd, r2, min(ho_form_cd) as ho_form_cd, min(ho_no_of_fmly_cd) as ho_no_of_fmly_cd, min(ho_ord_or_law_cd) as ho_ord_or_law_cd, min(ho_status_code) as ho_status_code, min(ho_wind_ded_size_cd) as ho_wind_ded_size_cd, min(ho_construction_cd) as ho_construction_cd, min(ho_protection_class_cd) as ho_protection_class_cd, min(ho_mold_damage_coverage) as ho_mold_damage_coverage, r3, min(ho_theft_ded_size_cd) as ho_theft_ded_size_cd, min(ho_type_of_ded_cd) as ho_type_of_ded_cd, min(ho_fire_ded_size_cd) as ho_fire_ded_size_cd, iso_construction_year_code, envirmnt_impair_cov_s1_code, envirmnt_impair_cov_s2_code, condo_alter_lib_lmt_code, min(ho_policy_program_code) as ho_policy_program_code, min(ho_covc_percent_amt) as ho_covc_percent_amt, green_upgrd_ind_code, ho_cov_liab_lmt_cd, ho_roof_loss_settlement_code, max(cast(exposure_amt as decimal(18, 5))) as exposure_amt, bceg_classification_code, ho_protective_devices_code, HO_LOSS_CAUSE_CD, r5, mobilehome_endorsement_id, tie_down, r6, ho_st_exp_ind1, iso_claim_cnt, zip_code, r7, ho_st_exp_ind2, ho_st_exp_ind3, min(iso_wind_hail_cov_ind_code) as iso_wind_hail_cov_ind_code, ho_loss_hstry_cd, iso_roof_instl_year_code, ho_risk_ind_1, ho_risk_ind_2, r8, company_program_excpt_ind, statistical_plan_ind_code, r9, round(cast(loss_amt as decimal(18, 5))) as loss_amt, loss_record_id, policy_num, r10 from ( select distinct claim_transaction_key, lpad(coalesce(refcomp.alt_code, '    '), 4, ' ') as company_num, iso_transaction_type_code as iso_transaction_type_code, lpad(coalesce(concat(( case when ( substr(cast(accounting_date as varchar(25)), 6, 2) ) in ( '01', '02', '03' ) then '3' when ( substr(cast(accounting_date as varchar(25)), 6, 2) ) in ( '04', '05', '06' ) then '6' when ( substr(cast(accounting_date as varchar(25)), 6, 2) ) in ( '07', '08', '09' ) then '9' when ( substr(cast(accounting_date as varchar(25)), 6, 2) ) in ( '10', '11', '12' ) then '&' end ), ( substr(cast(accounting_date as varchar(25)), 4, 1) ) ), '  '), 2, ' ') as accounting_date, lpad(coalesce(concat( case when ( substr(cast(inception_date as varchar(25)), 6, 2) ) = '10' then '0' when ( substr(cast(inception_date as varchar(25)), 6, 2) ) = '11' then '-' when ( substr(cast(inception_date as varchar(25)), 6, 2) ) = '12' then '&' else substr(cast(inception_date as varchar(25)), 7, 1) end , substr(cast(inception_date as varchar(25)), 3, 2)), '  '), 3, ' ') as inception_date, lpad(coalesce(concat(concat( case when ( substr(cast(loss_date as varchar(25)), 6, 2) ) = '10' then '0' when ( substr(cast(loss_date as varchar(25)), 6, 2) ) = '11' then '-' when ( substr(cast(loss_date as varchar(25)), 6, 2) ) = '12' then '&' else substr(cast(loss_date as varchar(25)), 7, 1) end , substr(cast(loss_date as varchar(25)), 3, 2)), substr(cast(loss_date as varchar(25)), 1, 2)), '     '), 5, ' ') as loss_date, ' ' as r1, lpad(coalesce(cast(st_code.alt_code as varchar(2)), '  '), 2, ' ') as state_code, lpad(coalesce(territory_code, '   '), 3, ' ') as territory_code, lpad(coalesce(rc.ho_home_busn_cls_cd, '  '), 2, ' ') as ho_home_busn_cls_cd, lpad(coalesce(annual_statement_line_code, '000'), 3, '0') as annual_statement_line_code, lpad(coalesce(rc.ho_subline, '   '), 3, ' ') as ho_subline, coalesce(rc.ho_exp_cd, ' ') as ho_exp_cd, ' ' as r2, coalesce(rc.ho_form_cd, ' ') as ho_form_cd, coalesce(rc.ho_no_of_fmly_cd, ' ') as ho_no_of_fmly_cd, coalesce(rc.ho_ord_or_law_cd, ' ') as ho_ord_or_law_cd, coalesce(rc.ho_status_code, ' ') as ho_status_code, lpad(coalesce(rc.ho_wind_ded_size_cd, '  '), 2, ' ') as ho_wind_ded_size_cd, coalesce(rc.ho_construction_cd, ' ') as ho_construction_cd, lpad(coalesce(rc.ho_protection_class_cd, '00'), 2, '0') as ho_protection_class_cd, coalesce(rc.ho_mold_damage_coverage, ' ') as ho_mold_damage_coverage, ' ' as r3, coalesce(rc.ho_theft_ded_size_cd, ' ') as ho_theft_ded_size_cd, coalesce(rc.ho_type_of_ded_cd, ' ') as ho_type_of_ded_cd, lpad(coalesce(rc.ho_fire_ded_size_cd, '  '), 2, ' ') as ho_fire_ded_size_cd, lpad(coalesce(iso_construction_year_code, '  '), 2, ' ') as iso_construction_year_code, coalesce(envirmnt_impair_cov_s1_code, ' ') as envirmnt_impair_cov_s1_code, coalesce(envirmnt_impair_cov_s2_code, ' ') as envirmnt_impair_cov_s2_code, lpad(coalesce(condo_alter_lib_lmt_code, ' '), 1, ' ') as condo_alter_lib_lmt_code, coalesce(rc.ho_policy_program_code, ' ') as ho_policy_program_code, coalesce(rc.ho_covc_percent_amt, ' ') as ho_covc_percent_amt, ' ' as green_upgrd_ind_code, coalesce(rc.ho_cov_liab_lmt_cd, ' ') as ho_cov_liab_lmt_cd, lpad(coalesce(rc.ho_roof_loss_settlement_code, ' '), 1, ' ') as ho_roof_loss_settlement_code, exposure_amt as exposure_amt, lpad(coalesce(bceg_classification_code, '  '), 2, ' ') as bceg_classification_code, lpad(coalesce(rc.ho_protective_devices_code, '00'), 2, '0') as ho_protective_devices_code, lpad(coalesce(rc.HO_LOSS_CAUSE_CD, '00'), 2, '0') as HO_LOSS_CAUSE_CD , ' ' as r5, lpad(coalesce(mobilehome_endorsement_id, ' '), 1, ' ') as mobilehome_endorsement_id, lpad(coalesce(tie_down, ' '), 1, ' ') as tie_down, ' ' as r6, coalesce(rc.ho_st_exp_ind1, ' ') as ho_st_exp_ind1, coalesce(iso_claim_cnt, ' ') as iso_claim_cnt, lpad(coalesce(zip_code, '     '), 5, ' ') as zip_code, '    ' as r7, coalesce(rc.ho_st_exp_ind2, ' ') as ho_st_exp_ind2, coalesce(rc.ho_st_exp_ind3, ' ') as ho_st_exp_ind3, coalesce(iso_wind_hail_cov_ind_code, ' ') as iso_wind_hail_cov_ind_code, coalesce(rc.ho_loss_hstry_cd, ' ') as ho_loss_hstry_cd, lpad( case when cast(substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 4, 4) as bigint) < 1985 then '99' when cast(substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 3, 4) as bigint) between 1985 and 1998 then substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 1, 2) when cast(substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 3, 4) as bigint) = 1999 then 'NN' when cast(substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 3, 4) as bigint) = 2000 then 'TT' when cast(substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 3, 4) as bigint) between 2001 and 2084 then substring(iso_roof_instl_year_code, length(iso_roof_instl_year_code) - 1, 2) else '  ' end , 2, ' ') as iso_roof_instl_year_code, coalesce(rc.ho_risk_ind_1, ' ') as ho_risk_ind_1, coalesce(rc.ho_risk_ind_2, ' ') as ho_risk_ind_2, '  ' as r8, lpad(coalesce(company_program_excpt_ind, '  '), 2, ' ') as company_program_excpt_ind, coalesce(statistical_plan_ind_code, ' ') as statistical_plan_ind_code, ' ' as r9, loss_amt, lpad(coalesce(loss_record_id, '              '), 14, ' ') as loss_record_id, lpad(coalesce(main.policy_num, '0000000000000'), 13, '0') as policy_num, '                    ' as r10 from $V_TRNS_DB.iso_ho_df_prem_loss main left join $V_TRNS_DB.outloss_iso_ho_df_prem_loss_resulting_codes rc on rc.policy_num = main.policy_num and rc.policy_join_id = main.policy_join_id and rc.product_line_form = main.policy_type_code left join $V_EDW_EXTERNAL.ent_ref_code st_code on st_code.code = main.state_code left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code = main.company_num where main.source_system_code = 'OUTLOSS' and iso_claim_cnt <> '99' and cast(main.accounting_date as date) between cast('${V_FROM_DATE}' as date) and cast('${V_TO_DATE}' as date) and cast(rc.create_dateyyyymm as varchar(20)) = concat(substr('${V_TO_DATE}', 1, 4), substr('${V_TO_DATE}', 6, 2)) ) a group by company_num, iso_transaction_type_code, accounting_date, inception_date, loss_date, r1, state_code, territory_code, ho_home_busn_cls_cd, annual_statement_line_code, ho_subline, /*ho_exp_cd,*/ r2,/* ho_form_cd, ho_no_of_fmly_cd, ho_ord_or_law_cd, ho_status_code, ho_construction_cd, ho_protection_class_cd, ho_mold_damage_coverage,*/ r3, /*ho_theft_ded_size_cd, ho_type_of_ded_cd, ho_fire_ded_size_cd, */iso_construction_year_code, envirmnt_impair_cov_s1_code, envirmnt_impair_cov_s2_code, condo_alter_lib_lmt_code, /*ho_policy_program_code, ho_covc_percent_amt,*/ green_upgrd_ind_code, ho_cov_liab_lmt_cd, ho_roof_loss_settlement_code, bceg_classification_code, ho_protective_devices_code, HO_LOSS_CAUSE_CD, r5, mobilehome_endorsement_id, tie_down, r6, ho_st_exp_ind1, iso_claim_cnt, zip_code, r7, ho_st_exp_ind2, ho_st_exp_ind3, /*iso_wind_hail_cov_ind_code,*/ ho_loss_hstry_cd, iso_roof_instl_year_code, ho_risk_ind_1, ho_risk_ind_2, r8, company_program_excpt_ind, statistical_plan_ind_code, r9, loss_record_id, policy_num, r10,claim_transaction_key,loss_amt ) b ) c where loss_amt != '00000000' and loss_amt != '0000000}' /*and policy_num='0001000000355''0001000000091'*/;
 " | sed 's/[\t]//g' >> /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO PLSP Homeowners Paid Loss file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO PLSP Homeowners Paid Loss file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO PLSP Homeowners Paid Loss Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO PLSP Homeowners Paid Loss Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
