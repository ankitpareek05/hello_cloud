#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]] || [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_FILE_NAME="ISO_CUP_PREMIUM_TX_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_TX_PREM/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating ISO TX Extract file"

info "Connecting to ${V_TRNS_DB}"

hive -S -e "SELECT DISTINCT concat(
    rpad(
	case when cast(refcode_value AS STRING) is NULL or cast(refcode_value AS STRING)='' then ' '
	else cast(refcode_value AS STRING)
	end,4,' '), 
	rpad(
	case when cast(iso_transaction_type_code AS STRING) is NULL or cast(iso_transaction_type_code AS STRING)='' then ' '
	else cast(iso_transaction_type_code AS STRING) end
	,1,' '), 
	rpad(case
    WHEN substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(accounting_date AS STRING),4,1))
    WHEN substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(accounting_date AS STRING),4,1))
    ELSE concat(substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) AS STRING),7,1),substr(cast(accounting_date AS STRING),4,1)) end,2,' '), 
	rpad(case
    WHEN substr(cast(inception_date AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(inception_date AS STRING),3,2))
    WHEN substr(cast(inception_date AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(inception_date AS STRING),3,2))
    ELSE concat(substr(cast(inception_date AS STRING),7,1),substr(cast(inception_date AS STRING),3,2)) end,3,' '), 
	rpad(case
    WHEN substr(cast(transaction_eff_date AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(transaction_eff_date AS STRING),3,2))
    WHEN substr(cast(transaction_eff_date AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(transaction_eff_date AS STRING),3,2))
    ELSE concat(substr(cast(transaction_eff_date AS STRING),7,1),substr(cast(transaction_eff_date AS STRING),3,2)) end,3,' '), 
	rpad(case
    WHEN substr(cast(transaction_exp_date AS STRING),6,2) ='12' THEN
    concat('&',substr(cast(transaction_exp_date AS STRING),3,2))
    WHEN substr(cast(transaction_exp_date AS STRING),6,2) ='11' THEN
    concat('-',substr(cast(transaction_exp_date AS STRING),3,2))
    ELSE concat(substr(cast(transaction_exp_date AS STRING),7,1),substr(cast(transaction_exp_date AS STRING),3,2)) end,3,' '), 
	lpad(case
    WHEN risk_state_code='' OR risk_state_code is NULL THEN ' '
	WHEN st.code is NULL then ' '
    ELSE cast(st.code AS STRING)
    END ,2,'0'), 
	rpad(case WHEN territory_code=''
        OR territory_code is NULL THEN ' '
    ELSE territory_code end,3,' '), 
	rpad(
	case when cast(iso_policy_type_code AS STRING) is NULL or cast(iso_policy_type_code AS STRING)='' then ' '
	else cast(iso_policy_type_code AS STRING)
	end
	,2,' '), 
	rpad(
	case when cast(annual_statement_line_code AS STRING) is NULL or cast(annual_statement_line_code AS STRING)='' then ' '
	else cast(annual_statement_line_code AS STRING)
	end
	,3,' '), 
	rpad(
	case when cast(iso_csp_subline_code AS STRING) is NULL or cast(iso_csp_subline_code AS STRING)='' then ' '
	else cast(iso_csp_subline_code AS STRING)
	end
	,3,' '), 
	rpad(
	case when cast(iso_classification_code AS STRING) is NULL or cast(iso_classification_code AS STRING)='' then ' '
	else cast(iso_classification_code AS STRING)
	end
	,5,' '), 
	rpad(case
    WHEN iso_state_exception_code='' or iso_state_exception_code is null THEN ' '
    ELSE iso_state_exception_code end,1,' '), 
	rpad(
	case when cast(limits_ind AS STRING)='' or cast(limits_ind AS STRING) is NULL then ' '
	else cast(limits_ind AS STRING)
	end
	,1,' '), 
	rpad(case
    WHEN cast(bodily_injury_limit_amt AS STRING)= ''
    OR bodily_injury_limit_amt is NULL THEN ' '
    WHEN agg_limit.code is NOT NULL THEN
    agg_limit.code
    WHEN bodily_injury_limit_amt=4000000 THEN
    '23'
    WHEN bodily_injury_limit_amt=8000000 THEN
    '25'
    ELSE ' '
    END ,2,' '), 
	rpad(case
    WHEN cast(property_damage_limit_amt AS STRING)= ''
        OR property_damage_limit_amt is NULL THEN ' '
    ELSE property_damage_limit_amt
    END ,2,' '), 
	coalesce(case
    WHEN trans.retention_amt > 10000000 THEN
    '93'
    ELSE ret_amt.code end,' '), 
	rpad(case
    WHEN cast(property_damage_deduct_code AS STRING)=''
        OR property_damage_deduct_code is NULL THEN ' '
    ELSE cast(property_damage_deduct_code AS STRING)
    END ,2,' '),
    CASE
    WHEN coverage_code=''
        OR coverage_code is NULL THEN ' '
    ELSE coverage_code end, 
	rpad(case
    WHEN risk_identification_code=''
        OR risk_identification_code is NULL THEN ' '
    ELSE risk_identification_code end,1,' '), 
	rpad(case
    WHEN claims_made_year_month=''
        OR claims_made_year_month is NULL THEN ' '
    ELSE claims_made_year_month end,3,' '), 
	lpad(case
    WHEN cast(policy_aggregate_limit_amt AS STRING)= ''
        OR policy_aggregate_limit_amt is NULL THEN ' '
    ELSE cast(cast((policy_aggregate_limit_amt/1000) AS Integer) AS STRING)
    END ,6,'0'), 
	rpad(case
    WHEN terrorism_coverage_code = ''
        OR terrorism_coverage_code is NULL THEN ' '
    ELSE terrorism_coverage_code
    END ,1,' '), 
	rpad(case
    WHEN cast(job_type_code AS STRING)= '' OR job_type_code is NULL THEN ' '
	WHEN trans_type.code is NULL OR trans_type.code ='' then ' '
    ELSE trans_type.code
    END ,2,' '), 
	rpad(case
    WHEN rating_identification_code=''
    OR rating_identification_code is NULL THEN ' '
    ELSE rating_identification_code end,1,' '), ' ', 
	rpad(case
    WHEN cast(deduct_amt AS STRING)= ''
    OR deduct_amt is NULL THEN ' '
    ELSE cast(deduct_amt AS STRING)
    END ,5,' '), 
	lpad(case
    WHEN cast(policy_occurrence_limit_amt AS STRING)= ''
    OR policy_occurrence_limit_amt is NULL THEN ' '
    ELSE cast(cast((policy_occurrence_limit_amt/1000) AS Integer) AS STRING)
    END ,6,'0'), 
	lpad(case
    WHEN cast(transaction_eff_day AS STRING)= ''
    OR transaction_eff_day is NULL THEN ' '
    ELSE cast(transaction_eff_day AS STRING)
    END ,2,'0'), lpad(case
    WHEN cast(transaction_exp_day AS STRING)= ''
    OR transaction_exp_day is NULL THEN ' '
    ELSE cast(transaction_exp_day AS STRING)
    END ,2,'0'), 
	rpad(case
    WHEN mga_ind='' OR mga_ind is NULL THEN ' '
    ELSE mga_ind end,1,' '), 
	rpad(case
    WHEN exposure_ind_code=''
    OR exposure_ind_code is NULL THEN ' '
    ELSE exposure_ind_code end,1,' '), 
	rpad(case
    WHEN schedule_rating_modifier=''
    OR schedule_rating_modifier is NULL THEN ' '
    ELSE schedule_rating_modifier end,3,' '), 
	rpad(case
    WHEN exposure=''
    OR exposure is NULL THEN ' '
    ELSE exposure end,7,' '), 
	rpad(case
    WHEN rating_modifier=''
    OR rating_modifier is NULL THEN ' '
    ELSE rating_modifier end,3,' '), 
	rpad(case
    WHEN loss_cost_multiplier=''
    OR loss_cost_multiplier is NULL THEN ' '
    ELSE loss_cost_multiplier end,3,' '), 
	rpad(case
    WHEN endorsement_id_code=''
    OR endorsement_id_code is NULL THEN ' '
    ELSE endorsement_id_code end,1,' '), ' ', 
	lpad(
    CASE
    WHEN bodily_injury_prem_amt < 0 THEN
    concat( substr(cast(bodily_injury_prem_amt AS STRING),2,length(cast(bodily_injury_prem_amt AS STRING))-2),
    CASE substr(cast(bodily_injury_prem_amt AS STRING),length(cast(bodily_injury_prem_amt AS STRING)),length(cast(bodily_injury_prem_amt AS STRING))+1)
    WHEN '0' THEN
    '}'
    WHEN '1' THEN
    'J'
    WHEN '2' THEN
    'K'
    WHEN '3' THEN
    'L'
    WHEN '4' THEN
    'M'
    WHEN '5' THEN
    'N'
    WHEN '6' THEN
    'O'
    WHEN '7' THEN
    'P'
    WHEN '8' THEN
    'Q'
    WHEN '9' THEN
    'R'
    END )
    WHEN bodily_injury_prem_amt > 0 THEN
    concat( substr(cast(bodily_injury_prem_amt AS STRING),1,length(cast(bodily_injury_prem_amt AS STRING))-1),
    CASE substr(cast(bodily_injury_prem_amt AS STRING),length(cast(bodily_injury_prem_amt AS STRING)),length(cast(bodily_injury_prem_amt AS STRING))+1)
    WHEN '0' THEN
    '{'
    WHEN '1' THEN
    'A'
    WHEN '2' THEN
    'B'
    WHEN '3' THEN
    'C'
    WHEN '4' THEN
    'D'
    WHEN '5' THEN
    'E'
    WHEN '6' THEN
    'F'
    WHEN '7' THEN
    'G'
    WHEN '8' THEN
    'H'
    WHEN '9' THEN
    'I'
    END )
    END ,8,'0'),rpad(case
    WHEN cast(property_damage_prem_amt AS STRING)= '' OR property_damage_prem_amt is NULL THEN ' '
    ELSE cast(property_damage_prem_amt AS STRING)
    END ,9,' '),
    rpad(case WHEN cast(standard_industrial_classifi AS STRING)= '' OR standard_industrial_classifi is NULL THEN ' '
    ELSE cast(standard_industrial_classifi AS STRING)
    END ,4,' '),
	' ',
    rpad(case
    WHEN policy_num=''
    OR policy_num is NULL THEN ' '
    ELSE policy_num end,33,' ') )
FROM $V_TRNS_DB.iso_cup_prem trans
LEFT JOIN $V_TRNS_DB.ISO_Company_Number ref_comp
    ON cast(ref_comp.iso_code AS STRING)=trans.company_num
LEFT JOIN $V_TRNS_DB.iso_ref_policy_lmt_code agg_limit
    ON agg_limit.liab_lim=cast(trans.bodily_injury_limit_amt AS STRING)
LEFT JOIN $V_TRNS_DB.iso_ref_umb_attch_point ret_amt
    ON ret_amt.attch_point=cast(trans.retention_amt AS STRING)
LEFT JOIN $V_TRNS_DB.ISO_REF_Transact_ID trans_type
    ON trans.job_type_code=trans_type.trans_subtype
LEFT JOIN $V_TRNS_DB.iso_ref_state_code st
    ON trans.risk_state_code=st.state
WHERE risk_state_code='TX'
        AND cast(accounting_date AS date)
    BETWEEN '${V_FROM_DATE}'
        AND '${V_TO_DATE}'" > /home/hadoop/ISO_TX_PREM/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO TX Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
