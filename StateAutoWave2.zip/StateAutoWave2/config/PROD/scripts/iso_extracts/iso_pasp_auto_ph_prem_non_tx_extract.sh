#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_pasp_auto_ph_prem_non_tx_extract.sh                      #
#                                                                             #
# Description  : Script to generate ISO file with PASP Auto Physical Damage Premkum Non-TX details 			  #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../../shell_functions/bin/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_FILE_NAME="PASP_PHYSICALDAMAGE_PREMIUM_NONTX""_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"
V_S3_PATH="${v_serving_bucket_path_iso}"'PASP/Premium/'




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating ISO Premium for Inland Marines extract"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

#frame the final query for extract
V_EXTRACT_SQL="
set hive.strict.checks.cartesian.product=false;
with ph_prem_trans as (
	select 
		ipa.transaction_key,
		ipa.cost_key,
		ipa.statistical_plan_ind_code,
		ipa.iso_transaction_type_code,
		ipa.reserve01,
		ipa.company_num,
		nvl(refcomp.alt_code, '') as company_code,
		ipa.record_type_code,
		inception_date,
		date_format(ipa.inception_date, 'MMyyyy') as inception_date_mmyyyy,
		ipa.transaction_eff_date,
		date_format(ipa.transaction_eff_date, 'MMddyyyy') as transaction_eff_date_mmddyyyy,
		ipa.transaction_exp_date,
		date_format(ipa.transaction_exp_date, 'MMddyyyy') as transaction_exp_date_mmddyyyy,
		ipa.state_code,
		nvl(refst.alt_code, '') as state_ref_code,
		ipa.territory_code,
		case when ipa.state_code = 'CT' then nvl(refter.alt_code, '') when ipa.state_code in ('PA', 'GA') then lpad(ipa.territory_code, 3, '0') end as territory_ref_code,
		ipa.zip_code,
		ipa.reserve02,
		ipa.busn_type_code,
		ipa.policy_type_code,
		ipa.reserve03,
		ipa.vehicle_motorcycle_cnt_code,
		ipa.vehicle_w_youthful_cnt_code,
		ipa.policy_operator_cnt,
		ipa.vehicle_operator_cnt,
		ipa.principal_operator_code,
		ipa.birth_date,
		ipa.gender_code,
		ipa.marital_status_code,
		ipa.vehicle_use_code,
		ipa.drive_miles_code,
		'' as drive_miles_code_extract,
		ipa.drive_days_code,
		ipa.estimated_annual_mileage,
		lpad(cast(cast(round(coalesce(ipa.estimated_annual_mileage, 0), -3) / 1000 as integer) as string), 2, '0') as estimated_annual_mileage_extract,
		ipa.persistency_month_year,
		ipa.vehicle_performance_code,
		ipa.driver_licensed_date_code,
		ipa.traffic_conviction_cnt,
		'' as traffic_conviction_cnt_extract,
		ipa.traffic_conviction_major_cnt,
		ipa.traffic_conviction_minor_cnt,
		ipa.chrgbl_atfault_accident_cnt,
		ipa.atfault_accident_bi_cnt,
		ipa.chrgbl_atflt_accdnt_pd_cnt,
		ipa.good_driver_discount_code,
		ipa.driver_traing_discount_code,
		ipa.good_student_discount_code,
		'' as good_student_discount_code_extract,
		ipa.defensive_driver_discnt_code,
		ipa.antilock_brake_discnt_code,
		ipa.multi_car_discount_code,
		'' as multi_car_discount_code_extract,
		ipa.multi_policy_code,
		ipa.rated_operator_usage_pct,
		ipa.smoker_status_code,
		ipa.rate_level_ind_code,
		ipa.point_forgiveness_code,
		ipa.daytime_lights_discount_code,
		ipa.model_year_code,
		ipa.vin,
		ipa.policy_num,
		lpad(ipa.policy_num, 20, '0') as policy_num_lpad,
		ipa.reserve04,
		ipa.reserve05,
		ipa.reserve06,
		ipa.atfault_bi_sec_addl_drv_cnt,
		ipa.atfault_pd_sec_addl_drv_cnt,
		ipa.frst_addl_drv_prncpl_oprt_cd,
		ipa.sec_addl_drv_prncpl_oprt_cd,
		ipa.iso_pasp_subline_code,
		ipa.reserve07,
		ipa.otc_deduct_code,
		ipa.reserve08,
		ipa.otc_deduct_amt,
		ipa.otc_symbol_code,
		ipa.excess_equipment_limit_code,
		ipa.collision_coverage_code,
		ipa.collision_deduct_code,
		ipa.reserve09,
		ipa.collision_deduct_amt,
		ipa.collision_sym_code,
		ipa.reserve10,
		'' as reserve10_extract,
		ipa.anti_theft_device_code,
		reftheft.alt_code as anti_theft_device_ref_code,
		ipa.state_exception_code,
		ipa.reserve11,
		'' as reserve11_extract,
		ipa.traffic_convct_opr2_majr_cnt,
		ipa.traffic_convct_opr2_minr_cnt,
		ipa.reserve12,
		ipa.atfault_bi_frst_addl_drv_cnt,
		ipa.atfault_pd_frst_addl_drv_cnt,
		ipa.frst_addl_drv_licensed_dt_cd,
		ipa.sec_addl_drv_licensd_dt_cd,
		ipa.elgbl_point_addl_drv1_code,
		ipa.elgbl_point_addl_drv2_code,
		ipa.frst_addl_drv_pnt_frgv_code,
		ipa.sec_addl_drv_pnt_frgv_code,
		ipa.reserve13,
		ipa.premium_amt,
		case 
			cast(round(cast(ipa.premium_amt as decimal(19,2)), 0) % 10 as int)
			when 0 then 
				case 
					when ipa.premium_amt < 0 then '}' 
					when ipa.premium_amt >= 0 then '0' 
				end
			when -1 then 'J'
			when -2 then 'K'
			when -3 then 'L'
			when -4 then 'M'
			when -5 then 'N'
			when -6 then 'O'
			when -7 then 'P'
			when -8 then 'Q'
			when -9 then 'R'
			else cast(round(cast(ipa.premium_amt as decimal(19,2)), 0) % 10 as int)
		end as premium_amt_sign_code,
		cast(abs(round(cast(ipa.premium_amt as decimal(19,2)), 0)) / 10 as int) as premium_amt_code,
		ipa.annual_statement_line_code,
		ipa.coverage_join_identifier,
		ipa.coverage_term_code,
		ipa.coverage_term_type_code,
		ipa.coverage_term_value_code,
		round(cast(ipa.coverage_term_value_amt as decimal(19,4))) as coverage_term_value_amt,
		ipa.age_range_code,
		ipa.driver_experience_year_cnt,
		ipa.vehicle_motorcycle_cnt_ind,
		ipa.sdip_points_num,
		ipa.accident_cnt,
		ipa.vehicle_type_code,
		ipa.vehicle_body_type_code,
		ipa.engine_size_code,
		ipa.passenger_hazard_excl_ind,
		ipa.classif_code
	from
		$V_TRNS_DB.iso_pasp_auto_ph ipa
		left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'ISO' 
			and refcomp.code_type_name ='UNDERWRITING-CO' and refcomp.alt_code_type_name = 'ISO-CO' and upper(refcomp.code) = upper(ipa.company_num)
		left join $V_EDW_EXTERNAL.ent_ref_code refst on refst.group_code = 'LGCY' 
			and refst.code_type_name = 'STATE-CD' and refst.alt_code_type_name = 'STATE-NUM' and upper(refst.code) = upper(ipa.state_code)
		left join $V_EDW_EXTERNAL.ent_ref_code refter on refter.group_code = 'ISO' 
			and refter.alt_code_type_name = 'ISO-CT-TOWN-CD' and upper(split(refter.code, '~')[1]) = upper(split(ipa.territory_code, '~')[1])
		left join $V_EDW_EXTERNAL.ent_ref_code reftheft on reftheft.group_code = 'ISO' 
			and reftheft.alt_code_type_name = 'ISO-PH-ANTITHEFT-CD' and upper(reftheft.code) = upper(ipa.anti_theft_device_code)
	where 
		ipa.iso_extract_type_name = 'PASP_PH_Premium'
		and ipa.extract_type = 'phntprem'
		and cast(ipa.accounting_date as date) between cast('${V_FROM_DATE}' as date) and cast('${V_TO_DATE}' as date)
	),
trans_classif_code_1_4_expr as (
	select 
		transaction_key, 
		cost_key, 
		policy_num, 
		state_code, 
		gender_code, 
		marital_status_code, 
		vehicle_use_code, 
		vehicle_motorcycle_cnt_code, 
		driver_traing_discount_code, 
		drive_miles_code, 
		age_range_code, 
		good_student_discount_code, 
		driver_experience_year_cnt, 
		multi_car_discount_code,
		case when state_code in ('CA', 'PA', 'NJ', 'MT', 'MI', 'NC') then state_code else 'XX' end 
		|| '~' || gender_code 
		|| '~' || marital_status_code 
		|| '~' || vehicle_use_code 
		|| '~' || vehicle_motorcycle_cnt_ind 
		|| '~' || driver_traing_discount_code 
		|| '~' || drive_miles_code 
		|| '~' || age_range_code 
		|| '~' || good_student_discount_code 
		|| '~' || coalesce(driver_experience_year_cnt, 'NA') 
		|| '~' || coalesce(multi_car_discount_code, 'NA') as classification_code_1_4
	from 
		ph_prem_trans
	where
		lower(vehicle_type_code) = 'auto' or lower(reserve11) = 'ot_auto'
),
classif_code_1_4 as (
	select
		lookup_type_code, 
		iso_code, 
		rule_order, 
		row_order, 
		rule_row_count,
		state_code, 
		exclude_state_list, 
		case when trim(state_code) in ('CA', 'PA', 'NJ', 'MT', 'MI', 'NC') then '^(' || trim(state_code) || ')' else '^[^(' || replace(trim(exclude_state_list), ':', '|') || ')]+' end as state_code_expr,
		gender_code, 
		case trim(gender_code) when 'NA' then '.*' else coalesce(trim(gender_code), '.*') end as gender_code_expr,
		marital_status_code, 
		case trim(marital_status_code) when 'NA' then '.*' else coalesce(trim(marital_status_code), '.*') end as marital_status_code_expr,
		vehicle_use_code, 
		case trim(vehicle_use_code) when 'NA' then '.*' else coalesce(replace(trim(vehicle_use_code),  ':', '|'), '.*') end as vehicle_use_code_expr,
		vehicle_motorcycle_cnt_code, 
		case trim(vehicle_motorcycle_cnt_code) when 'NA' then '.*' else coalesce(replace(trim(vehicle_motorcycle_cnt_code),  ':', '|'), '.*') end as vehicle_motorcycle_cnt_code_expr,
		driver_traing_discount_code, 
		case trim(driver_traing_discount_code) when 'NA' then '.*' else coalesce(trim(driver_traing_discount_code), '.*') end as driver_traing_discount_code_expr,
		drive_miles_code, 
		case trim(drive_miles_code) when 'NA' then '.*' else coalesce(trim(drive_miles_code), '.*') end as drive_miles_code_expr,
		age_range_code, 
		case trim(age_range_code) when 'NA' then '.*' else coalesce(replace(trim(age_range_code),  ':', '|'), '.*') end as age_range_code_expr,
		good_student_discount_code, 
		case trim(good_student_discount_code) when 'NA' then '.*' else coalesce(trim(good_student_discount_code), '.*') end as good_student_discount_code_expr,
		driver_experience_year_cnt, 
		case trim(driver_experience_year_cnt) when 'NA' then '.*' else coalesce(trim(driver_experience_year_cnt), '.*') end as driver_experience_year_cnt_expr,
		multi_car_discount_code,  
		case trim(multi_car_discount_code) when 'NA' then '.*' else coalesce(trim(multi_car_discount_code), '.*') end as multi_car_discount_code_expr
	from 
		$V_EDW_EXTERNAL.iso_pasp_rules_lookup 
	where 
		lookup_type_code = 'CLASSIF_CD_1-4'
),
lookup_classif_code_1_4_expr as (
	select 
		iso_code, 
		lookup_type_code, 
		rule_order, 
		row_order, 
		rule_row_count,
		state_code_expr || '~' 
		|| gender_code_expr || '~' 
		|| marital_status_code_expr || '~(' 
		|| vehicle_use_code_expr || ')~(' 
		|| vehicle_motorcycle_cnt_code_expr || ')~' 
		|| driver_traing_discount_code_expr || '~' 
		|| drive_miles_code_expr || '~(' 
		|| age_range_code_expr || ')~' 
		|| good_student_discount_code_expr || '~' 
		|| driver_experience_year_cnt_expr || '~' 
		|| multi_car_discount_code_expr || '$' as classification_code_1_4_expr
	from 
		classif_code_1_4
),
classif_code_1_4_iso_code_trans as (
	select
		transaction_key, 
		cost_key, 
		policy_num, 
		classification_code_1_4, 
		classification_code_1_4_expr, 
		iso_code,
		row_number() over(partition by transaction_key, cost_key order by rule_order) as rno
	from 
		trans_classif_code_1_4_expr trans 
		join lookup_classif_code_1_4_expr lkup on 1=1 
	where 
		trans.classification_code_1_4 regexp lkup.classification_code_1_4_expr
),
matched_iso_code_classif_code_1_4 as (
	select
		transaction_key, 
		cost_key, 
		policy_num, 
		classification_code_1_4, 
		classification_code_1_4_expr, 
		iso_code
	from 
		classif_code_1_4_iso_code_trans 
	where 
		rno = 1
),
trans_classif_code_5_6_expr as (
	select 
		transaction_key, 
		cost_key, 
		policy_num, 
		state_code, 
		vehicle_motorcycle_cnt_code, 
		sdip_points_num, 
		traffic_conviction_cnt, 
		accident_cnt,
		case when state_code in ('CA', 'PA', 'NJ', 'MT', 'MI', 'NC') then state_code else 'XX' end 
		|| '~' || vehicle_motorcycle_cnt_ind 
		|| '~' || coalesce(sdip_points_num, 'NA') 
		|| '~' || coalesce(traffic_conviction_cnt, 'NA') 
		|| '~' || coalesce(accident_cnt, 'NA') as classification_code_5_6
	from 
		ph_prem_trans
	where
		lower(vehicle_type_code) = 'auto' or lower(reserve11) = 'ot_auto'
),
classif_code_5_6 as (
	select
		lookup_type_code, 
		iso_code, 
		rule_order, 
		row_order, 
		rule_row_count,
		state_code, 
		exclude_state_list, 
		case when trim(state_code) in ('CA', 'PA', 'NJ', 'MT', 'MI', 'NC') then '^(' || trim(state_code) || ')' else '^[^(' || replace(trim(exclude_state_list), ':', '|') || ')]+' end as state_code_expr,
		vehicle_motorcycle_cnt_code, 
		case trim(vehicle_motorcycle_cnt_code) when 'NA' then '.*' else coalesce(replace(trim(vehicle_motorcycle_cnt_code),  ':', '|'), '.*') end as vehicle_motorcycle_cnt_code_expr,
		sdip_points_num, 
		case trim(sdip_points_num) when 'NA' then '.*' else coalesce(trim(sdip_points_num), '.*') end as sdip_points_num_expr,
		traffic_conviction_cnt, 
		case trim(traffic_conviction_cnt) when 'NA' then '.*' else coalesce(trim(traffic_conviction_cnt), '.*') end as traffic_conviction_cnt_expr,
		accident_cnt, 
		case trim(accident_cnt) when 'NA' then '.*' else coalesce(trim(accident_cnt), '.*') end as accident_cnt_expr
	from 
		$V_EDW_EXTERNAL.iso_pasp_rules_lookup 
	where 
		lookup_type_code = 'CLASSIF_CD_5-6'
		and rule_order not in (109)
),
lookup_classif_code_5_6_expr as (
	select 
		iso_code, 
		lookup_type_code, 
		rule_order, 
		row_order, 
		rule_row_count,
		state_code_expr || '~(' 
		|| vehicle_motorcycle_cnt_code_expr || ')~' 
		|| sdip_points_num_expr || '~' 
		|| traffic_conviction_cnt_expr || '~' 
		|| accident_cnt_expr || '$' as classification_code_5_6_expr
	from 
		classif_code_5_6
),
classif_code_5_6_iso_code_trans as (
	select
		transaction_key, 
		cost_key, 
		policy_num, 
		classification_code_5_6, 
		classification_code_5_6_expr, 
		iso_code,
		row_number() over(partition by transaction_key, cost_key order by rule_order) as rno
	from 
		trans_classif_code_5_6_expr trans 
		join lookup_classif_code_5_6_expr lkup on 1=1 
	where 
		trans.classification_code_5_6 regexp lkup.classification_code_5_6_expr
),
matched_iso_code_classif_code_5_6 as (
	select
		transaction_key, 
		cost_key, 
		policy_num, 
		classification_code_5_6, 
		classification_code_5_6_expr, 
		iso_code
	from 
		classif_code_5_6_iso_code_trans 
	where 
		rno = 1
),
classif_code_misc as (
	select
		iso_code, 
		lookup_type_code, 
		rule_order, 
		row_order, 
		rule_row_count, 
		state_code, 
		exclude_state_list, 
		vehicle_type_code, 
		vehicle_body_type_code, 
		age_range_code, 
		engine_size_name, 
		gender_code, 
		passenger_hazard_excl_ind,
		case when exclude_state_list not in ('NA') then '^[^(' || replace(trim(exclude_state_list), ':', '|') || ')]+' when trim(state_code) = 'NA' then '^(.*)' else '^(' || trim(state_code) || ')' end as state_code_expr,
		case trim(engine_size_name) when 'NA' then '.*' else coalesce(trim(engine_size_name), '.*') end as engine_size_name_expr,
		case trim(age_range_code) when 'NA' then '.*' else coalesce(replace(trim(age_range_code),  ':', '|'), '.*') end as age_range_code_expr,
		case trim(vehicle_type_code) when 'NA' then '.*' else coalesce(trim(vehicle_type_code), '.*') end as vehicle_type_code_expr,
		case trim(vehicle_body_type_code) when 'NA' then '.*' else coalesce(trim(vehicle_body_type_code), '.*') end as vehicle_body_type_code_expr,
		case trim(gender_code) when 'NA' then '.*' else coalesce(trim(gender_code), '.*') end as gender_code_expr,
		case trim(passenger_hazard_excl_ind) when 'NA' then '.*' else coalesce(trim(passenger_hazard_excl_ind), '.*') end as passenger_hazard_excl_ind_expr
	from 
		$V_EDW_EXTERNAL.iso_pasp_rules_lookup
	where 
		lookup_type_code = 'MISC_CLASSIF' 
		and state_code = 'NA'
),
lookup_classif_code_misc_expr as (
	select 
		iso_code, 
		lookup_type_code, 
		rule_order, 
		row_order, 
		rule_row_count,
		state_code_expr || '~' 
		|| vehicle_type_code_expr || '~' 
		|| vehicle_body_type_code_expr || '~('
		|| age_range_code_expr || ')~' 
		|| gender_code_expr || '~' 
		|| engine_size_name_expr || '~' 
		|| passenger_hazard_excl_ind_expr || '$' as classification_code_misc_expr
	from 
		classif_code_misc
),
trans_classif_code_misc_expr as (
	select 
		transaction_key, 
		cost_key, 
		policy_num, 
		state_code, 
		vehicle_type_code, 
		vehicle_body_type_code, 
		age_range_code, 
		gender_code, 
		engine_size_code, 
		passenger_hazard_excl_ind,
		case when state_code in ('PA') then state_code else 'XX' end 
		|| '~' || coalesce(vehicle_type_code, 'NA') 
		|| '~' || coalesce(vehicle_body_type_code, 'NA')
		|| '~' || age_range_code 
		|| '~' || gender_code 
		|| '~' || engine_size_code 
		|| '~' || passenger_hazard_excl_ind as classification_code_misc
	from 
		ph_prem_trans
	where
		lower(reserve11) = 'ot_auto'
),
classif_code_misc_iso_code_trans as (
	select
		transaction_key, 
		cost_key, 
		policy_num, 
		classification_code_misc, 
		classification_code_misc_expr, 
		iso_code,
		row_number() over(partition by transaction_key, cost_key order by rule_order) as rno
	from 
		trans_classif_code_misc_expr trans 
		join lookup_classif_code_misc_expr lkup on 1=1 
	where 
		trans.classification_code_misc regexp lkup.classification_code_misc_expr
),
matched_iso_code_classif_code_misc as (
	select
		transaction_key, 
		cost_key, 
		policy_num, 
		classification_code_misc, 
		classification_code_misc_expr, 
		iso_code
	from 
		classif_code_misc_iso_code_trans 
	where 
		rno = 1
),
cov_term_group_trans as (
	select 
		transaction_key, 
		policy_num, 
		cost_key,
		iso_pasp_subline_code,
		coalesce(coverage_join_identifier, 'NA') || '~' 
		|| coalesce(coverage_term_code, 'NA') || '~' 
		|| coalesce(coverage_term_type_code, 'NA') || '~' 
		|| coalesce(case when iso_pasp_subline_code = '531' then coverage_term_value_amt else coverage_term_value_code end, 'NA') || '~'
		|| case when ((iso_pasp_subline_code = '531' and state_code in ('MI', 'SC')) or (iso_pasp_subline_code = '530' and state_code in ('MD', 'VA', 'NC'))) then state_code else 'XX' end as cov_term_group_map 
	from 
		ph_prem_trans
), 
cov_term_array_trans as (
	select 
		transaction_key, 
		cost_key, 
		iso_pasp_subline_code,
		sort_array(collect_set(cov_term_group_map)) as array_cov_term 
	from 
		cov_term_group_trans 
	group by 
		transaction_key, 
		cost_key,
		iso_pasp_subline_code
), 
cov_term_trans as (
	select 
		transaction_key,
		cost_key,
		iso_pasp_subline_code,
		array_cov_term,
		size(array_cov_term) as array_cov_term_size,
		upper(concat_ws('~~', array_cov_term)) as cov_term_list 
	from 
		cov_term_array_trans
), 
cov_term_group_lookup_expr as (
	select 
		lookup_type_code,
		iso_code,
		rule_order,
		row_order,
		rule_row_count,
		state_code, 
		exclude_state_list, 
		case when lookup_type_code = 'PH-COLL-COV-CODE' then '531' else '530' end as subline_code,
		case 
			when lookup_type_code = 'PH-COLL-COV-CODE' then
				case when state_code in ('MI', 'SC') then '(' || state_code || ')' else '[^(' || replace(exclude_state_list, ':', '|') || ')]+' end 
			else
				case 
					when state_code = 'NA' and exclude_state_list = 'NA' then '.*' 
					when state_code in ('MD', 'VA', 'NC') then '(' || state_code || ')' 
					else '[^(' || replace(exclude_state_list, ':', '|') || ')]+' 
				end 
		end as state_code_expr,
		regexp_replace(regexp_replace(trim(coverage_code),'\r',''),'\n','') as coverage_code,
		trim(coverage_term_code) as coverage_term_code,
		trim(coverage_term_type_code) as coverage_term_type_code,
		trim(coverage_term_value_code) as coverage_term_value_code,
		trim(coverage_term_value_amt) as coverage_term_value_amt,
		case when lookup_type_code = 'PH-COLL-COV-CODE' then trim(coverage_term_value_amt) else trim(coverage_term_value_code) end as coverage_term_value_code_amt
	from 
		$V_EDW_EXTERNAL.iso_pasp_rules_lookup 
	where 
		lookup_type_code in ('PH-COLL-COV-CODE', 'PH-OTC-COV-CODE') and iso_code not in ('069')
), 
cov_term_group_lookup as (
	select 
		iso_code,
		rule_order,
		row_order,
		rule_row_count,
		subline_code,
		case when coverage_code = 'NA' then '.*' else coverage_code end || '~' 
		|| case when coverage_term_code = 'NA' then '.*' else coverage_term_code end || '~' 
		|| case when coverage_term_type_code = 'NA' then '.*' else coverage_term_type_code end || '~' 
		|| case when coverage_term_value_code_amt = 'NA' then '.*' else coverage_term_value_code_amt end || '~' 
		|| state_code_expr as cov_term_group_map 
	from 
		cov_term_group_lookup_expr
), 
cov_term_array_lookup as (
	select 
		iso_code,
		rule_order,
		rule_row_count,
		subline_code,
		sort_array(collect_set(cov_term_group_map)) as array_cov_term 
	from 
		cov_term_group_lookup 
	group by 
		iso_code,
		rule_order,
		rule_row_count,
		subline_code
),
cov_term_lookup as (
	select 
		iso_code,
		rule_order,
		rule_row_count,
		subline_code,
		array_cov_term,
		size(array_cov_term) as array_cov_term_size,
		upper(concat_ws('~~', array_cov_term)) as cov_term_list 
	from 
		cov_term_array_lookup
),
otc_iso_code_trans as (
	select 
		lp.array_cov_term as lookup_array_cov_term,
		t.array_cov_term as trans_array_cov_term,
		lp.iso_code,
		t.transaction_key,
		t.cost_key,
		lp.rule_row_count,
		t.cov_term_list as trans_cov_list,
		lp.cov_term_list as lookup_cov_list,
		row_number() over(partition by transaction_key, cost_key order by rule_order) as rno 
	from 
		cov_term_lookup lp 
		join cov_term_trans t on 1=1 
	where 
		t.array_cov_term_size = lp.array_cov_term_size 
		and t.iso_pasp_subline_code = lp.subline_code
		and t.cov_term_list regexp lp.cov_term_list
),
matched_iso_code_otc_cov_code as (
	select 
		lookup_array_cov_term,
		trans_array_cov_term,
		iso_code,
		transaction_key,
		cost_key,
		trans_cov_list,
		lookup_cov_list
	from 
		otc_iso_code_trans 
	where 
		rno = 1
),
ph_sym_codes as (
	select 
		iso_code, 
		model_year_code, 
		case when ocn_amt = 'NA' then 99999999999999 else cast(ocn_amt as bigint) end as ocn_amt
	from 
		$V_EDW_EXTERNAL.iso_pasp_rules_lookup 
	where 
		lookup_type_code = 'PH-SYM-CODE'
),
ph_sym_code_range as (
	select 
		coalesce(lag(ocn_amt) over(partition by model_year_code order by ocn_amt) + 1, 0) as start_ocn_amt, 
		ocn_amt as end_ocn_amt, 
		iso_code,
		model_year_code 
	from 
		ph_sym_codes
),
trans_sym_codes_split as (
	select
		transaction_key,
		cost_key,
		otc_symbol_code,
		case when instr(otc_symbol_code, '~') > 0 then 'Y' else 'N' end as is_otc_sym_exist,
		split(otc_symbol_code, '~') as otc_sym_arr,
		collision_sym_code,
		case when instr(collision_sym_code, '~') > 0 then 'Y' else 'N' end as is_coll_sym_exist,
		split(collision_sym_code, '~') as coll_sym_arr
	from
		ph_prem_trans
),
matched_iso_sym_code as (
	select
		ts.transaction_key,
		ts.cost_key,
		ts.otc_symbol_code,
		coalesce(otcsym.iso_code, case when ts.is_otc_sym_exist = 'Y' then null else ts.otc_symbol_code end) as otc_sym_iso_code,
		ts.collision_sym_code,
		coalesce(collsym.iso_code, case when ts.is_coll_sym_exist = 'Y' then null else ts.collision_sym_code end) as coll_sym_iso_code
	from
		trans_sym_codes_split ts
		left join ph_sym_code_range otcsym 
			on ts.is_otc_sym_exist = 'Y' and cast(ts.otc_sym_arr[0] as bigint) between otcsym.start_ocn_amt and otcsym.end_ocn_amt and otcsym.model_year_code = ts.otc_sym_arr[1]
		left join ph_sym_code_range collsym 
			on ts.is_coll_sym_exist = 'Y' and cast(ts.coll_sym_arr[0] as bigint) between collsym.start_ocn_amt and collsym.end_ocn_amt and collsym.model_year_code = ts.coll_sym_arr[1]
),
iso_ph_prem_non_tx_rno as (
	select 
		ppt.transaction_key,
		ppt.cost_key,
		ppt.statistical_plan_ind_code,
		ppt.iso_transaction_type_code,
		ppt.reserve01,
		ppt.company_num,
		ppt.company_code,
		ppt.record_type_code,
		ppt.inception_date,
		ppt.inception_date_mmyyyy,
		ppt.transaction_eff_date,
		ppt.transaction_eff_date_mmddyyyy,
		ppt.transaction_exp_date,
		ppt.transaction_exp_date_mmddyyyy,
		ppt.state_code,
		ppt.state_ref_code,
		ppt.territory_code,
		case when trim(ppt.state_code) = 'TX' then '050' else ppt.territory_ref_code end as territory_ref_code,
		ppt.zip_code,
		ppt.reserve02,
		ppt.busn_type_code,
		ppt.policy_type_code,
		ppt.reserve03,
		ppt.vehicle_motorcycle_cnt_code,
		ppt.vehicle_w_youthful_cnt_code,
		ppt.policy_operator_cnt,
		ppt.vehicle_operator_cnt,
		ppt.principal_operator_code,
		ppt.birth_date,
		ppt.gender_code,
		ppt.marital_status_code,
		ppt.vehicle_use_code,
		ppt.drive_miles_code,
		ppt.drive_miles_code_extract,
		ppt.drive_days_code,
		ppt.estimated_annual_mileage_extract,
		ppt.persistency_month_year,
		ppt.vehicle_performance_code,
		ppt.driver_licensed_date_code,
		ppt.traffic_conviction_cnt,
		ppt.traffic_conviction_cnt_extract,
		ppt.traffic_conviction_major_cnt,
		ppt.traffic_conviction_minor_cnt,
		ppt.chrgbl_atfault_accident_cnt,
		ppt.atfault_accident_bi_cnt,
		ppt.chrgbl_atflt_accdnt_pd_cnt,
		ppt.good_driver_discount_code,
		ppt.driver_traing_discount_code,
		ppt.good_student_discount_code,
		ppt.good_student_discount_code_extract,
		ppt.defensive_driver_discnt_code,
		ppt.antilock_brake_discnt_code,
		ppt.multi_car_discount_code,
		ppt.multi_car_discount_code_extract,
		ppt.multi_policy_code,
		ppt.rated_operator_usage_pct,
		ppt.smoker_status_code,
		ppt.rate_level_ind_code,
		ppt.point_forgiveness_code,
		ppt.daytime_lights_discount_code,
		ppt.model_year_code,
		ppt.vin,
		ppt.policy_num,
		ppt.policy_num_lpad,
		ppt.reserve04,
		ppt.reserve05,
		ppt.reserve06,
		ppt.atfault_bi_sec_addl_drv_cnt,
		ppt.atfault_pd_sec_addl_drv_cnt,
		ppt.frst_addl_drv_prncpl_oprt_cd,
		ppt.sec_addl_drv_prncpl_oprt_cd,
		ppt.iso_pasp_subline_code,
		ppt.reserve07,
		ppt.otc_deduct_code,
		ppt.reserve08,
		ppt.otc_deduct_amt,
		ppt.otc_symbol_code,
		if(isnotnull(sym.otc_sym_iso_code), lpad(sym.otc_sym_iso_code, 2, '0'), '') as otc_sym_iso_code,
		ppt.excess_equipment_limit_code,
		ppt.collision_coverage_code,
		ppt.collision_deduct_code,
		ppt.reserve09,
		ppt.collision_deduct_amt,
		ppt.collision_sym_code,
		if(isnotnull(sym.coll_sym_iso_code), lpad(sym.coll_sym_iso_code, 2, '0'), '') as coll_sym_iso_code,
		ppt.reserve10,
		ppt.reserve10_extract,
		ppt.anti_theft_device_code,
		coalesce(ppt.anti_theft_device_ref_code, ppt.reserve10) as anti_theft_device_ref_code,
		ppt.state_exception_code,
		ppt.reserve11,
		ppt.reserve11_extract,
		ppt.traffic_convct_opr2_majr_cnt,
		ppt.traffic_convct_opr2_minr_cnt,
		ppt.reserve12,
		ppt.atfault_bi_frst_addl_drv_cnt,
		ppt.atfault_pd_frst_addl_drv_cnt,
		ppt.frst_addl_drv_licensed_dt_cd,
		ppt.sec_addl_drv_licensd_dt_cd,
		ppt.elgbl_point_addl_drv1_code,
		ppt.elgbl_point_addl_drv2_code,
		ppt.frst_addl_drv_pnt_frgv_code,
		ppt.sec_addl_drv_pnt_frgv_code,
		ppt.reserve13,
		ppt.premium_amt,
		ppt.premium_amt_sign_code,
		ppt.premium_amt_code,
		ppt.annual_statement_line_code,
		cc14.classification_code_1_4,
		cc14.classification_code_1_4_expr,
		cc14.iso_code as classif_code_1_4_iso_code,
		cc56.classification_code_5_6,
		cc56.classification_code_5_6_expr,
		lpad(case when trim(ppt.state_code) not in ('CA', 'PA', 'NJ', 'MT', 'MI', 'NC') then coalesce(cc56.iso_code, '24') else cc56.iso_code end, 2, '0') as classif_code_5_6_iso_code,
		ccmisc.classification_code_misc,
		ccmisc.classification_code_misc_expr,
		ccmisc.iso_code as classif_code_misc_iso_code,
		ppt.classif_code,
		otccov.trans_cov_list,
		otccov.lookup_cov_list,
		coalesce(otccov.iso_code, '069') as otc_cov_iso_code,
		case 
			when reserve11 = 'ot_auto' then ccmisc.iso_code
			when reserve11 = 'auto' then cc14.iso_code 
			else ppt.classif_code 
		end as class_code_derived,
		row_number() over(partition by ppt.transaction_key, ppt.cost_key order by ppt.transaction_key, ppt.cost_key) as rno
	from
		ph_prem_trans ppt
		left join matched_iso_code_classif_code_1_4 cc14 on ppt.transaction_key = cc14.transaction_key and ppt.cost_key = cc14.cost_key
		left join matched_iso_code_classif_code_5_6 cc56 on ppt.transaction_key = cc56.transaction_key and ppt.cost_key = cc56.cost_key
		left join matched_iso_code_classif_code_misc ccmisc on ppt.transaction_key = ccmisc.transaction_key and ppt.cost_key = ccmisc.cost_key
		left join matched_iso_code_otc_cov_code otccov on ppt.transaction_key = otccov.transaction_key and ppt.cost_key = otccov.cost_key
		left join matched_iso_sym_code sym on ppt.transaction_key = sym.transaction_key and ppt.cost_key = sym.cost_key
),
iso_ph_prem_non_tx_layout as (
	select
		nvl(transaction_key, '') || '|' ||
		nvl(cost_key, '') || '|' ||
		nvl(company_num, '') || '|' ||
		nvl(inception_date, '') || '|' ||
		nvl(transaction_eff_date, '') || '|' ||
		nvl(transaction_exp_date, '') || '|' ||
		nvl(state_code, '') || '|' ||
		nvl(territory_code, '') || '|' ||
		nvl(classification_code_1_4, '') || '|' ||
		nvl(classification_code_1_4_expr, '') || '|' ||
		nvl(classification_code_5_6, '') || '|' ||
		nvl(classification_code_5_6_expr, '') || '|' ||
		nvl(policy_num, '') || '|' ||
		nvl(trans_cov_list, '') || '|' ||
		nvl(lookup_cov_list, '') || '|' ||
		otc_cov_iso_code || '|' ||
		nvl(otc_symbol_code, '') || '|' ||
		nvl(collision_sym_code, '') || '|' ||
		nvl(anti_theft_device_code, '') || '|' ||
		nvl(premium_amt, '') as other_cols,
		lpad(nvl(statistical_plan_ind_code, ''), 1, ' ') || 
		lpad(nvl(iso_transaction_type_code, ''), 1, ' ') || 
		lpad(nvl(reserve01, ''), 2, ' ') || 
		lpad(nvl(company_code, ''), 4, ' ') || 
		lpad(nvl(record_type_code, ''), 1, ' ') || 
		lpad(date_format(cast('${V_TO_DATE}' as date), 'MMyyyy'), 6, ' ') || 
		lpad(nvl(inception_date_mmyyyy, ''), 6, ' ') || 
		lpad(nvl(transaction_eff_date_mmddyyyy, ''), 8, ' ') || 
		lpad(nvl(transaction_exp_date_mmddyyyy, ''), 8, ' ') || 
		lpad(nvl(state_ref_code, ''), 2, ' ') || 
		lpad(nvl(territory_ref_code, ''), 3, ' ') || 
		lpad(nvl(zip_code, ''), 5, ' ') || 
		lpad(nvl(reserve02, ''), 4, ' ') || 
		lpad(nvl(busn_type_code, ''), 1, ' ') || 
		lpad(nvl(policy_type_code, ''), 2, ' ') || 
		lpad(nvl(reserve03, ''), 1, ' ') || 
		case 
		when reserve11 = 'ot_auto' then if(isnotnull(classif_code_misc_iso_code), lpad(nvl(classif_code_misc_iso_code, ''), 6, ' '), lpad(nvl(classif_code_1_4_iso_code, '') || nvl(classif_code_5_6_iso_code, ''), 6, ' '))
		when reserve11 = 'auto' then lpad(nvl(classif_code_1_4_iso_code, '') || nvl(classif_code_5_6_iso_code, ''), 6, ' ') 
		else lpad(nvl(classif_code, ''), 6, ' ') end || 
		lpad(nvl(vehicle_motorcycle_cnt_code, ''), 1, ' ') || 
		lpad(nvl(vehicle_w_youthful_cnt_code, ''), 1, '0') || 
		lpad(nvl(policy_operator_cnt, ''), 1, ' ') || 
		lpad(nvl(vehicle_operator_cnt, ''), 1, ' ') || 
		lpad(nvl(principal_operator_code, ''), 1, ' ') || 
		lpad(nvl(birth_date, ''), 8, ' ') || 
		lpad(nvl(gender_code, ''), 1, ' ') || 
		lpad(nvl(marital_status_code, ''), 1, ' ') || 
		lpad(nvl(vehicle_use_code, ''), 1, ' ') || 
		lpad(nvl(drive_miles_code_extract, ''), 2, ' ') || 
		lpad(nvl(drive_days_code, ''), 1, ' ') || 
		lpad(nvl(estimated_annual_mileage_extract, ''), 2, '0') || 
		lpad(nvl(persistency_month_year, ''), 6, ' ') || 
		lpad(nvl(vehicle_performance_code, ''), 1, ' ') || 
		lpad(nvl(driver_licensed_date_code, ''), 6, ' ') || 
		lpad(nvl(traffic_conviction_cnt_extract, ''), 2, ' ') || 
		lpad(nvl(traffic_conviction_major_cnt, ''), 2, '0') || 
		lpad(nvl(traffic_conviction_minor_cnt, ''), 2, '0') || 
		lpad(nvl(chrgbl_atfault_accident_cnt, ''), 2, ' ') || 
		lpad(nvl(atfault_accident_bi_cnt, ''), 2, '0') || 
		lpad(nvl(chrgbl_atflt_accdnt_pd_cnt, ''), 2, '0') || 
		lpad(nvl(case when state_code = 'MD' then '1' else '' end, ''), 1, ' ') || 
		lpad(nvl(case when class_code_derived like '9%' then driver_traing_discount_code else '' end, ''), 1, ' ') || 
		lpad(nvl(good_student_discount_code_extract, ''), 1, ' ') || 
		lpad(nvl(defensive_driver_discnt_code, ''), 1, ' ') || 
		lpad(nvl(antilock_brake_discnt_code, ''), 1, ' ') || 
		lpad(nvl(multi_car_discount_code_extract, ''), 1, ' ') || 
		lpad(nvl(multi_policy_code, ''), 1, ' ') || 
		lpad(nvl(rated_operator_usage_pct, ''), 1, ' ') || 
		lpad(nvl(smoker_status_code, ''), 1, ' ') || 
		lpad(nvl(rate_level_ind_code, ''), 1, ' ') || 
		lpad(nvl(point_forgiveness_code, ''), 1, ' ') || 
		lpad(nvl(daytime_lights_discount_code, ''), 1, ' ') || 
		lpad(nvl(model_year_code, ''), 4, ' ') || 
		rpad(nvl(vin, ''), 17, ' ') || 
		lpad(nvl(policy_num_lpad, ''), 20, '0') || 
		lpad(nvl(reserve04, ''), 30, ' ') || 
		lpad(nvl(reserve05, ''), 3, ' ') || 
		lpad(nvl(reserve06, ''), 1, ' ') || 
		lpad(nvl(atfault_bi_sec_addl_drv_cnt, ''), 2, ' ') || 
		lpad(nvl(atfault_pd_sec_addl_drv_cnt, ''), 2, ' ') || 
		lpad(nvl(frst_addl_drv_prncpl_oprt_cd, ''), 1, ' ') || 
		lpad(nvl(sec_addl_drv_prncpl_oprt_cd, ''), 1, ' ') || 
		lpad(nvl(iso_pasp_subline_code, ''), 3, ' ') || 
		lpad(nvl(reserve07, ''), 2, ' ') || 
		lpad(otc_cov_iso_code, 3, '0') || 
		lpad(nvl(otc_deduct_code, ''), 1, ' ') || 
		lpad(nvl(reserve08, ''), 1, ' ') || 
		lpad(nvl(otc_deduct_amt, ''), 4, ' ') || 
		lpad(nvl(case when iso_pasp_subline_code = '530' and (class_code_derived like '9%' or cast(model_year_code as integer) < 1981) then 'AA' else otc_sym_iso_code end, ''), 2, ' ') || 
		lpad(nvl(excess_equipment_limit_code, ''), 4, ' ') || 
		lpad(nvl(collision_coverage_code, ''), 3, ' ') || 
		lpad(nvl(collision_deduct_code, ''), 1, ' ') || 
		lpad(nvl(reserve09, ''), 1, ' ') || 
		lpad(nvl(collision_deduct_amt, ''), 4, ' ') || 
		lpad(nvl(case when iso_pasp_subline_code = '531' and (class_code_derived like '9%' or cast(model_year_code as integer) < 1981) then 'AA' else coll_sym_iso_code end, ''), 2, ' ') || 
		lpad(nvl(reserve10_extract, ''), 24, ' ') || 
		lpad(nvl(anti_theft_device_ref_code, ''), 1, ' ') || 	
		lpad(nvl(state_exception_code, ''), 2, ' ') || 
		lpad(nvl(reserve11_extract, ''), 2, ' ') || 
		lpad(nvl(traffic_convct_opr2_majr_cnt, ''), 2, ' ') || 
		lpad(nvl(traffic_convct_opr2_minr_cnt, ''), 2, ' ') || 
		lpad(nvl(reserve12, ''), 2, ' ') || 
		lpad(nvl(atfault_bi_frst_addl_drv_cnt, ''), 2, ' ') || 
		lpad(nvl(atfault_pd_frst_addl_drv_cnt, ''), 2, ' ') || 
		lpad(nvl(frst_addl_drv_licensed_dt_cd, ''), 6, ' ') || 
		lpad(nvl(sec_addl_drv_licensd_dt_cd, ''), 6, ' ') || 
		lpad(nvl(elgbl_point_addl_drv1_code, ''), 2, ' ') || 
		lpad(nvl(elgbl_point_addl_drv2_code, ''), 2, ' ') || 
		lpad(nvl(frst_addl_drv_pnt_frgv_code, ''), 1, ' ') || 
		lpad(nvl(sec_addl_drv_pnt_frgv_code, ''), 1, ' ') || 
		lpad(nvl(reserve13, ''), 1, ' ') || 
		lpad(nvl(premium_amt_code, '') || nvl(premium_amt_sign_code, ''), 8, '0') || 
		lpad(nvl(annual_statement_line_code, ''), 3, ' ') as layout_cols	
	from 
		iso_ph_prem_non_tx_rno
	where 
		rno = 1
)
select layout_cols from iso_ph_prem_non_tx_layout"

info "Query for file extraction: $V_EXTRACT_SQL"

#execute the query and write the output to a file
hive -S -e "${V_EXTRACT_SQL}" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO Premium for PASP Physical Damage Non-TX Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : ISO Premium for PASP Physical Damage Non-TX Extract file - ${V_FILE_NAME} generation failed !!";

fi

# info "Uploading ${V_FILE_NAME} to ${V_S3_PATH} - aws s3 cp /home/hadoop/ISO_Extracts/${V_FILE_NAME} ${V_S3_PATH}";

#copy the file from local to s3 folder
aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}"

if [ $? == 0 ]

then info "ISO Premium for PASP Physical Damage Non-TX Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO Premium for PASP Physical Damage Non-TX Extract file - ${V_FILE_NAME} upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
