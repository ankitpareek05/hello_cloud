#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_cup_loss_extract.sh                                      #
#                                                                             #
# Description  : Script to generate ISO file with CUP Loss details 			  #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_TRANS_TYPE=${TRANS_TYPE}
V_STATE_CODE=${STATE_CODE}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

info "Trans type: $V_TRANS_TYPE, State Code: $V_STATE_CODE"
if [[ -z "$V_TRANS_TYPE" ]] || [[ -z "$V_STATE_CODE" ]]
then
info "Message : The parameters (Transaction type and State code) passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_FILE_NAME="ISO_CUP_""$V_TRANS_TYPE""_""$V_STATE_CODE""_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"
V_S3_PATH="${v_serving_bucket_path_iso}"'CommercialUmbrella/Loss/'




#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_STATE_CODE}_${V_TRANS_TYPE}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_STATE_CODE}_${V_TRANS_TYPE}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating ISO CUP Loss - ${V_TRANS_TYPE} Extract file for ${V_STATE_CODE}"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi

#frame transaction type code condition dynamically and patch it in final query
if [ $V_TRANS_TYPE == 'PAIDS' ]
then
	V_TRANS_TYPE_CONDITION=" and icl.cost_category_code not in ('7', '9') "
elif [ $V_TRANS_TYPE == 'OUTS' ] 
then
	V_TRANS_TYPE_CONDITION=" and icl.cost_category_code in ('7', '9') "
fi

info " Conditions to be patched are : $V_TRANS_TYPE_CONDITION"

#frame state code condition dynamically and patch it in final query
if [ $V_STATE_CODE == 'TX' ]
then
	V_STATE_SQL="
with retention_amt_limit_ranges as (
	select 
		nvl(lag(cast(code as int)) over(order by cast(code as int)) + 1, 0) as start_retention_amt_limit, 
		cast(code as int) as end_retention_amt_limit, 
		alt_code 
	from 
		$V_EDW_EXTERNAL.ent_ref_code 
	where 
		group_code = 'ISO' 
		and alt_code_type_name = 'ISO_CUP_UMB_ATT_PNT_CODE'
),
iso_cup_loss_tx_extract as (
	select 
		refcomp.alt_code as company_num,
		case 
			when icl.cost_category_code in (7, 9) then cost_category_code 
			else 
				case 
					when upper(icl.iso_transaction_type_code) in ('PAYMENT', 'RECOVERY') and upper(icl.cost_type_code) in ('INDEMNITY') then 6
					when upper(icl.iso_transaction_type_code) in ('PAYMENT', 'RECOVERY') and upper(icl.cost_type_code) in ('EXPENSE') then 8
					else ''
				end
		end as transaction_type_code,
		cast(date_format(accounting_date, 'y') % 10 as int) as accounting_date_year_code, 
		case 
			cast(date_format(accounting_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(accounting_date, 'M'), 10) as int) 
		end as accounting_date_month_code,
		cast(date_format(inception_date, 'yy') as int) as inception_date_year_code,
		case 
			cast(date_format(inception_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(inception_date, 'M'), 10) as int) 
		end as inception_date_month_code,
		cast(date_format(loss_date, 'yy') as int) as loss_date_year_code,
		case 
			cast(date_format(loss_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(loss_date, 'M'), 10) as int) 
		end as loss_date_month_code,
		date_format(loss_date, 'dd') as loss_date_day_code,
		nvl(icl.mga_ind, '') as mga_ind,
		refstate.alt_code as risk_state_code,
		nvl(icl.territory_code, '') as territory_code,
		icl.iso_policy_type_code,
		icl.annual_statement_line_code,
		icl.iso_csp_subline_code,
		icl.iso_classification_code,
		nvl(icl.iso_state_exception_code, '') as iso_state_exception_code,
		icl.limits_id,
		nvl(icl.policy_limits_code, '') as policy_limits_code,
		icl.retention_amt,
		refretamt.start_retention_amt_limit,
		refretamt.end_retention_amt_limit,
		refretamt.alt_code as retention_amt_limit_code,
		nvl(icl.notice_of_claim_day, '') as notice_of_claim_day,
		case when icl.coverage_code in ('CUEmpBenCov', 'CUCondo_DandO_Cov') then '2' else '3' end as coverage_code,	
		nvl(icl.risk_identification_code, '') as risk_identification_code,
		nvl(icl.claims_made_year_month, '') as claims_made_year_month,
		nvl(icl.notice_of_claim_year_month, '') as notice_of_claim_year_month,
		substring(cast(loss_year_month as string), 3, 4) as loss_year_month_year_code,
		case 
			cast(substring(cast(loss_year_month as string), 3, 4) as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(substring(cast(loss_year_month as string), 3, 4), 10) as int) 
		end as loss_year_month_month_code,
		icl.terrorism_coverage_code,
		reftranstype.alt_code as iso_transaction_id_code,
		nvl(icl.rating_identification, '') as rating_identification,
		cast(icl.deduct_amt / 1000 as int) as deduct_amt_code,
		case when lower(icl.bureau_cause_of_loss_code) like '%medical%' then 41 else 40 end as bureau_cause_of_loss_code,
		icl.iso_claim_cnt,
		nvl(icl.standard_industrial_classifi, '') as standard_industrial_classifi,
		nvl(icl.exposure_ind_code, '') as exposure_ind_code,
		nvl(icl.endorsement_id_code, '') as endorsement_id_code,
		nvl(icl.exposure, '') as exposure,
		cast(icl.policy_aggregate_limit_amt / 1000 as int) as policy_aggregate_limit_amt_code,
		cast(icl.policy_occurrence_limit_amt / 1000 as int) as policy_occurrence_limit_amt_code,
		icl.loss_amt,
		case 
			cast(icl.loss_amt % 10 as int)
			when 0 then 
				case 
					when icl.loss_amt < 0 then '}' 
					when icl.loss_amt >= 0 then '{' 
				end
			when -1 then 'J'
			when -2 then 'K'
			when -3 then 'L'
			when -4 then 'M'
			when -5 then 'N'
			when -6 then 'O'
			when -7 then 'P'
			when -8 then 'Q'
			when -9 then 'R'
			when 1 then 'A'
			when 2 then 'B'
			when 3 then 'C'
			when 4 then 'D'
			when 5 then 'E'
			when 6 then 'F'
			when 7 then 'G'
			when 8 then 'H'
			when 9 then 'I'
		end as loss_amt_sign_code,
		cast(icl.loss_amt / 10 as int) as loss_amt_code,
		icl.claim_num,
		icl.exposure_num,
		icl.policy_num
	from $V_TRNS_DB.iso_cup_loss icl
	left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code = icl.company_num
	left join $V_EDW_EXTERNAL.ent_ref_code refstate on refstate.alt_code_type_name = 'STATE-NUM' and refstate.code_type_name = 'STATE-CD' and refstate.code = icl.risk_state_code
	left join retention_amt_limit_ranges refretamt on icl.retention_amt between refretamt.start_retention_amt_limit and refretamt.end_retention_amt_limit
	left join $V_EDW_EXTERNAL.ent_ref_code reftranstype ON  reftranstype.group_code = 'ISO' and reftranstype.alt_code_type_name = 'ISO_CUP_TRANS_ID' and icl.iso_transaction_id_code = reftranstype.code
	where cast(icl.accounting_date as date) between cast('${V_FROM_DATE}' as date) and cast('${V_TO_DATE}' as date) and icl.risk_state_code = 'TX'
	$V_TRANS_TYPE_CONDITION
)
select
	lpad(company_num, 4, ' ')
	|| lpad(transaction_type_code, 1, ' ')
	|| lpad(accounting_date_month_code || accounting_date_year_code, 2, ' ')
	|| lpad(inception_date_month_code || inception_date_year_code, 3, ' ')
	|| lpad(loss_date_day_code || loss_date_month_code || loss_date_year_code, 5, ' ')
	|| lpad(mga_ind, 1, ' ')
	|| lpad(risk_state_code, 2, 0)
	|| lpad(territory_code, 3, ' ')
	|| lpad(iso_policy_type_code, 2, ' ')
	|| lpad(annual_statement_line_code, 3, ' ')
	|| lpad(iso_csp_subline_code, 3, ' ')
	|| lpad(iso_classification_code, 5, ' ')
	|| lpad(iso_state_exception_code, 1, ' ')
	|| lpad(limits_id, 1, ' ')
	|| lpad(policy_limits_code, 2, ' ')
	|| lpad('', 2, ' ')
	|| retention_amt_limit_code
	|| lpad(notice_of_claim_day, 2, ' ')
	|| coverage_code
	|| lpad(risk_identification_code, 1, ' ')
	|| lpad(claims_made_year_month, 3, ' ')
	|| lpad(notice_of_claim_year_month, 3, ' ')
	|| lpad(loss_year_month_month_code || loss_year_month_year_code, 3, ' ')
	|| lpad(terrorism_coverage_code, 1, ' ')
	|| lpad(iso_transaction_id_code, 2, ' ')
	|| lpad(rating_identification, 1, ' ')
	|| lpad('', 1, ' ')
	|| lpad(deduct_amt_code, 5, 0)
	|| lpad('', 4, ' ')
	|| bureau_cause_of_loss_code
	|| iso_claim_cnt
	|| lpad(standard_industrial_classifi, 4, ' ')
	|| lpad(exposure_ind_code, 1, ' ')
	|| lpad('', 1, ' ')
	|| lpad(endorsement_id_code, 1, ' ')
	|| lpad(exposure, 4, ' ')
	|| lpad(policy_aggregate_limit_amt_code, 6, 0)
	|| lpad(policy_occurrence_limit_amt_code, 6, 0)
	|| lpad(loss_amt_code || loss_amt_sign_code, 8, 0)
	|| lpad(claim_num, 12, ' ')
	|| lpad(exposure_num, 2, ' ')
	|| lpad(policy_num, 13, ' ')
	|| lpad('', 20, ' ')
from iso_cup_loss_tx_extract"
	
else
	
	V_STATE_SQL="
with retention_amt_limit_ranges as (
	select 
		nvl(lag(cast(code as int)) over(order by cast(code as int)) + 1, 0) as start_retention_amt_limit, 
		cast(code as int) as end_retention_amt_limit, 
		alt_code 
	from 
		$V_EDW_EXTERNAL.ent_ref_code 
	where 
		group_code = 'ISO' 
		and alt_code_type_name = 'ISO_CUP_UMB_ATT_PNT_CODE'
),
iso_cup_loss_nontx_extract as (
	select 
		refcomp.alt_code as company_num,
		case 
			when icl.cost_category_code in (7, 9) then cost_category_code 
			else 
				case 
					when upper(icl.iso_transaction_type_code) in ('PAYMENT', 'RECOVERY') and upper(icl.cost_type_code) in ('INDEMNITY') then 6
					when upper(icl.iso_transaction_type_code) in ('PAYMENT', 'RECOVERY') and upper(icl.cost_type_code) in ('EXPENSE') then 8
					else ''
				end
		end as transaction_type_code,
		cast(date_format(accounting_date, 'y') % 10 as int) as accounting_date_year_code, 
		case 
			cast(date_format(accounting_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(accounting_date, 'M'), 10) as int) 
		end as accounting_date_month_code,
		cast(date_format(inception_date, 'yy') as int) as inception_date_year_code,
		case 
			cast(date_format(inception_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(inception_date, 'M'), 10) as int) 
		end as inception_date_month_code,
		cast(date_format(loss_date, 'yy') as int) as loss_date_year_code,
		case 
			cast(date_format(loss_date, 'M') as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(date_format(loss_date, 'M'), 10) as int) 
		end as loss_date_month_code,
		cast(date_format(loss_date, 'dd') as int) as loss_date_day_code,
		'M' as statistical_plan_ind,
		refstate.alt_code as risk_state_code,
		nvl(icl.territory_code, '') as territory_code,
		icl.iso_policy_type_code,
		icl.annual_statement_line_code,
		icl.iso_csp_subline_code,
		icl.iso_classification_code,
		nvl(icl.iso_state_exception_code, '') as iso_state_exception_code,
		icl.limits_id,
		nvl(icl.policy_limits_code, '') as policy_limits_code,
		icl.retention_amt,
		refretamt.start_retention_amt_limit,
		refretamt.end_retention_amt_limit,
		refretamt.alt_code as retention_amt_limit_code,
		case when icl.coverage_code in ('CUEmpBenCov', 'CUCondo_DandO_Cov') then '2' else '3' end as coverage_code,	
		nvl(icl.risk_identification_code, '') as risk_identification_code,
		nvl(icl.claims_made_year_month, '') as claims_made_year_month,
		nvl(icl.notice_of_claim_year_month, '') as notice_of_claim_year_month,
		substring(cast(loss_year_month as string), 3, 4) as loss_year_month_year_code,
		case 
			cast(substring(cast(loss_year_month as string), 3, 4) as int) 
			when 12 then '&' 
			when 11 then '-' 
			else cast(mod(substring(cast(loss_year_month as string), 3, 4), 10) as int) 
		end as loss_year_month_month_code,
		icl.terrorism_coverage_code,
		nvl(substring(icl.insur_zip_code, 1, 5), '') as insur_zip_code,
		case when lower(icl.bureau_cause_of_loss_code) like '%medical%' then 41 else 40 end as bureau_cause_of_loss_code,
		icl.iso_claim_cnt,
		nvl(icl.standard_industrial_classifi, '') as standard_industrial_classifi,
		nvl(icl.exposure_ind_code, '') as exposure_ind_code,
		nvl(icl.endorsement_id_code, '') as endorsement_id_code,
		nvl(icl.exposure, '') as exposure,
		icl.loss_amt,
		case 
			cast(icl.loss_amt % 10 as int)
			when 0 then 
				case 
					when icl.loss_amt < 0 then '}' 
					when icl.loss_amt >= 0 then '{' 
				end
			when -1 then 'J'
			when -2 then 'K'
			when -3 then 'L'
			when -4 then 'M'
			when -5 then 'N'
			when -6 then 'O'
			when -7 then 'P'
			when -8 then 'Q'
			when -9 then 'R'
			when 1 then 'A'
			when 2 then 'B'
			when 3 then 'C'
			when 4 then 'D'
			when 5 then 'E'
			when 6 then 'F'
			when 7 then 'G'
			when 8 then 'H'
			when 9 then 'I'
		end as loss_amt_sign_code,
		cast(icl.loss_amt / 10 as int) as loss_amt_code,
		icl.claim_num,
		icl.exposure_num,
		icl.policy_num
	from $V_TRNS_DB.iso_cup_loss icl
	left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code = icl.company_num
	left join $V_EDW_EXTERNAL.ent_ref_code refstate on refstate.alt_code_type_name = 'STATE-NUM' and refstate.code_type_name = 'STATE-CD' and refstate.code = icl.risk_state_code
	left join retention_amt_limit_ranges refretamt on icl.retention_amt between refretamt.start_retention_amt_limit and refretamt.end_retention_amt_limit
	where cast(icl.accounting_date as date) between cast('${V_FROM_DATE}' as date) and cast('${V_TO_DATE}' as date) and icl.risk_state_code not in ('TX')
	$V_TRANS_TYPE_CONDITION
)
select
	lpad(company_num, 4, ' ')
	|| lpad(transaction_type_code, 1, ' ')
	|| lpad(accounting_date_month_code || accounting_date_year_code, 2, ' ')
	|| lpad(inception_date_month_code || inception_date_year_code, 3, ' ')
	|| lpad(loss_date_day_code || loss_date_month_code || loss_date_year_code, 5, ' ')
	|| lpad(statistical_plan_ind, 1, ' ')
	|| lpad(risk_state_code, 2, 0)
	|| lpad(territory_code, 3, ' ')
	|| lpad(iso_policy_type_code, 2, ' ')
	|| lpad(annual_statement_line_code, 3, ' ')
	|| lpad(iso_csp_subline_code, 3, ' ')
	|| lpad(iso_classification_code, 5, ' ')
	|| lpad(iso_state_exception_code, 1, ' ')
	|| lpad(limits_id, 1, ' ')
	|| lpad(policy_limits_code, 2, ' ')
	|| lpad('', 2, ' ')
	|| retention_amt_limit_code
	|| lpad('', 2, ' ')
	|| coverage_code
	|| lpad(risk_identification_code, 1, ' ')
	|| lpad(claims_made_year_month, 3, ' ')
	|| lpad(notice_of_claim_year_month, 3, ' ')
	|| lpad(loss_year_month_month_code || loss_year_month_year_code, 3, ' ')
	|| lpad(terrorism_coverage_code, 1, ' ')
	|| lpad('', 3, ' ')
	|| lpad('', 1, ' ')
	|| lpad(insur_zip_code, 5, 0)
	|| lpad('', 4, ' ')
	|| bureau_cause_of_loss_code
	|| iso_claim_cnt
	|| lpad(standard_industrial_classifi, 4, ' ')
	|| lpad(exposure_ind_code, 1, ' ')
	|| lpad('', 1, ' ')
	|| lpad(endorsement_id_code, 1, ' ')
	|| lpad(exposure, 4, ' ')
	|| lpad('', 12, ' ')
	|| lpad(loss_amt_code || loss_amt_sign_code, 8, 0)
	|| lpad(claim_num, 12, ' ')
	|| lpad(exposure_num, 2, ' ')
	|| lpad(policy_num, 13, ' ')
	|| lpad('', 20, ' ')
from iso_cup_loss_nontx_extract"
fi

#frame the final query for extract
V_EXTRACT_SQL="set hive.mapred.mode = nonstrict;set hive.strict.checks.cartesian.product = false;${V_STATE_SQL}"

info "Query for file extraction: $V_EXTRACT_SQL"

#execute the query and write the output to a file
hive -S -e "${V_EXTRACT_SQL}" > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]

then info "ISO CUP Loss Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : ISO CUP Loss Extract file - ${V_FILE_NAME} generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

#copy the file from local to s3 folder
aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO CUP Loss Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO CUP Loss Extract file - ${V_FILE_NAME} upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
