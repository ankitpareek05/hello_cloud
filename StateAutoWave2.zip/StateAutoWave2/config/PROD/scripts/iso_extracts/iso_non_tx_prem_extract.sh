#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : iso_non_tx_prem.sh                                           #
#                                                                             #
# Description  : Script to generate ISO file from the respective source table #
#                from transformation layer                                    #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

SCRIPT_DIR='/home/hadoop/transform/scripts'
#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_DIR}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi

if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi

V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}

V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_FILE_NAME="ISO_CUP_PREMIUM_NON-TX_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"
V_S3_PATH="${v_serving_bucket_path_iso}"'CommercialUmbrella/Premium/'



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/extract_${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi


mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}" 

info "Generating ISO NON-TX Extract file"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";

info "File ${V_FILE_NAME} already exists"

fi


hive -S -e "set hive.strict.checks.cartesian.product=false;select  distinct concat(
rpad(case when ref_comp.alt_code is NULL or ref_comp.alt_code='' or trans.company_num is NULL or trans.company_num='' then ' ' else ref_comp.alt_code end,4,' '),  
rpad(case when cast(iso_transaction_type_code as string)= '' or iso_transaction_type_code is null then ' ' else cast(iso_transaction_type_code as string) end,1,' '),
rpad(case when substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) as string),6,2) ='12' then concat('&',substr(cast(accounting_date as string),4,1))
when substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) as string),6,2) ='11' then concat('-',substr(cast(accounting_date as string),4,1))
else concat(substr(cast(date_add(trunc(add_months(accounting_date,3-pmod(month(accounting_date)-1,3)),'MM'),-1) as string),7,1),substr(cast(accounting_date as string),4,1)) end,2,' '),
rpad(case
WHEN substr(cast(inception_date AS STRING),6,2) ='12' THEN
concat('&',substr(cast(inception_date AS STRING),3,2))
WHEN substr(cast(inception_date AS STRING),6,2) ='11' THEN
concat('-',substr(cast(inception_date AS STRING),3,2))
ELSE concat(substr(cast(inception_date AS STRING),7,1),substr(cast(inception_date AS STRING),3,2)) end,3,' '), 
rpad(case
WHEN substr(cast(transaction_eff_date AS STRING),6,2) ='12' THEN
concat('&',substr(cast(transaction_eff_date AS STRING),3,2))
WHEN substr(cast(transaction_eff_date AS STRING),6,2) ='11' THEN
concat('-',substr(cast(transaction_eff_date AS STRING),3,2))
ELSE concat(substr(cast(transaction_eff_date AS STRING),7,1),substr(cast(transaction_eff_date AS STRING),3,2)) end,3,' '),
rpad(case when substr(cast(transaction_exp_date as string),6,2) ='12' then concat('&',substr(cast(transaction_exp_date as string),3,2)) when substr(cast(transaction_exp_date as string),6,2) ='11' then concat('-',substr(cast(transaction_exp_date as string),3,2)) else concat(substr(cast(transaction_exp_date as string),7,1),substr(cast(transaction_exp_date as string),3,2)) end,3,' '),
lpad(case when risk_state_code='' or risk_state_code is null then ' '  WHEN st.alt_code is NULL then ' ' ELSE cast(st.alt_code AS STRING) end,2,'0'),
rpad(case when territory_code='' or territory_code is null then ' ' else territory_code end,3,' '),
rpad(case when cast(iso_policy_type_code as string) is null or cast(iso_policy_type_code as string)='' then ' ' else cast(iso_policy_type_code as string) end,2,' '),
rpad(case when cast(annual_statement_line_code as string) is null or cast(annual_statement_line_code as string)='' then ' ' else cast(annual_statement_line_code as string) end,3,' '), 
rpad(case when cast(iso_csp_subline_code as string) is null or cast(iso_csp_subline_code as string)='' then ' ' else cast(iso_csp_subline_code as string) end,3,' '),
rpad(case when cast(iso_classification_code as string) is null or cast(iso_classification_code as string)='' then ' ' else cast(iso_classification_code as string) end,5,' '), 
rpad(case when iso_state_exception_code='' then ' ' else iso_state_exception_code end,1,' '), 
rpad(case when cast(limits_ind as string) is null or cast(limits_ind as string)='' then ' ' else cast(limits_ind as string) end,1,' '), 
rpad(case 
when cast(bodily_injury_limit_amt as string)= '' or bodily_injury_limit_amt is null then ' '  
when agg_limit.alt_code is not null then agg_limit.alt_code
when limit_range.code is not null then cast(cast(limit_range.code as integer) + 1 as string)
else ' ' 
end ,
2,' '),
rpad(case when cast(property_damage_limit_amt as string)= '' or property_damage_limit_amt is null then ' '  else  property_damage_limit_amt end ,2,' '),
coalesce(case when trans.retention_amt > 10000000 then '93' else ret_amt.alt_code end,'  '),
rpad(case when cast(property_damage_deduct_code as string)='' or property_damage_deduct_code is null then ' ' else cast(property_damage_deduct_code as string) end ,2,' '),
case when coverage_code='' or coverage_code is null then ' ' else coverage_code end,
rpad(case when risk_identification_code='' or risk_identification_code is null then ' ' else risk_identification_code end,1,' '),
rpad(case when claims_made_year_month='' or claims_made_year_month is null then ' ' else claims_made_year_month end,3,' '),
'      ',
rpad(case when terrorism_coverage_code = '' or terrorism_coverage_code is null then ' ' else terrorism_coverage_code end,1,' ' ),
'   ',
' ',
rpad(case when insur_zip_code = '' or insur_zip_code is null then ' '  else  insur_zip_code end ,5,' '),
'          ',
'M',
rpad(case when exposure_ind_code='' or exposure_ind_code is null then ' ' else exposure_ind_code end,1,' '),
'   ',
rpad(case when exposure='' or exposure is null then ' ' else exposure end,7,' '),
rpad(case when rating_modifier='' or rating_modifier is null then ' ' else rating_modifier end,3,' '),
rpad(case when loss_cost_multiplier='' or loss_cost_multiplier is null then ' ' else loss_cost_multiplier end,3,' '),
rpad(case when endorsement_id_code='' or endorsement_id_code is null then ' ' else endorsement_id_code end,1,' '),
' ',
lpad(
case when bodily_injury_prem_amt < 0 then
concat(
substr(cast(bodily_injury_prem_amt as string),2,length(cast(bodily_injury_prem_amt as string))-2),
case substr(cast(bodily_injury_prem_amt as string),length(cast(bodily_injury_prem_amt as string)),length(cast(bodily_injury_prem_amt as string))+1)
when '0' then '}'
when '1' then 'J'
when '2' then 'K'
when '3' then 'L'
when '4' then 'M'
when '5' then 'N'
when '6' then 'O'
when '7' then 'P'
when '8' then 'Q'
when '9' then 'R'
end
) 
when bodily_injury_prem_amt > 0 then
concat(
substr(cast(bodily_injury_prem_amt as string),1,length(cast(bodily_injury_prem_amt as string))-1),
case substr(cast(bodily_injury_prem_amt as string),length(cast(bodily_injury_prem_amt as string)),length(cast(bodily_injury_prem_amt as string))+1)
when '0' then '{'
when '1' then 'A'
when '2' then 'B'
when '3' then 'C'
when '4' then 'D'
when '5' then 'E'
when '6' then 'F'
when '7' then 'G'
when '8' then 'H'
when '9' then 'I'
end
) 
else '00000000'
end ,8,'0'),
lpad(case when cast(property_damage_prem_amt as string)= '' or property_damage_prem_amt is null then ' ' else  cast(property_damage_prem_amt as string) end ,8,' '),
'  ',
lpad(case when cast(standard_industrial_classifi as string)= '' or standard_industrial_classifi is null then ' ' else  cast(standard_industrial_classifi as string) end ,4,' '),
rpad(case when policy_num='' or policy_num is null then ' ' else policy_num end,33,' '),
'~',trans.job_type_code
)

from $V_TRNS_DB.iso_cup_prem trans
 
LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code ref_comp ON  ref_comp.group_code='ISO' and ref_comp.alt_code_type_name='ISO-CO' and ref_comp.code=trans.company_num

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code agg_limit ON  agg_limit.group_code='ISO' and agg_limit.alt_code_type_name='ISO_CUP_LIAB_LMT_CODE' and agg_limit.code=cast(trans.bodily_injury_limit_amt AS STRING)


LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code ret_amt ON  ret_amt.group_code='ISO' and ret_amt.alt_code_type_name='ISO_CUP_UMB_ATT_PNT_CODE' and ret_amt.code=cast(trans.retention_amt AS STRING) 

LEFT JOIN $V_EDW_EXTERNAL.ent_ref_code st ON  st.alt_code_type_name='STATE-NUM' and st.code_type_name='STATE-CD' and st.code=trans.risk_state_code


LEFT JOIN
(select lim.code,lim.liab_lim as min_limit,LEAD(lim.liab_lim) over (ORDER BY cast(lim.code as integer)) AS max_limit from 
(
select alt_code as code,code as liab_lim from $V_EDW_EXTERNAL.ent_ref_code sub_limit
where  sub_limit.group_code='ISO' and sub_limit.alt_code_type_name='ISO_CUP_LIAB_LMT_CODE' order by cast(code as integer)
)lim
)limit_range
on trans.bodily_injury_limit_amt between cast(limit_range.min_limit as integer) and cast(limit_range.max_limit as integer)

where risk_state_code <> 'TX' AND cast(accounting_date AS date) BETWEEN '${V_FROM_DATE}' AND '${V_TO_DATE}'" > /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"


if [ $? == 0 ]

then info "ISO NON-TX Extract file - ${V_FILE_NAME} is generated sucessfully";

else 

info "ERROR : Extract file generation failed !!";

fi

cat /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}" | cut -d~ -f1 > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"

if [ $? == 0 ]

then rm /home/hadoop/ISO_Extracts/"TEMP_${V_FILE_NAME}"

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 


if [ $? == 0 ]

then info "ISO NON-TX Extract file - ${V_FILE_NAME} sucessfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1


###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
