#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : ISO CSP LIAB Outstanding Loss_extract.sh                                         #
#                                                                             #
# Description  : Script to generate ISO CSP LIAB Outstanding Loss file from the respective source table from transformation layer                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../../shell_functions/bin/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
V_FROM_DATE=${FROM_DATE}
V_TO_DATE=${TO_DATE}


if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi


if [[ -z "$V_FROM_DATE" ]] || [[ -z "$V_TO_DATE" ]]
then
info "Message : Extract start and end date ranges are not passed. Dynamically getting the range based on current date"
l=( 0 J F 31 A M 30 J A 30 O N 31 )
m=$(date +%m)
y=$(date +%Y)

if [ $m -ge 1 -a $m -le 3 ]; then
     s=10
         y=`expr $y - 1`
elif [ $m -ge 4 -a $m -le 6 ]; then
     s=1
elif [ $m -ge 7 -a $m -le 9 ]; then
     s=4
elif [ $m -ge 10 -a $m -le 12 ]; then
     s=7
fi

(( e = s + 2 ))

if [ $s -lt 10 ]
then
V_FROM_DATE=${y}-0${s}-01
else
V_FROM_DATE=${y}-${s}-01
fi

if [ $e -lt 10 ]
then
V_TO_DATE=${y}-0$e-${l[${e}]}
else
V_TO_DATE=${y}-$e-${l[${e}]}
fi


fi


V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}



V_CURR_QTR=$(($(($((10#$(date -d "$V_TO_DATE" +%m))) - 1)) / 3 + 1));
V_CURR_YEAR=$(echo $V_TO_DATE | cut -d"-" -f1)
V_RPT_DATE=`date -d"$V_FROM_DATE" +%Y%m%d`
V_S3_PATH="${v_serving_bucket_path}"'/CSP/'
V_DATE_PART=`echo "$V_RPT_DATE"|cut -c 3-8`
V_TIME_PART=`date +"%T"|sed 's/://g'`
V_EPOC_DATE="`date +'%Y-%m-%d'|sed 's/-//g'`"
V_FILE_NAME="ISO_PERS_IM_CSP_MISC_PAID_LOSS_LIAB_TX""_""$V_CURR_YEAR""Q""$V_CURR_QTR"".txt"



#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else   
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

mkdir -p /home/hadoop/ISO_Extracts/

info "FROM DATE - ${V_FROM_DATE} - To Date: ${V_TO_DATE}   Quarter start Date :${V_D_PART}" 

info "Generating ISO CSP Paid Loss"

info "Connecting to ${V_TRNS_DB}"

if [ -f /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" ]

then 

rm /home/hadoop/ISO_Extracts/"${V_FILE_NAME}";
 
info "File ${V_FILE_NAME} already exists"

fi


hive -S -e"
set hive.strict.checks.cartesian.product=false;
select
lpad(coalesce(refcomp.alt_code,'    '),4,' ') as company_num,
lpad(coalesce(ISO_CSP_PAIDLOSS.iso_transaction_type_code,' '),1,' ') as iso_transaction_type_code,
 lpad(coalesce(concat((case  cast(date_format(cast(ISO_CSP_PAIDLOSS.accounting_date as date), 'M') as int) when 12 then '&' when 11 then '-' else cast(mod(date_format(cast(ISO_CSP_PAIDLOSS.accounting_date as date), 'M'), 10) as int) end), cast(date_format(cast(ISO_CSP_PAIDLOSS.accounting_date as date), 'y') % 10 as int)),'  '),2,' ') as accounting_date,
 
lpad(coalesce(concat((case  cast(date_format(cast(ISO_CSP_PAIDLOSS.inception_date as date), 'M') as int) when 12 then '&' when 11 then '-' else cast(mod(date_format(cast(ISO_CSP_PAIDLOSS.inception_date as date), 'M'), 10) as int) end),cast(date_format(cast(ISO_CSP_PAIDLOSS.inception_date as date), 'yy') as int)),'   '),3,' ') as inception_date,
lpad(coalesce(concat((case  cast(date_format(cast(ISO_CSP_PAIDLOSS.Loss_Occurrence_date as date), 'M') as int) when 12 then '&' when 11 then '-' else cast(mod(date_format(cast(ISO_CSP_PAIDLOSS.Loss_Occurrence_date as date), 'M'), 10) as int) end),cast(date_format(cast(ISO_CSP_PAIDLOSS.Loss_Occurrence_date as date), 'yydd') as int)),'     '),5,' ') as Loss_Occurrence_date,
 ' ' as mga_ind,
'42' as state_code,
'   ' as reserve1,
'  ' as reserve2,
lpad(coalesce(ISO_CSP_PAIDLOSS.annual_statement_line_code,'   '),3,' ') as annual_statement_line_code,
'480' as iso_csp_subline_code,
lpad(coalesce(refclscd.alt_code,'   '),3,' ') as classif_code,
'   ' as reserve3,
'   ' as reserve4,
'  ' as form_code,
'                ' as reserve5,
lpad(coalesce((case when transaction_id in ('salvage_ext','subrogation_ext') then '55' else '99' END ),'  '),2,' ') as transaction_id, 
lpad(coalesce(ISO_CSP_PAIDLOSS.contract_bond_type_code,' '),1,' ') as contract_bond_type_code,
' ' as reserve6,
' ' as small_busn_ind,
' ' as expedited_underwriting_prgm,
'       ' as reserve7,
lpad(coalesce(reflosscd.alt_code,'  '),2,' ') as Bureau_Cause_of_Loss_code,
lpad(coalesce(case when ISO_Claim_cnt = '1' then '1' when ISO_Claim_cnt = '-1' then 'J' ELSE '0' END, ' '),1,' ') as ISO_Claim_cnt,
'                       ' as reserve8,
 lpad(coalesce(case when substr(cast(cast(ISO_CSP_PAIDLOSS.loss_amt as decimal(18,0)) as varchar(20)),1,1)='-' then concat(substr(cast(cast(ISO_CSP_PAIDLOSS.loss_amt as decimal(18,0)) as varchar(20)),2,(length(cast(cast(ISO_CSP_PAIDLOSS.loss_amt as decimal(18,0)) as varchar(20)))-2)),(case substr(cast(cast(ISO_CSP_PAIDLOSS.loss_amt as decimal(18,0)) as varchar(20)),length(cast(cast(ISO_CSP_PAIDLOSS.loss_amt as decimal(18,0)) as varchar(20))),1) when '0' then '}' when '1' then 'J' when '2' then 'K' when '3' then 'L' when '4' then 'M' when '5' then 'N' when '6' then 'O' when '7' then 'P' when '8' then 'Q' when '9' then 'R' end)) else cast(cast(ISO_CSP_PAIDLOSS.loss_amt as decimal(18,0)) as varchar(20)) end,'00000000'),8,'0') as loss_amt,
lpad(coalesce(case when length(Occurence_id) > 12 then regexp_replace(SUBSTR(Occurence_id,((length(Occurence_id)-12)+1),12),'-','0') else regexp_replace(RPAD(Occurence_id,12,' '),'-','0') END,'            '),12,' ') as Occurence_id,
lpad(coalesce(ISO_CSP_PAIDLOSS.Claim_seq_num,'  '),2,' '),
lpad(coalesce(case when length(policy_num) > 13 then SUBSTR(policy_num,((length(policy_num)-13)+1),13) else RPAD(policy_num,13,' ') END,'             '),13,' ') as policy_num ,
'                    ' as positions_for_company_use
from $V_TRNS_DB.ISO_CSP_Inland_Marine_tx ISO_CSP_PAIDLOSS
left join $V_EDW_EXTERNAL.ent_ref_code refcomp on refcomp.group_code = 'ISO' and refcomp.alt_code_type_name = 'ISO-CO' and refcomp.code_type_name='UNDERWRITING-CO' and refcomp.code = ISO_CSP_PAIDLOSS.company_num
left join $V_EDW_EXTERNAL.ent_ref_code refclscd on refclscd.alt_code_type_name='ISO-CSPLIABLTY-CLASSCD' and refclscd.code_type_name='CLASS_CD' and refclscd.group_code='ISO' and refclscd.code = ISO_CSP_PAIDLOSS.classif_code
left join $V_EDW_EXTERNAL.ent_ref_code reflosscd on reflosscd.alt_code_type_name='ISO-LOC-CD' and reflosscd.code_type_name='LOSS_CD' and reflosscd.group_code='ISO' and reflosscd.code = ISO_CSP_PAIDLOSS.Bureau_Cause_of_Loss_code
where ISO_CSP_PAIDLOSS.ISO_Claim_cnt != '99'
and ISO_CSP_PAIDLOSS.iso_extract_type_name = 'Liability-Paid-Loss'
and ISO_CSP_PAIDLOSS.extract_type = 'PAIDLOSSLIAB'
and cast(ISO_CSP_PAIDLOSS.accounting_date as date) between cast('${V_FROM_DATE}' as date) and cast('${V_TO_DATE}' as date);" | sed 's/[\t]//g' > /home/hadoop/ISO_Extracts/"${V_FILE_NAME}"
		
if [ $? == 0 ]  

then info "ISO CSP LIAB Paid Loss file - ${V_FILE_NAME} is generated successfully";

else 

info "ERROR :  ISO CSP LIAB paid Loss file generation failed !!";

fi

info "Uploading ${V_FILE_NAME} to ${V_S3_PATH}";

aws s3 cp /home/hadoop/ISO_Extracts/"${V_FILE_NAME}" "${V_S3_PATH}" 

if [ $? == 0 ]

then info "ISO CSP LIAB Paid Loss Extract file - ${V_FILE_NAME} successfully uploaded to "${V_S3_PATH}"  ";

else 

info "ERROR : ISO CSP LIAB Paid Loss Extract file upload to S3 bucket failed!!";

fi

echo "Log file path :${v_Log}" 2>&1



###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
