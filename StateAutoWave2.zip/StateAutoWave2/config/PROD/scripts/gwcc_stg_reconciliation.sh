#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : populate_curation.sh                                         #
#                                                                             #
# Description  : Script to populate the data from stage to Transformation/    #
#		 Curation Layer	                                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`
LOG_PATH="$SCRIPT_HOME/../logs"
JAR_PATH="$SCRIPT_HOME/../jars"
CONFIG_PATH="$SCRIPT_HOME/../spec_files"


info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
configfile=$CONFIG_PATH/gwcc_stg_connection.cfg
V_STG_DB=`grep -w "stg_hive_db" $configfile | cut -d"=" -f2`
echo ${V_STG_DB}
V_TRNS_DB=`grep -w "transform_hive_db" $configfile | cut -d"=" -f2`
echo ${V_TRNS_DB}
V_STG_RECON_DB=`grep -w "result_db" $configfile | cut -d"=" -f2`
echo ${V_STG_RECON_DB}
V_MAIL_ID=`grep -w "email_id" $configfile | cut -d"=" -f2`
echo ${V_MAIL_ID}

#All the path are mentioned in the Namespace properties
	# Log File Details
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${LOG_PATH}/gwcc_staging_recon_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
info "log:${v_Log}"
echo "Log file path :${v_Log}" 2>&1

. $SCRIPT_HOME/insert_load_cycle.sh GWCC STAGE 1


echo "Starting spark submit"

spark-submit --conf spark.dynamicAllocation.enabled=true  --conf spark.dynamicAllocation.maxExecutors=15 --conf spark.driver.maxResultSize=10G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode client --jars /home/hadoop/processed/jars/sqljdbc42.jar --driver-memory 3G --executor-memory 11G --executor-cores 5 --name "gwcc_staging_recon" --class staging.recon.StagingReconDriver ${JAR_PATH}/datalake_staging_recon-assembly-2.0.0.jar "GWCC" $configfile >> ${v_Log} 2>&1

echo "Starting spark submit"
info "Spark successfully completed">> ${v_Log} 
   echo "Spark successfully completed" >> ${v_Log} 


#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='CLAIM_ID_CNT' and source_system_code='GWCC' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='CLAIM_ID_CNT' and source_system_code='GWCC' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "CLAIM_ID_CNT count not matching" >> ${v_Log} 2>&1
   query_string[0]="CLAIM_ID_CNT count not matching" 
   flag_1="failed"
else
   info "CLAIM_ID_CNT count matching" >> ${v_Log} 2>&1
   flag_1="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='CLAIM_NBR_CNT' and source_system_code='GWCC' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='CLAIM_NBR_CNT' and source_system_code='GWCC' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "CLAIM_NBR_CNT count not matching" >> ${v_Log} 2>&1
   query_string[1]="CLAIM_NBR_CNT count not matching" 
   flag_2="failed"
else
   info "CLAIM_NBR_CNT count matching" >> ${v_Log} 2>&1
   flag_2="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='MTD_LOSSAMT' and source_system_code='GWCC' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='MTD_LOSSAMT' and source_system_code='GWCC' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "MTD_LOSSAMT count not matching" >> ${v_Log} 2>&1
   query_string[2]="MTD_LOSSAMT count not matching" 
   flag_3="failed"
else
   info "MTD_LOSSAMT count matching" >> ${v_Log} 2>&1
   flag_3="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='YTD_LOSSAMT' and source_system_code='GWCC' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='YTD_LOSSAMT' and source_system_code='GWCC' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "YTD_LOSSAMT count not matching" >> ${v_Log} 2>&1
   query_string[3]="YTD_LOSSAMT count not matching" 
   flag_4="failed"
else
   info "YTD_LOSSAMT count matching" >> ${v_Log} 2>&1
   flag_4="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='ALL_LOSSAMT' and source_system_code='GWCC' and source = 'GWSource')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "select metricresult from ((SELECT metricresult,etl_load_cycle_id FROM ${V_STG_RECON_DB}.stg_recon where auditentity='ALL_LOSSAMT' and source_system_code='GWCC' and source = 'DataLake')A inner join(SELECT  load_cycle_id from ${V_TRNS_DB}.vw_abc_load_cycle where source_system_code = 'GWCC' and cycle_type_code = 'STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "ALL_LOSSAMT count not matching" >> ${v_Log} 2>&1
   query_string[4]="ALL_LOSSAMT count not matching" 
   flag_5="failed"
else
   info "ALL_LOSSAMT count matching" >> ${v_Log} 2>&1
   flag_5="success"
fi
#############################################
if  ( [ $flag_1 = 'success' ] && [ $flag_2 = 'success' ] && [ $flag_3 = 'success' ] && [ $flag_4 = 'success' ] && [ $flag_5 =  'success' ] )
then
   info "Processing completed successfully" >> ${v_Log} 2>&1
. $SCRIPT_HOME/insert_load_cycle.sh GWCC STAGE 3
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for Claim staging" ${V_MAIL_ID};
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Failed" >>  ${v_Log} 2>&1
   exit 1
fi
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
