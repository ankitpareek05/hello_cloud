#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : populate_curation.sh                                         #
#                                                                             #
# Description  : Script to populate the data from stage to Transformation/    #
#		 Curation Layer	                                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

echo "Starting spark submit"

spark-submit --conf spark.dynamicAllocation.enabled=true  --conf spark.driver.maxResultSize=5G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode cluster --jars /home/hadoop/edf/jars/sqljdbc42.jar --num-executors 4 --driver-memory 5G --executor-memory 10G --executor-cores 5 --class staging.recon.claimStgRecon /home/hadoop/transform/jars/claimStgRecon-1.0-SNAPSHOT-jar-with-dependencies.jar /home/hadoop/curation/cc_stg_connection.prob >> ${v_Log} 2>&1
echo "Starting spark submit"
info "Spark successfully completed">> ${v_Log} 
   echo "Spark successfully completed" >> ${v_Log} 



##############################################################################################################################################################
CC_DUP_CHECK=`hive -S -e "SELECT *  FROM ${V_TRNS_DB}.stg_reconc where source = 'CLAIM_COUNT'"`

if [ $CC_DUP_CHECK -ne 0 ]
then
   info "CC tables have duplicates"
   query_string[0]="CC tables have duplicates" 
   flag_1="failed"
else
   info "CC tables have no duplicates" ${v_Log} 
   echo "CC tables have no duplicates" >> ${v_Log}
   flag_1="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.stg_cnt_reconc where auditentity='CLAIM_CNT'  and source_system='GWCC' and source = 'GWSource'"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.stg_cnt_reconc where auditentity='CLAIM_CNT'  and source_system='GWCC' and source = 'DataLake'"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "CLAIM_CNT count not matching"
   query_string[1]="CLAIM_CNT count not matching" 
   flag_2="failed"
else
   info "CLAIM_CNT count matching" >>  ${v_Log} 2>&1
   flag_2="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.stg_cnt_reconc where auditentity='MTD_LOSSAMT'  and source_system='GWCC' and source = 'GWSource'"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.stg_cnt_reconc where auditentity='MTD_LOSSAMT'  and source_system='GWCC' and source = 'DataLake'"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "MTD_LOSSAMT count not matching"
   query_string[2]="MTD_LOSSAMT count not matching" 
   flag_3="failed"
   status2="MTD_LOSSAMT count not matching"
else
   info "MTD_LOSSAMT count matching" >>  ${v_Log} 2>&1
   flag_3="success"
fi
#############################################
GWsrc_INFORCE_UCommercialUmbrella=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.stg_cnt_reconc where auditentity='YTD_LOSSAMT'  and source_system='GWCC' and source = 'GWSource'"`
DLsrc_INFORCE_UCommercialUmbrella=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.stg_cnt_reconc where auditentity='YTD_LOSSAMT'  and source_system='GWCC' and source = 'DataLake'"`
if [ $GWsrc_INFORCE_UCommercialUmbrella -ne $DLsrc_INFORCE_UCommercialUmbrella ]
then
   info "YTD_LOSSAMT count not matching"
   query_string[3]="YTD_LOSSAMT count not matching" 
   flag_4="failed"
   status2="YTD_LOSSAMT count not matching"
else
   info "YTD_LOSSAMT count matching" >>  ${v_Log} 2>&1
   flag_4="success"
fi
#############################################
if [ $flag_4 = 'success' ]
then
   info "Processing completed successfully" >>  ${v_Log} 2>&1
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for Claim staging" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com,shijas.km@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Failed" >>  ${v_Log} 2>&1
   exit 0
fi
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1