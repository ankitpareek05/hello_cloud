#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : populate_curation.sh                                         #
#                                                                             #
# Description  : Script to populate the data from stage to Transformation/    #
#		 Curation Layer	                                              #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`
src_claim_common=0
tgt_claim_common=0
src_exp_common=0
tgt_exp_common=0
src_ccp_common=0
tgt_ccp_common=0
src_claimtrndet_common=0
tgt_claimtrndet_common=0
src_claimtrndet_common_amnt=0
tgt_claimtrndet_common_amnt=0

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1

echo "Starting spark submit"

spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --master yarn --deploy-mode client --num-executors 6 --driver-memory 3G --executor-memory 36G --executor-cores 6 --class com.curation.Curation /home/hadoop/transform/jars/curation_retro-1.0-SNAPSHOT-jar-with-dependencies.jar -c ${YAML_PATH}/transform_gwcc_transform_reconc.yaml >> ${v_Log} 2>&1

if [ $status -ne 0 ]
    then
 		    info "spark submit failed for GWCL Transform Reconciliation">> ${v_Log} 2>&1
        echo mail -s "Spark Submit Failed for new account GWCC Transform Reconciliation" edlakerun@stateauto.com;
        info "Email Sent successfully"  >> ${v_Log} 2>&1
			  exit 1
        ### EXIT HERE due to spark submit issue!
    else
 		    info "Spark successfully completed" >> ${v_Log} 2>&1
fi

#######################################################################
CRT_UPD_TS=$(date "+%Y-%m-%d %T.%3N")
  
hive -e "INSERT INTO ${V_TRNS_DB}.transform_reconc_hist select cast('$CRT_UPD_TS' as timestamp) as extractdate,* from ${V_TRNS_DB}.transform_reconc where source ='CLAIMS';"
if [[ ${?} -eq 0 ]] ; then
info "insert is successful for the table transform_reconc_hist"
else
info "insert is failed for the table transform_reconc_hist"
fi

	

##############################################################################################################################################################

src_claim_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_claim_common' and system = 'SOURCE'"`

tgt_claim_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_claim_common' and system = 'TARGET'"`
if [ $src_claim_common = $tgt_claim_common ]
then
   info "Claim common count matching" ${v_Log} 2>&1
   query_string[0]="Claim common count matching"
   flag_1="success"
else
   info "Claim Common count not matching" >> ${v_Log} 2>&1
   query_string[0]="Claim common count not matching"  
   flag_1="failed"
fi
#############################################
src_exp_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_loss_exposure_common' and system = 'SOURCE'"`
tgt_exp_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_loss_exposure_common' and system = 'TARGET'"`
if [ $src_exp_common = $tgt_exp_common ]
then
   info "Exposure common count matching" >>  ${v_Log} 2>&1 
   query_string[1]="Exposure common count matching"
   flag_2="success"
else
   info "Exposure count not matching" >> ${v_Log} 2>&1
   query_string[1]="Exposure common count not matching" 
   flag_2="failed"   
fi
#############################################
src_ccp_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_payment' and system = 'SOURCE'"`
tgt_ccp_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_payment' and system = 'TARGET'"`
if [ $src_ccp_common = $tgt_ccp_common ]
then
   info "ccpayment count matching" >>  ${v_Log} 2>&1 
   query_string[2]="CCPayment count matching"
   flag_3="success"
else
	info "ccpayment count not matching" >> ${v_Log} 2>&1
   query_string[2]="CCPayment count not matching" 
   flag_3="failed"
fi
#############################################
src_claimtrndet_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_claim_trans_detail' and system = 'SOURCE'"`
tgt_claimtrndet_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_claim_trans_detail' and system = 'TARGET'"`
src_claimtrndet_common_amnt=`hive -S -e "SELECT tran_amount  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_claim_trans_detail' and system = 'SOURCE'"`
tgt_claimtrndet_common_amnt=`hive -S -e "SELECT tran_amount  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_claim_trans_detail' and system = 'TARGET'"`
if [ $src_claimtrndet_common != $tgt_claimtrndet_common -o $src_claimtrndet_common_amnt != $tgt_claimtrndet_common_amnt ]
then
   info "Claim trans detail count or amount not matching" >>  ${v_Log} 2>&1
   query_string[3]="Claim tran detail count or amount not matching"
   flag_4="failed"
else
   info "Claim trans detail count or amount matching" >> ${v_Log} 2>&1
   query_string[3]="Claim tran detail count or amount matching" 
   flag_4="success"   
fi
#############################################
src_res_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_exposure_reserve_eom' and system = 'SOURCE'"`
tgt_res_common=`hive -S -e "SELECT count  FROM ${V_TRNS_DB}.transform_reconc where table_nm='gwcc_exposure_reserve_eom' and system = 'TARGET'"`
if [ $src_res_common = $tgt_res_common ]
then
   info "Reserve eom count matching" >>  ${v_Log} 2>&1 
   query_string[4]="Reserve eom count matching"
   flag_5="success"
else
   info "Reserve eom count not matching" >> ${v_Log} 2>&1
   query_string[4]="Reserve eom count not matching" 
   flag_5="failed"   
fi
#############################################
if  ( [ $flag_1 == "success" ] && [ $flag_2 == 'success' ] && [ $flag_3 = 'success' ] && [ $flag_4 = 'success' ] && [ $flag_5 = 'success' ] )
then
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email Success for new account GWCC Transform Reconciliation" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log} 2>&1
   info "Processing completed successfully" >>  ${v_Log} 2>&1 
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for new account GWCC Transform Reconciliation" edlakerun@stateauto.com,kalyan.gaddipati@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log} 2>&1
   info "Processing Failed" >>  ${v_Log} 2>&1 
   exit 1
fi
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1