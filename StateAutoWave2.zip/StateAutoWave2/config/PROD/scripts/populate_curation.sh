#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : populate_curation.sh                                         #
#                                                                             #
# Description  : Script to populate the data from stage to Transformation/    #
#		 Curation Layer	                                                      #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . $SCRIPT_HOME/../modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_ACTUAL_TABLE=${V_TGT_TABLE}
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
	 # Log File Details
        mkdir -p ${v_tmp_path_serving}
        V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
        v_Log=${v_tmp_path_serving}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
        export LOGFILE=${v_Log}
        info "log:${v_Log}"
        echo "Log file path :${v_Log}" 2>&1

else
	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1
fi

#########Remove the feeder system from the hive table name####
if [ $V_LAYER_NAME == 'SERVING' ]
then
V_TABLE_OVRD=`grep -w ${V_TARGET_TABLE} ${configuration_path}/serving_table_conf.properties | cut -d"|" -f8`
V_FEED_COL=`grep -w ${V_TARGET_TABLE} ${configuration_path}/serving_table_conf.properties | cut -d"|" -f7`
else
V_TABLE_OVRD=`grep -w ${V_TARGET_TABLE} ${configuration_path}/trans_table_conf.properties | cut -d"|" -f8`
V_FEED_COL=`grep -w ${V_TARGET_TABLE} ${configuration_path}/trans_table_conf.properties | cut -d"|" -f7`
fi
info "FEEDER COLUMN NAME: ${V_FEED_COL} "
info "FEEDER SYSTEM INDICATOR: ${V_TABLE_OVRD} "
if [ "${V_TABLE_OVRD}" == 'Y' ]
then
V_HIVE_TABLE_NAME=`echo $V_TARGET_TABLE |cut -d '_' -f2-`
V_FEED_SYS_NAME=`echo $V_TARGET_TABLE |cut -d '_' -f1`
else
V_HIVE_TABLE_NAME=$V_TARGET_TABLE
fi
V_ACTUAL_TABLE_NAME=$V_TARGET_TABLE
# Echo parameters
info "TARGET_TABLE:${V_HIVE_TABLE_NAME}"
info "LAYER_NAME:${V_LAYER_NAME}"
info "HIVE TABLE _NAME:${V_HIVE_TABLE_NAME}"
#check if the transaction for the target table is already in running state

START_time="`date +"%Y-%m-%d %H:%M:%S"`"
export Start_time=$START_time

#info "Start Checking entry for running status in table ${V_TARGET_TABLE}"

#fn_check_status_curation $V_TARGET_TABLE $V_LAYER_NAME

#info "Table ${V_TARGET_TABLE} has no entry in the stats for the status RUNNING"

#INSERT ENTRY IN TO CURATION STATS TABLE AS RUNNING

#info "Start inserting an entry into stats for table ${V_TARGET_TABLE} as status RUNNING"

#fn_insert_stats_curation $V_TARGET_TABLE $V_LAYER_NAME

#info "Entry in to the stats as Running for table ${V_TARGET_TABLE} is successfully done"

#CHECK FOR THE SUCCESSFUL ENTRY IN THE STATS TABLE 

v_count=$(fn_check_success_entry_curation $V_TARGET_TABLE $V_LAYER_NAME)

if [ ${v_count} == 0 ]
then

info "Stats table has no successful entry for ${V_TARGET_TABLE}.Therefore running history load"

	if [ $V_LAYER_NAME == 'SERVING' ]
	then
	v_delta_column_value=`grep -wP ${V_TARGET_TABLE} ${configuration_path}/serving_table_conf.properties | cut -d"|" -f3`
	else
	v_delta_column_value=`grep -wP ${V_TARGET_TABLE} ${configuration_path}/trans_table_conf.properties | cut -d"|" -f3`
	fi
info "Delta Value: ${v_delta_column_value}"

else

v_delta_column_value=`hive -S -e "SELECT delta_value FROM ${V_TRNS_DB}.CURATION_STATS where layer_name='$LAYER_NAME' and table_name='$V_ACTUAL_TABLE' and status='SUCCESSFUL' order by delta_value desc limit 1"`

info "Stats table has more than one successful entry for the table: ${V_TARGET_TABLE}. Therefore fetching data from: ${v_delta_column_value}"
fi

info "Start Creating YAML File at: ${YAML_PATH}"
if [ $V_LAYER_NAME == 'SERVING' ]
then
	info "Creating YAML for serving layer"
	if [ -e "${YAML_PATH}/serving_${V_TARGET_TABLE}.yaml" ]
        then
        info "Removing the older file : ${YAML_PATH}/serving_${V_TARGET_TABLE}.yaml"
        rm ${YAML_PATH}/serving_${V_TARGET_TABLE}.yaml
        fi

        sh ${YAML_SCRIPT_PATH}/serving_create_yaml.sh ${V_TARGET_TABLE} ${YAML_PATH} ${V_GWPL_STG_DB} ${V_GWCL_STG_DB} ${V_GWCC_STG_DB} ${V_GWBC_STG_DB} ${V_LGCY_STG_DB} ${V_TRNS_DB} ${V_LGCY_SABIR} ${V_LGCY_DMACT} ${V_LGCY_GAIN} ${V_EDW_EXTERNAL} ${V_SERVING_DB} "${v_delta_column_value}" > ${YAML_PATH}/serving_${V_TARGET_TABLE}.yaml

        info "YAML file successfully created at: ${YAML_PATH}/serving_${V_TARGET_TABLE}.yaml"
else
	info "creating YAML for transformation layer"
	if [ -e "${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml" ]
	then
	info "Removing the older file : ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml"
	rm ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml
	fi

	sh ${YAML_SCRIPT_PATH}/create_yaml.sh ${V_TARGET_TABLE} ${YAML_PATH} ${V_GWPL_STG_DB} ${V_GWCL_STG_DB} ${V_GWCC_STG_DB} ${V_GWBC_STG_DB} ${V_LGCY_STG_DB} ${V_TRNS_DB} ${V_LGCY_SABIR} ${V_LGCY_DMACT} ${V_LGCY_GAIN} ${V_EDW_EXTERNAL}  "${v_delta_column_value}" "${V_TEMP_DB}" > ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml
	info "YAML file successfully created at: ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml"
fi

if [ $V_LAYER_NAME == 'SERVING' ]
then
v_temp=`grep -wo ${V_TARGET_TABLE}  ${configuration_path}/serving_spark_conf.properties`
else
v_temp=`grep -wo ${V_TARGET_TABLE}  ${configuration_path}/spark_conf.properties`
fi
if [ ${v_temp} ]
then
	if [ $V_LAYER_NAME == 'SERVING' ]
	then
	v_conf=`grep -w ${V_TARGET_TABLE} ${configuration_path}/serving_spark_conf.properties | cut -d":" -f2`
	else
	v_conf=`grep -w ${V_TARGET_TABLE} ${configuration_path}/spark_conf.properties | cut -d":" -f2`
	fi
info "Table name present in the Spark cofig properties file"
else
	if [ $V_LAYER_NAME == 'SERVING' ]
	then
	v_conf=`grep 'default' ${configuration_path}/serving_spark_conf.properties | cut -d":" -f2`
	else
	v_conf=`grep 'default' ${configuration_path}/spark_conf.properties | cut -d":" -f2`
	fi
info "Table name not found in the Spark config properties file, Therefore using the default configuration"
fi

info "Check flag for hot and cold"
if [ $V_LAYER_NAME == 'SERVING' ]
then
hot_cold_flag=`grep -w ${V_TARGET_TABLE} ${configuration_path}/serving_table_conf.properties | cut -d"|" -f5`
else
hot_cold_flag=`grep -w ${V_TARGET_TABLE} ${configuration_path}/trans_table_conf.properties | cut -d"|" -f5`
fi
info "Hot and cold Flag for $V_TARGET_TABLE: $hot_cold_flag"

####Blocking for temporary####

if [ $hot_cold_flag == 'N' ]
        then
                info "Table name is ${V_TARGET_TABLE}"
        else
		if [ $V_LAYER_NAME == 'SERVING' ]
		then
		info "Running function fn_hot_and_cold_backup_serving ${V_HIVE_TABLE_NAME} ${V_LAYER_NAME}"
                fn_hot_and_cold_backup_serving ${V_HIVE_TABLE_NAME} ${V_LAYER_NAME}
		else
                info "Running function fn_hot_and_cold_backup ${V_HIVE_TABLE_NAME} ${V_LAYER_NAME}"
               fn_hot_and_cold_backup ${V_HIVE_TABLE_NAME} ${V_LAYER_NAME}
		fi 
fi

info "Taking input from the Spark_conf.txt file: ${v_conf}"

info "Start running Spark submit"

if [ $V_LAYER_NAME == 'SERVING' ]
then
	info "Running Spark submit for serving layer"
	info "spark-submit --class com.curation.Curation --master yarn --deploy-mode cluster ${v_conf} --conf spark.dynamicAllocation.enabled=true --conf spark.sql.broadcastTimeout=600 --conf spark.sql.autoBroadcastJoinThreshold=-1 --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --name serving_${V_TARGET_TABLE} --files /home/hadoop/transform/yaml/*.yaml,/etc/spark/conf/hive-site.xml ${JAR_PATH}/datalake_transform-assembly-2.0.0.jar -c serving_${V_TARGET_TABLE}.yaml"
	cd ${YAML_PATH}	
	spark-submit --class com.curation.Curation --master yarn --deploy-mode cluster ${v_conf} --conf spark.dynamicAllocation.enabled=true --conf spark.sql.broadcastTimeout=600 --conf spark.sql.autoBroadcastJoinThreshold=-1 --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --name serving_${V_TARGET_TABLE} --files /home/hadoop/transform/yaml/*.yaml,/etc/spark/conf/hive-site.xml ${JAR_PATH}/datalake_transform-assembly-2.0.0.jar -c serving_${V_TARGET_TABLE}.yaml  >> ${v_Log} 2>&1
       
	   status=$?
        if [ $status -ne 0 ]
        then
        	if [ $hot_cold_flag == 'N' ]
                then
                        info "spark submit failed"
                        fn_check_status_and_exit_Curation "${V_TARGET_TABLE}" "${V_LAYER_NAME}" "$status" "Spark job Failed for Layer:${V_LAYER_NAME} and Table:${V_TARGET_TABLE}" "" ""
                else
                info "spark submit failed,reverting the changes for hot and cold and exit"
                fn_swap_view_serving "${V_SERVING_DB}" "${V_HIVE_TABLE_NAME}" "${V_LAYER_NAME}"
                fn_check_status_and_exit_Curation "${V_TARGET_TABLE}" "${V_LAYER_NAME}" "$status" "Spark job Failed for Layer:${V_LAYER_NAME} and Table:${V_TARGET_TABLE}" "" ""
                fi
	else
		info "Status : $status"
	fi

        info "Spark successfully completed"

	if [ $hot_cold_flag == 'N' ]
        then
                info "Table name is ${V_TARGET_TABLE}"
        else
                info "Reverting swaped view to original view"
                info "Running function fn_swap_view ${V_SERVING_DB} ${V_TARGET_TABLE} ${V_LAYER_NAME}"
                fn_swap_view_serving "${V_SERVING_DB}" "${V_HIVE_TABLE_NAME}" "${V_LAYER_NAME}"
        fi

else
	info "Running  spark submit for transformation layer"
	info "spark-submit --class com.curation.Curation --master yarn --deploy-mode cluster ${v_conf} --conf spark.dynamicAllocation.enabled=true --conf spark.sql.broadcastTimeout=600 --conf spark.sql.autoBroadcastJoinThreshold=-1 --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --name transform_${V_TARGET_TABLE} --files /home/hadoop/transform/yaml/*.yaml,/etc/spark/conf/hive-site.xml ${JAR_PATH}/datalake_transform-assembly-2.0.0.jar -c transform_${V_TARGET_TABLE}.yaml"
	cd ${YAML_PATH}
	spark-submit --class com.curation.Curation --master yarn --deploy-mode cluster ${v_conf} --conf spark.dynamicAllocation.enabled=true --conf spark.sql.broadcastTimeout=600 --conf spark.sql.autoBroadcastJoinThreshold=-1 --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --name transform_${V_TARGET_TABLE} --files /home/hadoop/transform/yaml/*.yaml,/etc/spark/conf/hive-site.xml ${JAR_PATH}/datalake_transform-assembly-2.0.0.jar -c transform_${V_TARGET_TABLE}.yaml  >> ${v_Log} 2>&1
	   
status=$?
	if [ $status -ne 0 ]
        	then
        	        info "spark submit failed"
                	fn_check_status_and_exit_Curation "${V_TARGET_TABLE}" "${V_LAYER_NAME}" "$status" "Spark job Failed for Layer:${V_LAYER_NAME} and Table:${V_TARGET_TABLE}"
	else
        	info "Status : $status"
	fi

info "Spark successfully completed"

fi

info "calculating the record count"

#Record_count=`grep "No. of records inserted in the table" ${v_Log}| cut -d"=" -f2 | tr -d '[:space:]'`
#info "Records count:${Record_count}"

if [ $V_LAYER_NAME == 'SERVING' ]
then
v_delta_column=`grep -w ${V_ACTUAL_TABLE} ${configuration_path}/serving_table_conf.properties | cut -d"|" -f2`
else
v_delta_column=`grep -w ${V_ACTUAL_TABLE} ${configuration_path}/trans_table_conf.properties | cut -d"|" -f2`
fi
info "Delta column:"${v_delta_column}

if [ ${v_delta_column} == 'NULL' ]
then
	v_hive_tnl=${hive_script_path}/max_delta_value_tnl_stats.hql
	info "Hive Script to find the record count for truncate and load target table:"${v_hive_tnl}

	if [ $V_LAYER_NAME == 'SERVING' ]
	then
	fn_run_hive_curation ${V_SERVING_DB} ${V_HIVE_TABLE_NAME} ${v_delta_column} "${v_delta_column_value}" ${v_hive_tnl} ${V_LAYER_NAME} ${V_TARGET_TABLE}
	else
	fn_run_hive_curation ${V_TRNS_DB} ${V_HIVE_TABLE_NAME} ${v_delta_column} "${v_delta_column_value}" ${v_hive_tnl} ${V_LAYER_NAME} ${V_TARGET_TABLE}
	fi
	Record_count_tmp=`echo $HIVE_OUTPUT`
        Record_count=$(echo "${Record_count_tmp}" | sed -e 's/^ *//g;s/ *$//g')
        info "Records count:${Record_count}"
	v_max_delta_value=NULL
	info "Delta value:$v_max_delta_value"

else
	if [ $V_TABLE_OVRD == 'Y' ]
        then
	v_hive_script=${hive_script_path}/feeder_max_delta_value.hql
        else
        v_hive_script=${hive_script_path}/max_delta_value.hql
        fi
	info "Hive Script to find the max delta value in target table:"${v_hive_script}
	if [ $V_LAYER_NAME == 'SERVING' ]
        then
	fn_run_hive_curation ${V_SERVING_DB} ${V_HIVE_TABLE_NAME} ${v_delta_column} "${v_delta_column_value}" ${v_hive_script} ${V_LAYER_NAME} ${V_TARGET_TABLE} ${V_FEED_COL} ${V_FEED_SYS_NAME}
	else
    if [ $V_LAYER_NAME == 'STAGING' ]
        then
        info "hive table:${V_HIVE_TABLE_NAME}, target_table:${V_TARGET_TABLE}"
        fn_run_hive_curation ${V_LGCY_STG_DB} ${V_HIVE_TABLE_NAME} ${v_delta_column} "${v_delta_column_value}" ${v_hive_script} ${V_LAYER_NAME} ${V_TARGET_TABLE} ${V_FEED_COL} ${V_FEED_SYS_NAME}  
        else 
		if [ $V_TARGET_TABLE == 'temp_iso_ca_prem' ]
		then 
		V_TEMP_DB='serving_temp'
        info "hive table:${V_HIVE_TABLE_NAME}, target_table:${V_TARGET_TABLE}" 
            fn_run_hive_curation ${V_TEMP_DB} ${V_HIVE_TABLE_NAME} ${v_delta_column} "${v_delta_column_value}" ${v_hive_script} ${V_LAYER_NAME} ${V_TARGET_TABLE} ${V_FEED_COL} ${V_FEED_SYS_NAME}
		else
		info "hive table:${V_HIVE_TABLE_NAME}, target_table:${V_TARGET_TABLE}" 
            fn_run_hive_curation ${V_TRNS_DB} ${V_HIVE_TABLE_NAME} ${v_delta_column} "${v_delta_column_value}" ${v_hive_script} ${V_LAYER_NAME} ${V_TARGET_TABLE} ${V_FEED_COL} ${V_FEED_SYS_NAME}
		fi	
    fi
fi
	v_max_delta_value=`echo $HIVE_OUTPUT | cut -d'|'  -f1`
        if [ ${v_max_delta_value} == 'NULL' ]
        then
                v_max_delta_value=$v_delta_column_value
        else
                info "v_max_delta_value is not NULL"
        fi
	info "Max delta value: ${v_max_delta_value}"

	Record_count=`echo $HIVE_OUTPUT | cut -d'|'  -f2`
	Record_count=$(echo "${Record_count}" | sed -e 's/^ *//g;s/ *$//g')
	info "Records count:${Record_count}"
fi

if [ $V_LAYER_NAME == 'SERVING' ]
then
v_driver_table_name=`grep -wP ${V_ACTUAL_TABLE} ${configuration_path}/serving_table_conf.properties | cut -d"|" -f4`
else
v_driver_table_name=`grep -wP ${V_ACTUAL_TABLE} ${configuration_path}/trans_table_conf.properties | cut -d"|" -f4`
fi

info "Source driver name: ${v_driver_table_name}"

info "Start updating the status for table ${V_ACTUAL_TABLE_NAME}  as SUCCESSFUL"

fn_update_current_status_curation $V_ACTUAL_TABLE_NAME $V_LAYER_NAME $Record_count "${v_max_delta_value}" ${v_driver_table_name} ${v_delta_column} "$v_delta_column_value" 

#info "Placing copy in curation_stats_ext"
#hive -S -e "INSERT OVERWRITE TABLE ${V_TRNS_DB}.CURATION_STATS_EXT select * from ${V_TRNS_DB}.CURATION_STATS;"

info "Updates successfuly done"

info "Processing completed successfully!!!!!" >>  ${v_Log} 2>&1

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1
