#!/bin/bash
###############################################################################
#                          Load cycle insert                                  #
# sh insert_load_cycle.sh GWPL STAGE 1                                        #
# sh insert_load_cycle.sh GWPL STAGE 3                                        #
# sh insert_load_cycle.sh GWPL STAGE 2                                        #
###############################################################################
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`
CONFIG_PATH="$SCRIPT_HOME/../spec_files"
db=`grep -w "transform_hive_db" ${CONFIG_PATH}/gwcc_stg_connection.cfg | cut -d"=" -f2`

#db='dev_mms_transform'
## Set's cut off time
cutofftime=' 23:59:59.999'
## Set as 0 if no date subtract (this isn't feeder specific here yet, but generic form)
subtractday='-1'

#source_system_code = GWPL GWCL GWBC GWCC LGCY
#cycle_type_code = STAGE TRANSFORM SERVING
#new_close = 1 or 3 (1 = In Progress, 2 = Failed, 3 = Complete)
source_system_code=$1
cycle_type_code=$2
new_close=$3

if [ ${source_system_code} == 'GWPL' ] || [ ${source_system_code} == 'GWCL' ] || [ ${source_system_code} == 'GWBC' ] || [ ${source_system_code} == 'GWCC' ] || [ ${source_system_code} == 'LGCY' ]
then
  echo ${source_system_code}
else
  echo "Invalid source system code. Acceptiable are GWPL, GWCL, GWCC, GWBC, or LGCY!"
  EXIT 1
fi

if [ ${cycle_type_code} == 'STAGE' ] || [ ${cycle_type_code} == 'TRANSFORM' ] || [ ${cycle_type_code} == 'SERVING' ]
then
  echo ${cycle_type_code}
else
  echo "Invalid cycle type code. Acceptiable are STAGE, TRANSFORM, or SERVING!"
  EXIT 1
fi

if [ ${new_close} == '1' ] || [ ${new_close} == '2' ] || [ ${new_close} == '3' ]
then
  echo ${new_close}
else
  echo "Invalid action code. Acceptable are 1, 2, or 3!"
  EXIT 1
fi

## Cleanup
## cleanup works in hive for these 2 commands
## dfs -rm -r s3://sa-l3-dev-emr-edl-transform/devmms_transform/abc_load_cycle;
## dfs -mkdir s3://sa-l3-dev-emr-edl-transform/devmms_transform/abc_load_cycle;
##
## Cycle start
## sh -x insert_load_cycle.sh "GWPL" "STAGE" "1"
## select * from abc_load_cycle; select * from vw_abc_load_cycle;
##
## Cycle set Fail
## sh -x insert_load_cycle.sh "GWPL" "STAGE" "2"
## select * from abc_load_cycle; select * from vw_abc_load_cycle;
##
## Cycle set Close
## sh -x insert_load_cycle.sh "GWPL" "STAGE" "3"
## select * from abc_load_cycle; select * from vw_abc_load_cycle;

if [ ${new_close} == '1' ]
then
  #Get next load cycle id
  MAXID=`hive -S -e "select max(load_cycle_id)+1 from ${db}.abc_load_cycle;"`
  if [ ${MAXID} == NULL ] 
  then 
    echo "Defaulted load cycle to 1"
    MAXID=1
  fi
fi

if [ ${new_close} == '1' ]
then
  echo "Check if cycle open already"
  open_check=`hive -S -e "select max(tally) from (select 1 as tally from ${db}.vw_abc_load_cycle v where v.source_system_code = '${source_system_code}' and v.cycle_type_code = '${cycle_type_code}' union all select 0 as tally) data;"`
  if [ ${open_check} == 0 ]
  then
  echo "Start inserting new entry into table"
    if [ ${cycle_type_code} == 'STAGE' ] && [ ${source_system_code} = 'GWPL' ]
    then
     # cutofftime=' 16:00:00.000'
      maxtime=`hive -S -e "select cast(max(Repl_UpdateTime) as date) CutOff from processed_gwpl.pcx_EDW_Replication_Ext"`
      echo ${maxtime} ${source_system_code}
      `hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select ${MAXID},null,null,'1900-01-01 00:00:00','${source_system_code}',cast(concat(cast(date_add(cast('${maxtime}' as date),${subtractday}) as string),'${cutofftime}') as timestamp),'${cycle_type_code}',null,current_timestamp(),1,'In Progress',null,current_timestamp();"`
    echo "Insert table successfully done"
    fi
    if [ ${cycle_type_code} == 'STAGE' ] && [ ${source_system_code} = 'GWCL' ]
    then
      #cutofftime=' 17:00:00.000'
      maxtime=`hive -S -e "select cast(max(Repl_UpdateTime) as date) CutOff from processed_gwcl.pcx_EDW_Replication_Ext"`
      echo ${maxtime} ${source_system_code}
      `hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select ${MAXID},null,null,'1900-01-01 00:00:00','${source_system_code}',cast(concat(cast(date_add(cast('${maxtime}' as date),${subtractday}) as string),'${cutofftime}') as timestamp),'${cycle_type_code}',null,current_timestamp(),1,'In Progress',null,current_timestamp();"`
    echo "Insert table successfully done"
    fi
    if [ ${cycle_type_code} == 'STAGE' ] && [ ${source_system_code} = 'GWBC' ]
    then
      #cutofftime=' 17:30:00.000'
      maxtime=`hive -S -e "select cast(max(Repl_UpdateTime) as date) CutOff from processed_gwbc.bcx_EDW_Replication_Ext"`
      echo ${maxtime} ${source_system_code}
      `hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select ${MAXID},null,null,'1900-01-01 00:00:00','${source_system_code}',cast(concat(cast(date_add(cast('${maxtime}' as date),${subtractday}) as string),'${cutofftime}') as timestamp),'${cycle_type_code}',null,current_timestamp(),1,'In Progress',null,current_timestamp();"`
    echo "Insert table successfully done"
    fi
    if [ ${cycle_type_code} == 'STAGE' ] && [ ${source_system_code} = 'GWCC' ]
    then
      #cutofftime=' 17:00:00.000'
      ## Set as 0 if no date subtract (this isn't feeder specific here yet, but generic form)
      subtractday='-1'
      maxtime=`hive -S -e "select cast(max(Repl_UpdateTime) as date) CutOff from processed_gwcc.ccx_EDW_Replication_Ext"`
      echo ${maxtime} ${source_system_code}
      `hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select ${MAXID},null,null,'1900-01-01 00:00:00','${source_system_code}',cast(concat(cast(date_add(cast('${maxtime}' as date),${subtractday}) as string),'${cutofftime}') as timestamp),'${cycle_type_code}',null,current_timestamp(),1,'In Progress',null,current_timestamp();"`
    echo "Insert table successfully done"
    fi
    if [ ${cycle_type_code} == 'STAGE' ] && [ ${source_system_code} = 'LGCY' ]
    then
      maxtime=`hive -S -e "select max(dwtimestamp) as CutOff from processed_sabir.agency) as timestamp"`
      echo ${maxtime} ${source_system_code}
      `hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select ${MAXID},null,null,'1900-01-01 00:00:00','${source_system_code}',cast('${maxtime}' as timestamp),'${cycle_type_code}',null,current_timestamp(),1,'In Progress',null,current_timestamp();"`
    echo "Insert table successfully done"
    fi
#      `hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select ${MAXID},null,null,'1900-01-01 00:00:00','${source_system_code}',cast(concat(cast(date_add(current_date(),${subtractday}) as string),'${cutofftime}') as timestamp),'${cycle_type_code}',null,current_timestamp(),1,'In Progress',null,current_timestamp();"`
#    echo "Insert table successfully done"
  else
  echo "Cycle open already thus no action taken"
  fi
fi

# if cycle is NOT open, this doesn't do anything
if [ ${new_close} == '2' ]
then
echo "Start inserting failed entry into table if applicable"
`hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select lc.load_cycle_id, lc.source_schema_name, lc.target_schema_name, lc.extract_range_start, lc.source_system_code, lc.extract_range_end, lc.cycle_type_code, lc.acquired_cycle_id, lc.cycle_start_dttm, 2 as cycle_status, 'Failed' AS cycle_status_desc, current_timestamp() as cycle_end_dttm, current_timestamp() AS cycle_as_of_dttm  from ${db}.abc_load_cycle lc join ${db}.vw_abc_load_cycle v on lc.load_cycle_id = v.load_cycle_id and lc.source_system_code = v.source_system_code and v.cycle_type_code = lc.cycle_type_code WHERE v.source_system_code = '${source_system_code}' and v.cycle_type_code = '${cycle_type_code}';"`

echo "Insert table as failed successfully done"
fi

# if cycle is NOT open, this doesn't do anything
if [ ${new_close} == '3' ]
then
echo "Start inserting complete entry into table if applicable"
`hive -S -e "INSERT INTO TABLE ${db}.abc_load_cycle select lc.load_cycle_id, lc.source_schema_name, lc.target_schema_name, lc.extract_range_start, lc.source_system_code, lc.extract_range_end, lc.cycle_type_code, lc.acquired_cycle_id, lc.cycle_start_dttm, 3 as cycle_status, 'Complete' AS cycle_status_desc, current_timestamp() as cycle_end_dttm, current_timestamp() AS cycle_as_of_dttm  from ${db}.abc_load_cycle lc join ${db}.vw_abc_load_cycle v on lc.load_cycle_id = v.load_cycle_id and lc.source_system_code = v.source_system_code and v.cycle_type_code = lc.cycle_type_code WHERE v.source_system_code = '${source_system_code}' and v.cycle_type_code = '${cycle_type_code}';"`

echo "Insert table as complete successfully done"
fi

