#!/bin/bash
echo "started shell script"
echo "Reading Parameters"
#readParameters "$@"
DATE=`date +%Y-%m-%d`
base_dir=/home/hadoop/transform
hadoop_base_dir=/home/hadoop/transform

mkdir -p $base_dir"/logs/transformation_log/"$DATE
DATE_TS=`date '+%Y-%m-%d_%H%M%S%s'`
function readParameters() {
    echo "Parsing args ..."
    for item in "$@"; do
        case $item in
        (*=*) eval $item;;
        esac
    done
    echo "Done parsing args ..!!!"
}

readParameters "$@"

V_JAR_FILE_PATH=${JAR_FILE_PATH}
V_SOURCE_PATH=${SOURCE_FILE_PATH}
V_TARGET_PATH=${DB_FILE_PATH}
V_CLASS_NAME=${CLASS_NAME}
V_SOURCE_SYSTEM=${SOURCE_SYSTEM}
V_TRANS_TYPE=${TRANS_TYPE}

source_system_name=`echo $V_CLASS_NAME | cut -d'.' -f4`;
log_file_name=`echo $V_CLASS_NAME | cut -d'.' -f5`;

logDir="$base_dir/logs/transformation_log/$DATE/${source_system_name}"

if [ ! -d $logDir ]; then mkdir $logDir; fi

log_file=$base_dir"/logs/transformation_log/"$DATE"/${source_system_name}/${log_file_name}_"$DATE_TS".log"

if [[ -z "$V_TARGET_PATH" ]]
then
V_TARGET_PATH="db_properties.csv"
fi

echo $V_JAR_FILE_PATH > $log_file
echo $V_SOURCE_PATH >> $log_file
echo $V_TARGET_PATH >> $log_file
echo $V_CLASS_NAME >> $log_file
echo ${V_SOURCE_SYSTEM} >> $log_file
echo ${V_TRANS_TYPE} >> $log_file

if [[ -z "$V_JAR_FILE_PATH" ]] || [[ -z "$V_SOURCE_PATH" ]]  || [[ -z "$V_TARGET_PATH" ]] || [[ -z "$V_CLASS_NAME" ]]
then
echo "Message : The parameter passed with the script are empty" >> $log_file
echo "Warning : Please pass the correct parameter" >> $log_file
exit 1
fi

echo "executing spark submit for..,"$log_file_name >> $log_file

spark-submit --class ${V_CLASS_NAME} \
 --master yarn --deploy-mode client \
 --conf spark.executor.extraJavaOptions=-XX:MaxPermSize=512m \
 --conf spark.sql.planner.externalSort=true --conf spark.shuffle.manager=sort \
 --conf spark.ui.port=8088 --conf spark.executor.memoryOverhead=12096  \
 --conf spark.rpc.message.maxSize=1024 --conf spark.file.transferTo=false \
 --conf spark.driver.maxResultSize=10g --conf spark.rdd.compress=true \
 --conf spark.executor.extraJavaOptions="-Dconfig.resource=spark-defaults.conf" \
 --conf spark.driver.JavaOptions="-Dspark.yarn.app.container.log.dir=/mnt/var/log/hadoop" \
 --conf spark.driver.extraJavaOptions="-Dconfig.file=spark-defaults.conf" \
 --conf spark.executor.memory=15g --conf spark.driver.memory=10g  \
 --conf spark.executor.cores=5 \
 --conf spark.dynamicAllocation.enabled=true \
 --conf spark.dynamicAllocation.maxExecutors=10 \
 --conf spark.dynamicAllocation.minExecutors=1 \
 --conf spark.executor.instances=3 \
 --conf spark.serializer=org.apache.spark.serializer.KryoSerializer  \
 --jars $base_dir/jars/mysql-connector-java-5.1.18.jar ${V_JAR_FILE_PATH} ${V_SOURCE_PATH} ${V_SOURCE_SYSTEM} ${V_TRANS_TYPE} 1>>$log_file 2>&1

status=$?
echo "Completed the script and the status is $status" >> $log_file
if [ ${status} -eq 0 ]; then
        exit 0
else
        echo "Spark job failed with error status, Please have a look at the logs in below path \n ${log_file}" >> $log_file
exit 1
fi

