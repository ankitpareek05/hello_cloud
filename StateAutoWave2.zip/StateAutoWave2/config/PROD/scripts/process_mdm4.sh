#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : process_mdm4.sh                                              #
#                                                                             #
# Description  : Script to Send Email, If MDM Exceptions happened Daily       #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################  
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}
 
###############################################################################

Run_Time=$(date +"%Y-%m-%d %H:%M:%S")
Run_Date=$(date +"%Y-%m-%d")
echo "Run_Time: " ${Run_Time}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"

## Parameters passed to py file executed from a given path thru Spark-Submit Command ##
mdm_excp_loc="s3://sa-l4-datalake-processed-secure/mdm/mdm_exceptions/" 

SRC_PATH="/home/hadoop/transform/mdm"
Target="Customer360_StepIV"
MAIL_TO=edlakerun@stateauto.com,anvarroy.siluvaimuthu@stateauto.com,praveen.kaniyamparambilprakasan@stateauto.com

## Layer Name Check for Log File Creation Path ##
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
     # Log File Details
     mkdir -p ${v_tmp_path_serving}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_serving}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
else
     # Log File Details
     mkdir -p ${v_tmp_path_curation}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_curation}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
fi

echo "Checking MDM Exceptions happened on Today's ${Run_Date} Batch...." >> ${v_Log}
$(hdfs dfs -test -d ${mdm_excp_loc}${Run_Date})

if [ $? != 0 ]
then
   echo "[INFO] From MDM Step-III, No Exceptions Occurred Today...." >> ${v_Log}
else
   echo "[INFO] From MDM Step-III, Exceptions Occurred Today...." >> ${v_Log}
   echo "Refer Today's Exception Path: ${mdm_excp_loc}${Run_Date}" >> ${v_Log}
   mdm_excp_msg="MDM Exception Occurred today ${Run_Date} in PROD for the Keys given below"
   keys=$(hdfs dfs -cat ${mdm_excp_loc}${Run_Date}/part* | grep "Customer_Key" | cut -d "," -f 1 | cut -c 2-)
   path_ref_msg="Please refer S3 Path ${mdm_excp_loc}${Run_Date} for more info"
   echo -e "${mdm_excp_msg} \n ${keys} \n ${path_ref_msg}" | mail -s "Production: MDM Exception Occurred in Today's Load" ${MAIL_TO}
   echo "Exception e-mail sent Successfully" >> ${v_Log}
fi  

echo "[INFO] Script Ends Here...." >> ${v_Log}

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1            
