#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : process_mdm_lgcy1.sh (LGCY_V6_Cont1.py)                      #
#                                                                             #
# Description  : Read LGCY Source Data and Write LGCY Grouped Data to S3      #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################

Run_Time=$(date +"%Y-%m-%d %H:%M:%S")
Run_Date=$(date +"%Y-%m-%d")
Run_Month=$(date +"%Y-%m")
echo "Run_Time: " ${Run_Time}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"

## Parameters passed to py file executed from a given path thru Spark-Submit Command ##
v6_secr_data="processed_secured_v6pif" 
dmact_data="processed_dmact" 
v6_data="processed_v6pif"
pinfo53k="V6M_02_PINFO53K"
amlob="ref_am_line_of_busienss"
pifaddr="V6M_PIF_Addresses"
commnt5k="V6M_03_COMMNT5K"
driver5k="V6M_25_DRIVER5K"
desc53k="V6M_12_DESC53K"
prev_yyyymm=201805
curr_yyyymm=$(date +"%Y%m")

muserid="svc_partyMDM"
mpassword="d0lsbE1BdFRHM3RBbmYzNTA="
mhost="l4-mdm-a.ce3vfbdrlipy.us-east-1.docdb.amazonaws.com"
mport="27017"
mprop1="ssl=true"
mprop2="ssl_ca_certs=/home/hadoop/transform/mdm/rds-combined-ca-bundle.pem"
mprop3="replicaSet=rs0"
mprop4="readPreference=secondaryPreferred"

mdatabase="partyMDM"
mcustomer="Customer360"
mstats="transform_mdm_stats"

lgcy_grp_data_loc="s3://sa-l4-datalake-processed-secure/mdm_lgcy/lgcy_group/"
lgcy_apc_data_loc="s3://sa-l4-datalake-processed-secure/mdm_lgcy/lgcy_apc/"

SRC_PATH="/home/hadoop/transform/mdm"
Target="LGCY_Customer360_StepI"

## Layer Name Check for Log File Creation Path ##
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
     # Log File Details
     mkdir -p ${v_tmp_path_serving}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_serving}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
else
     # Log File Details
     mkdir -p ${v_tmp_path_curation}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_curation}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
fi

echo "In-case of an error in Step-I, Deleting Today's Incomplete Step-I Output Folders for Re-Run" >> ${v_Log}
hdfs dfs -rm -r ${lgcy_grp_data_loc}${curr_yyyymm}/
hdfs dfs -rm -r ${lgcy_apc_data_loc}${curr_yyyymm}/

echo "Spark Submit to Read and Transform LGCY Customer Data and Write LGCY Grouped Customer Data to S3" >> ${v_Log}
spark-submit --conf spark.dynamicAllocation.enabled=true --master yarn --deploy-mode client --num-executors 17 --driver-memory 3G --executor-memory 51G --executor-cores 16 ${SRC_PATH}/LGCY_V6_Cont1.py ${v6_secr_data} ${dmact_data} ${v6_data} ${pinfo53k} ${amlob} ${pifaddr} ${commnt5k} ${driver5k} ${desc53k} ${prev_yyyymm} ${curr_yyyymm} ${muserid} ${mpassword} ${mhost} ${mport} ${mprop1} ${mprop2} ${mprop3} ${mprop4} ${mdatabase} ${mcustomer} ${mstats} ${lgcy_grp_data_loc} ${lgcy_apc_data_loc} >> ${v_Log} 2>&1
  
if [ $? == 0 ]
then
   csv_sucs_msg="MDM Write LGCY Grouped Customer Data to S3 - Completed for ${Run_Month}" 
   echo -e "${csv_sucs_msg}" >> ${v_Log}
   info "MDM Step-I Completed and Email Sent successfully"  >> ${v_Log} 
else
   csv_fail_msg="MDM Write LGCY Grouped Customer Data to S3 - Failed for ${Run_Month}"
   echo "${csv_fail_msg}" >> ${v_Log}
   info "MDM Step-I Failed and Email Sent"  >> ${v_Log}
   exit 1   
fi
echo "[INFO] Script Ends Here...." >> ${v_Log}

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1             
