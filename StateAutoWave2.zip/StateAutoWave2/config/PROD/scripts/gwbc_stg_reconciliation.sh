#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : gwbc_stg_reconciliation.sh                                   #
#                                                                             #
# Description  : Script to reconcile gwbc source with staging                 #
#                Curation Layer                                                       #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################

if [ $# -eq 0 ]
  then
    echo "No arguments supplied. Pass Source_system_code" 
fi

#propfile=$1
V_TRNS_DB=$1

if [ $# -eq 0 ]
   then
     V_TRNS_DB="transformed"
fi
base_dir=/home/hadoop/transform
SCRIPT_HOME=$base_dir/scripts
JAR_PATH=$base_dir/jars
CONFIG_PATH=$base_dir/spec_files
LOG_DIR=$base_dir/logs

        # Log File Details
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${LOG_DIR}/gwbc_staging_recon_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
info "log:${v_Log}"
echo "Log file path :${v_Log}" 2>&1

. $SCRIPT_HOME/insert_load_cycle.sh GWBC STAGE 1 >>  ${v_Log} 2>&1

echo "Starting spark submit"

#spark-submit --conf spark.dynamicAllocation.enabled=true --conf spark.yarn.blacklist.executor.launch.blacklisting.enabled=true --conf spark.driver.maxResultSize=5G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode client --num-executors 4 --driver-memory 5G --executor-memory 36G --executor-cores 4 --class com.curation.Curation /home/hadoop/curation/stgRecon-1.0-SNAPSHOT-jar-with-dependencies.jar -c ${YAML_PATH}/transform_${V_TARGET_TABLE}.yaml >> ${v_Log} 2>&1

spark-submit --conf spark.dynamicAllocation.enabled=true  --conf spark.driver.maxResultSize=5G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode client --jars /home/hadoop/processed/jars/sqljdbc42.jar --driver-memory 5G --executor-memory 20G --executor-cores 5 --name "gwbc_staging_recon" --class staging.recon.StagingReconDriver ${JAR_PATH}/datalake_staging_recon-assembly-2.0.0.jar "GWBC" ${CONFIG_PATH}/gwbc_stg_connection.cfg >> ${v_Log} 2>&1
echo "Starting spark submit"
status=$?

##############################################################################################################################################################
#`hive -S -e "INSERT INTO TABLE edf_transform.abc_load_cycle(load_cycle_id,source_schema_name,target_schema_name,extract_range_start,source_system_code,extract_range_end,cycle_type_code,acquired_cycle_id,cycle_start_dttm,cycle_status,cycle_status_desc,cycle_end_dttm,restart_ind) VALUES (1,"uat_l31_staging","dev_l39_transform","1900-01-01 00:00:00","GWBC","2019-11-01 23:59:59.999","TRANSFORM",NULL,NULL,1,"In Progress",NULL,NULL)"`

##############################################################################################################################################################

GWsrc_TOTAL_BILL_INV_ITM_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_INV_ITM_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_INV_ITM_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_INV_ITM_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_INV_ITM_CNT -ne $DLsrc_TOTAL_BILL_INV_ITM_CNT ]
then
   info "TOTAL_BILL_INV_ITM_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[0]="TOTAL_BILL_INV_ITM_CNT count not matching"
   flag_1="failed"
else
   info "TOTAL_BILL_INV_ITM_CNT count matching" >>  ${v_Log} 2>&1
   flag_1="success"
fi
#############################################
GWsrc_TOTAL_BILL_INV_ITM_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_INV_ITM_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_INV_ITM_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_INV_ITM_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_INV_ITM_AMT -ne $DLsrc_TOTAL_BILL_INV_ITM_AMT ]
then
   info "TOTAL_BILL_INV_ITM_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[1]="TOTAL_BILL_INV_ITM_AMT count not matching"
   flag_2="failed"
else
   info "TOTAL_BILL_INV_ITM_AMT count matching" >>  ${v_Log} 2>&1
   flag_2="success"
fi
#############################################
GWsrc_TOTAL_BILL_CHRG_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_CHRG_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_CHRG_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_CHRG_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_CHRG_CNT -ne $DLsrc_TOTAL_BILL_CHRG_CNT ]
then
   info "TOTAL_BILL_CHRG_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[2]="TOTAL_BILL_CHRG_CNT count not matching"
   flag_3="failed"
else
   info "TOTAL_BILL_CHRG_CNT count matching" >>  ${v_Log} 2>&1
   flag_3="success"
fi
#############################################
GWsrc_TOTAL_BILL_CHRG_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_CHRG_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_CHRG_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_CHRG_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_CHRG_AMT -ne $DLsrc_TOTAL_BILL_CHRG_AMT ]
then
   info "TOTAL_BILL_CHRG_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[]="TOTAL_BILL_CHRG_AMT count not matching"
   flag_4="failed"
else
   info "TOTAL_BILL_CHRG_AMT count matching" >>  ${v_Log} 2>&1
   flag_4="success"
fi
#############################################
GWsrc_TOTAL_BILL_DIST_ITM_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_DIST_ITM_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_DIST_ITM_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_DIST_ITM_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_DIST_ITM_CNT -ne $DLsrc_TOTAL_BILL_DIST_ITM_CNT ]
then
   info "TOTAL_BILL_DIST_ITM_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[4]="TOTAL_BILL_DIST_ITM_CNT count not matching"
   flag_5="failed"
else
   info "TOTAL_BILL_DIST_ITM_CNT count matching" >>  ${v_Log} 2>&1
   flag_5="success"
fi
#############################################
GWsrc_TOTAL_GROSS_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_GROSS_APPLY_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_GROSS_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_GROSS_APPLY_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_GROSS_APPLY_AMT-ne $DLsrc_TOTAL_GROSS_APPLY_AMT ]
then
   info "TOTAL_GROSS_APPLY_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[5]="TOTAL_GROSS_APPLY_AMT count not matching"
   flag_6="failed"
else
   info "TOTAL_GROSS_APPLY_AMT count matching" >>  ${v_Log} 2>&1
   flag_6="success"
fi
#############################################
GWsrc_TOTAL_BILL_DIST_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_DIST_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_DIST_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_DIST_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_DIST_CNT -ne $DLsrc_TOTAL_BILL_DIST_CNT ]
then
   info "TOTAL_BILL_DIST_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[6]="TOTAL_BILL_DIST_CNT count not matching"
   flag_7="failed"
else
   info "TOTAL_BILL_DIST_CNT count matching" >>  ${v_Log} 2>&1
   flag_7="success"
fi
#############################################
GWsrc_TOTAL_BILL_DIST_WO_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_DIST_WO_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_DIST_WO_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_DIST_WO_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_DIST_WO_AMT -ne $DLsrc_TOTAL_BILL_DIST_WO_AMT ]
then
   info "TOTAL_BILL_DIST_WO_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[7]="TOTAL_BILL_DIST_WO_AMT count not matching"
   flag_8="failed"
else
   info "TOTAL_BILL_DIST_WO_AMT count matching" >>  ${v_Log} 2>&1
   flag_8="success"
fi
#############################################
GWsrc_TOTAL_BILL_WO_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_WO_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_WO_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_WO_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_WO_CNT -ne $DLsrc_TOTAL_BILL_WO_CNT ]
then
   info "TOTAL_BILL_WO_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[8]="TOTAL_BILL_WO_CNT count not matching"
   flag_9="failed"
else
   info "TOTAL_BILL_WO_CNT count matching" >>  ${v_Log} 2>&1
   flag_9="success"
fi
#############################################
GWsrc_TOTAL_REVERSED_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_REVERSED_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_REVERSED_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_REVERSED_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_REVERSED_AMT -ne $DLsrc_TOTAL_REVERSED_AMT ]
then
   info "TOTAL_REVERSED_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[9]="TOTAL_REVERSED_AMT count not matching"
   flag_10="failed"
else
   info "TOTAL_REVERSED_AMT count matching" >>  ${v_Log} 2>&1
   flag_10="success"
fi
#############################################
GWsrc_TOTAL_WO_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_WO_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_WO_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_WO_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_WO_AMT -ne $DLsrc_TOTAL_WO_AMT ]
then
   info "TOTAL_WO_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[10]="TOTAL_WO_AMT count not matching"
   flag_11="failed"
else
   info "TOTAL_WO_AMT count matching" >>  ${v_Log} 2>&1
   flag_11="success"
fi
#############################################
GWsrc_TOTAL_COMM_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_COMM_APPLY_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_COMM_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_COMM_APPLY_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_COMM_APPLY_AMT -ne $DLsrc_TOTAL_COMM_APPLY_AMT ]
then
   info "TOTAL_COMM_APPLY_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[11]="TOTAL_COMM_APPLY_AMT count not matching"
   flag_12="failed"
else
   info "TOTAL_COMM_APPLY_AMT count matching" >>  ${v_Log} 2>&1
   flag_12="success"
fi
#############################################
GWsrc_MTD_BILL_CHRG_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_CHRG_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_CHRG_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_CHRG_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_CHRG_TRANS_AMT -ne $DLsrc_MTD_BILL_CHRG_TRANS_AMT ]
then
   info "MTD_BILL_CHRG_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[12]="MTD_BILL_CHRG_TRANS_AMT count not matching"
   flag_13="failed"
else
   info "MTD_BILL_CHRG_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_13="success"
fi
#############################################
GWsrc_YTD_BILL_CHRG_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_CHRG_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_CHRG_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_CHRG_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_CHRG_TRANS_AMT -ne $DLsrc_YTD_BILL_CHRG_TRANS_AMT ]
then
   info "YTD_BILL_CHRG_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[13]="YTD_BILL_CHRG_TRANS_AMT count not matching"
   flag_14="failed"
else
   info "YTD_BILL_CHRG_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_14="success"
fi
#############################################
GWsrc_TOTAL_BILL_NWO_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_NWO_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_NWO_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_NWO_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_NWO_CNT -ne $DLsrc_TOTAL_BILL_NWO_CNT ]
then
   info "TOTAL_BILL_NWO_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[14]="TOTAL_BILL_NWO_CNT count not matching"
   flag_15="failed"
else
   info "TOTAL_BILL_NWO_CNT count matching" >>  ${v_Log} 2>&1
   flag_15="success"
fi
#############################################
GWsrc_TOTAL_NWO_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_NWO_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_NWO_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_NWO_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_NWO_AMT -ne $DLsrc_TOTAL_NWO_AMT ]
then
   info "TOTAL_NWO_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[15]="TOTAL_NWO_AMT count not matching"
   flag_16="failed"
else
   info "TOTAL_NWO_AMT count matching" >>  ${v_Log} 2>&1
   flag_16="success"
fi
#############################################
GWsrc_TOTAL_DISB_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_DISB_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_DISB_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_DISB_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_DISB_AMT -ne $DLsrc_TOTAL_DISB_AMT ]
then
   info "TOTAL_DISB_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[16]="TOTAL_DISB_AMT count not matching"
   flag_17="failed"
else
   info "TOTAL_DISB_AMT count matching" >>  ${v_Log} 2>&1
   flag_17="success"
fi
#############################################
GWsrc_TOTAL_FUND_TRANFR_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_FUND_TRANFR_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_FUND_TRANFR_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_FUND_TRANFR_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_FUND_TRANFR_AMT -ne $DLsrc_TOTAL_FUND_TRANFR_AMT ]
then
   info "TOTAL_FUND_TRANFR_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[17]="TOTAL_FUND_TRANFR_AMT count not matching"
   flag_18="failed"
else
   info "TOTAL_FUND_TRANFR_AMT count matching" >>  ${v_Log} 2>&1
   flag_18="success"
fi
#############################################
GWsrc_TOTAL_BILL_NONRECV_DIST_ITM_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_NONRECV_DIST_ITM_CNT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_BILL_NONRECV_DIST_ITM_CNT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_BILL_NONRECV_DIST_ITM_CNT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_BILL_NONRECV_DIST_ITM_CNT -ne $DLsrc_TOTAL_BILL_NONRECV_DIST_ITM_CNT ]
then
   info "TOTAL_BILL_NONRECV_DIST_ITM_CNT count not matching" >>  ${v_Log} 2>&1
   query_string[18]="TOTAL_BILL_NONRECV_DIST_ITM_CNT count not matching"
   flag_19="failed"
else
   info "TOTAL_BILL_NONRECV_DIST_ITM_CNT count matching" >>  ${v_Log} 2>&1
   flag_19="success"
fi
#############################################
GWsrc_TOTAL_GROSS_NONRECV_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_GROSS_NONRECV_APPLY_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_GROSS_NONRECV_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_GROSS_NONRECV_APPLY_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_GROSS_NONRECV_APPLY_AMT -ne $DLsrc_TOTAL_GROSS_NONRECV_APPLY_AMT ]
then
   info "TOTAL_GROSS_NONRECV_APPLY_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[19]="TOTAL_GROSS_NONRECV_APPLY_AMT count not matching"
   flag_20="failed"
else
   info "TOTAL_GROSS_NONRECV_APPLY_AMT count matching" >>  ${v_Log} 2>&1
   flag_20="success"
fi
#############################################
GWsrc_TOTAL_COMM_NONRECV_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_COMM_NONRECV_APPLY_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_TOTAL_COMM_NONRECV_APPLY_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='TOTAL_COMM_NONRECV_APPLY_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_TOTAL_COMM_NONRECV_APPLY_AMT -ne $DLsrc_TOTAL_COMM_NONRECV_APPLY_AMT ]
then
   info "TOTAL_COMM_NONRECV_APPLY_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[20]="TOTAL_COMM_NONRECV_APPLY_AMT count not matching"
   flag_21="failed"
else
   info "TOTAL_COMM_NONRECV_APPLY_AMT count matching" >>  ${v_Log} 2>&1
   flag_21="success"
fi
#############################################
GWsrc_MTD_BILL_PROD_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_PROD_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_PROD_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_PROD_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_PROD_TRANS_AMT -ne $DLsrc_MTD_BILL_PROD_TRANS_AMT ]
then
   info "MTD_BILL_PROD_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[21]="MTD_BILL_PROD_TRANS_AMT count not matching"
   flag_22="failed"
else
   info "MTD_BILL_PROD_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_22="success"
fi
#############################################
GWsrc_YTD_BILL_PROD_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_PROD_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_PROD_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_PROD_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_PROD_TRANS_AMT -ne $DLsrc_YTD_BILL_PROD_TRANS_AMT ]
then
   info "YTD_BILL_PROD_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[22]="YTD_BILL_PROD_TRANS_AMT count not matching"
   flag_23="failed"
else
   info "YTD_BILL_PROD_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_23="success"
fi
#############################################
GWsrc_MTD_BILL_ACCT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_ACCT_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_ACCT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_ACCT_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_ACCT_TRANS_AMT -ne $DLsrc_MTD_BILL_ACCT_TRANS_AMT ]
then
   info "MTD_BILL_ACCT_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[23]="MTD_BILL_ACCT_TRANS_AMT count not matching"
   flag_24="failed"
else
   info "MTD_BILL_ACCT_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_24="success"
fi
#############################################
GWsrc_YTD_BILL_ACCT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_ACCT_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_ACCT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_ACCT_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_ACCT_TRANS_AMT -ne $DLsrc_YTD_BILL_ACCT_TRANS_AMT ]
then
   info "YTD_BILL_ACCT_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[24]="YTD_BILL_ACCT_TRANS_AMT count not matching"
   flag_25="failed"
else
   info "YTD_BILL_ACCT_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_25="success"
fi
#############################################
GWsrc_MTD_BILL_DBMR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_DBMR_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_DBMR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_DBMR_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_DBMR_TRANS_AMT -ne $DLsrc_MTD_BILL_DBMR_TRANS_AMT ]
then
   info "MTD_BILL_DBMR_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[25]="MTD_BILL_DBMR_TRANS_AMT count not matching"
   flag_26="failed"
else
   info "MTD_BILL_DBMR_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_26="success"
fi
#############################################
GWsrc_YTD_BILL_DBMR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_DBMR_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_DBMR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_DBMR_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_DBMR_TRANS_AMT -ne $DLsrc_YTD_BILL_DBMR_TRANS_AMT ]
then
   info "YTD_BILL_DBMR_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[26]="YTD_BILL_DBMR_TRANS_AMT count not matching"
   flag_27="failed"
else
   info "YTD_BILL_DBMR_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_27="success"
fi
#############################################
GWsrc_MTD_BILL_SUSPYMT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_SUSPYMT_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_SUSPYMT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_SUSPYMT_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_SUSPYMT_TRANS_AMT -ne $DLsrc_MTD_BILL_SUSPYMT_TRANS_AMT ]
then
   info "MTD_BILL_SUSPYMT_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[27]="MTD_BILL_SUSPYMT_TRANS_AMT count not matching"
   flag_28="failed"
else
   info "MTD_BILL_SUSPYMT_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_28="success"
fi
#############################################
GWsrc_YTD_BILL_SUSPYMT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_SUSPYMT_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_SUSPYMT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_SUSPYMT_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_SUSPYMT_TRANS_AMT -ne $DLsrc_YTD_BILL_SUSPYMT_TRANS_AMT ]
then
   info "YTD_BILL_SUSPYMT_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[28]="YTD_BILL_SUSPYMT_TRANS_AMT count not matching"
   flag_29="failed"
else
   info "YTD_BILL_SUSPYMT_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_29="success"
fi
#############################################
GWsrc_MTD_BILL_TRANSFR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_TRANSFR_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_TRANSFR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_TRANSFR_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_TRANSFR_TRANS_AMT -ne $DLsrc_MTD_BILL_TRANSFR_TRANS_AMT ]
then
   info "MTD_BILL_TRANSFR_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[29]="MTD_BILL_TRANSFR_TRANS_AMT count not matching"
   flag_30="failed"
else
   info "MTD_BILL_TRANSFR_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_30="success"
fi
#############################################
GWsrc_YTD_BILL_TRANSFR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_TRANSFR_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_TRANSFR_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_TRANSFR_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_TRANSFR_TRANS_AMT -ne $DLsrc_YTD_BILL_TRANSFR_TRANS_AMT ]
then
   info "YTD_BILL_TRANSFR_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[30]="YTD_BILL_TRANSFR_TRANS_AMT count not matching"
   flag_31="failed"
else
   info "YTD_BILL_TRANSFR_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_31="success"
fi
#############################################
GWsrc_MTD_BILL_NONRECV_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_NONRECV_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_NONRECV_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_NONRECV_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_NONRECV_TRANS_AMT -ne $DLsrc_MTD_BILL_NONRECV_TRANS_AMT ]
then
   info "MTD_BILL_NONRECV_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[31]="MTD_BILL_NONRECV_TRANS_AMT count not matching"
   flag_32="failed"
else
   info "MTD_BILL_NONRECV_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_32="success"
fi
#############################################
GWsrc_YTD_BILL_NONRECV_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_NONRECV_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_NONRECV_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_NONRECV_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_NONRECV_TRANS_AMT -ne $DLsrc_YTD_BILL_NONRECV_TRANS_AMT ]
then
   info "YTD_BILL_NONRECV_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[32]="YTD_BILL_NONRECV_TRANS_AMT count not matching"
   flag_33="failed"
else
   info "YTD_BILL_NONRECV_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_33="success"
fi
#############################################
GWsrc_MTD_BILL_CREDIT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_CREDIT_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_MTD_BILL_CREDIT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='MTD_BILL_CREDIT_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_MTD_BILL_CREDIT_TRANS_AMT -ne $DLsrc_MTD_BILL_CREDIT_TRANS_AMT ]
then
   info "MTD_BILL_CREDIT_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[33]="MTD_BILL_CREDIT_TRANS_AMT count not matching"
   flag_34="failed"
else
   info "MTD_BILL_CREDIT_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_34="success"
fi
#############################################
GWsrc_YTD_BILL_CREDIT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_CREDIT_TRANS_AMT'  and source_system_code='GWBC' and source = 'GWSource')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
DLsrc_YTD_BILL_CREDIT_TRANS_AMT=`hive -S -e "SELECT cast(metricresult as bigint) from ((SELECT metricresult,etl_load_cycle_id  FROM $V_TRNS_DB.stg_recon where auditentity='YTD_BILL_CREDIT_TRANS_AMT'  and source_system_code='GWBC' and source = 'DataLake')A INNER JOIN (SELECT load_cycle_id from $V_TRNS_DB.vw_abc_load_cycle where source_system_code='GWBC' and cycle_type_code='STAGE')B ON A.etl_load_cycle_id=B.load_cycle_id)"`
if [ $GWsrc_YTD_BILL_CREDIT_TRANS_AMT -ne $DLsrc_YTD_BILL_CREDIT_TRANS_AMT ]
then
   info "YTD_BILL_CREDIT_TRANS_AMT count not matching" >>  ${v_Log} 2>&1
   query_string[34]="YTD_BILL_CREDIT_TRANS_AMT count not matching"
   flag_35="failed"
else
   info "YTD_BILL_CREDIT_TRANS_AMT count matching" >>  ${v_Log} 2>&1
   flag_35="success"
fi
#############################################
if  ( [ $flag_1 = 'success' ] && [ $flag_2 = 'success' ] && [ $flag_3 = 'success' ] && [ $flag_4 = 'success' ] && [ $flag_5 = 'success' ] && [ $flag_6 = 'success' ] && [ $flag_7 = 'success' ] && [ $flag_8 = 'success' ] && [ $flag_9 = 'success' ] && [ $flag_10 = 'success' ] && [ $flag_11 = 'success' ] && [ $flag_12 = 'success' ] && [ $flag_13 = 'success' ] && [ $flag_14 = 'success' ] && [ $flag_15 = 'success' ] && [ $flag_16 = 'success' ] && [ $flag_17 = 'success' ] && [ $flag_18 = 'success' ] && [ $flag_19 = 'success' ] && [ $flag_20 = 'success' ] && [ $flag_21 = 'success' ] && [ $flag_22 = 'success' ] && [ $flag_23 = 'success' ] && [ $flag_24 = 'success' ] && [ $flag_25 = 'success' ] && [ $flag_26 = 'success' ] && [ $flag_27 = 'success' ] && [ $flag_28 = 'success' ] && [ $flag_29 = 'success' ] && [ $flag_30 = 'success' ] && [ $flag_31 = 'success' ] && [ $flag_32 = 'success' ] && [ $flag_33 = 'success' ] && [ $flag_34 = 'success' ] && [ $flag_35 = 'success' ] )
then
   info "Processing completed successfully" >>  ${v_Log} 2>&1
. $SCRIPT_HOME/insert_load_cycle.sh GWBC STAGE 3 >>  ${v_Log}
else
   for i in "${query_string[@]}";do
   IFS=$'\n'
   MAIL="${query_string[*]}"
   done
   echo "$MAIL" | mail -s "Email alert for new account GWBC Staging Reconciliation" edlakerun@stateauto.com,itsupport@stateauto.com;
   info "Email Sent successfully"  >> ${v_Log}
   info "Processing Failed" >>  ${v_Log} 2>&1
#. $SCRIPT_HOME/insert_load_cycle.sh GWBC STAGE 2 >>  ${v_Log}
   exit 1
fi
###############################################################################
if [ $status -ne 1 ]
    then
                    info "spark submit failed for GWBC stage recon">> ${v_Log}
        echo mail -s "Spark Submit Failed in new account GWBC Staging Reconciliation" edlakerun@stateauto.com,itsupport@stateauto.com;
#	 echo mail -s "Spark Submit Failed GWBC Staging Reconciliation" nidhi.kumari@stateauto.com;
        info "Email Sent successfully"  >> ${v_Log}
                          exit 1
    else
                    echo "Spark successfully completed" >> ${v_Log}
fi
###############################################################################
#                                   END                                       #
###############################################################################
