#!/bin/bash
#########################################################################################
#                               General Details                                         #
#########################################################################################
#                                                                                       #
# Name         : mdm_daily_delete.sh                                                    #
#                                                                                       #
# Description  : Script to Execute if MDM Failure NOT Restarted on the Same Day         #
#                To Delete Intermediate S3 Storages created  (and)                      #
#                To Delete Entries on Collection transform_mdm_stats                    #
#                                                                                       #
# Argument     : Pass Failed Date in yyyy-mm-dd format                                  #
#                                                                                       #
# S3 Storages  :  s3://sa-l4-datalake-processed-secure/mdm/cc_pc_group/<date>           #
#                 s3://sa-l4-datalake-processed-secure/mdm/cc_pc_apc/<date>             #
#                 s3://sa-l4-datalake-processed-secure/mdm/match_data/<date>            #
#                 s3://sa-l4-datalake-processed-secure/mdm/golden_data/date=<date>      #
#                 s3://sa-l4-datalake-processed-secure/mdm/cc_pc_apc_full/<date>        #
#                                                                                       #
# Collection   : L4 --> l4-mdm-a.ce3vfbdrlipy.us-east-1.docdb.amazonaws.com:27017       #
#                DB --> partyMDM                                                        #
#                Collection --> transform_mdm_stats                                     #
#                                                                                       #
# Author       : State Auto                                                             #
#                                                                                       #
#########################################################################################
#                          Script Environment Setup                                     #
#########################################################################################

echo "[INFO] Begin - Deleting MDM Daily for the Given Date...."
Run_Time=$(date +"%Y-%m-%d %H:%M:%S")

## Parameters passed to Script ##
echo "[INFO] Reading Parameters...."
if [ $# -eq 0 ]
then
   echo "[INFO] Message : The parameter passed with the script are empty...." 
   echo "[INFO] Warning : Pass the correct MDM Daily failed Date per UTC in YYYY-MM-DD format...."
   exit 1
else
   fdate=$1
   echo "[INFO] MDM Daily Date Passed for Deletion: ${fdate}"
fi

## Parameters passed to py file executed from a given path thru Python3 Command ##
muserid="svc_partyMDM"
mpassword="d0lsbE1BdFRHM3RBbmYzNTA="
mhost="l4-mdm-a.ce3vfbdrlipy.us-east-1.docdb.amazonaws.com"
mport="27017"
mprop1="ssl=true"
mprop2="ssl_ca_certs=/home/hadoop/transform/mdm/rds-combined-ca-bundle.pem"
mprop3="replicaSet=rs0"
mprop4="readPreference=secondaryPreferred"
mdatabase="partyMDM"
mstats="transform_mdm_stats"
fsys="GW"

LOG_PATH="/home/hadoop/transform/logs/transformation_log"
SRC_PATH="/home/hadoop/transform/mdm"

## Log File Details ##
V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
v_Log=${LOG_PATH}/${mstats}_${V_EPOC_TIME}.log
export LOGFILE=${v_Log}
#info "log:${v_Log}"
echo "[INFO] Log file path :${v_Log}" 2>&1

echo "[INFO] Deletion In-Progress and Writing Log File, Wait for a Minute...."
echo "[INFO] Script Execution Time: ${Run_Time}" >> ${v_Log}

echo "[INFO] Deleting MDM Daily Intermediate S3 Storages for ${fdate}...." >> ${v_Log}

echo "[INFO] Deleting MDM cc_pc_group for ${fdate}...." >> ${v_Log}
hdfs dfs -rm -r s3://sa-l4-datalake-processed-secure/mdm/cc_pc_group/${fdate} >> ${v_Log}

echo "[INFO] Deleting MDM cc_pc_apc for ${fdate}...." >> ${v_Log}
hdfs dfs -rm -r s3://sa-l4-datalake-processed-secure/mdm/cc_pc_apc/${fdate} >> ${v_Log}

echo "[INFO] Deleting MDM match_data for ${fdate}...." >> ${v_Log}
hdfs dfs -rm -r s3://sa-l4-datalake-processed-secure/mdm/match_data/${fdate} >> ${v_Log}

echo "[INFO] Deleting MDM golden_data for ${fdate}...." >> ${v_Log}
hdfs dfs -rm -r s3://sa-l4-datalake-processed-secure/mdm/golden_data/date=${fdate} >> ${v_Log}

echo "[INFO] Deleting MDM cc_pc_apc_full for ${fdate}...." >> ${v_Log}
hdfs dfs -rm -r s3://sa-l4-datalake-processed-secure/mdm/cc_pc_apc_full/${fdate} >> ${v_Log}

echo "[INFO] Deleting MDM Daily Stat entries on transform_mdm_stats for ${fdate}...." >> ${v_Log}
echo "[INFO] Calling py source by Passing Parameters...." >> ${v_Log}
python3 ${SRC_PATH}/mdm_delete_stat_entry.py ${muserid} ${mpassword} ${mhost} ${mport} ${mprop1} ${mprop2} ${mprop3} ${mprop4} ${mdatabase} ${mstats} ${fdate} ${fsys} >> ${v_Log} 2>&1

echo "[INFO] Completed - Deleting MDM Daily for the Given Date...."
  
###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1             
