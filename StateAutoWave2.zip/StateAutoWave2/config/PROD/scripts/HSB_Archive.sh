#!/bin/bash
echo "started shell script"
echo "Reading Parameters"
DATE=`date +%Y-%m-%d`
base_dir=/home/hadoop/transform
mkdir -p $base_dir"/logs/transformation_log/"$DATE
DATE_TS=`date '+%Y-%m-%d_%H%M%S%s'`

function readParameters() {
    echo "Parsing args ..."
    for item in "$@"; do
        case $item in
        (*=*) eval $item;;
        esac
    done
    echo "Done parsing args ..!!!"
}

readParameters "$@"

V_SOURCE_BUCKET_PATH=${SOURCE_BUCKET_PATH}
V_TARGET_BUCKET_PATH=${TARGET_BUCKET_PATH}

#V_SOURCE_BUCKET_PATH=s3://sa-l3-dev-emr-edl-reporting-secure/hsb/cpp
#V_TARGET_BUCKET_PATH=s3://sa-l3-dev-emr-edl-reporting-secure/hsb/cpp_date


echo ${V_SOURCE_BUCKET_PATH}
echo ${V_TARGET_BUCKET_PATH}

log_file_name="HSB_Archive"
logDir="$base_dir/logs/transformation_log/$DATE/"

if [ ! -d $logDir ]; then mkdir -p $logDir; fi

log_file="${logDir}/${log_file_name}_${DATE_TS}.log"

if [[ -z "$V_SOURCE_BUCKET_PATH" ]]
then
echo "Message : The source bucket paths in s3 is empty" >> $log_file
echo "Warning : Please pass the correct source path of s3" >> $log_file
exit 1
fi


echo "executing hadoop copy command.."
hadoop fs -cp -f ${V_SOURCE_BUCKET_PATH}/*[0-9].txt ${V_TARGET_BUCKET_PATH} 1>>$log_file 2>&1
status=$?
echo "Hadoop Copy command status is $status" >> $log_file
if [ ${status} -eq 0 ]; then
        echo "files copied successfully"
else
        echo "Error while copying files, Please have a look at the logs in below path \n ${log_file}" >> $log_file
exit 1
fi
hadoop fs -rm -r ${V_SOURCE_BUCKET_PATH}/*[0-9].txt
status=$?
echo "Completed the script and the status is $status" >> $log_file
if [ ${status} -eq 0 ]; then
        exit 0
else
        echo "Error while removing the HSB Files that ends with date, Please have a look at the logs in below path \n ${log_file}" >> $log_file
exit 1
fi

