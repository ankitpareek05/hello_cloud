#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : gwpl_stg_reconciliation.sh                                   #
#                                                                             #
# Description  : Script to reconcile gwpl source with staging                 #
#		 Curation Layer	                                                      #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"
V_TGT_TABLE=${TABLE_NAME}
V_LYR_NAME=${LAYER_NAME}
V_METRICS=${METRICS}
if [[ -z "$V_TGT_TABLE" ]] || [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_TARGET_TABLE=${V_TGT_TABLE,,}
V_LAYER_NAME=${V_LYR_NAME^^}
V_METRICS=${V_METRICS^^}

	# Log File Details
	mkdir -p ${v_tmp_path_curation}
	V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
	v_Log=${v_tmp_path_curation}/${V_TARGET_TABLE}_${V_LAYER_NAME}_validation_${V_EPOC_TIME}.log
	export LOGFILE=${v_Log}
	info "log:${v_Log}"
	echo "Log file path :${v_Log}" 2>&1

echo "Starting spark submit"
V_AUDIT_DB="audit_ingestion"
V_LOAD_TYPE="DI"

spark-submit --conf spark.dynamicAllocation.enabled=true  --conf spark.driver.maxResultSize=5G --conf spark.shuffle.consolidateFiles=true --master yarn --deploy-mode client --jars /home/hadoop/processed/jars/sqljdbc42.jar --driver-memory 5G --executor-memory 20G --executor-cores 5 --name "gwpl_staging_recon_validation" --class com.stageload.StagingReconValidation /home/hadoop/transform/jars/datalake_staging_recon_validation-assembly-2.0.0.jar /home/hadoop/transform/spec_files/gwpl_stg_connection.cfg ${V_GWPL_STG_DB} ${V_AUDIT_DB} ${V_METRICS} DI >> ${v_Log} 2>&1

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1