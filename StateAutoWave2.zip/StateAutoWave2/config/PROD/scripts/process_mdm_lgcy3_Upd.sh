#!/bin/bash
###############################################################################
#                               General Details                               #
###############################################################################
#                                                                             #
# Name         : process_mdm_lgcy3_Upd.sh (LGCY_V6_Cont3_Upd.py)              #
#                                                                             #
# Description  : Read Golden Data from S3 and Write to Customer360 at MongoDB #
#                                                                             #
# Author       : State Auto                                                   #
#                                                                             #
###############################################################################
#                          Script Environment Setup                           #
###############################################################################
SECONDS=0

SCRIPT_START_TIME="`TZ=America/New_York date +"%Y-%m-%d %H:%M:%S"`"

#Extract SCRIPT_HOME
SCRIPT_PATH="${BASH_SOURCE[0]}";
SCRIPT_HOME=`dirname $SCRIPT_PATH`

info "Script home is: $SCRIPT_HOME"

#Set module, project, subject area home paths.
 . /home/hadoop/transform/modules/shell_functions/import_dependencies.sh ${SCRIPT_HOME}
 
###############################################################################

Run_Time=$(date +"%Y-%m-%d %H:%M:%S")
Run_Date=$(date +"%Y-%m-%d")
Run_Month=$(date +"%Y-%m")
echo "Run_Time: " ${Run_Time}

###############################################################################
#                                   Declare                                   #
###############################################################################

#######Reading Parameters######
info "Reading Parameters"
readParameters "$@"

## Parameters passed to py file executed from a given path thru Spark-Submit Command ##
muserid="svc_partyMDM"
mpassword="d0lsbE1BdFRHM3RBbmYzNTA="
mhost="l4-mdm-a.ce3vfbdrlipy.us-east-1.docdb.amazonaws.com"
mport="27017"
mprop1="ssl=true"
mprop2="ssl_ca_certs=/home/hadoop/transform/mdm/rds-combined-ca-bundle.pem"
mprop3="replicaSet=rs0"
mprop4="readPreference=secondaryPreferred"

mdatabase="partyMDM"
mcustomer="Customer360"
mstats="transform_mdm_stats"

lgcy_golden_data_loc="s3://sa-l4-datalake-processed-secure/mdm_lgcy/lgcy_golden_data/yyyymm="
lgcy_apc_data_loc="s3://sa-l4-datalake-processed-secure/mdm_lgcy/lgcy_apc/"
cc_pc_apc_full_data_loc="s3://sa-l4-datalake-processed-secure/mdm/cc_pc_apc_full/"
lgcy_mdm_excp_loc="s3://sa-l4-datalake-processed-secure/mdm_lgcy/lgcy_exceptions/"
curr_yyyymm=$(date +"%Y%m")

SRC_PATH="/home/hadoop/transform/mdm"
Target="LGCY_Customer360_StepIII_Upd"

## Layer Name Check for Log File Creation Path ##
V_LYR_NAME=${LAYER_NAME}
if [[ -z "$V_LYR_NAME" ]]
then
info "Message : The parameter passed with the script are empty"
info "Warning : Please pass the correct parameter"
exit 1
fi
V_LAYER_NAME=${V_LYR_NAME^^}


#All the path are mentioned in the Namespace properties
if [ $V_LAYER_NAME == 'SERVING' ]
then
     # Log File Details
     mkdir -p ${v_tmp_path_serving}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_serving}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
else
     # Log File Details
     mkdir -p ${v_tmp_path_curation}
     V_EPOC_TIME="`TZ=America/New_York date +'%Y%d%m%H%M%S'`"
     v_Log=${v_tmp_path_curation}/${Target}_${V_LAYER_NAME}_${V_EPOC_TIME}.log
     export LOGFILE=${v_Log}
     info "log:${v_Log}"
     echo "Log file path :${v_Log}" 2>&1
fi

echo "Check Current Month Step-II Output present or not to Start Step-III" >> ${v_Log}
$(hdfs dfs -test -d ${lgcy_golden_data_loc}${curr_yyyymm})

if [ $? != 0 ]
then
   echo "[INFO] MDM Step-II Output for Current Month NOT EXISTS to Read" >> ${v_Log}
else
   echo "[INFO] MDM Step-II Output for Current Month EXISTS and Processing Starts" >> ${v_Log}
   
   echo "Spark Submit to Read LGCY Golden Data from S3 and Write to Customer360 Collection" >> ${v_Log}    
   spark-submit --conf spark.dynamicAllocation.enabled=true --master yarn --deploy-mode client --num-executors 17 --driver-memory 3G --executor-memory 51G --executor-cores 16 ${SRC_PATH}/LGCY_V6_Cont3_Upd.py ${muserid} ${mpassword} ${mhost} ${mport} ${mprop1} ${mprop2} ${mprop3} ${mprop4} ${mdatabase} ${mcustomer} ${mstats} ${lgcy_golden_data_loc} ${lgcy_apc_data_loc} ${cc_pc_apc_full_data_loc} ${lgcy_mdm_excp_loc} ${curr_yyyymm} >> ${v_Log} 2>&1
   
   if [ $? == 0 ]
   then
      csv_sucs_msg="LGCY MDM Update Golden Data to Customer360 Collection - Completed for ${Run_Month}"
      echo -e "${csv_sucs_msg}" >> ${v_Log}
      info "MDM Step-III Updating Completed and Email Sent successfully"  >> ${v_Log} 
   else
      csv_fail_msg="LGCY MDM Update Golden Data to Customer360 Collection - Failed for ${Run_Month}"
      echo "${csv_fail_msg}" >> ${v_Log}
      info "MDM Step-III Updating Failed and Email Sent"  >> ${v_Log}
      exit 1	  
   fi  
fi
echo "[INFO] Script Ends Here...." >> ${v_Log}

###############################################################################
#                                   END                                       #
###############################################################################
echo "${v_Log}" 2>&1             
