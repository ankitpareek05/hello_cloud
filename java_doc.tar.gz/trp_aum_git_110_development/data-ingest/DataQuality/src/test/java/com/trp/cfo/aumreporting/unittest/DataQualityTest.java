package com.trp.cfo.aumreporting.unittest;

import com.trp.cfo.aumreporting.commonutils.EnvironmentVariable;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.dataquality.services.impl.DQRuleProcessImpl;
import com.trp.cfo.aumreporting.dataquality.udfs.UdfRegister;
import com.trp.cfo.aumreporting.dataquality.utils.ValidationUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static com.trp.cfo.aumreporting.commonutils.CommonUtils.calculateSizeAndRepartition;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getDataFromRdd;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getInfoFromRDD;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getMapFromString;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getPropertiesFromConfig;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getValue;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.parseConfigFile;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.readAsRDD;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.readFromCSVFile;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.readFromDelimiterFile;
import static org.apache.spark.sql.functions.asc;
import static org.apache.spark.sql.functions.desc;

public class DataQualityTest
{
	private static final Logger	 logger =LogManager.getLogger(DataQualityTest.class);
	private   ClassLoader	 classLoader =	getClass().getClassLoader();
	private File filedqConfigPathEmpty =new File(classLoader.getResource("DQ_CONFIG_Empty.csv").getFile());
	private  File filedqConfigPath      =new File(classLoader.getResource("DQ_CONFIG.csv").getFile());
	private  File fileinputConfig       =new File(classLoader.getResource("config.csv").getFile());
	private  File filesrcFilePath       =new File(classLoader.getResource("ff_IDM_TAUMD_AGR_PTY_20200107062033.txt").getFile());
	private  File errorLkpFile          =new File(classLoader.getResource("Error_Lkp.csv").getFile());

	private String       dqConfigPath      = filedqConfigPath.getAbsolutePath();
	private String       inputConfig       = fileinputConfig.getAbsolutePath();
	private String       srcFileName       = "ff_IDM_TAUMD_AGR_PTY";
	private String       srcFilePath       = filesrcFilePath.getAbsolutePath();
	private String		 dqConfigPathEmpty =filedqConfigPathEmpty.getAbsolutePath();
	private String       errorLkp          = errorLkpFile.getAbsolutePath();
	private String       tempView          = "input";
	private String       layerName         = "LANDINGTOSTAGE";
	private String       delimiterFilter   = "Delimiter";
	private String       headerFilter      = "HeaderFilter";
	private String       infoRecordsFilter = "InfoRecordsFilter";
	private String       validFilter       = "Valid";
	private SparkSession spark;

	@Before
	public void createSparkSession()
	{
		InitiateSparkSession.createSparkSession("local");
		spark = InitiateSparkSession.getSparkSession();
	}


	private Dataset<Row> getInputDF()
	{
		StructField[] structFields = new StructField[] {
				new StructField("InpTrimString", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpUpperString", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpLowerString", DataTypes.StringType, true,Metadata.empty()),
				new StructField("nullCheckString", DataTypes.IntegerType, true,Metadata.empty()),
				new StructField("InpSplChar", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpReplaceValid", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpIsNumeric", DataTypes.StringType, true,Metadata.empty())
		};
		StructType structType = new StructType(structFields);
		ArrayList<Row> rows = new ArrayList<>();
		rows.add(RowFactory.create("  Amit", "Disha", "Ankit", null, "-123.2","Valid,", ""));
		rows.add(RowFactory.create("Anshuman  ", "Prudhvi", "Vishal", 123,"12345", "days", "123avc45"));
		Dataset<Row> df = spark.createDataFrame(rows, structType);
		return df;
	}

	private Dataset<Row> getExpOutputDF()
	{
		StructField[] structFields = new StructField[] {
				new StructField("ExpTrimString", DataTypes.StringType, true,
						Metadata.empty()),
				new StructField("ExpUpperString", DataTypes.StringType, true,
						Metadata.empty()),
				new StructField("ExpLowerString", DataTypes.StringType, true,
						Metadata.empty()),
				new StructField("ExpReplaceValid", DataTypes.StringType, true,
						Metadata.empty())
		};
		StructType structType = new StructType(structFields);
		ArrayList<Row> rows = new ArrayList<>();
		rows.add(RowFactory.create("Amit", "DISHA", "ankit", ""));
		rows.add(RowFactory.create("Anshuman", "PRUDHVI", "vishal", "days"));
		return spark.createDataFrame(rows, structType);
	}

	@Test
	public void stringUpperTest()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select STD_RULE_UPPERCASE(InpUpperString,'InpUpperString') as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();

		// Expected
		Dataset<Row> dfExp = getExpOutputDF().select("ExpUpperString");
		dfExp.show(false);
		org.junit.Assert.assertEquals(0, outputRow.except(dfExp).count());
	}

	@Test
	public void stringLowerTest()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select STD_RULE_LOWERCASE(InpLowerString,'InpLowerString') as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();

		// Expected
		Dataset<Row> dfExp = getExpOutputDF().select("ExpLowerString");
		dfExp.show(false);
		org.junit.Assert.assertEquals(0, outputRow.except(dfExp).count());
	}

	@Test
	public void stringTrimTest()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select STD_RULE_TRIM_CASE(InpTrimString,'InpTrimString') as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();

		// Expected
		Dataset<Row> dfExp = getExpOutputDF().select("ExpTrimString");
		dfExp.show(false);
		org.junit.Assert.assertEquals(0, outputRow.except(dfExp).count());
	}

	@Test
	public void replaceSplCharTest()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select VAL_RULE_CHCKSPECIALCHAR(InpSplChar,'InpSplChar') as Actual_output from input";
		Dataset<Row> outDF = spark.sql(Actexpr1);
		outDF.createOrReplaceTempView("outDf");
		outDF.show(false);
		Row outputRow = outDF.first();
		Row outputRow2 = outDF.orderBy(desc("Actual_output")).first();
		Assert.assertNotSame(validFilter, outputRow.get(0).toString());
		Assert.assertEquals(validFilter, outputRow2.get(0).toString());
	}

	@Test
	public void replaceValidTest()
	{
		UdfRegister.processUdfRegister();
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select VAL_RULE_REPLACE_VALID(InpReplaceValid) as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();
		Dataset<Row> dfExp = getExpOutputDF().select("ExpReplaceValid");
		dfExp.show(false);
		org.junit.Assert.assertEquals(0, outputRow.except(dfExp).count());
	}

	@Test
	public void nullCheckTest()
	{
		UdfRegister.processUdfRegister();
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String	Actexpr1 ="select VAL_RULE_NULLCHECK(nullCheckString,'nullCheckString') as Actual_output from input";
		Dataset<Row> outDF = spark.sql(Actexpr1);
		outDF.createOrReplaceTempView("outDf");
		outDF.show(false);
		Row outputRow = outDF.first();
		Row outputRow2 = outDF.orderBy(asc("Actual_output")).first();
		Assert.assertNotSame(validFilter, outputRow.get(0).toString());
		Assert.assertEquals(validFilter, outputRow2.get(0).toString());
	}

	@Test
	public void isNumericTest()
	{
		UdfRegister.processUdfRegister();
		// Actual
		Dataset<Row> df = getInputDF();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select VAL_RULE_ISNUMERIC(InpIsNumeric,'InpIsNumeric') as Actual_output from input";
		Dataset<Row> outDF = spark.sql(Actexpr1);
		outDF.createOrReplaceTempView("outDf");
		outDF.show(false);
		Row outputRow = outDF.first();
		Row outputRow2 = outDF.orderBy(desc("Actual_output")).first();
		Assert.assertNotSame(validFilter, outputRow.get(0).toString());
		Assert.assertEquals(validFilter, outputRow2.get(0).toString());
	}

	@Test
	public void parseConfigFileTest()
			throws IOException
	{
		String srcName = "DST";
		Map<String, String>
				configMap =
				parseConfigFile(dqConfigPath, srcFileName, srcName, layerName);
		org.junit.Assert.assertTrue(configMap.keySet().size() > 0);
	}

	@Test
	public void getMapStringTest()
			throws IOException
	{
		String
				str =
				"src_col_name=PMY_PTY_IN  ||  tgt_col_name=PRIMARY_PARTY_INDICATOR";
		Map<String, String> getMap = getMapFromString(str);
		org.junit.Assert.assertTrue(getMap.keySet().size() > 0);
	}

	@Test
	public void readFromCsvTest()
			throws IOException
	{
		String headerRequired = "true";
		String prefixForColumns = "";
		Dataset<Row>
				readCsv =
				readFromCSVFile(dqConfigPath, headerRequired, prefixForColumns);
		org.junit.Assert.assertTrue(readCsv.count() > 0);
	}

	@Test
	public void readFromEmptyCsvTest()
			throws IOException
	{
		String headerRequired = "true";
		String prefixForColumns = "";
		Dataset<Row>
				readCsv =
				readFromCSVFile(dqConfigPathEmpty, headerRequired,
						prefixForColumns);
		org.junit.Assert.assertTrue(readCsv.count() == 0);
	}

	@Test
	public void readFromDelimitedTest()
			throws IOException
	{
		String headerRequired = "true";
		String prefixForColumns = "";
		String delimiter = ",";
		Dataset<Row>
				readDelimiter =
				readFromDelimiterFile(dqConfigPath, delimiter, headerRequired,
						prefixForColumns);
		org.junit.Assert.assertTrue(readDelimiter.count() > 0);
	}

	@Test
	public void getValueTest()
			throws IOException
	{
		Map<String, String> getVal = new HashMap<>();
		getVal.put("STAGETOTARGET_SCHEMA",
				"BUSINESS_PARTY_IDENTIFIER || AGREEMENT_IDENTIFIER|| AGREEMENT_PARTY_ROLE_TYPE_IDENTIFIER |");
		String schemaVal = getValue("_SCHEMA", getVal);
		org.junit.Assert.assertEquals("BUSINESS_PARTY_IDENTIFIER || AGREEMENT_IDENTIFIER|| AGREEMENT_PARTY_ROLE_TYPE_IDENTIFIER |",schemaVal);
	}

	@Test
	public void calculateSizeAndRepartitionTest()
			throws IOException
	{
		int size = calculateSizeAndRepartition(dqConfigPath);
		org.junit.Assert.assertTrue(size > 0);
	}

	@Test
	public void getPropertiesFromConfigTest()
			throws IOException
	{
		Properties
				getPropertyConfig =
				getPropertiesFromConfig(inputConfig, srcFileName);
		org.junit.Assert.assertFalse(getPropertyConfig.isEmpty());
	}

	@Test
	public void readAsRDDTest()
			throws IOException
	{
		JavaRDD<String> outputRDD = readAsRDD(dqConfigPath);
		org.junit.Assert.assertTrue(outputRDD.count() > 0);
	}

	@Test
	public void getInfoFromRDDTest()
			throws IOException
	{
		JavaRDD<String> srcRDD = readAsRDD(srcFilePath);
		Properties
				getPropertyConfig =
				getPropertiesFromConfig(inputConfig, srcFileName);
		String
				infoRecordsFilterProp =
				getPropertyConfig.getProperty(infoRecordsFilter);
		String delimiter = getPropertyConfig.getProperty(delimiterFilter);
		String
				infoRecordsSchema =
				getPropertyConfig.getProperty("InfoRecordsSchema");
		Dataset
				getInfo =
				getInfoFromRDD(srcRDD, infoRecordsFilterProp, infoRecordsSchema,
						delimiter);
		org.junit.Assert.assertTrue(getInfo.count() > 0);
	}

	@Test
	public void getDataFromRDDTest()
			throws IOException
	{
		JavaRDD<String> srcRDD = readAsRDD(srcFilePath);
		Properties
				getPropertyConfig =
				getPropertiesFromConfig(inputConfig, srcFileName);
		String delimiter = getPropertyConfig.getProperty(delimiterFilter);
		String headerFilterProp = getPropertyConfig.getProperty(headerFilter);
		String
				infoRecordsFilterProp =
				getPropertyConfig.getProperty(infoRecordsFilter);
		Dataset
				getData =
				getDataFromRdd(srcRDD, infoRecordsFilterProp, headerFilterProp,
						delimiter);
		org.junit.Assert.assertTrue(getData.count() > 0);
	}

	@Test
	public void dqRuleImplTest()
			throws IOException
	{
		String srcName = "DST";

		Map<String, String>
				configMap =
				parseConfigFile(dqConfigPath, srcFileName, srcName, layerName);
		JavaRDD<String> srcRDD = readAsRDD(srcFilePath);
		Properties
				getPropertyConfig =
				getPropertiesFromConfig(inputConfig, srcFileName);
		getPropertyConfig.setProperty("DQ_ERROR_PATH", errorLkp);
		String delimiter = getPropertyConfig.getProperty(delimiterFilter);
		String headerFilterProp = getPropertyConfig.getProperty(headerFilter);
		String
				infoRecordsFilterProp =
				getPropertyConfig.getProperty(infoRecordsFilter);
		Dataset
				getData =
				getDataFromRdd(srcRDD, infoRecordsFilterProp, headerFilterProp,
						delimiter);
		DQRuleProcessImpl objDq = new DQRuleProcessImpl();
		Dataset<Row> ruleOutPut =objDq.processDataQualityRules(getData, configMap,getPropertyConfig);
		org.junit.Assert.assertTrue(ruleOutPut.count() > 0);
	}

	@Test
	public void dqValImplTest()
			throws IOException
	{
		String srcName = "DST";

		Map<String, String>
				configMap =
				parseConfigFile(dqConfigPath, srcFileName, srcName, layerName);
		JavaRDD<String> srcRDD = readAsRDD(srcFilePath);
		Properties
				getPropertyConfig =
				getPropertiesFromConfig(inputConfig, srcFileName);
		getPropertyConfig.setProperty("DQ_ERROR_PATH", errorLkp);
		String delimiter = getPropertyConfig.getProperty(delimiterFilter);
		String headerFilterProp = getPropertyConfig.getProperty(headerFilter);
		String
				infoRecordsFilterProp =
				getPropertyConfig.getProperty(infoRecordsFilter);
		Dataset
				getData =
				getDataFromRdd(srcRDD, infoRecordsFilterProp, headerFilterProp,
						delimiter);
		DQRuleProcessImpl objDq = new DQRuleProcessImpl();
		Dataset<Row>
				ruleOutPut =
				objDq.processDataValidationRules(getData, configMap,
						getPropertyConfig);
		org.junit.Assert.assertTrue(ruleOutPut.count() > 0);
	}

	@Test
	public void validationUtilsTest()	throws IOException
	{
		Properties	getPropertyConfig =	getPropertiesFromConfig(inputConfig, srcFileName);
		getPropertyConfig.setProperty("DQ_ERROR_PATH", errorLkp);
		String srcName = "DST";
		String srcFile = "ff_IDM_TAUMD_AGR_PTY";
		String delimiter = getPropertyConfig.getProperty(delimiterFilter);
		String headerFilterProp = getPropertyConfig.getProperty(headerFilter);
		String infoRecordsFilterProp =	getPropertyConfig.getProperty(infoRecordsFilter);
		Map<String, String>	configMap =parseConfigFile(dqConfigPath, srcFileName, srcName, layerName);
		JavaRDD<String> srcRDD = readAsRDD(srcFilePath);
		String schemaVal = getValue("_SCHEMA", configMap);
		Dataset	getData =getDataFromRdd(srcRDD, infoRecordsFilterProp, headerFilterProp,delimiter);
		ValidationUtils validationUtilsObj = new ValidationUtils();
		DQRuleProcessImpl objDq = new DQRuleProcessImpl();
		Dataset<Row> ruleOutPut =objDq.processDataQualityRules(getData, configMap,getPropertyConfig);
		Dataset<Row> valOutPut =objDq.processDataValidationRules(ruleOutPut, configMap,getPropertyConfig);
		List<Dataset<Row>>	validationDFList = null;

		validationDFList =validationUtilsObj.processValidationRules(valOutPut,configMap, schemaVal, srcName, getPropertyConfig,	srcFile);
		org.junit.Assert.assertTrue(validationDFList.size() > 0);

	}


	@Test
	public void loadPropertiesFile()
	{
		File inputfile =new File(classLoader.getResource("EnvProperties.csv").getFile());
		Properties	configFile =EnvironmentVariable.loadPropertiesFile(inputfile.getAbsolutePath());
		org.junit.Assert.assertEquals("airflow",configFile.getProperty("trp.dbName"));
	}

	@Test
	public void replaceSplCharTest2()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF2();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select VAL_RULE_CHCKSPECIALCHAR(InpSplChar,'InpSplChar') as Actual_output from input";
		Dataset<Row> outDF = spark.sql(Actexpr1);
		outDF.createOrReplaceTempView("outDf");
		outDF.show(false);
		Row outputRow = outDF.first();
		Assert.assertEquals("InpSplChar:$$$$$$$:Special Character Found", outputRow.get(0).toString());
	}

	@Test
	public void stringTrimTest2()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF2();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select STD_RULE_TRIM_CASE(InpTrimString,'InpTrimString') as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();

		// Expected
		Dataset<Row> dfExp = getExpOutputDF2().select("ExpTrimString");
		dfExp.show(false);
		org.junit.Assert.assertEquals(0, outputRow.except(dfExp).count());
	}

	@Test
	public void stringLowerTest2()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF2();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select STD_RULE_LOWERCASE(InpLowerString,'InpLowerString') as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();

		// Expected
		Dataset<Row> dfExp = getExpOutputDF2().select("ExpLowerString");
		dfExp.show(false);

	}

	@Test
	public void stringUpperTest2()
	{
		UdfRegister.processUdfRegister();

		// Actual
		Dataset<Row> df = getInputDF2();
		df.show(false);
		df.createOrReplaceTempView(tempView);
		String
				Actexpr1 =
				"select STD_RULE_UPPERCASE(InpUpperString,'InpUpperString') as Actual_output from input";
		logger.info(Actexpr1);
		Dataset<Row> outputRow = spark.sql(Actexpr1);
		outputRow.show();
		// Expected
		Dataset<Row> dfExp = getExpOutputDF2().select("ExpUpperString");
		dfExp.show(false);
		org.junit.Assert.assertEquals(0, outputRow.except(dfExp).count());
	}


	private Dataset<Row> getExpOutputDF2()
	{
		StructField[] structFields = new StructField[] {
				new StructField("ExpTrimString", DataTypes.StringType, true,
						Metadata.empty()),
				new StructField("ExpUpperString", DataTypes.StringType, true,
						Metadata.empty()),
				new StructField("ExpLowerString", DataTypes.StringType, true,
						Metadata.empty()),
				new StructField("ExpReplaceValid", DataTypes.StringType, true,
						Metadata.empty())
		};
		StructType structType = new StructType(structFields);
		ArrayList<Row> rows = new ArrayList<>();
		rows.add(RowFactory.create(null, null, null, "days"));
		return spark.createDataFrame(rows, structType);
	}


	private Dataset<Row> getInputDF2()
	{
		StructField[] structFields = new StructField[] {
				new StructField("InpTrimString", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpUpperString", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpLowerString", DataTypes.StringType, true,Metadata.empty()),
				new StructField("nullCheckString", DataTypes.IntegerType, true,Metadata.empty()),
				new StructField("InpSplChar", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpReplaceValid", DataTypes.StringType, true,Metadata.empty()),
				new StructField("InpIsNumeric", DataTypes.StringType, true,Metadata.empty())
		};
		StructType structType = new StructType(structFields);
		ArrayList<Row> rows = new ArrayList<>();
		rows.add(RowFactory.create(null, null, null, 123,"$$$$$$$", "days", "123avc45"));
		Dataset<Row> df = spark.createDataFrame(rows, structType);
		return df;
	}

}

