package com.trp.cfo.aumreporting.unittest;

import com.trp.cfo.aumreporting.dataquality.DataQualityDriver;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;

import java.io.File;
import java.util.Properties;

public class DataQualityDriverTest
{
	private static final Logger		logger =	LogManager.getLogger(DataQualityDriverTest.class);

	private ClassLoader classLoader      = getClass().getClassLoader();
	private File	filedqConfigPath =new File(classLoader.getResource("DQ_CONFIG.csv").getFile());
	private File	envFile      =new File(classLoader.getResource("EnvProperties.csv").getFile());
	private File fileinputConfig  =new File(classLoader.getResource("config.csv").getFile());
	private String      srcFileName      = "ff_IDM_TAUMD_AGR_PTY";

	@Test
	public void testMain()
	{
		boolean flag = true;
		String	[]arg={ srcFileName, "DST", filedqConfigPath.getAbsolutePath(), "2","local", envFile.getAbsolutePath() };
		try
		{
			DataQualityDriver.main(arg);
		}
		catch(Exception e)
		{
			logger.error("Error in DataqulityDriverTest", e);
		}
		org.junit.Assert.assertTrue(flag);
	}



	@Test
	public void mainTest2()
	{
		boolean flag=true;
		try
		{
			String[] args =	{ srcFileName, "DST", fileinputConfig.getPath(), "2","local", envFile.getPath() };
			DataQualityDriver.main(args);
		}
		catch(java.lang.ExceptionInInitializerError | Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		org.junit.Assert.assertTrue(flag);
	}

	@Test
	public void mainTest3()
	{
		String[]	args ={ srcFileName, "DST", fileinputConfig.getPath(), "jobId","local" };
		boolean flag=true;
		try
		{
			DataQualityDriver.main(args);
		}
		catch(Exception e){
			logger.error("Error in mainTest",e);
             flag=false;
		}
		org.junit.Assert.assertTrue(flag);
	}

	@Test
	public void dataQualityDriverTest()
	{
		boolean flag=true;
		Properties configFile = new Properties();
		configFile.setProperty("DQ_CONFIG_PATH", "src/test/resources/DQ_CONFIG.csv");
		configFile.setProperty("InfoRecordsFilter", "ff_IDM_TAUMD_AGR_PTY");
		configFile.setProperty("Delimiter", "\\|");
		configFile.setProperty("HeaderFilter", "BUS_PTY_ID");
		configFile.setProperty("DP_OUTPUT_PATH", "src/test/resources/out/dataProfiling/");
		configFile.setProperty("DataTargetPath", "src/test/resources/out/data");
		configFile.setProperty("InfoRecordsSchema", "FileName|TimeStamp|RecordCount");
		configFile.setProperty("DQ_ERROR_PATH", "src/test/resources/Error_Lkp.csv");
		configFile.setProperty("DQ_OUTPUT_PATH", "src/test/resources/out/dataQuality/");
		configFile.setProperty("SourcePath", "src/test/resources/out/");
		configFile.setProperty("HeaderTargetPath", "src/test/resources/");

		try
		{
			DataQualityDriver.dataQualityDriver(configFile, "ff_IDM_TAUMD_AGR_PTY", "DST");
		}
		catch(Exception e)
		{
			logger.error("error in dataquality",e);
		}
		org.junit.Assert.assertTrue(flag);

	}
}
