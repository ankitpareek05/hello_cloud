package com.trp.cfo.aumreporting.dataquality.udfs;

import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import java.io.Serializable;
public class UdfRegister implements Serializable
{
	public static void processUdfRegister()
	{
		SparkSession spark = InitiateSparkSession.getSparkSession();
		StandarizationUDF stdUdf = new StandarizationUDF();
		ValidationUDF valUdf = new ValidationUDF();
		spark.udf().register("STD_RULE_UPPERCASE", stdUdf.STD_RULE_UPPERCASE, DataTypes.StringType);
		spark.udf().register("STD_RULE_LOWERCASE", stdUdf.STD_RULE_LOWERCASE, DataTypes.StringType);
		spark.udf().register("STD_RULE_TRIM_CASE", stdUdf.STD_RULE_TRIM_CASE, DataTypes.StringType);
		spark.udf().register("VAL_RULE_CHCKSPECIALCHAR", valUdf.VAL_RULE_CHCKSPECIALCHAR, DataTypes.StringType);
		spark.udf().register("VAL_RULE_NULLCHECK", valUdf.VAL_RULE_NULLCHECK, DataTypes.StringType);
		spark.udf().register("VAL_RULE_REPLACE_VALID", valUdf.VAL_RULE_REPLACE_VALID, DataTypes.StringType);
		spark.udf().register("VAL_RULE_ISNUMERIC", valUdf.VAL_RULE_ISNUMERIC, DataTypes.StringType);
	}
}
