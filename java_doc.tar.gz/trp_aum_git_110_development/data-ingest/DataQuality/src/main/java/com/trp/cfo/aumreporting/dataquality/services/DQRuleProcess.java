package com.trp.cfo.aumreporting.dataquality.services;

import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

public interface DQRuleProcess extends Serializable
{
	public Dataset<Row> processDataQualityRules(Dataset inputDf, Map<String, String> inputConfigData, Properties configFile) throws	IngestException;

	public Dataset<Row> processDataValidationRules(Dataset inputDf, Map<String, String> inputConfigData, Properties configFile) throws IngestException;
}
