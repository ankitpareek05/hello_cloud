package com.trp.cfo.aumreporting.dataquality.services.impl;

import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.dataquality.services.DQRuleProcess;
import com.trp.cfo.aumreporting.dataquality.udfs.UdfRegister;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DQRuleProcessImpl implements DQRuleProcess, Serializable
{
	private static final Logger logger = LogManager.getLogger(DQRuleProcessImpl.class);

	SparkSession spark = InitiateSparkSession.getSparkSession();

	@Override
	public Dataset<Row> processDataQualityRules(Dataset	inputDf, Map<String, String> inputConfigData, Properties configFile)
	{

		/**
		 * Selecting keys which are realted to rules
		 */
		inputConfigData = inputConfigData.entrySet().stream()
				.filter(x -> x.getKey().contains("_STD") || x.getKey().contains("_CLN"))
				.collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
		/**
		 * Creating expression to replace it later
		 */
		String	regexExp ="LANDINGTOSTAGE_STANDARIZATION_|LANDINGTOSTAGE_CLEANSING_";
		List<String> expr = new ArrayList<>();
		for(Map.Entry<String,String> x:inputConfigData.entrySet())
		{
			Map<String, String> strTOMap = CommonUtils.getMapFromString(x.getValue());
			String srcCol = strTOMap.getOrDefault("src_col_name", "NA");
			String tgtCol = strTOMap.getOrDefault("tgt_col_name", "NA");
			String configExpr = strTOMap.getOrDefault("expr", "NA");
			Pattern p = Pattern.compile("\\)");
			Matcher m = p.matcher(x.getKey().replaceAll(regexExp, ""));
			/**
			 * Creating expression
			 */
			if ("NA".equalsIgnoreCase(configExpr.trim()))
			{
				if (m.find())
				{
					expr.add(x.getKey()
							.replaceAll(regexExp, "")
							.replaceAll("\\d", "")
							.replaceFirst("\\)", "") + "(" + srcCol + ",'" + srcCol + "'))" + " as " + tgtCol);
				}
				else
				{
					expr.add(x.getKey()
							.replaceAll(regexExp, "")
							.replaceAll("\\d", "")
							.replaceFirst("\\)", "") + "(" + srcCol + ",'" + srcCol + "')" + " as " + tgtCol);
				}
			}
			else
			{
				expr.add(configExpr);
			}
		}
		/**
		 * 	Concatenation two arrays
		 */

		/**
		 * 	Registering all the UDFs
		 */
		UdfRegister.processUdfRegister();
		List<String> sqlList = Stream.concat(expr.stream(), Arrays.stream(inputDf.columns()))
				.collect(Collectors.toList());
		inputDf.createOrReplaceTempView("inputDf");
		String finalStr = "select " + String.join(",", sqlList) + " from inputDf";
		logger.info("Expression==" + finalStr);
		logger.info("---DataQuality Rules Applied---");
		return spark.sql(finalStr);
	}



	/*
	Validation
	 */

	@Override
	public Dataset<Row> processDataValidationRules(	Dataset	inputDf, Map<String, String> inputConfigData, Properties configFile)
	{

		/**
		 * Selecting keys which are realted to rules
		 */
		inputConfigData = inputConfigData.entrySet().stream()
				.filter(x -> x.getKey().contains("_VAL_"))
				.collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
		/**
		 * Creating expression to replace it later
		 */
		String	regexExp ="LANDINGTOSTAGE_VALIDATION_";
		List<String> expr = new ArrayList<>();
		for(Map.Entry<String,String> x:inputConfigData.entrySet())
		{
			Map<String, String> strTOMap = CommonUtils.getMapFromString(x.getValue());
			String srcCol = strTOMap.getOrDefault("src_col_name", "NA");
			String tgtCol = strTOMap.getOrDefault("tgt_col_name", "NA");
			String configExpr = strTOMap.getOrDefault("expr", "NA");
			Pattern p = Pattern.compile("\\)");
			Matcher m = p.matcher(x.getKey().replaceAll(regexExp, ""));

			/**
			 * Creating expression
			 */
			if (configExpr.trim().equalsIgnoreCase("NA"))
			{
				if (m.find())
				{
					String
							s =
							x.getKey()
									.replaceAll(regexExp, "")
									.replaceAll("\\d", "")
									.replaceFirst("\\)", "") + "(" + srcCol + ",'" + srcCol + "'))" + " as " + tgtCol;
					expr.add(s);
				}
				else
				{
					String
							s =
							x.getKey()
									.replaceAll(regexExp, "")
									.replaceAll("\\d", "")
									.replaceFirst("\\)", "") + "(" + srcCol + ",'" + srcCol + "')" + " as " + tgtCol;
					expr.add(s);
				}
			}
			else
			{
				String s = configExpr;
				expr.add(s);
			}
		}
		/**
		 * 	Concatenation two arrays
		 */

		/**
		 * 	Registering all the UDFs
		 */
		UdfRegister.processUdfRegister();
		List<String> sqlList = Stream.concat(expr.stream(), Arrays.stream(inputDf.columns()))
				.collect(Collectors.toList());
		inputDf.createOrReplaceTempView("inputDf");
		String finalStr = "select " + String.join(",", sqlList) + " from inputDf";
		logger.info("Expression==" + finalStr);
		logger.info("---DataQuality Rules Applied---");
		return spark.sql(finalStr);
	}
}
