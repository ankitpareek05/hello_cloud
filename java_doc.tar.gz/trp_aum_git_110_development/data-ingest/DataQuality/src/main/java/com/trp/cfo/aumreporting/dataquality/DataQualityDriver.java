package com.trp.cfo.aumreporting.dataquality;

import com.trp.cfo.aumreporting.commonutils.AuditLog;
import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.EnvironmentVariable;
import com.trp.cfo.aumreporting.commonutils.GlobalVariable;
import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.dataquality.services.impl.DQRuleProcessImpl;
import com.trp.cfo.aumreporting.dataquality.utils.ValidationUtils;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getValue;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.readFromCSVFile;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.writeToCSVFile;

public class DataQualityDriver implements Serializable
{
	private static final Logger logger = LogManager.getLogger(DataQualityDriver.class);
	public static final String OVERWRITE = "OVERWRITE";
	public static final String TRP_ING = "TRP_ING_";
	public static final String L2_S = "L2S";

	public static void main(String[] args)	throws Exception
	{
		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);
		Logger.getLogger("org.apache.spark.SparkContext").setLevel(Level.WARN);
		Logger.getLogger("org.apache.spark.SparkContext").setLevel(Level.ERROR);
		int inputArgumentLength = args.length;
		if (inputArgumentLength != 6) {
			logger.error("Invalid Number Of Arguments: Expected '6', Received::" + inputArgumentLength);
		}
		else {
			String fileName = args[0];
			fileName = fileName.replaceAll("_*\\d*.txt$", "");
			String sourceName = args[1];
			String srcConfigPath = args[2];

			int jobId = 0;
			InitiateSparkSession.createSparkSession(args[4]);
			try {
				jobId = Integer.parseInt(args[3]);
			}
			catch(NumberFormatException e) {
				logger.error("JobId is Illegal:" + e.getMessage());
				jobId = 0;
			}
			logger.info("Job Id:" + GlobalVariable.jobId);
			GlobalVariable.jobId = jobId;

			//Reading property file for env variable
			EnvironmentVariable.loadPropertiesFile(args[5]);
			Properties configProperties=CommonUtils.getPropertiesFromConfig(srcConfigPath,fileName);
			if ("cluster".equalsIgnoreCase(args[4])) {
				CommonUtils.parseSourceFile(fileName, configProperties, sourceName, false);
			}
			else {
				CommonUtils.parseSourceFile(fileName, configProperties, sourceName, true);
			}
			try {
				dataQualityDriver(configProperties,fileName,sourceName);
				CommonUtils.saveHeaderInfo(fileName, configProperties);
			}
			catch(Exception e) {
				logger.error(e.getMessage(),e);
				throw new IngestException("Spark Exception",e);
			}
		}
	}

	public static void dataQualityDriver(Properties configFile, String key, String src)	throws IngestException
	{
		Map<String, String> configData = new HashMap<>();
		String fileName = key;
		String sourceName = src;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

		SparkSession spark = InitiateSparkSession.getSparkSession();
		logger.info("Initializing DataQuality....");
		String configInputPath = configFile.getProperty("DQ_CONFIG_PATH");
		String dqOutputPath = configFile.getProperty("DQ_OUTPUT_PATH");
		String layerName = "LANDINGTOSTAGE";
		logger.info("Input Path for Config File: " + configInputPath);
		logger.info("FileName to Process: " + fileName);
		logger.info("Source to Process: " + sourceName);
		logger.info("Layer to Process: " + layerName);
		logger.info("Parsing Config File...");
		try {
			configData = CommonUtils.parseConfigFile(configInputPath, fileName, sourceName, layerName);
		}
		catch(IOException e) {
			logger.info("Config File not found::"+e.getMessage(),e);
			throw new IngestException("Exception in file",e);
		}
		String schemaVal = getValue("_SCHEMA", configData);
		Dataset<Row> df = readFromCSVFile(configFile.getProperty("DataTargetPath") + key, "true", "");
		Long srcCount = df.count();
		String startTime = format.format(Calendar.getInstance().getTime());
		try {
			// Calling Quality rules
			DQRuleProcessImpl objDq = new DQRuleProcessImpl();
			Dataset<Row> finalDQDF = objDq.processDataQualityRules(df, configData, configFile);
			Dataset<Row> finalDF = objDq.processDataValidationRules(finalDQDF, configData, configFile);

			// Validation
			ValidationUtils validationUtilsObj = new ValidationUtils();
			List<Dataset<Row>> validationDFList = validationUtilsObj.processValidationRules(finalDF, configData, schemaVal, src, configFile,fileName);
			Long errorCount = 0L;
			Long tgtCount;
			if (validationDFList != null && !validationDFList.isEmpty()) {
				errorCount = validationDFList.get(2).count();
				tgtCount = validationDFList.get(0).count();
				writeToCSVFile(validationDFList.get(1), dqOutputPath + "ERROR_OP/" + key, "true",
						OVERWRITE);
				writeToCSVFile(validationDFList.get(0), dqOutputPath + sourceName + "/" + key, "true",
						OVERWRITE);
			}
			else {
				logger.info("*****Reading schema for DQ DF with No validation ****");
				logger.info(schemaVal);
				finalDF.createOrReplaceTempView("finalDF");
				String schemaexpr = "select " + (schemaVal.replace("||", ",") + " from finalDF");
				logger.info(schemaexpr);				Dataset<Row> nonSuspendedRecordsDFFinal = spark.sql(schemaexpr);
				String endTime = format.format(Calendar.getInstance().getTime());
				nonSuspendedRecordsDFFinal = nonSuspendedRecordsDFFinal.withColumn("FILENAME", functions.lit(fileName))
						.withColumn("CREATE_USER", functions.lit(TRP_ING + src + L2_S))
						.withColumn("CREATE_DATE", functions.lit(endTime))
						.withColumn("UPDATE_USER", functions.lit(TRP_ING + src + L2_S))
						.withColumn("UPDATE_DATE", functions.lit(endTime));

				writeToCSVFile(nonSuspendedRecordsDFFinal, dqOutputPath + sourceName + "/" + key, "true",OVERWRITE);
				tgtCount = finalDF.count();
			}
			String endTime = format.format(Calendar.getInstance().getTime());
			new AuditLog().auditEntry("cfo_scheduler_data.cfo_scheduler_process_runlog","APPEND", fileName, startTime, endTime, "SUCCESS", layerName,
					srcCount, tgtCount, errorCount, GlobalVariable.jobId, null,"Ingestion",String.valueOf(java.time.LocalDate.now()));

		}
		catch(Exception ex) {
			logger.error(ex.getMessage());
			String endTime = format.format(Calendar.getInstance().getTime());
			new AuditLog().auditEntry("cfo_scheduler_data.cfo_scheduler_process_runlog","APPEND", fileName, startTime, endTime, "FAILURE", layerName,
					srcCount, 0L, 0L, GlobalVariable.jobId, null,"Ingestion",String.valueOf(java.time.LocalDate.now()));
			throw new IngestException("Exception in Spark",ex);
		}
	}
}
