package com.trp.cfo.aumreporting.dataquality.udfs;

import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUDF implements Serializable
{
	public static final String VALID = "Valid";

	UDF2 VAL_RULE_CHCKSPECIALCHAR = (UDF2<Object, String, String>) (str, colName) -> {
		String errorDesc = "Special Character Found";
		Pattern pattern = Pattern.compile("[\\-a-zA-Z0-9.]*");
		String value = String.valueOf(str);
		Matcher matcher = pattern.matcher(value);
		if (!(value.isEmpty() || str == null || value.equals("null") || String.valueOf(str).equals("")) && !matcher.matches()) {
			return colName + ":" + str + ":" + errorDesc;
		}
		else {
			return VALID;
		}
	};

	UDF2 VAL_RULE_NULLCHECK = (UDF2<Object, String, String>) (str, colName) -> {
		String errorDesc = "Null Value";
		String value = String.valueOf(str);
		if (value.isEmpty() || value.equals("null")) {
			return colName + ":" + str + ":" + errorDesc;
		}
		else {
			return VALID;
		}
	};

	UDF2 VAL_RULE_ISNUMERIC = (UDF2<Object, String, String>) (str, colName) -> {
		String errorDesc = "Non-Numeric Value";
		String value = String.valueOf(str);
		if (!(value.isEmpty() || value.equals("null")) && !String.valueOf(str).matches("\\-{0,1}[0-9]+\\.{0,1}[0-9]*")) {
			return colName + ":" + str + ":" + errorDesc;
		}
		else {
			return VALID;
		}
	};

	UDF1 VAL_RULE_REPLACE_VALID = (UDF1<String, String>) str -> {
		if (str.contains("Valid,") || str.contains(",Valid")) {
			return str.replace("Valid,", "").replace(",Valid", "");
		}
		else {
			return str;
		}
	};
}
