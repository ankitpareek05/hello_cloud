package com.trp.cfo.aumreporting.dataquality.udfs;

import org.apache.spark.sql.api.java.UDF2;

import java.io.Serializable;

public class StandarizationUDF implements Serializable
{
	UDF2 STD_RULE_UPPERCASE = new UDF2<Object, String, Object>()
	{
		public Object call(Object str, String col)
				throws Exception
		{
			if (str != null)
			{
				return str.toString().toUpperCase();
			}
			else
			{
				return str;
			}
		}
	};

	UDF2 STD_RULE_LOWERCASE = new UDF2<Object, String, Object>()
	{
		public Object call(Object str, String col)
				throws Exception
		{
			if (str != null)
			{
				return str.toString().toLowerCase();
			}
			else
			{
				return str;
			}

		}
	};

	UDF2 STD_RULE_TRIM_CASE = new UDF2<Object, String, Object>()
	{
		public Object call(Object str, String col)
				throws Exception
		{
			if (str != null)
			{
				return str.toString().trim();
			}
			else
			{
				return str;
			}
		}
	};
}
