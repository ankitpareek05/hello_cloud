package com.trp.cfo.aumreporting.dataquality.utils;

import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.dataquality.udfs.UdfRegister;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class ValidationUtils implements  Serializable
{
	private static final Logger logger = LogManager.getLogger(ValidationUtils.class);
	private static final String ERROR_MSG_COL_NAME = "errorMsg";

	public List<Dataset<Row>> processValidationRules(Dataset<Row> inputDf, Map<String, String> inputConfigData, String schema, String src, Properties configFile,String scrFileName)
	{
		ArrayList<Dataset<Row>> returnDF = new ArrayList<>();
		SparkSession spark = InitiateSparkSession.getSparkSession();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		UdfRegister.processUdfRegister();

		// compile list of expressions from configuration values
		List<String> filterExpressions = CommonUtils.buildFilterExpressionList(inputConfigData);

		// load file containing previously failed records
		Dataset<Row> errorFile = CommonUtils.readFromCSVFile(configFile.getProperty("DQ_ERROR_PATH"), "true", "");

		if (!filterExpressions.isEmpty())
		{
			logger.info("************************* Suspended Records ***************");
			Dataset<Row> suspendedRecordsDF = CommonUtils.buildSuspendedRecordsDataframe(spark, inputDf, filterExpressions);
			suspendedRecordsDF.show(false);

			List<String> originalColList = Arrays.stream(inputDf.columns()).filter(col -> !(col.endsWith("_VAL"))).collect(Collectors.toList());
			List<String> generatedColList = Arrays.stream(inputDf.columns()).filter(col -> col.endsWith("_VAL")).collect(Collectors.toList());

			Dataset<Row> storedDF = suspendedRecordsDF;
			storedDF = storedDF.withColumn("concatRows", functions.expr("concat_ws('|'," + String.join(",", originalColList) + ")"));
			storedDF = storedDF.withColumn(ERROR_MSG_COL_NAME, functions.expr("VAL_RULE_REPLACE_VALID(errorMsgF)")).drop("errorMsgF");
			suspendedRecordsDF = suspendedRecordsDF.drop("errorMsgF").distinct();

			for (String col : originalColList) {
				storedDF = storedDF.drop(col);
			}
			for (String col : generatedColList) {
				inputDf = inputDf.drop(col);
			}

			logger.info("************************* Success Records ***************");
			Dataset<Row> successRecordsDF = inputDf.except(suspendedRecordsDF);
			successRecordsDF.createOrReplaceTempView("successRecordsDF");
			successRecordsDF.show(false);

			logger.info("**************** Success Records Final ***************");
			String schemaExpression = "select " + (schema.replace("||", ",") + " from successRecordsDF");
			Dataset<Row> successRecordsFinalDF = spark.sql(schemaExpression);
			String endTime = format.format(Calendar.getInstance().getTime());
			successRecordsFinalDF = successRecordsFinalDF
					.withColumn("FILENAME", functions.lit(scrFileName))
					.withColumn("CREATE_USER", functions.lit("TRP_ING_" + src + "L2S"))
					.withColumn("CREATE_DATE", functions.lit(endTime))
					.withColumn("UPDATE_USER", functions.lit("TRP_ING_" + src + "L2S"))
					.withColumn("UPDATE_DATE", functions.lit(endTime));
			successRecordsFinalDF.show(false);

			storedDF.distinct();
			storedDF = storedDF
					.withColumn("Date", functions.lit(endTime)).withColumn("Process_id", functions.lit(scrFileName))
					.withColumn("Job_runlog_id", functions.lit(src));
			storedDF = storedDF
					.withColumn(ERROR_MSG_COL_NAME, functions.split(functions.col(ERROR_MSG_COL_NAME), ","))
					.withColumn(ERROR_MSG_COL_NAME, functions.explode(functions.column(ERROR_MSG_COL_NAME)))
					.withColumn("errorColumn", functions.split(functions.col(ERROR_MSG_COL_NAME), ":").getItem(0))
					.withColumn("errorDesc", functions.split(functions.col(ERROR_MSG_COL_NAME), ":").getItem(2))
					.withColumn("errorValue", functions.split(functions.col(ERROR_MSG_COL_NAME), ":").getItem(1));
			storedDF = storedDF
					.join(errorFile, storedDF.col("errorDesc").equalTo(errorFile.col("ErrorDesc")), "inner")
					.select("Job_runlog_id", "Process_id", "concatRows", "errorColumn", "errorCode", "errorValue", "Date");
			storedDF = storedDF.distinct();

			returnDF.add(successRecordsFinalDF);
			returnDF.add(storedDF);
			returnDF.add(suspendedRecordsDF);
		}
		return returnDF;
	}

}
