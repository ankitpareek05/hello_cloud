package com.trp.cfo.aumreporting.informationmart.services;

import org.apache.spark.sql.SparkSession;

import java.util.Map;

public interface InformationMartService
{
	String informationMartProcess(Map<String, String> map,SparkSession spark,String archNameWithActionName) throws Exception;
}
