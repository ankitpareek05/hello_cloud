package com.trp.cfo.aumreporting.informationmart.utils;

import com.trp.cfo.aumreporting.commonutils.AuditLog;
import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.GlobalVariable;
import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getMapFromString;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.writeToCSVFile;
import static com.trp.cfo.aumreporting.commonutils.DBUtils.mergeTarget;
import static com.trp.cfo.aumreporting.commonutils.DBUtils.writeToSnowflake;

public class InformationMartUtils implements Serializable
{
	private static final Logger logger       = LogManager.getLogger(InformationMartUtils.class);
	public static final  String SF_WAREHOUSE = "sf_warehouse";
	public static final  String SF_DATABASE  = "sf_database";

	public static void informationMartProcess(String archNameWithActionName,
											  Map<String, String> configData,
											  SparkSession spark) throws Exception {
		long srcCount = CommonUtils.loadDataToSpark(archNameWithActionName, configData, spark);

		// Get all the SQL queries to be executed
		List<String> expectedSQLQueries = configData.keySet().stream().filter(x -> x.contains("SQL_QUERY")).collect(Collectors.toList());
		logger.info(":::" + expectedSQLQueries);
		List<String> expectedMergeQueries = configData.keySet().stream().filter(x -> x.contains("MERGE_QUERY")).collect(Collectors.toList());

		// run the sql transform queries
		for (int i = 1; i <= expectedSQLQueries.size(); i++) {
			String sqlQueryDetails = configData.get(archNameWithActionName + "_SQL_QUERY" + i);
			logger.info("Printing sql: " + sqlQueryDetails);
			Map<String, String> sqlQueryMap = getMapFromString(sqlQueryDetails);
			String type = sqlQueryMap.get("type");
			String sqlQuery = sqlQueryMap.get("query");

			String outputDetails = configData.getOrDefault(archNameWithActionName + "_OUTPUT_DETAILS" + i,"NA");
			logger.info("Running " + type + " " + sqlQuery);
			Dataset<Row> df1 = spark.sql(sqlQuery);
			logger.info("Dataset Result Count: " + df1.count());
			df1.persist(StorageLevel.MEMORY_AND_DISK());

			if (!"NA".equalsIgnoreCase(outputDetails)) {
				logger.info("----going in output---");
				Map<String, String> outputDetailsMap = getMapFromString(outputDetails);
				String outputPath = outputDetailsMap.getOrDefault("path", "NA");
				String fileFormat = outputDetailsMap.getOrDefault("file_format", "NA");
				String header = outputDetailsMap.getOrDefault("header", "true");
				String sfWareHouse = outputDetailsMap.getOrDefault(SF_WAREHOUSE,"NA");
				String sfDataBase = outputDetailsMap.getOrDefault(SF_DATABASE,"NA");
				String sfSchema = outputDetailsMap.getOrDefault("sf_schema","NA");
				String sfTableName = outputDetailsMap.getOrDefault("sf_table","NA");
				String mode = outputDetailsMap.getOrDefault("mode", "overwrite");

				logger.info("Writing DataFrame to output path");

				switch (fileFormat)
				{
					case "csv":
						writeToCSVFile(df1, outputPath, header, mode);
						break;
					case "table":
						writeToSnowflake(df1, sfWareHouse, sfDataBase, sfSchema, sfTableName, mode);
						break;
					default:
						break;
				}
				df1.unpersist();
			}
		}

		// run the merge queries
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String startTime=format.format(Calendar.getInstance().getTime());

		for (int i = 1; i <= expectedMergeQueries.size(); i++)
		{
			long tgtCount = 0;
			String mergeQueryDetails = configData.get(archNameWithActionName + "_MERGE_QUERY" + i);
			Map<String, String> outputDetailsMap = getMapFromString(mergeQueryDetails);
			String sfWareHouse = outputDetailsMap.getOrDefault(SF_WAREHOUSE, "NA");
			String sfDataBase = outputDetailsMap.getOrDefault(SF_DATABASE, "NA");
			String mergeQuery = outputDetailsMap.getOrDefault("query", "NA");
			String sfTbl = outputDetailsMap.getOrDefault("sf_tbl", "NA");
			String sfType = outputDetailsMap.getOrDefault("sf_type", "NA");
			mergeTarget(sfWareHouse, sfDataBase, mergeQuery);
			String endTime = format.format(Calendar.getInstance().getTime());
			new AuditLog().auditEntry("cfo_scheduler_data.cfo_scheduler_process_runlog", "APPEND", sfTbl + "_" + sfType, startTime, endTime, "SUCCESS", "DWTOMART",
					srcCount, tgtCount, 0L, GlobalVariable.jobId, null, "Ingestion", String.valueOf(java.time.LocalDate.now()));
			logger.info("******" + mergeQuery);
		}
	}

}
