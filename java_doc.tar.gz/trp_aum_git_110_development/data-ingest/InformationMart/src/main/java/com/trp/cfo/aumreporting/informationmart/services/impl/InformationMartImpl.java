package com.trp.cfo.aumreporting.informationmart.services.impl;

import com.trp.cfo.aumreporting.informationmart.services.InformationMartService;
import com.trp.cfo.aumreporting.informationmart.utils.InformationMartUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;
import java.util.Map;

public class InformationMartImpl implements InformationMartService,Serializable
{
	private static final Logger	logger = LogManager.getLogger(InformationMartImpl.class);

	@Override
	public String informationMartProcess(Map<String, String> configMap, SparkSession spark, String archNameWithActionName) throws Exception
	{
		String result;
		try {
			InformationMartUtils.informationMartProcess(archNameWithActionName, configMap, spark);
			result = "SUCCESS";
		}
		catch(Exception e) {
			logger.info("Exception in InformationMartImpl:"+e.getMessage(),e);
			throw e;
		}
		return result;
	}

}
