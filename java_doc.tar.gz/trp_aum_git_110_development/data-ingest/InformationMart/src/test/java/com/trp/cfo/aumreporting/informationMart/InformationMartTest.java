package com.trp.cfo.aumreporting.informationMart;

import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.informationmart.InformationMartDriver;
import com.trp.cfo.aumreporting.informationmart.services.InformationMartService;
import com.trp.cfo.aumreporting.informationmart.services.impl.InformationMartImpl;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.SparkSession;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InformationMartTest
{
	private static final Logger       logger = LogManager.getLogger(InformationMartTest.class);
	private ClassLoader classLoader = getClass().getClassLoader();
	private File infoConfigPath = new File(classLoader.getResource("informationMart_test.csv").getFile());
	private File infoEnvPath = new File(classLoader.getResource("EnvProperties_info.csv").getFile());
	private  SparkSession spark;

	@Before
	public void createSparkSession(){
		InitiateSparkSession.createSparkSession("local");
		spark = InitiateSparkSession.getSparkSession();
	}


	@Test
	public void informationMartServiceTest()
	{

		String result="FAILURE";
		InformationMartService informationMartService =            new InformationMartImpl();
		int count=0;
		try
		{
			List<Map<String,String>> list=getTestMap();
			for(Map<String,String> configData:list)
			{
				count++;
				result=informationMartService.informationMartProcess(configData, spark,"STAGETOTARGET_TRANSACTION");
				if(count==1)
					org.junit.Assert.assertEquals("SUCCESS",result);
			}
		}catch(Exception e){
			result="FAILURE";
		}
		if(count>1)
			org.junit.Assert.assertEquals("FAILURE",result);

	}

	public List<Map<String,String>> getTestMap(){

		File configPath2 = new File(classLoader.getResource("ff_IDM_TAUMD_TRN_TYP.csv").getFile());
		File configPath3 = new File(classLoader.getResource("property_type_value.csv").getFile());
		File configPath4 = new File(classLoader.getResource("transaction_type_dim.csv").getFile());
		File configPath5 = new File(classLoader.getResource("part-rtl-file.csv").getFile());
		File configPath6 = new File(classLoader.getResource("out/empty.csv").getFile());

		Map<String, String>        map=new HashMap<String,String>();
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS1","path="+configPath2+ "|| file_format = csv || header=true || view_name =ff_IDM_TAUMD_TRN_TYP || sep=NA ||db_type = snowflake ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS2","path="+configPath4+" || file_format = csv || header=true || view_name =transaction_type_dim|| sep=NA ||db_type = snowflake ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS3","path="+configPath3+" || file_format = csv || header=true || view_name =PROPERTY_TYPE_VALUE_REF|| sep=NA ||db_type = snowflake ||table_name=NA ");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS3","path="+configPath3+" || file_format = csv || header=true || view_name =PROPERTY_TYPE_VALUE_REF|| sep=NA ||db_type = snowflake ||table_name=NA ");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS4","path="+configPath5+" || file_format = delimited || header=true || view_name =SQ_SU_Retail_Transaction_Fact_Temp|| sep=| ||db_type = NA ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS5","path=NA || file_format = parquet || header=true || view_name =parquet_test_view|| sep=| ||db_type = NA ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS1","NA");
		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY1"," Type =sql || query = CREATE TEMPORARY VIEW  TRANSACTIONFACT AS "
				+ "(Select            null As TRANSACTION_TYPE_ID,NULL AS CREATE_TMSTP,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER "
				+ " AS TRANSACTION_TYPE_IDENTIFIER,                ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_NAME AS TRANSACTION_TYPE_NAME,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_CATEGORY_NAME AS "
				+ "TRANSACTION_CATEGORY_NAME,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE AS BALANCE_CHANGE_CODE,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE As TRANSACTION_AMOUNT_SIGN_CODE,ff_IDM_TAUMD_TRN_TYP.TRADE_STATUS_CODE AS "
				+ "TRADE_STATUS_CODE,transaction_type_dim.idm_ods_transaction_type_id AS IDM_ODS_TRANSACTION_TYPE_ID FROM ff_IDM_TAUMD_TRN_TYP LEFT OUTER JOIN "
				+"transaction_type_dim ON ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER=transaction_type_dim.idm_ods_transaction_type_id)");
		map.put("STAGETOTARGET_PROCESSES_PROCESS_LIST","TRANSACTION");
		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY2" , "Type = sql || query = CREATE TEMPORARY VIEW  SOURCEVIEW AS (SELECT * FROM TRANSACTIONFACT)");


		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY3","Type = sql || query =SELECT * FROM SOURCEVIEW");
		map.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS3","path="+configPath5+" || file_format =parquet || header=true || view_name =NA|| sep=NA ||db_type = NA ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY4","Type = sql || query =SELECT * FROM transaction_type_dim");

		map.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS4","path="+configPath6+" || file_format =csv || header=true || view_name =NA|| sep=NA ||db_type = NA ||table_name=NA");

		Map<String, String> map1=new HashMap<String,String>();
		map1.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS1","path="+configPath2+ "|| file_format = csv || header=true || view_name = ff_IDM_TAUMD_TRN_TYP || sep=NA ||db_type = snowflake ||table_name=NA");
		map1.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS2","path="+configPath4+" || file_format = csv || header=true || view_name =transaction_type_dim|| sep=NA ||db_type = snowflake ||table_name=NA");
		map1.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS3","path="+configPath3+" || file_format = csv || header=true || view_name =PROPERTY_TYPE_VALUE_REF|| sep=NA ||db_type = snowflake ||table_name=NA ");
		map1.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS1","NA");
		map1.put("STAGETOTARGET_TRANSACTION_SQL_QUERY1"," Type =sql || query = CREATE TEMPORARY VIEW  TRANSACTIONFACT AS "
				+ "(Select            null As TRANSACTION_TYPE_ID,NULL AS CREATE_TMSTP,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER "
				+ " AS TRANSACTION_TYPE_IDENTIFIER,                ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_NAME AS TRANSACTION_TYPE_NAME,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_CATEGORY_NAME AS "
				+ "TRANSACTION_CATEGORY_NAME,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE AS BALANCE_CHANGE_CODE,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE As TRANSACTION_AMOUNT_SIGN_CODE,ff_IDM_TAUMD_TRN_TYP.TRADE_STATUS_CODE AS "
				+ "TRADE_STATUS_CODE,transaction_type_dim.idm_ods_transaction_type_id AS IDM_ODS_TRANSACTION_TYPE_ID FROM ff_IDM_TAUMD_TRN_TYP LEFT OUTER JOIN "
				+"transaction_type_dim ON ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER=transaction_type_dim.idm_ods_transaction_type_id)");
		map1.put("STAGETOTARGET_PROCESSES_PROCESS_LIST","TRANSACTION");
		map1.put("STAGETOTARGET_TRANSACTION_SQL_QUERY2" , "Type = sql || query = CREATE TEMPORARY VIEW  SOURCEVIEW AS (SELECT TRANSACTIONFACT.Employee FROM TRANSACTIONFACT)");
		map1.put("STAGETOTARGET_TRANSACTION_SQL_QUERY3","Type = sql || query =CREATE TEMPORARY VIEW  TRANSACTIONFACTUNION AS(SELECT * FROM SOURCEVIEW)");
		map1.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS2","NA");
		List<Map<String,String>> list = Arrays.asList(map,map1);
		return list;
	}



	public Map<String,String> getmap(){
		Map<String,String> map=new HashMap<>();
		map.put("test1","test");
		return map;
	}

	@Test
	public void mainTest1()
	{
		boolean flag=true;
		try
		{
			String[] args = {"TRANSACTION_DIM","TRP",infoConfigPath.getPath(),"2","local"};
			InformationMartDriver.main(args);
		}
		catch(Exception e){
			logger.error("error in mainTest",e);
			flag=false;
		}
		org.junit.Assert.assertTrue(flag);
	}

	@Test
	public void mainTest2()
	{
		boolean flag=true;
		try
		{
			String[] args =    { "TRANSACTION_DIM", "TRP", infoConfigPath.getPath(), "2","local", infoEnvPath.getPath() };
			InformationMartDriver.main(args);
		}
		catch(Exception e){
			logger.error("error in mainTest",e);
			flag=false;
		}
		org.junit.Assert.assertTrue(flag);

	}
	@Test
	public void mainTest3()
	{
		boolean flag=true;
		try
		{
			String[] args = {"TRANSACTION_DIM","TRP",infoConfigPath.getPath(),"jobId","local",infoEnvPath.getPath()};
			InformationMartDriver.main(args);
		}
		catch(Exception e){
			logger.error("error in mainTest",e);
			flag=false;
		}
		org.junit.Assert.assertTrue(flag);

	}

}
