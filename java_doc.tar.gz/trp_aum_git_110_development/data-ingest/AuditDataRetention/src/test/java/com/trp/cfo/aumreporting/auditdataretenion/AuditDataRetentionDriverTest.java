package com.trp.cfo.aumreporting.auditdataretenion;
import com.trp.cfo.aumreporting.auditretention.AuditDataRetentionDriver;
import com.trp.cfo.aumreporting.auditretention.services.DataRetentionProcess;
import com.trp.cfo.aumreporting.auditretention.services.impl.DataRetentionProcessImpl;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.mockito.Mockito;

import java.io.File;

public class AuditDataRetentionDriverTest
{
	private static final Logger      logger      =LogManager.getLogger(AuditDataRetentionDriverTest.class);
	private              ClassLoader classLoader = getClass().getClassLoader();
	private              File        configPath  = new File(classLoader.getResource("datamodelling_test2.csv").getFile());
	private              File        envPath     = new File(classLoader.getResource("EnvProperties.csv").getFile());

	@Test
	public void mainTest1(){
		boolean flag=true;
		String[] args = {"TRANSACTION_DIM","TRP",configPath.getPath(),"2","local",envPath.getPath()};
		DataRetentionProcess process=Mockito.mock(DataRetentionProcessImpl.class);
		try
		{
			AuditDataRetentionDriver.main(args);
		}
		catch(Exception e){
			logger.error("Exception mainTest1",e);
			flag=false;
		}
		org.junit.Assert.assertTrue(flag);
	}

	@Test
	public void mainTest2(){
		boolean flag=true;
		String[] args = {"TRANSACTION_DIM","TRP",configPath.getPath(),"n","local",envPath.getPath()};
		DataRetentionProcess process=Mockito.mock(DataRetentionProcessImpl.class);
		process.processAuditDataRetention(envPath.getAbsolutePath(),args[0],args[1],false);
		try
		{
			AuditDataRetentionDriver.main(args);
		}
		catch(Exception e){
			logger.error("Error in mainTest2",e);
			flag=false;
		}
		org.junit.Assert.assertTrue(flag);
	}

	@Test
	public void mainTest3(){
		boolean flag=true;
		String[] args = {"TRANSACTION_DIM","TRP",configPath.getPath(),"n","local"};
		;
		try
		{
			AuditDataRetentionDriver.main(args);
		}
		catch(Exception e){
			logger.error("Error in mainTest3",e);
			flag=false;
		}
		org.junit.Assert.assertTrue(flag);
	}


}
