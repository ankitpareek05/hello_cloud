package com.trp.cfo.aumreporting.auditdataretenion;

import com.trp.cfo.aumreporting.auditretention.services.DataRetentionProcess;
import com.trp.cfo.aumreporting.auditretention.services.impl.DataRetentionProcessImpl;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import java.io.File;

public class DataRetentionProcessTest
{
	private static final Logger      logger      =LogManager.getLogger(DataRetentionProcessTest.class);
	private  ClassLoader classLoader = getClass().getClassLoader();
	private  File        configPath  = new File(classLoader.getResource("test_auditdataretention.csv").getFile());

	@Before
	public void createSparkSession()
	{
		InitiateSparkSession.createSparkSession("local");

	}

	@Test
	public void processAuditDataRetentionTest(){
		boolean flag=true;
    	DataRetentionProcess dataRetentionProcess=new DataRetentionProcessImpl();
    	try
		{
			dataRetentionProcess.processAuditDataRetention(configPath.getAbsolutePath(), "DST", "DATA_RETENTION", false);
		}catch(Exception e){
    		flag=false;
    		logger.error("Error in processAuditDataRetentionTest",e);
		}

		org.junit.Assert.assertTrue(flag);
	}



}
