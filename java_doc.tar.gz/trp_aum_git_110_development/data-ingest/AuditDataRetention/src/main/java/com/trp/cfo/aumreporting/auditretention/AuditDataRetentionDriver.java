package com.trp.cfo.aumreporting.auditretention;

import com.trp.cfo.aumreporting.auditretention.services.DataRetentionProcess;
import com.trp.cfo.aumreporting.auditretention.services.impl.DataRetentionProcessImpl;
import com.trp.cfo.aumreporting.commonutils.EnvironmentVariable;
import com.trp.cfo.aumreporting.commonutils.GlobalVariable;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import java.io.Serializable;

public class AuditDataRetentionDriver implements Serializable
{
	private static final Logger logger = LogManager.getLogger(AuditDataRetentionDriver.class);

	public static void main(String[] args)
	{
		int inputArgumentLength = args.length;

		if (inputArgumentLength != 6) {
			logger.error("Invalid Number Of Arguments: Expected: 6, Received:" + inputArgumentLength);
		}
		else {
			String layerName = args[0];
			String sourceName = args[1];
			String srcConfigPath = args[2];

			int jobId = 0;
			InitiateSparkSession.createSparkSession(args[4]);
			try {
				jobId = Integer.parseInt(args[3]);
			}
			catch(NumberFormatException e) {
				logger.error("JobId is not a number:" + e.getMessage());
			}
			GlobalVariable.jobId = jobId;
			EnvironmentVariable.loadPropertiesFile(args[5]);
			DataRetentionProcess dataRetentionProcess = new DataRetentionProcessImpl();
			dataRetentionProcess.processAuditDataRetention(srcConfigPath, sourceName, layerName, true);
		}
	}
}
