package com.trp.cfo.aumreporting.auditretention.services.impl;

import com.trp.cfo.aumreporting.auditretention.services.DataRetentionProcess;
import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.DBUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.Tuple2;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getMapFromString;

public class DataRetentionProcessImpl implements DataRetentionProcess
{
	private static final Logger logger = LogManager.getLogger(DataRetentionProcessImpl.class);

	public void processAuditDataRetention(	String configFile, String srcName, String layerName, boolean flag)
	{
		Dataset<Row> config = CommonUtils.readFromCSVFile(configFile, "true", "");
		config = config.filter(config.col("ARCHITECTURE_LAYER").equalTo(layerName));
		config.show();
		Map<String, String> configData = config.rdd().toJavaRDD().mapToPair(x ->
				new Tuple2(x.getAs("KEY").toString(), x.getAs("VALUE").toString())
		).collectAsMap();

		configData.forEach((k, v) -> {
			Map<String, String> inputDetailsMap = getMapFromString(v);
			String	sfWareHouse =inputDetailsMap.getOrDefault("sf_warehouse", "NA");
			String	sfDataBase =inputDetailsMap.getOrDefault("sf_database", "NA");
			String sfSchema = inputDetailsMap.getOrDefault("sf_schema", "NA");
			int	retentionDays =	Integer.parseInt(inputDetailsMap.get("retention_days"));
			String	columnNameFilter =inputDetailsMap.getOrDefault("filter_column_name", "NA");
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.DATE, -retentionDays);
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
			String date = simpleDateFormat.format(calendar.getTime());
			String	sql ="delete from " + k + " where " + columnNameFilter + "<'"+ date + "'";
			if(flag) {
				try {
					DBUtils.deleteTableRecords(sfWareHouse, sfDataBase, sql, sfSchema);
				}
				catch(Exception e) {
					logger.error("Delete query failed::" + e.getMessage(), e);
				}
			}
		});

	}
}
