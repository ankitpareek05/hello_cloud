package com.trp.cfo.aumreporting.auditretention.services;

import java.io.Serializable;

public interface DataRetentionProcess extends Serializable
{
	public void processAuditDataRetention(String configFile,String srcName,String layerName,boolean flag) ;
}
