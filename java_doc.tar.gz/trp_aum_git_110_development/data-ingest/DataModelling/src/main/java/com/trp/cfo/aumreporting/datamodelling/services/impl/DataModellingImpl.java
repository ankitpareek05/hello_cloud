package com.trp.cfo.aumreporting.datamodelling.services.impl;

import com.trp.cfo.aumreporting.datamodelling.services.DataModellingService;
import com.trp.cfo.aumreporting.datamodelling.utils.DataModellingUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;
import java.util.Map;

public class DataModellingImpl implements DataModellingService,Serializable
{
	private static final Logger logger = LogManager.getLogger(DataModellingImpl.class);

	@Override
	public String dataModellingProcess(Map<String, String> configMap, SparkSession spark, String archNameWithActionName) throws Exception
	{
		String result = null;
		try {
			DataModellingUtils.dataModelProcess(archNameWithActionName, configMap, spark);
			result = "SUCCESS";
		}
		catch(Exception e) {
			logger.error("Exception in DataModellingImpl:"+e.getMessage(),e);
			throw e;
		}
		return result;
	}

}
