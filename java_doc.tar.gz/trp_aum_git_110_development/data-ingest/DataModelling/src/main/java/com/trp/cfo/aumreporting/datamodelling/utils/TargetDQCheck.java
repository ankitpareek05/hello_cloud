package com.trp.cfo.aumreporting.datamodelling.utils;

import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Decimal;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import scala.Serializable;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.Iterator;

import static com.trp.cfo.aumreporting.commonutils.DBUtils.readFromSnowflakeQuery;
import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.current_date;
import static org.apache.spark.sql.functions.expr;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.monotonically_increasing_id;

public class TargetDQCheck implements Serializable
{

	private              String processDate;
	private              String errType;
	private              String errCol;
	private static final Logger logger = LogManager.getLogger(TargetDQCheck.class);

	TargetDQCheck()
	{
		this.processDate = "Processed_Date";
		this.errType = "ErrType";
		this.errCol = "ErrCol";
	}

	TargetDQCheck(String processDate, String errType, String errCol)
	{
		this.processDate = processDate;
		this.errCol = errCol;
		this.errType = errType;

	}

	public Tuple2<Dataset<Row>, Dataset<Row>> getDQCheck(SparkSession spark, Dataset<Row> mainDF, String sfWarehouse, String sfReadDbName, String sfReadTableSchema, String sfReadDbTable)
			throws IngestException
	{

		final String nullColsQuery =
				"select column_name from " + sfReadDbName + ".INFORMATION_SCHEMA.COLUMNS " + "where table_name = '" + sfReadDbTable + "' and is_nullable = 'NO' and table_schema = '"
						+ sfReadTableSchema + "'";

		final String precisionColsQuery =
				"select column_name, case when DATA_TYPE='NUMBER' THEN " + "NUMERIC_PRECISION||'-'||NUMERIC_SCALE END DATA_TYPE from " + sfReadDbName + ".INFORMATION_SCHEMA.COLUMNS "
						+ "where table_name = '" + sfReadDbTable + "' and data_type = 'NUMBER' and table_schema = '" + sfReadTableSchema + "'";

		Dataset snowflakeNullSchemaDF = readFromSnowflakeQuery(nullColsQuery, sfWarehouse, sfReadDbName, sfReadTableSchema, null);

		Dataset<Row> snowflakePrecisionSchemaDF = readFromSnowflakeQuery(precisionColsQuery, sfWarehouse, sfReadDbName, sfReadTableSchema, null);
		String rowID = "rowID";
		mainDF = mainDF.withColumn(rowID, monotonically_increasing_id().cast(DataTypes.StringType));
		mainDF.persist(StorageLevel.MEMORY_AND_DISK());

		// Get the Null Error Records -
		Dataset<Row> nullDF = getNullData(spark, mainDF, snowflakeNullSchemaDF);
		nullDF.persist(StorageLevel.MEMORY_AND_DISK());

		// Get the Precision Error Records -
		Dataset<Row> precisionDF = getPrecisionData(spark, mainDF, snowflakePrecisionSchemaDF);
		precisionDF.persist(StorageLevel.MEMORY_AND_DISK());

		// Union Both the data -
		Dataset<Row> finalErrorDF = nullDF.union(precisionDF);
		finalErrorDF.persist(StorageLevel.MEMORY_AND_DISK());

		// Subtracting Main DF with Error DF -
		Dataset<Row> finalMainDF = mainDF.alias("mainDF")
				.join(finalErrorDF.select(rowID).distinct().alias("finalDF"), expr("mainDF.rowID = finalDF.rowID"), "left_anti")
				.selectExpr("mainDF.*")
				.drop(rowID);
		mainDF.unpersist();
		nullDF.unpersist();
		precisionDF.unpersist();

		return new Tuple2(finalMainDF, finalErrorDF.drop(rowID));

	}

	private Dataset<Row> getNullData(SparkSession spark, Dataset<Row> df, Dataset<Row> snowflakeSchemaDF)
	{

		// Getting all the columns into Array -
		Row[] dataRows = (Row[]) snowflakeSchemaDF.collect();
		ArrayList<String> cols = new ArrayList<String>();
		for (Row row : dataRows)
		{
			cols.add(row.getString(0));
		}
		Dataset<Row> nullDF = spark.emptyDataFrame();

		// Iterating over all the columns to get null Records
		for (int i = 0; i < cols.size(); i++)
		{
			logger.info("Running Null Check for - " + cols.get(i));
			String expr = cols.get(i) + " is null or " + cols.get(i) + " = 'null'";

			Dataset<Row> interimNullDF = df.filter(expr(expr));

			interimNullDF = interimNullDF.select(lit(current_date()).as(processDate), lit("Null_Check").alias(errType), lit(cols.get(i)).alias(errCol), col("*"));

			if (i == 0)
			{
				nullDF = interimNullDF;
			}
			else
			{
				nullDF = nullDF.union(interimNullDF);
			}
		}
		return nullDF;
	}

	private Dataset<Row> getPrecisionData(SparkSession spark, Dataset<Row> df, Dataset<Row> snowflakePrecisionSchemaDF)
	{

		//Getting all the columns into Array -
		Row[] dataRows = (Row[]) snowflakePrecisionSchemaDF.collect();
		// Column List with precision values List([colValue, precision],[],..)
		ArrayList<ArrayList<String>> precisionList = new ArrayList<ArrayList<String>>();

		for (Row row : dataRows)
		{
			ArrayList<String> col = new ArrayList<String>();
			col.add(row.getString(0));
			col.add(row.getString(1));

			precisionList.add(col);
		}
		logger.info("Precision Columns - " + precisionList);
		// Getting the schema from MainDF -
		StructType mainDFSchema = df.schema();
		StructField errTypeSchema = new StructField(errCol, DataTypes.StringType, true, Metadata.empty());
		StructType finalSchema = new StructType();

		finalSchema = finalSchema.add(errTypeSchema);
		for (StructField sf : mainDFSchema.fields())
		{
			finalSchema = finalSchema.add(new StructField(sf.name(), DataTypes.StringType, true, Metadata.empty()));
		}

		// Creating an Error Row for each precision Column -
		JavaRDD<ArrayList<Row>> precisionRows = df.rdd().toJavaRDD().map(new Function<Row, ArrayList<Row>>()
		{

			@Override
			public ArrayList<Row> call(Row row)
					throws Exception
			{
				ArrayList<Row> rowList = new ArrayList<>();
				logger.info("######");
				logger.info("Running for Row - " + row);
				for (ArrayList<String> precisions : precisionList)
				{
					logger.info("Running Precision Check for - " + precisions);

					Object obj = row.getAs(precisions.get(0));
					String rowValue = getValueFromObj(obj);

					if (rowValue == null || rowValue.isEmpty())
					{
						String[] rows = (precisions.get(0) + " " + precisions.get(1) + "," + row.mkString(",")).split(",");
						rowList.add(RowFactory.create(rows));
					}
					else
					{
						Boolean match = checkPrecision(rowValue.toString(), precisions.get(1));
						if (!match)
						{
							String[] rows = (precisions.get(0) + " " + precisions.get(1) + "," + row.mkString(",")).split(",");
							logger.info("row - " + precisions + " - " + rows);
							rowList.add(RowFactory.create(rows));
						}
						else
						{
							String[] rows = null;
						}
					}
				}

				return rowList;
			}
		}).filter(x -> x != null);

		JavaRDD<Row> rowRdd1 = precisionRows.flatMap(new FlatMapFunction<ArrayList<Row>, Row>()
		{
			@Override
			public Iterator<Row> call(ArrayList<Row> rows)
					throws Exception
			{
				return rows.iterator();
			}
		});

		Dataset<Row> precisionErrorDF = spark.createDataFrame(rowRdd1, finalSchema);

		precisionErrorDF = precisionErrorDF.select(lit(current_date()).as(processDate)
				, lit("Precision_Check").as(errType)
				, col("*"));

		return precisionErrorDF;
	}

	private Boolean checkPrecision(String colValue, String precisionValue)
	{
		// Get the list of precision column and precision value
		try
		{
			String[] precisionList = precisionValue.split("-");

			Integer precisionMax = Integer.parseInt(precisionList[0].trim());
			Integer precisionScale = Integer.parseInt(precisionList[1].trim());

			Integer maxIntBeforeDot = precisionMax - precisionScale;

			if (precisionScale == 0)
			{
				String pattern = "^\\d{1," + maxIntBeforeDot + "}(\\.0)?$";
				Boolean match = colValue.matches(pattern);
				return match;
			}
			else
			{
				String pattern = "^\\d{1," + maxIntBeforeDot + "}(\\.\\d{1," + precisionScale + "})?$";
				Boolean match = colValue.matches(pattern);
				return match;
			}
		}
		catch(Exception e)
		{
			logger.info(e);
			return false;
		}

	}

	private String getValueFromObj(Object obj)
	{
		String rowValue = "";
		try
		{

			if (obj instanceof Long)
			{
				Long rowValueInt = (Long) obj;
				rowValue = String.valueOf(rowValueInt);
			}
			else if (obj instanceof Double)
			{
				Double rowValueDou = (Double) obj;
				rowValue = rowValueDou.toString();
			}
			else if (obj instanceof Decimal)
			{
				Decimal rowValueDecimal = (Decimal) obj;
				rowValue = rowValueDecimal.toString();
			}
			else if (obj instanceof Integer)
			{
				Integer rowValueInt = (Integer) obj;
				rowValue = rowValueInt.toString();
			}
			else if (obj instanceof Number)
			{
				Number rowValueNumber = (Number) obj;
				rowValue = rowValueNumber.toString();
			}
			else if (obj instanceof String)
			{
				String rowValueString = (String) obj;
				rowValue = rowValueString.toString();
			}

		}
		catch(NullPointerException n)
		{
			rowValue = null;
		}
		return rowValue;
	}

}
