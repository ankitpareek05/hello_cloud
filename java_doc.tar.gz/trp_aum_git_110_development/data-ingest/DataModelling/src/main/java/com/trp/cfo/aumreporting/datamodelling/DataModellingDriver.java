package com.trp.cfo.aumreporting.datamodelling;

import com.trp.cfo.aumreporting.commonutils.AuditLog;
import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.GlobalVariable;
import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import com.trp.cfo.aumreporting.datamodelling.services.DataModellingService;
import com.trp.cfo.aumreporting.datamodelling.services.impl.DataModellingImpl;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;
import java.util.stream.Collectors;

public class DataModellingDriver implements Serializable
{
	private static final Logger logger = LogManager.getLogger(DataModellingDriver.class);
	private static final String STAGE_TO_TARGET = "STAGETOTARGET";

	public static void main(String[] args) throws Exception
	{
		Logger.getLogger("org").setLevel(Level.OFF);
		Logger.getLogger("akka").setLevel(Level.OFF);
		Logger.getLogger("org.apache.spark.SparkContext").setLevel(Level.WARN);
		Logger.getLogger("org.apache.spark.SparkContext").setLevel(Level.ERROR);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		Map<String, String> configData;

		if (CommonUtils.parseCommandlineArgs(args)) {
			SparkSession spark = InitiateSparkSession.getSparkSession();
			String startTime = format.format(Calendar.getInstance().getTime());
			try {
				configData = CommonUtils.parseConfigFile(GlobalVariable.configInputPath, GlobalVariable.fileName, GlobalVariable.sourceName, STAGE_TO_TARGET);
				String processJob = CommonUtils.checkJobProcess(spark, configData, STAGE_TO_TARGET);

				if (processJob.equalsIgnoreCase("true")) {
					String processString = CommonUtils.getValue("_PROCESSES", configData);
					DataModellingService dataModellingService = new DataModellingImpl();

					if (processString != null && !(processString.isEmpty())) {
						String[] processList = processString.split("\\|\\|");
						for (String processName : processList) {
							logger.info("Running DataModel for :" + processName);
							Map<String, String> processConfigMap = configData.entrySet().stream()
									.filter(map -> map.getKey().contains(processName))
									.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
							dataModellingService.dataModellingProcess(processConfigMap, spark, STAGE_TO_TARGET + "_" + processName);
						}
					}
				}
			} catch (Exception e) {
				String endTime = format.format(Calendar.getInstance().getTime());
				new AuditLog().auditEntry("cfo_scheduler_data.cfo_scheduler_process_runlog", "APPEND", GlobalVariable.fileName, startTime,
						endTime, "FAILURE", STAGE_TO_TARGET, 0L, 0L, 0L, GlobalVariable.jobId, null, "Ingestion",
						String.valueOf(java.time.LocalDate.now()));
				logger.error("Failed to run Stage to Target service", e);
				throw new IngestException("Failed to run Stage to Target service: " + e.getMessage());
			}
		}
	}

}
