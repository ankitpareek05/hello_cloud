package com.trp.cfo.aumreporting.datamodelling.utils;

import com.trp.cfo.aumreporting.commonutils.AuditLog;
import com.trp.cfo.aumreporting.commonutils.CommonUtils;
import com.trp.cfo.aumreporting.commonutils.DBUtils;
import com.trp.cfo.aumreporting.commonutils.GlobalVariable;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.io.Serializable;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.trp.cfo.aumreporting.commonutils.CommonUtils.getMapFromString;
import static com.trp.cfo.aumreporting.commonutils.CommonUtils.writeToCSVFile;
import static com.trp.cfo.aumreporting.commonutils.DBUtils.writeToSnowflake;

public class DataModellingUtils implements Serializable
{
	private static final Logger logger       = LogManager.getLogger(DataModellingUtils.class);
	public static final  String SF_WAREHOUSE = "sf_warehouse";
	public static final  String SF_DATABASE  = "sf_database";

	/**
	 *
	 * @param archNameWithActionName
	 * @param configData
	 * @param spark
	 * @throws SQLException
	 */
	/*dataModelProcess is the core method for datamodelling.ConfigData is map which contains input<n>,sqlQueries<n>,output<n>,and merge queries.
	1.From input we are reading them in spark and creating the dataframe and registering them as view as define in config file.
	2.We ran the sql queries on the view created in point 1.These sqlQueries is main business logic.
	3.OutPut is where we need to write the final output .In our case we are writing in snowflake temp tables.(Temp tables are created on fly).
	4.Merge Queries are finally merging the data from temp tables to final table.
	*/
	public static void dataModelProcess(
			String archNameWithActionName,
			Map<String, String> configData,
			SparkSession spark)
			throws Exception
	{
		long srcCount = CommonUtils.loadDataToSpark(archNameWithActionName, configData, spark);

		// Get all the SQL queries to be executed
		List<String> expectedSQLQueries = configData.keySet().stream().filter(x -> x.contains("SQL_QUERY")).collect(Collectors.toList());
		logger.info(":::" + expectedSQLQueries);
		List<String> expectedMergeQueries = configData.keySet().stream().filter(x -> x.contains("MERGE_QUERY")).collect(Collectors.toList());

		// run the sql transform queries
		long finalCount = 0L;
		long errCount = 0L;
		for (int i = 1; i <= expectedSQLQueries.size(); i++)
		{
			String sqlQueryDetails = configData.get(archNameWithActionName + "_SQL_QUERY" + i);
			logger.info("printing SQLquerydetails" + sqlQueryDetails);
			Map<String, String> sqlQueryMap = getMapFromString(sqlQueryDetails);
			String type = sqlQueryMap.get("type");
			String sqlQuery = sqlQueryMap.get("query");

			String outputDetails = configData.getOrDefault(archNameWithActionName + "_OUTPUT_DETAILS" + i, "NA");
			logger.info("Running " + type + " " + sqlQuery);
			Dataset<Row> df1 = spark.sql(sqlQuery);
			df1.persist(StorageLevel.MEMORY_AND_DISK());
			if ("sql_suspend".equalsIgnoreCase(type))
			{
				errCount = df1.count();
			}

			String dqChecksDetails = configData.getOrDefault(archNameWithActionName + "_DQCHECK_DETAILS" + i, "NA");
			if (!"NA".equalsIgnoreCase(dqChecksDetails))
			{
				logger.info("Running  DQ Checks For Null and Number Precision");
				Map<String, String> dqCheckDetailsMap = getMapFromString(dqChecksDetails);

				String fileFormat = dqCheckDetailsMap.getOrDefault("file_format", "NA");
				String header = dqCheckDetailsMap.getOrDefault("header", "true");
				String sfWareHouse = dqCheckDetailsMap.getOrDefault(SF_WAREHOUSE, "NA");
				String sfDataBase = dqCheckDetailsMap.getOrDefault(SF_DATABASE, "NA");
				String sfSchema = dqCheckDetailsMap.getOrDefault("sf_schema", "NA");
				String sfTableName = dqCheckDetailsMap.getOrDefault("sf_table", "NA");
				String outputPath = dqCheckDetailsMap.getOrDefault("path", "NA");
				String mode = dqCheckDetailsMap.getOrDefault("mode", "overwrite");
				String sfReadDB = dqCheckDetailsMap.get("sf_target_read_db");
				String sfReadSchema = dqCheckDetailsMap.get("sf_target_read_schema");
				String sfReadTable = dqCheckDetailsMap.get("sf_target_read_table");

				TargetDQCheck dq = new TargetDQCheck();
				Tuple2<Dataset<Row>, Dataset<Row>> data = dq.getDQCheck(spark, df1, sfWareHouse, sfReadDB, sfReadSchema, sfReadTable);

				df1 = data._1;
				df1.persist(StorageLevel.MEMORY_AND_DISK());
				df1.show();

				data._2.persist(StorageLevel.MEMORY_AND_DISK());
				data._2.show(100, false);
				switch (fileFormat)
				{
					case "csv":
						writeToCSVFile(data._2, outputPath, header, mode);
						break;
					case "parquet":
						break;
					case "table":
						writeToSnowflake(data._2, sfWareHouse, sfDataBase, sfSchema, sfTableName, mode);
						break;
					default:
						break;
				}

			}

			if (!"NA".equalsIgnoreCase(outputDetails))
			{
				logger.info("----going in output---");
				Map<String, String> outputDetailsMap = getMapFromString(outputDetails);

				String outputPath = outputDetailsMap.getOrDefault("path", "NA");
				String fileFormat = outputDetailsMap.getOrDefault("file_format", "NA");
				String header = outputDetailsMap.getOrDefault("header", "true");
				String sfWareHouse = outputDetailsMap.getOrDefault(SF_WAREHOUSE, "NA");
				String sfDataBase = outputDetailsMap.getOrDefault(SF_DATABASE, "NA");
				String sfSchema = outputDetailsMap.getOrDefault("sf_schema", "NA");
				String sfTableNameToExport = outputDetailsMap.getOrDefault("sf_table", "NA");
				String mode = outputDetailsMap.getOrDefault("mode", "overwrite");

				logger.info("Writing DataFrame to output path");

				switch (fileFormat)
				{
					case "csv":
						writeToCSVFile(df1, outputPath, header, mode);
						break;
					case "table":
						writeToSnowflake(df1, sfWareHouse, sfDataBase, sfSchema, sfTableNameToExport, mode);
						finalCount = df1.count();
						break;
					default:
						break;
				}
				df1.unpersist();
			}
		}

		// run the merge queries
		for (int i = 1; i <= expectedMergeQueries.size(); i++)
		{
			String mergeQueryDetails = configData.get(archNameWithActionName + "_MERGE_QUERY" + i);
			Map<String, String> outputDetailsMap = getMapFromString(mergeQueryDetails);
			String mergeQuery = outputDetailsMap.getOrDefault("query", "NA");
			String sfWareHouse = outputDetailsMap.getOrDefault(SF_WAREHOUSE, "NA");
			String sfDataBase = outputDetailsMap.getOrDefault(SF_DATABASE, "NA");
			String sfTbl = outputDetailsMap.getOrDefault("sf_tbl", "NA");
			String sfType = outputDetailsMap.getOrDefault("sf_type", "NA");
			DBUtils.mergeTarget(sfWareHouse, sfDataBase, mergeQuery);

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String startTime = format.format(Calendar.getInstance().getTime());
			String endTime = format.format(Calendar.getInstance().getTime());
			new AuditLog().auditEntry("cfo_scheduler_data.cfo_scheduler_process_runlog", "APPEND", sfTbl + "_" + sfType, startTime, endTime, "SUCCESS", "STAGETOTARGET",
					srcCount, finalCount, errCount, GlobalVariable.jobId, null, "Ingestion", String.valueOf(java.time.LocalDate.now()));
			logger.info("******" + mergeQuery);

		}

	}
}
