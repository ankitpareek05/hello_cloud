package com.trp.cfo.aumreporting.datamodelling.services;

import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import org.apache.spark.sql.SparkSession;

import java.util.Map;

public interface DataModellingService
{
	public String dataModellingProcess(Map<String, String> map, SparkSession spark, String archNameWithActionName)
			throws
			Exception;

}
