package com.trp.cfo.aumreporting.datamodelling;

import com.trp.cfo.aumreporting.commonutils.InitiateSparkSession;
import com.trp.cfo.aumreporting.datamodelling.services.DataModellingService;
import com.trp.cfo.aumreporting.datamodelling.services.impl.DataModellingImpl;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.SparkSession;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataModelDriverTest
{
	private static final Logger logger = LogManager.getLogger(DataModelDriverTest.class);

	private ClassLoader classLoader = getClass().getClassLoader();
	private File configPath = new File(classLoader.getResource("datamodelling_test2.csv").getFile());
	private File envPath = new File(classLoader.getResource("EnvProperties.csv").getFile());
	private File errorConfigPath = new File(classLoader.getResource("datamodelling_error_test.csv").getFile());

	private File configPath2 =new File(classLoader.getResource("ff_IDM_TAUMD_TRN_TYP.csv").getFile());
	private File configPath3 =new File(classLoader.getResource("property_type_value.csv").getFile());
	private File configPath4 =new File(classLoader.getResource("transaction_type_dim.csv").getFile());


	@Test
	public void mainTest()
	{
		boolean flag=true;
		try
		{
			String[] args = {"TRANSACTION_DIM","TRP",configPath.getPath(),"2","local",envPath.getPath()};
			DataModellingDriver.main(args);
		}
		catch(Exception e){
			logger.error("error in mainTest",e);
			flag=false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void mainTest2()
	{
		boolean flag=true;
		try
		{
			String[] args = {"TRANSACTION_DIM","TRP",configPath.getPath(),"2","local"};
			DataModellingDriver.main(args);
		}
		catch(Exception e){
			logger.error("error in mainTest",e);
			flag=false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void mainTest3()
	{
		boolean flag=true;
		try
		{
			String[] args = {"TRANSACTION_DIM","TRP",configPath.getPath(),"jobId","local",envPath.getPath()};
			DataModellingDriver.main(args);
		}
		catch(Exception e){
			logger.error("error in mainTest",e);
			flag=false;
		}
		Assert.assertTrue(flag);
	}


	@Test
	public void dataModellingProcessServiceTest()
	{
		SparkSession spark = InitiateSparkSession.getSparkSession();
		String result = "FAILURE";
		DataModellingService dataModellingService = new DataModellingImpl();
		int count = 0;
		try
		{
			List<Map<String, String>> list = getTestMap();
			for (Map<String, String> configData : list)
			{
				count++;
				result =
						dataModellingService.dataModellingProcess(configData,
								spark, "STAGETOTARGET_TRANSACTION");
				if (count == 1)
				{
					org.junit.Assert.assertEquals("SUCCESS", result);
				}
			}
		}
		catch(Exception e)
		{
			result = "FAILURE";
			logger.info(e.getMessage());
		}
		if (count > 1)
		{
			org.junit.Assert.assertEquals("FAILURE", result);
		}

	}

	public List<Map<String, String>> getTestMap()
	{
		Map<String, String> map = new HashMap<String, String>();
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS1",
				"path=" + configPath2
						+ "|| file_format = csv || header=true || view_name =ff_IDM_TAUMD_TRN_TYP || sep=NA ||db_type = snowflake ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS2",
				"path=" + configPath4
						+ " || file_format = csv || header=true || view_name =transaction_type_dim|| sep=NA ||db_type = snowflake ||table_name=NA");
		map.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS3",
				"path=" + configPath3
						+ " || file_format = csv || header=true || view_name =PROPERTY_TYPE_VALUE_REF|| sep=NA ||db_type = snowflake ||table_name=NA ");
		map.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS1", "NA");
		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY1",
				" Type =sql || query = CREATE TEMPORARY VIEW  TRANSACTIONFACT AS "
						+ "(Select            null As TRANSACTION_TYPE_ID,NULL AS CREATE_TMSTP,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER "
						+ " AS TRANSACTION_TYPE_IDENTIFIER,                ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_NAME AS TRANSACTION_TYPE_NAME,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_CATEGORY_NAME AS "
						+ "TRANSACTION_CATEGORY_NAME,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE AS BALANCE_CHANGE_CODE,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE As TRANSACTION_AMOUNT_SIGN_CODE,ff_IDM_TAUMD_TRN_TYP.TRADE_STATUS_CODE AS "
						+ "TRADE_STATUS_CODE,transaction_type_dim.idm_ods_transaction_type_id AS IDM_ODS_TRANSACTION_TYPE_ID FROM ff_IDM_TAUMD_TRN_TYP LEFT OUTER JOIN "
						+ "transaction_type_dim ON ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER=transaction_type_dim.idm_ods_transaction_type_id)");
		map.put("STAGETOTARGET_PROCESSES_PROCESS_LIST", "TRANSACTION");
		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY2",
				"Type = sql || query = CREATE TEMPORARY VIEW  SOURCEVIEW AS (SELECT * FROM TRANSACTIONFACT)");

		map.put("STAGETOTARGET_TRANSACTION_SQL_QUERY3",
				"Type = sql || query =CREATE TEMPORARY VIEW  TRANSACTIONFACTUNION AS(SELECT * FROM SOURCEVIEW)");

		map.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS2", "NA");

		Map<String, String> map1 = new HashMap<String, String>();
		map1.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS1",
				"path=" + configPath2+ "|| file_format = csv || header=true || view_name = ff_IDM_TAUMD_TRN_TYP || sep=NA ||db_type = snowflake ||table_name=NA");
		map1.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS2",
				"path=" + configPath4
						+ " || file_format = csv || header=true || view_name =transaction_type_dim|| sep=NA ||db_type = snowflake ||table_name=NA");
		map1.put("STAGETOTARGET_TRANSACTION_INPUT_DETAILS3",
				"path=" + configPath3
						+ " || file_format = csv || header=true || view_name =PROPERTY_TYPE_VALUE_REF|| sep=NA ||db_type = snowflake ||table_name=NA ");
		map1.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS1", "NA");
		map1.put("STAGETOTARGET_TRANSACTION_SQL_QUERY1",
				" Type =sql || query = CREATE TEMPORARY VIEW  TRANSACTIONFACT AS "
						+ "(Select            null As TRANSACTION_TYPE_ID,NULL AS CREATE_TMSTP,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER "
						+ " AS TRANSACTION_TYPE_IDENTIFIER,                ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_NAME AS TRANSACTION_TYPE_NAME,ff_IDM_TAUMD_TRN_TYP.TRANSACTION_CATEGORY_NAME AS "
						+ "TRANSACTION_CATEGORY_NAME,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE AS BALANCE_CHANGE_CODE,ff_IDM_TAUMD_TRN_TYP.BALANCE_CHANGE_CODE As TRANSACTION_AMOUNT_SIGN_CODE,ff_IDM_TAUMD_TRN_TYP.TRADE_STATUS_CODE AS "
						+ "TRADE_STATUS_CODE,transaction_type_dim.idm_ods_transaction_type_id AS IDM_ODS_TRANSACTION_TYPE_ID FROM ff_IDM_TAUMD_TRN_TYP LEFT OUTER JOIN "
						+ "transaction_type_dim ON ff_IDM_TAUMD_TRN_TYP.TRANSACTION_TYPE_IDENTIFIER=transaction_type_dim.idm_ods_transaction_type_id)");
		map1.put("STAGETOTARGET_PROCESSES_PROCESS_LIST", "TRANSACTION");
		map1.put("STAGETOTARGET_TRANSACTION_SQL_QUERY2",
				"Type = sql || query = CREATE TEMPORARY VIEW  SOURCEVIEW AS (SELECT TRANSACTIONFACT.Employee FROM TRANSACTIONFACT)");
		map1.put("STAGETOTARGET_TRANSACTION_SQL_QUERY3",
				"Type = sql || query =CREATE TEMPORARY VIEW  TRANSACTIONFACTUNION AS(SELECT * FROM SOURCEVIEW)");
		map1.put("STAGETOTARGET_TRANSACTION_OUTPUT_DETAILS2", "NA");
		List<Map<String, String>> list = Arrays.asList(map, map1);

		return list;
	}

}
