package com.trp.cfo.aumreporting.commonutils.exception;

public class SecretsException extends Exception {

    private static final long serialVersionUID = 1L;
    private String errorMsg = "";

    public SecretsException() {
        super();
    }
    public SecretsException(String errorMsg) {
        super(errorMsg);
        this.errorMsg = errorMsg;
    }
    public SecretsException(String errorMsg, Throwable e) {
        super(errorMsg, e);
        this.errorMsg = errorMsg;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
