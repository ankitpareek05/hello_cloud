package com.trp.cfo.aumreporting.commonutils;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import scala.Tuple2;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.trp.cfo.aumreporting.commonutils.DBUtils.readFromSnowflake;
import static com.trp.cfo.aumreporting.commonutils.DBUtils.readFromPostgresql;
import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.concat;
import static org.apache.spark.sql.functions.lit;
import static org.apache.spark.sql.functions.upper;

public class CommonUtils implements Serializable
{
	private static final Logger	logger    =LogManager.getLogger(CommonUtils.class);
	/**
	 * This method is used to return an empty map which is used in test class
	 *
	 * @param s This is accepting data frame reader object
	 * @return This returns a new empty map
	 *
	 */
	private static final String VALUE              = "VALUE";
	private static final String KEY                = "KEY";
	public static final  String HEADER             = "header";
	public static final  String HEADER_REQUIRED    = "headerRequired";
	public static final  String HEADER_TARGET_PATH = "HeaderTargetPath";
	public static final  String FILE_NAME          = "FileName";
	public static final  String OVERWRITE          = "OVERWRITE";
	public static final  String PROCESS_DATE       = "ProcessDate";
	public static final  String PROCESSED          = "processed/";

	/**
	 *This is to parse the config file
	 *
	 * @param inputConfigPath This is path of the config file to be parsed
	 * @param fileName This is the file name for which config file to be parsed for
	 * @param srcName This is source name for which we are executing
	 * @param layerName This is the layer name parameter
	 * @return
	 * @throws IOException
	 *
	 */
	public static Map<String, String> parseConfigFile(String inputConfigPath,String fileName,String srcName,String layerName)	throws IOException
	{
		Dataset<Row> configDf = readFromCSVFile(inputConfigPath, "TRUE", "");
		configDf.show();
		setEnvVariables(layerName);
		configDf =configDf.filter((upper(col("ARCHITECTURE_LAYER")).equalTo(layerName.trim().toUpperCase())
						.and(upper(col("FILE_NAME")).equalTo(fileName.trim().toUpperCase()))
						.and(upper(col("SOURCE_NAME")).equalTo(srcName.trim().toUpperCase()))));
		configDf =configDf.withColumn(KEY,concat(col("ARCHITECTURE_LAYER"), lit("_"),col("ACTION"), lit("_"), col(KEY))).withColumn(VALUE, col(VALUE));
		return configDf.rdd().toJavaRDD().mapToPair(x -> new Tuple2(x.getAs(KEY).toString(),x.getAs(VALUE).toString())).collectAsMap();

	}

	/**
	 *This is to set layer name env variable
	 *
	 * @param layerName This is layer name
	 */
	private static void setEnvVariables(String layerName)
	{
		GlobalVariable gv = new GlobalVariable();
		gv.setLayername(layerName);
		logger.info(gv.getLayername());
	}

	/**
	 * This is to get a map for a given string
	 * @param str input string to get map
	 * @return Map config data related to the given input string
	 */
	public static Map<String, String> getMapFromString(String str)
	{
		String[] s = str.split("\\|\\|");
		Map<String, String> strToMap = new HashMap<>();
		for (int i = 0; i < s.length; i++)
		{
			String[] t = s[i].split("=", 2);
			for (int j = 0; j < t.length; j++)
			{
				strToMap.put(t[0].trim(), t[1].trim());
			}
		}
		return strToMap;
	}

	/**
	 * This method is used to read the input file using spark session and returns a dataset of result
	 *
	 * @param inputPath Path of the file to be read
	 * @param headerRequired Do you need header when you read the file?
	 * @param prefixForColumns Do you want any prefix for the columns?
	 * @return Dataset with data from input file
	 */
	public static Dataset<Row> readFromCSVFile(String inputPath,String headerRequired,String prefixForColumns)
	{
		try {
			logger.info("Reading data from path - " + inputPath);
			SparkSession spark = InitiateSparkSession.getSparkSession();
			Dataset<Row> inputDS = spark.read().option(HEADER, headerRequired)
					.option("inferSchema", "true")
					.option("ignoreLeadingWhiteSpace", "true")
					.option("ignoreTrailingWhiteSpace", "true")
					.option("multiLine", true)
					.csv(inputPath)
					.repartition(calculateSizeAndRepartition(inputPath));
			return prefixColumnName(prefixForColumns, inputDS);
		}
		catch(Exception e) {
			logger.info(e.getMessage());
			throw e;
		}
	}

	/**
	 * This method is used to iterate over each column in dataset collection
	 * and prefix with desired string if prefixForColumns is not empty
	 * @param prefixForColumns Prefix string
	 * @param inputDS Dataset for which prefix to be applied
	 * @return Dataset with columns renamed
	 */
	public static Dataset<Row> prefixColumnName(String prefixForColumns, Dataset<Row> inputDS)
	{
		if ("".equals(prefixForColumns)) {
			return inputDS;
		}
		else {
			Dataset<Row> newInputDs = inputDS;
			for (String column : inputDS.columns()) {
				newInputDs = newInputDs.withColumnRenamed(column,prefixForColumns + column);
			}
			return newInputDs;
		}
	}

	/**
	 * This method is used to read the input file using spark session and returns a dataset of result
	 *
	 * @param inputPath Path of the file to be read
	 * @param delimiter Delimiter of the input file
	 * @param headerRequired Do you need header when you read the file?
	 * @param prefixForColumns Do you want any prefix for the columns?
	 * @return Dataset with data from input file
	 *
	 */
	public static Dataset readFromDelimiterFile(String inputPath,String delimiter,String headerRequired,String prefixForColumns)
	{

		try
		{
			logger.info("Reading data from path - " + inputPath);
			SparkSession spark = InitiateSparkSession.getSparkSession();
			Dataset<Row> inputDS = spark.read().option(HEADER, headerRequired)
					.option("inferSchema", "true")
					.option("sep", delimiter)
					.option("ignoreLeadingWhiteSpace", "true")
					.option("ignoreTrailingWhiteSpace", "true")
					.option("multiLine", true)
					.csv(inputPath)
					.repartition(calculateSizeAndRepartition(inputPath));
			return prefixColumnName(prefixForColumns, inputDS);
		}
		catch(Exception e)
		{
			logger.info(e.getMessage());
			throw e;
		}

	}

	public static String getValue(String key, Map<String, String> map)
	{
		return map.entrySet()
				.stream()
				.filter(x -> x.getKey().contains(key))
				.map(Map.Entry::getValue)
				.collect(Collectors.joining());
	}

	/**
	 * This method is used to write the dataset to a csv file using spark session with | delimiter
	 *
	 * @param mainDF Input data set to be written to a file
	 * @param outputPath Ouput path of file
	 * @param headerPresent Do you need header or not?
	 * @param writeMode overwrite or append?
	 */
	public static void writeToCSVFile(
			Dataset mainDF,
			String outputPath,
			String headerPresent,
			String writeMode)
	{
		logger.info("Writing Delimited data to path - " + outputPath);
		mainDF.coalesce(1).write().option(HEADER, headerPresent)
				.option("sep", "|")
				.mode(writeMode)
				.csv(outputPath);
	}

	/**
	 * This is to calculate size and repartition of the input file
	 *
	 * @param inputPath - Path of the input file
	 * @return size of the input file split
	 */
	public static Integer calculateSizeAndRepartition(String inputPath)

	{
		try
		{
			InitiateSparkSession spark = new InitiateSparkSession();
			Path fsPath = new Path(inputPath);
			int blockSize = 128;
			FileSystem fs =	fsPath.getFileSystem(spark.getSparkContext().hadoopConfiguration());
			long sizeMB =fs.getContentSummary(fsPath).getLength() / 1024 / 1024;
			if (sizeMB > blockSize)
			{
				logger.info("File size is" + sizeMB+ " MB, Repartitioning is set to - " + (sizeMB/ blockSize));

				return (int) (sizeMB / blockSize);
			}
			else
			{
				logger.info("File size is" + sizeMB+ " MB, Repartitioning is set to - 1");
				return 1;
			}
		}
		catch(IOException e)
		{
			return 1;
		}
	}

	/**
	 * This is to read the file as rdd
	 *
	 * @param inputPath Path of the input file
	 * @return returns a java rdd
	 *
	 */
	public static JavaRDD<String> readAsRDD(String inputPath)
	{
		InitiateSparkSession spark = new InitiateSparkSession();
		JavaSparkContext
				sc =
				JavaSparkContext.fromSparkContext(spark.getSparkContext());
		return sc.textFile(inputPath);
	}

	/**
	 * This method reads the info record from the input rdd
	 *
	 * @param sourceRdd input rdd
	 * @param infoFilter info record pattern to indentify info record
	 * @param infoCols columns for info record to prepare schema
	 * @param delimiter delimiter of the data
	 * @return dataset with info data
	 */
	public static Dataset getInfoFromRDD(
			JavaRDD<String> sourceRdd,
			String infoFilter,
			String infoCols,
			String delimiter)
	{
		JavaRDD<String> infoRdd = sourceRdd.filter(
				new Function<String, Boolean>()
				{
					@Override
					public Boolean call(String s)
							throws Exception
					{
						return s.startsWith(infoFilter);
					}
				}
		);

		StructType schema = new StructType();
		for (String s : infoCols.split("\\|"))
		{
			schema = schema.add(s, DataTypes.StringType);
		}
		JavaRDD<String[]>
				infoRddArray =
				infoRdd.map(row -> row.split(delimiter));
		JavaRDD<Row> infoRddRow = infoRddArray.map(RowFactory::create);
		return InitiateSparkSession.getSparkSession()
				.createDataFrame(infoRddRow, schema);
	}

	/**
	 * This method reads the info record from the input rdd
	 *
	 * @param sourceRdd input rdd
	 * @param infoFilter info record pattern
	 * @param headerFilter header record pattern
	 * @param delimiter delmiter of the file
	 * @return data set with data without info record
	 */
	public static Dataset getDataFromRdd(
			JavaRDD<String> sourceRdd,
			String infoFilter,
			String headerFilter,
			String delimiter)
	{
		JavaRDD<String> dataRDD = sourceRdd.filter(
				new Function<String, Boolean>()
				{
					@Override
					public Boolean call(String s)
							throws Exception
					{
						return !s.startsWith(infoFilter);
					}
				}
		);
		JavaRDD<String> headerRDD = dataRDD.filter(
				new Function<String, Boolean>()
				{
					@Override
					public Boolean call(String s)
							throws Exception
					{
						return s.startsWith(headerFilter);
					}
				}
		);
		String header = headerRDD.first();
		Long dataCount = dataRDD.filter(row -> !row.equals(header)).count();
		if (dataCount > 0)
		{
			dataRDD = dataRDD.filter(row -> !row.equals(header));

		}
		StructType schema = new StructType();
		for (String s : header.split(delimiter))
		{
			schema =
					schema.add(new StructField(s, DataTypes.StringType, false,
											   Metadata.empty()));
		}
		JavaRDD<String[]>
				dataRddArray =
				dataRDD.map(row -> row.split(delimiter, -1));
		JavaRDD<Row> dataRddRow = dataRddArray.map(RowFactory::create);
		Dataset
				dataDF =
				InitiateSparkSession.getSparkSession()
						.createDataFrame(dataRddRow, schema);
		if (dataCount > 0)
		{
			dataDF = dataDF.withColumn(HEADER_REQUIRED, functions.lit("true"));
		}
		else
		{
			dataDF = dataDF.withColumn(HEADER_REQUIRED, functions.lit("false"));
		}

		return dataDF;
	}

	/**
	 * This method is to parse the source config file and return properties object
	 * @param configPath input config path to be parsed
	 * @param key file name for which config file should be parsed for
	 * @return Properties with config data
	 */
	public static Properties getPropertiesFromConfig(String configPath, String key)
	{
		Properties configFile = new Properties();
		Dataset<Row> config = readFromCSVFile(configPath, "true", "");
		config = config.filter(config.col("FILE_NAME").equalTo(key));
		config.show();
		Map<String, String> configData = config.rdd().toJavaRDD().mapToPair(x ->
																					new Tuple2(x.getAs(KEY)
																									   .toString(), x
																									   .getAs(VALUE)
																									   .toString())

		).collectAsMap();
		configData.forEach(configFile::setProperty);
		return configFile;
	}


	private static List<String> getProcessedFilesListLocal(String key, String processedFileInputPath, String sourceFilePath) {
		// load processed files csv into Spark
		Dataset<Row> processedFilesDS = readFromCSVFile(processedFileInputPath, "true", "");
		List<String> processedFiles = processedFilesDS.filter(processedFilesDS.col("key").equalTo(key))
				.select(FILE_NAME).as(Encoders.STRING()).collectAsList();

		// build list of files to process
		List<String> srcFiles = new ArrayList<>();
		File folder = new File(sourceFilePath);
		File[] listOfFiles = folder.listFiles();
		for (File file : listOfFiles) {
			if (file.isFile() && file.getName().matches(key + "(_*)(\\d*)\\.txt") && !processedFiles.contains(file.getName())) {
				logger.info("File to be processed:: " + file.getName());
				srcFiles.add(file.getName());
			}
		}
		return srcFiles;
	}


	private static List<String> getProcessedFilesList(String key, String processedFileInputPath, String landingBucket, String sourceName)
	{
		// load processed files csv into Spark
		Dataset<Row> processedFilesDS = readFromCSVFile(processedFileInputPath, "true", "");
		List<String> processedFiles = processedFilesDS.filter(processedFilesDS.col("key").equalTo(key))
				.select(FILE_NAME).as(Encoders.STRING()).collectAsList();

		// build list of files to process
		List<String> srcFiles = new ArrayList<>();

		ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(landingBucket).withMaxKeys(2);
		ListObjectsV2Result result;
		AmazonS3 s3Client = AmazonS3ClientBuilder.defaultClient();
		do {
			result = s3Client.listObjectsV2(req);
			for (S3ObjectSummary objectSummary : result.getObjectSummaries()) {
				String fileName = objectSummary.getKey().substring(objectSummary.getKey().lastIndexOf('/') + 1);
				if (objectSummary.getKey().contains("RAW_CURR/" + sourceName) &&
						fileName.matches(key + "(_*)(\\d*)\\.txt$") &&
						!processedFiles.contains(fileName)) {
					logger.info("File to be processed:: " + fileName);
					srcFiles.add(fileName);
				}
			}
			String token = result.getNextContinuationToken();
			req.setContinuationToken(token);
		}
		while (result.isTruncated());

		return srcFiles;
	}


	/**
	 * This method parses source file, divides info and data records and writes data in to hadoop file system
	 *
	 * @param key File name to process
	 * @param configFile Config file properties
	 * @param sourceName source name of the system
	 * @param runLocally boolean indicating whether to load files locally or from s3
	 *
	 */
	public static boolean parseSourceFile(String key, Properties configFile, String sourceName, boolean runLocally)
	{
		String sourceFilePath = configFile.getProperty("SourcePath");
		String delimiter = configFile.getProperty("Delimiter");
		String infoRecordsFilter = configFile.getProperty("InfoRecordsFilter");
		String headerFilter = configFile.getProperty("HeaderFilter");
		String infoRecordsSchema = configFile.getProperty("InfoRecordsSchema");
		String targetPath = configFile.getProperty("DataTargetPath");
		String landingBucket = configFile.getProperty("LANDING_BUCKET");
		String processedFileInputPath = configFile.getProperty(HEADER_TARGET_PATH) + PROCESSED;

		// build list of files to process
		List<String> srcFiles;
		if(runLocally) {
			srcFiles = getProcessedFilesListLocal(key, processedFileInputPath, sourceFilePath);
		}else{
			srcFiles = getProcessedFilesList(key, processedFileInputPath, landingBucket, sourceName);
		}

		if (srcFiles.isEmpty()) {
			logger.info("No New File to Process");
			return false;
		}else {
			InitiateSparkSession spark = new InitiateSparkSession();
			JavaRDD<String> srcRdd = JavaSparkContext.fromSparkContext(spark.getSparkContext()).emptyRDD();
			for (String file : srcFiles) {
				logger.info("Processing file " + sourceFilePath + file);
				srcRdd = srcRdd.union(CommonUtils.readAsRDD(sourceFilePath + file));
			}
			Dataset infoDS = CommonUtils.getInfoFromRDD(srcRdd, infoRecordsFilter, infoRecordsSchema, delimiter);
			Dataset dataDS = CommonUtils.getDataFromRdd(srcRdd, infoRecordsFilter, headerFilter, delimiter);
			String headerRequired = dataDS.select(dataDS.col(HEADER_REQUIRED)).as(Encoders.STRING()).distinct().head().toString();
			dataDS = dataDS.drop(dataDS.col(HEADER_REQUIRED));
			logger.info("Writing data to path : " + targetPath);
			dataDS.repartition(1).write().option(HEADER, headerRequired).mode(
					OVERWRITE).csv(targetPath + key);
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String processDate = format.format(Calendar.getInstance().getTime());
			infoDS = infoDS.withColumn("key", functions.lit(key))
					.withColumn(PROCESS_DATE, functions.lit(processDate))
					.select("key", FILE_NAME, "TimeStamp", "RecordCount",
							PROCESS_DATE);
			logger.info("Writing header to path : " + targetPath + "/header");
			infoDS.repartition(1)
					.write()
					.option(HEADER, "true")
					.mode(OVERWRITE)
					.csv(configFile.getProperty(
							HEADER_TARGET_PATH) + key);
			return true;
		}
	}

	/**
	 * This is to save header info to a file
	 * @param key file name
	 * @param configProperties properties from config file
	 *
	 */
	public static void saveHeaderInfo(String key, Properties configProperties)
	{
		Dataset
				infoDS =
				readFromCSVFile(configProperties.getProperty(HEADER_TARGET_PATH)
										+ key, "true", "");
		infoDS.repartition(1)
				.write()
				.option(HEADER, "true")
				.mode("APPEND")
				.csv(configProperties.getProperty(HEADER_TARGET_PATH)
							 + PROCESSED);
	}


	/**
	 * Load input data into Spark for processing
	 * @param archNameWithActionName - layer name + process name, e.g. STAGETOTARGET_ACCOUNT_DIM_INSTITUTIONAL
	 * @param configData - Map of config key/values from the stage-to-target configuration file
	 * @param spark - spark session
	 * @return total number of source records
	 * @throws IngestException
	 */
	public static long loadDataToSpark(String archNameWithActionName, Map<String, String> configData, SparkSession spark) throws Exception
	{
		List<String> expectedInputDetails = configData.keySet().stream().filter(x -> x.contains("INPUT_DETAILS")).collect(Collectors.toList());
		long srcCount = 0L;

		for (int i = 1; i <= expectedInputDetails.size(); i++) {
			String inputDetails = configData.get(archNameWithActionName + "_INPUT_DETAILS" + i);
			Map<String, String> inputDetailsMap = getMapFromString(inputDetails);

			String inputPath = inputDetailsMap.getOrDefault("path","NA");
			String fileFormat = inputDetailsMap.getOrDefault("file_format","NA");
			String header = inputDetailsMap.getOrDefault(HEADER, "true");
			String viewName = inputDetailsMap.getOrDefault("view_name","NA");
			String prefix = inputDetailsMap.getOrDefault("prefix", "");
			String delimiter = inputDetailsMap.getOrDefault("sep", "|");
			String sfWareHouse = inputDetailsMap.getOrDefault("sf_warehouse","NA");
			String sfDataBase = inputDetailsMap.getOrDefault("sf_database","NA");
			String sfSchema = inputDetailsMap.getOrDefault("sf_schema","NA");
			String sfTableNameToImport = inputDetailsMap.getOrDefault("sf_table","NA");
			String postgresqlSchema = inputDetailsMap.getOrDefault("postgresql_schema","NA");
			String postgresqlTable = inputDetailsMap.getOrDefault("postgresql_table","NA");

			Dataset<Row> dF1 = null;

			switch (fileFormat) {
				case "csv":
					dF1 = readFromCSVFile(inputPath, header, prefix);
					dF1.show(false);
					break;
				case "delimited":
					dF1 = readFromDelimiterFile(inputPath, delimiter, header, prefix);
					dF1.show(false);
					break;
				case "table":
					dF1 = readFromSnowflake(sfWareHouse,sfDataBase,sfSchema,sfTableNameToImport);
					dF1.show(false);
					break;
				case "postgresql":
					dF1 = readFromPostgresql(postgresqlSchema, postgresqlTable);
				default:
					break;
			}
			//get the  total input count
			if(dF1!= null && i==1) {
				srcCount = Math.toIntExact(dF1.count());
			}

			if (dF1 != null) {
				dF1.createOrReplaceTempView(viewName);
				spark.sqlContext().cacheTable(viewName);
				logger.info("Temp table completed.");
			}
		}
		return srcCount;
	}

	/**
	 * Parse the commandline arguments and store in GlobalVariable
	 * @param args - commandline input arguments
	 * @return - arguments parsed successfully
	 */
	public static boolean parseCommandlineArgs(String[] args){

		if (args.length != 6) {
			logger.error("Invalid Number Of Arguments -- Expected: 6, Received:" + args.length);
			return false;
		}else {
			GlobalVariable.fileName = args[0];
			GlobalVariable.sourceName = args[1];
			GlobalVariable.configInputPath = args[2];
			try {
				GlobalVariable.jobId = Integer.parseInt(args[3]);
				logger.info("Job Id: " + GlobalVariable.jobId);
			} catch (NumberFormatException e) {
				logger.error("Job is invalid, setting to 0: ", e);
				GlobalVariable.jobId = 0;
			}
			InitiateSparkSession.createSparkSession(args[4]);

			//Load environment variables from property file
			EnvironmentVariable.loadPropertiesFile(args[5]);
			return true;
		}
	}

	/**
	 * Build a list of Filter SQL expressions
	 * @param inputConfigData - map of configuration data
	 * @return list of configuration expressions containing "FILTER" in the key
	 *
	 * e.g.
	 * Input:
	 * TYPE,	ARCHITECTURE_LAYER,		FILE_NAME,				SOURCE_NAME,	ACTION,		KEY,			VALUE
	 * DEV,		LANDINGTOSTAGE,			ff_IDM_TAUMD_AGR_PTY,	DST,			FLT,		FILTER_COL1,	src_col_name=NA||tgt_col_name=NA ||expr=BUS_PTY_ID_NULL_VAL not in ('Valid')
	 * DEV,		LANDINGTOSTAGE,			ff_IDM_TAUMD_AGR_PTY,	DST,			FLT,		FILTER_COL2,	src_col_name=NA||tgt_col_name=NA ||expr=AGR_ID_NULL_VAL not in ('Valid')
	 *
	 * Return:
	 * BUS_PTY_ID_NULL_VAL not in ('Valid')
	 * AGR_ID_NULL_VAL not in ('Valid')
	 */
	public static List<String> buildFilterExpressionList(Map<String, String> inputConfigData){
		String archAndActionName = "LANDINGTOSTAGE_FLT";

		// process configuration steps with Key containing "_FILTER"
		inputConfigData = inputConfigData.entrySet().stream().filter(x ->
				x.getKey().contains("_FILTER")).collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));

		// compile list of expressions from configuration values
		List<String> expr = new ArrayList<>();
		for(Map.Entry<String,String> x: inputConfigData.entrySet()) {
			Map<String, String> filterConfig = CommonUtils.getMapFromString(x.getValue());
			String srcCol = filterConfig.getOrDefault("src_col_name", "NA");
			String tgtCol = filterConfig.getOrDefault("tgt_col_name", "NA");
			String configExpr = filterConfig.getOrDefault("expr", "NA");
			Matcher m = Pattern.compile("\\)").matcher(x.getKey().replaceAll(archAndActionName, ""));

			// Creating  expression
			if ("NA".equalsIgnoreCase(configExpr.trim())) {
				if (m.find()) {
					String s = x.getKey().replaceAll(archAndActionName, "")
							.replaceAll("\\d", "")
							.replaceFirst("\\)", "") + "(" + srcCol + "))" + " as " + tgtCol;
					expr.add(s);
				}
				else {
					String s = x.getKey().replaceAll(archAndActionName, "")
							.replaceAll("\\d", "")
							.replaceFirst("\\)", "") + "(" + srcCol + ")" + " as " + tgtCol;
					expr.add(s);
				}
			}
			else {
				expr.add(configExpr);
			}
		}
		return expr;
	}

	/**
	 * Build a Suspended records dataframe by querying the data using filter expressions
	 * @param spark - Spark session
	 * @param inputDf - input dataframe from DataQualityDriver
	 * @param filterExpressions - list of sql filter expressions from config file
	 * @return
	 */
	public static Dataset<Row> buildSuspendedRecordsDataframe(SparkSession spark, Dataset inputDf, List<String> filterExpressions){
		Dataset<Row> suspendedRecordsDF = null;
		List<String> generatedColList = new ArrayList<>();
		List<String> originalColList = new ArrayList<>();

		for (String s : filterExpressions) {
			generatedColList.clear();
			originalColList.clear();
			String whereCondition = s.split(",")[0];
			inputDf.createOrReplaceTempView("inputDf");

			//load suspended records into temp view
			String suspendedRecordsSQL = "select * from inputDf where " + whereCondition;
			Dataset<Row> tempDF = spark.sql(suspendedRecordsSQL);
			tempDF.createOrReplaceTempView("suspendedRecordsDF");

			generatedColList = Arrays.stream(tempDF.columns()).filter(col -> col.endsWith("_VAL")).collect(Collectors.toList());
			originalColList = Arrays.stream(tempDF.columns()).filter(col -> !col.endsWith("_VAL")).collect(Collectors.toList());

			String finalStr = "select " + String.join(",", originalColList) +
								", concat_ws(','," + String.join(",", generatedColList) + ") as errorMsgF " +
								"from suspendedRecordsDF";
			Dataset<Row> concatDF = spark.sql(finalStr);

			if (suspendedRecordsDF != null) {
				suspendedRecordsDF = concatDF.union(suspendedRecordsDF);
			}
			else {
				suspendedRecordsDF = concatDF;
			}
		}
		return suspendedRecordsDF;
	}

	public static String checkJobProcess(SparkSession spark, Map<String, String> configData,String layerName) throws IngestException
	{
		String processJob = "true";
		if (configData.containsKey(layerName+"_"+"LOCKDATE_LOCK_DATE_CHECK")) {
			String	valueString =CommonUtils.getValue("_LOCK_DATE_CHECK", configData);
			Map<String, String> inputDetailsMap = getMapFromString(valueString);
			String	sfWareHouse =inputDetailsMap.getOrDefault("sf_warehouse", "NA");
			String	sfDataBase =inputDetailsMap.getOrDefault("sf_database", "NA");
			String sfSchema = inputDetailsMap.getOrDefault("sf_schema", "NA");
			String sfTableName = inputDetailsMap.getOrDefault("sf_table", "NA");
			String viewName = inputDetailsMap.getOrDefault("view_name", "NA");
			String query = inputDetailsMap.getOrDefault("query", "NA");
			Dataset<Row> dF1 =readFromSnowflake(sfWareHouse, sfDataBase, sfSchema,sfTableName);
			dF1.createOrReplaceTempView(viewName);
			processJob = spark.sql(query).first().get(0).toString();
		}
		return processJob;
	}


}
