package com.trp.cfo.aumreporting.commonutils.exception;

public class IngestException extends  Exception {
	private static final long serialVersionUID = 4L;
	private final String errorMsg;

	public IngestException(String errorMsg) {
		super(errorMsg);
		this.errorMsg = errorMsg;
	}
	public IngestException(String errorMsg,Throwable e) {
		super(errorMsg,e);
		this.errorMsg = errorMsg;
	}

	public String getErrorMsg() {
		return errorMsg;
	}
}
