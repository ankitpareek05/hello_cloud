package com.trp.cfo.aumreporting.commonutils;

import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import net.snowflake.spark.snowflake.Utils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class DBUtils implements Serializable
{
	private static final Logger       logger      = LogManager.getLogger(DBUtils.class);
	private static final SparkSession spark       = InitiateSparkSession.getSparkSession();
	static               Properties   envProperty = EnvironmentVariable.getEnvProperties();

	static       String              dbName                      = envProperty.getProperty("trp.dbName");
	static       String              driver                      = envProperty.getProperty("trp.driver");
	static       String              host                        = envProperty.getProperty("trp.host");
	static       String              sfUrl                       = envProperty.getProperty("trp.sfUrl");
	static       String              sfUser                      = envProperty.getProperty("trp.sfUser");
	static       String              sfRole                      = envProperty.getProperty("trp.sfRole");
	static       String              jdbcURL                     = "jdbc:postgresql://" + host + "/" + dbName;
	static final Map<String, String> postgresqlConnectionDetails = VaultUtils.getPostgresqlSecret();

	public static Properties getConnectionProperties()
	{
		Properties connectionProperties = new Properties();
		connectionProperties.put("user", postgresqlConnectionDetails.get("username"));
		connectionProperties.put("password", postgresqlConnectionDetails.get("password"));
		connectionProperties.put("driver", driver);
		connectionProperties.put("stringtype", "unspecified");
		return connectionProperties;
	}

	public static void writeToTable(Dataset<Row> resultSet, String tableName, String mode)
			throws IngestException
	{
		String log = "Writing to table " + tableName + " in " + mode + " mode.";
		logger.info(log);
		try
		{
			if ("OVERWRITE".equals(mode.toUpperCase()))
			{
				resultSet.write().mode(mode).option("truncate", "true").jdbc(jdbcURL, tableName, getConnectionProperties());
			}
			else
			{
				resultSet.write().mode(mode).jdbc(jdbcURL, tableName, getConnectionProperties());
			}
		}
		catch(Exception ex)
		{
			logger.error("Failure when writing to table " + tableName);
			logger.error(ex.getMessage());
			throw new IngestException("Error in DButils.writeToTable()", ex);
		}
	}

	public static Dataset readFromSnowflake(String sfWarehouse, String sfDatabase, String sfSchema, String sfTable)
			throws IngestException
	{
		Dataset df = null;
		try
		{
			df = spark.read().format(Utils.SNOWFLAKE_SOURCE_NAME())
					.options(
							prepareDfOptionsMap(sfWarehouse, sfDatabase, sfSchema, sfTable, null))
					.load();
		}
		catch(Exception ex)
		{
			logger.error("Error in executing query in spark::" + ex.getMessage());
			throw new IngestException("Error in DButils.readFromSnowflake()", ex);
		}
		return df;
	}

	public static Dataset readFromPostgresql(String postgre_schema, String postgre_table)
			throws Exception
	{
		Dataset df = null;
		try
		{
			df = spark.read()
					.jdbc(jdbcURL, postgre_schema + "." + postgre_table, getConnectionProperties());
		}
		catch(Exception ex)
		{
			logger.error("Error in reading data from postgresql::" + ex.getMessage());
			throw ex;
		}
		return df;
	}

	private static Map<String, String> prepareDfOptionsMap(String sfWarehouse, String sfDatabase, String sfSchema, String sfTable, String unstageTable)
	{
		Map<String, String> options = new HashMap();
		options.put("sfUrl", sfUrl);
		options.put("sfUser", sfUser);
		options.put("sfPassword", VaultUtils.getSnowflakeSecret());
		options.put("sfRole", sfRole);
		options.put("sfWarehouse", sfWarehouse);
		options.put("sfDatabase", sfDatabase);
		options.computeIfAbsent("sfSchema", val -> sfSchema);
		options.computeIfAbsent("dbtable", val -> sfTable);
		options.computeIfAbsent("usestagingtable", val -> unstageTable);
		return options;
	}

	public static void writeToSnowflake(Dataset outputDF, String sfWarehouse, String sfDatabase, String sfSchema, String sfTable, String sfMode)
			throws IngestException
	{
		try
		{
			outputDF.write().format(Utils.SNOWFLAKE_SOURCE_NAME())
					.options(prepareDfOptionsMap(sfWarehouse, sfDatabase, sfSchema, sfTable, null))
					.mode(sfMode)
					.save();
		}
		catch(Exception e)
		{
			logger.error("Error in snowflake::" + e.getMessage());
			throw new IngestException("writeToSnowflake", e);
		}
	}

	public static ResultSet mergeTarget(String sfWarehouse, String database, String mergeQuery)
			throws IngestException
	{
		ResultSet rs;
		try
		{
			Map<String, String> options = prepareDfOptionsMap(sfWarehouse, database, null, null, "false");
			logger.info("Merge Query: " + mergeQuery);
			rs = Utils.runQuery(options, mergeQuery);
		}
		catch(Exception e)
		{
			logger.error("Merge query failed::" + e.getMessage());
			throw new IngestException("mergeTarget()", e);
		}
		return rs;
	}

	public static ResultSet deleteTableRecords(String sfWarehouse, String database, String mergeQuery, String sfSchema)
			throws IngestException
	{
		ResultSet rs;
		try
		{
			Map<String, String> options = prepareDfOptionsMap(sfWarehouse, database, sfSchema, null, "false");
			logger.info("Delete Query: " + mergeQuery);
			rs = Utils.runQuery(options, mergeQuery);
		}
		catch(Exception e)
		{
			logger.error("Delete query failed::" + e.getMessage());
			throw new IngestException("Delete query failed::", e);
		}
		return rs;
	}

	public static Dataset readFromSnowflakeQuery(String query, String sfWarehouse, String sfDatabase, String sfSchema, String sfTable)
			throws IngestException
	{
		Dataset df = null;
		try
		{
			df = spark.read().format(Utils.SNOWFLAKE_SOURCE_NAME())
					.options(
							prepareDfOptionsMap(sfWarehouse, sfDatabase, sfSchema, sfTable, null))
					.option("query", query)
					.load();
		}
		catch(Exception ex)
		{
			logger.error("Error in executing query in spark:: " + ex.getMessage());
			throw new IngestException("Error in DButils.readFromSnowflake()", ex);
		}
		return df;
	}
}

