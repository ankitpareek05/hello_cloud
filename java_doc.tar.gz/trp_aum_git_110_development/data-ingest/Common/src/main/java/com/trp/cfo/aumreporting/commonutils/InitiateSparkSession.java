package com.trp.cfo.aumreporting.commonutils;

import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;

public class InitiateSparkSession implements Serializable
{
	private static SparkSession sparkSession = null;

	public  static void createSparkSession(String mode){
		if("local".equals(mode)){
			sparkSession = SparkSession.builder()
					.appName("DataProfiling")
					.master("local[*]")
					.config("spark.driver.host", "localhost")
					.config("spark.sql.tungsten.enabled", "true")
					.config("spark.io.compression.codec", "snappy")
					.config("spark.rdd.compress", "true")
					.getOrCreate();
		}
		else if ("cluster".equals(mode)){
			sparkSession = SparkSession.builder()
					.appName("DataProfiling")
					.config("spark.sql.tungsten.enabled", "true")
					.config("spark.io.compression.codec", "snappy")
					.config("spark.rdd.compress", "true")
					.getOrCreate();
		}

	}

	public SparkContext getSparkContext()
	{
		return sparkSession.sparkContext();
	}

	public static SparkSession getSparkSession()
	{
		return sparkSession;
	}
}
