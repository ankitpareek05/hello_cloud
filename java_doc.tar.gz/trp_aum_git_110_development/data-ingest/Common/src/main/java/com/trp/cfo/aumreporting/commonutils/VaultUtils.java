package com.trp.cfo.aumreporting.commonutils;

import java.util.Map;
import java.util.Properties;

/**
 * This class is responsible for providing Vault Secret
 */
public class VaultUtils
{
	private VaultUtils(){}
	private static final Properties envProperty  = EnvironmentVariable.getEnvProperties();
	/*
	Update below db properties as per the details provided by client. Below properties are for connecting to sql server db
	instance.
	*/
	private static final String     VAULT_ADDRESS    = envProperty.getProperty("trp.vault_address");
	private static final String     AWS_PROFILE_NAME = envProperty.getProperty("trp.aws_profile_name");
	private static final String     ORG              = envProperty.getProperty("trp.org");
	private static final String     SERVICE_NAME     = envProperty.getProperty("trp.service_name");

	/**
	 * This method is responsible for generating vault secret
	 * @return - returns vault secret.
	 */
	public static String getSnowflakeSecret()
	{
		SimpleSecretsProvider	secretsProvider = new SimpleSecretsProvider(VAULT_ADDRESS, AWS_PROFILE_NAME, ORG, SERVICE_NAME);
		return secretsProvider.getSnowflakeSecret();
	}
	public static Map<String, String> getPostgresqlSecret()
	{
		SimpleSecretsProvider secretsProvider = new SimpleSecretsProvider(VAULT_ADDRESS, AWS_PROFILE_NAME, ORG, SERVICE_NAME);
		return secretsProvider.getPostgresqlSecret();
	}
}
