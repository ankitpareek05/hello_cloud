package com.trp.cfo.aumreporting.commonutils;

import com.bettercloud.vault.VaultException;
import com.trp.cfo.aumreporting.commonutils.exception.SecretsException;
import com.trp.ea.fusion.aws.security.secrets.AwsIamVaultCredentialsFactory;
import com.trp.ea.fusion.utilities.security.secrets.AwsIamVaultCredentials;
import com.trp.ea.fusion.utilities.security.secrets.BaseVaultProviderBuilder;
import com.trp.ea.fusion.utilities.security.secrets.VaultAuth;
import com.trp.ea.fusion.utilities.security.secrets.VaultProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

public abstract class BaseSecretsProvider
{
	static final String         COMPANY              = "troweprice";
	static final String         SNOWFLAKE_SECRET_KEY = "snowflake-secret";
	static final String         POSTGRESQL_SECRET_KEY = "postgres_secret";
	private static final String IAM_ROLE             = "ec2-instance";

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private  String                         vaultAddress;
	private  String                         awsProfileName;
	private  String                         iamRole;
	private VaultProvider vaultProvider = null;
	String    org;
	String    serviceName;

	private BaseSecretsProvider(String vaultAddress, String awsProfileName, String org, String serviceName, String iamRole)
	{
		this.vaultAddress = vaultAddress;
		this.awsProfileName = awsProfileName;
		this.org = org;
		this.serviceName = serviceName;
		this.iamRole = iamRole;
	}

	BaseSecretsProvider(){}

	BaseSecretsProvider(String vaultAddress, String awsProfileName, String org, String serviceName)
	{
		this(vaultAddress, awsProfileName, org, serviceName, IAM_ROLE);
	}

	protected abstract Map<String, String> getSecretEndpoints();

	private Optional<VaultProvider> createVault()
	{
		String	vaultServerid =	vaultAddress.replace("https://", "").replace(":8200", "");
		try {
			BaseVaultProviderBuilder builder = new BaseVaultProviderBuilder().vaultAddr(vaultAddress);

			for (Map.Entry<String, String> entry : getSecretEndpoints().entrySet()) {
				builder.addSecretEndpoint(entry.getKey(), entry.getValue());
			}
			AwsIamVaultCredentials awsIamVaultCredentials = new AwsIamVaultCredentialsFactory(serviceName,vaultServerid)
							.create()
							.orElseThrow(Exception::new);

			String	awsAuthEndpoint ="aws/" + COMPANY + "/" + org + "/" + awsProfileName + "/"+ iamRole;
			builder.authEndpoint(awsAuthEndpoint, VaultAuth.AWS_IAM,awsIamVaultCredentials);
			return Optional.of(builder.build());
		}
		catch(VaultException e) {
			logger.error("Failed to authenticate with vault on " + vaultAddress, e);
			return Optional.empty();
		}
		catch(Exception e) {
			logger.error("Failed to retrieve AwsIamVaultCredentials for service: "+ serviceName + " from vault server: " + vaultServerid, e);
			return Optional.empty();
		}
	}

	private VaultProvider getVaultProvider() throws SecretsException
	{
		if(vaultProvider == null){
			Optional<VaultProvider> vp = this.createVault();
			return vp.orElseThrow(SecretsException::new);
		}else{
			return vaultProvider;
		}
	}

	public String getSnowflakeSecret() {
		return getSecrets(SNOWFLAKE_SECRET_KEY).get("value");
	}

	public Map<String, String> getPostgresqlSecret() {
		return getSecrets(POSTGRESQL_SECRET_KEY);
	}

	private Map<String, String> getSecrets(String endpoint)
	{
		try {
			return getVaultProvider().getSecretResponse(endpoint).getSecrets().orElseGet(Collections::emptyMap);
		}catch(SecretsException e){
			logger.error("Failed to setup Vault Provider", e);
			return Collections.emptyMap();
		}catch(VaultException e){
			logger.error("Failed to get secrets from vault", e);
			return Collections.emptyMap();
		}
	}
}
