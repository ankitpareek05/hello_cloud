package com.trp.cfo.aumreporting.commonutils;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import scala.Tuple2;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

public class EnvironmentVariable implements Serializable
{

	static Properties prop = null;

	public static Properties  loadPropertiesFile(String inputfile)
	{
		prop = new Properties();
		Dataset<Row> config = CommonUtils.readFromCSVFile(inputfile, "true", "");
		Map<String, String> configData = config.rdd().toJavaRDD().mapToPair(x ->
				new Tuple2(x.getAs("KEY").toString().trim(),x.getAs("VALUE").toString().trim())

		).collectAsMap();
		configData.forEach((k, v) -> prop.setProperty(k, v));
		return prop;
	}

	public static String getPropertyVal(String key){
		String val = "";
		if(prop != null )
			val = prop.getProperty(key);
		return val;
	}

	public static Properties getEnvProperties()
	{
		return prop;
	}

}
