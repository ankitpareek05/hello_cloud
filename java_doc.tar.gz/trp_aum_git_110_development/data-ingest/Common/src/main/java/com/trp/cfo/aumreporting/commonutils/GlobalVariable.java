package com.trp.cfo.aumreporting.commonutils;

public class GlobalVariable implements java.io.Serializable
{
	private String layername;

	public static int jobId = 0;
	public static String fileName;
	public static String sourceName;
	public static String configInputPath;

	public String getLayername()
	{
		return layername;
	}

	public void setLayername(String layername)
	{
		this.layername = layername;
	}


}
