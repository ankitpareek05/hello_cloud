package com.trp.cfo.aumreporting.commonutils;

import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import java.io.Serializable;
import java.util.Arrays;
@SuppressWarnings("all")
public class AuditLog implements Serializable
{

	private String  runlog_details;
	private String  runlog_start_date;
	private String  runlog_end_date;
	private String  runlog_completion_status;
	private String  runlog_state;
	private Long read_count;
	private Long write_count;
	private Long error_count;
	private Integer job_runlog_id;
	private Integer error_code;
	private String create_user;
	private String create_timestamp;

	public String getCreate_timestamp()
	{
		return create_timestamp;
	}

	public void setCreate_timestamp(String create_timestamp)
	{
		this.create_timestamp = create_timestamp;
	}



	public String getCreate_user()
	{
		return create_user;
	}

	public void setCreate_user(String create_user)
	{
		this.create_user = create_user;
	}


	public String getRunlog_details()
	{
		return runlog_details;
	}

	public void setRunlog_details(String runlog_details)
	{
		this.runlog_details = runlog_details;
	}

	public String getRunlog_start_date()
	{
		return runlog_start_date;
	}

	public void setRunlog_start_date(String runlog_start_date)
	{
		this.runlog_start_date = runlog_start_date;
	}

	public String getRunlog_end_date()
	{
		return runlog_end_date;
	}

	public void setRunlog_end_date(String runlog_end_date)
	{
		this.runlog_end_date = runlog_end_date;
	}

	public String getRunlog_completion_status()
	{
		return runlog_completion_status;
	}

	public void setRunlog_completion_status(String runlog_completion_status)
	{
		this.runlog_completion_status = runlog_completion_status;
	}

	public String getRunlog_state()
	{
		return runlog_state;
	}

	public void setRunlog_state(String runlog_state)
	{
		this.runlog_state = runlog_state;
	}

	public Long getRead_count()
	{
		return read_count;
	}

	public void setRead_count(Long read_count)
	{
		this.read_count = read_count;
	}

	public Long getWrite_count()
	{
		return write_count;
	}

	public void setWrite_count(Long write_count)
	{
		this.write_count = write_count;
	}

	public Long getError_count()
	{
		return error_count;
	}

	public void setError_count(Long error_count)
	{
		this.error_count = error_count;
	}

	public Integer getJob_runlog_id()
	{
		return job_runlog_id;
	}

	public void setJob_runlog_id(Integer job_runlog_id)
	{
		this.job_runlog_id = job_runlog_id;
	}

	public Integer getError_code()
	{
		return error_code;
	}

	public void setError_code(Integer error_code)
	{
		this.error_code = error_code;
	}

	public AuditLog()
	{
	}

	public AuditLog(
			String runlog_details,
			String runlog_start_date,
			String runlog_end_date,
			String runlog_completion_status,
			String runlog_state,
			Long read_count,
			Long write_count,
			Long error_count,
			Integer job_runlog_id,
			Integer error_code,
			String create_user,
			String create_timestamp)
	{
		super();
		this.runlog_details = runlog_details;
		this.runlog_start_date = runlog_start_date;
		this.runlog_end_date = runlog_end_date;
		this.runlog_completion_status = runlog_completion_status;
		this.runlog_state = runlog_state;
		this.read_count = read_count;
		this.write_count = write_count;
		this.error_count = error_count;
		this.job_runlog_id = job_runlog_id;
		this.error_code = error_code;
		this.create_timestamp=create_timestamp;
		this.create_user=create_user;
	}



	public void auditEntry(
			String table,
			String mode,
			String runlog_details,
			String runlog_start_date,
			String runlog_end_date,
			String runlog_completion_status,
			String runlog_state,
			Long read_count,
			Long write_count,
			Long error_count,
			Integer job_runlog_id,
			Integer error_code,
			String create_user,
			String create_timestamp) throws IngestException
	{
		SparkSession spark = InitiateSparkSession.getSparkSession();
		Dataset<Row> auditEntry = spark.createDataFrame(
				Arrays.asList(new AuditLog(runlog_details, runlog_start_date, runlog_end_date,
						runlog_completion_status, runlog_state, read_count, write_count,
						error_count, job_runlog_id, error_code,create_user,create_timestamp)), AuditLog.class)
				.select("runlog_details", "runlog_start_date", "runlog_end_date", "runlog_completion_status",
						"runlog_state", "read_count", "write_count", "error_count", "job_runlog_id", "error_code"
						,"create_user","create_timestamp");
		auditEntry.show();
		DBUtils.writeToTable(auditEntry.coalesce(1),table,mode);

	}

}
