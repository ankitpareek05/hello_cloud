package com.trp.cfo.aumreporting.commonutils;

import com.google.common.collect.ImmutableMap;

import java.io.Serializable;
import java.util.Map;

public class SimpleSecretsProvider extends BaseSecretsProvider implements       Serializable
{

	private static final String SNOWFLAKE_SECRET_NAME = EnvironmentVariable.getPropertyVal("trp.snowflake_secret_name");
	private static final String POSTGRES_ROLE_NAME = EnvironmentVariable.getPropertyVal("trp.postgresql_role_name");
	SimpleSecretsProvider(String vaultAddr, String awsProfileName, String org, String serviceName)
	{
		super(vaultAddr, awsProfileName, org, serviceName);
	}

	protected Map<String, String> getSecretEndpoints()
	{
		String vaultSecretEndpoint = "secret/" + COMPANY + "/" + org + "/" + serviceName + "/" + SNOWFLAKE_SECRET_NAME;
		String postgreSqlEndpoint="database/" + COMPANY + "/" + org +"/" + serviceName + "/creds/" + POSTGRES_ROLE_NAME;
		return ImmutableMap.of(SNOWFLAKE_SECRET_KEY, vaultSecretEndpoint,POSTGRESQL_SECRET_KEY,postgreSqlEndpoint);
	}

}
