package com.trp.cfo.aumreporting.commonutils;

import org.junit.Assert;
import org.junit.Test;

public class AuditLogTest
{


		private Integer  code = 2;
		private String  date = "03/22/2020";
		private String  status = "complete";
		private Long count = 2L;
		private String create_user = "trp_usr";


		@Test
		public void  setValues(){
			boolean flag=true;
			try{
				AuditLog auditLog = new AuditLog();
				auditLog.setCreate_timestamp(date);
				auditLog.setCreate_user(create_user);
				auditLog.setError_code(code);
				auditLog.setError_count(count);
				auditLog.setJob_runlog_id(code);
				auditLog.setRead_count(count);
				auditLog.setRunlog_end_date(date);
				auditLog.setRunlog_completion_status(status);
				auditLog.setRunlog_start_date(date);
				auditLog.setRunlog_state(status);
				auditLog.setWrite_count(count);
				auditLog.setRunlog_details(status);
			}catch(Exception e){
				flag = false;
			}

			Assert.assertTrue(flag);
		}

		@Test
		public void  getValues(){

			AuditLog newAuditLog =new AuditLog(status, date, date,
					status, status, count, count,
					count, code, code,create_user,date);

			Assert.assertNotNull(newAuditLog.getCreate_user());
			Assert.assertNotNull(newAuditLog.getCreate_timestamp());
			Assert.assertNotNull(newAuditLog.getError_code());
			Assert.assertNotNull(newAuditLog.getError_count());
			Assert.assertNotNull(newAuditLog.getRead_count());
			Assert.assertNotNull(newAuditLog.getWrite_count());
			Assert.assertNotNull(newAuditLog.getRunlog_completion_status());
			Assert.assertNotNull(newAuditLog.getRunlog_details());
			Assert.assertNotNull(newAuditLog.getRunlog_end_date());
			Assert.assertNotNull(newAuditLog.getRunlog_start_date());
			Assert.assertNotNull(newAuditLog.getRunlog_state());
			Assert.assertNotNull(newAuditLog.getJob_runlog_id());
		}

	}


