package com.trp.cfo.aumreporting.commonutils;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Map;
import java.util.Properties;

@RunWith(PowerMockRunner.class)
public class SimpleSecretsProviderTest
{
	@PrepareForTest({EnvironmentVariable.class})
	@Test
	public void getPostgresqlSecretTest()
			throws Exception
	{
		Properties envProperty = getProperties();
		String     VAULT_ADDRESS    = envProperty.getProperty("trp.vault_address");
		String     AWS_PROFILE_NAME = envProperty.getProperty("trp.aws_profile_name");
		String     ORG              = envProperty.getProperty("trp.org");
		String     SERVICE_NAME     = envProperty.getProperty("trp.service_name");

		mockCommonData();
		SimpleSecretsProvider secretsProvider = new SimpleSecretsProvider(VAULT_ADDRESS, AWS_PROFILE_NAME, ORG, SERVICE_NAME);
		Map<String, String> map = secretsProvider.getSecretEndpoints();
		Assert.assertEquals("secret/troweprice/aum-reporting/data-ingest/snowflake_secret", map.get("snowflake-secret"));
		Assert.assertEquals("database/troweprice/aum-reporting/data-ingest/creds/postgresql_secret", map.get("postgres_secret"));

	}

	private void mockCommonData()
	{
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getPropertyVal("trp.snowflake_secret_name")).thenReturn("snowflake_secret");
		PowerMockito.when(EnvironmentVariable.getPropertyVal("trp.postgresql_role_name")).thenReturn("postgresql_secret");

	}

	private Properties getProperties(){
		Properties properties = new Properties();
		properties.setProperty("trp.vault_address", "https://vault.dev.troweprice.io:8200");
		properties.setProperty("trp.service_name", "data-ingest");
		properties.setProperty("trp.aws_profile_name", "trp-shared-dev");
		properties.setProperty("trp.org", "aum-reporting");

		return properties;
	}
}
