package com.trp.cfo.aumreporting.commonutils;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static org.mockito.Mockito.*;

@PrepareForTest({VaultUtils.class, EnvironmentVariable.class, SimpleSecretsProvider.class})
@RunWith(PowerMockRunner.class)
public class VaultUtilsTest
{

	@Test
	public void getSnowflakeSecretTest()
			throws Exception
	{
		SimpleSecretsProvider secretsProvider = mockCommonData();
		when(secretsProvider.getSnowflakeSecret()).thenReturn("TestSnowFlakeSecret");

		Assert.assertEquals("TestSnowFlakeSecret",VaultUtils.getSnowflakeSecret());

	}

	@Test
	public void getPostgresqlSecretTest()
			throws Exception
	{

		SimpleSecretsProvider secretsProvider = mockCommonData();
		Map<String, String> map = new HashMap<>();
		when(secretsProvider.getPostgresqlSecret()).thenReturn(map);
		Assert.assertNotNull(VaultUtils.getPostgresqlSecret());

	}

	private SimpleSecretsProvider mockCommonData()
			throws Exception
	{
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		SimpleSecretsProvider secretsProvider = PowerMockito.mock(SimpleSecretsProvider.class);
		PowerMockito.whenNew(SimpleSecretsProvider.class).withArguments(anyString(), anyString(), anyString(), anyString()).thenReturn(secretsProvider);
		return secretsProvider;

	}

	private Properties getProperties(){
		Properties properties = new Properties();
		properties.setProperty("trp.vault_address", "https://vault.dev.troweprice.io:8200");
		properties.setProperty("trp.aws_profile_name", "trp-shared-dev");
		properties.setProperty("trp.org", "aum-reporting");
		properties.setProperty("trp.service_name", "data-ingest");
		return properties;
	}
}
