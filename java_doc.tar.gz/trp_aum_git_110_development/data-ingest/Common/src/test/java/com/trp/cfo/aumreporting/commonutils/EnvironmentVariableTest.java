package com.trp.cfo.aumreporting.commonutils;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import java.io.File;
import java.util.Properties;

public class EnvironmentVariableTest
{
	static Properties prop = null;

	@BeforeClass
	public static void loadProps(){
		prop = new Properties();
		prop.setProperty("test1","val1");
		EnvironmentVariable.prop = prop;
	}

	@Test
	public void loadPropertiesFileTest() {
		ClassLoader classLoader =getClass().getClassLoader();
		File envFile = new File(classLoader.getResource("EnvProperties.csv").getFile());
		InitiateSparkSession.createSparkSession("local");
		Properties properties = EnvironmentVariable.loadPropertiesFile(envFile.getPath());
		Assert.assertEquals("airflow", properties.getProperty("trp.dbName"));
	}

	@Test
	public void getPropertyValInvalidKeyTest(){
		Assert.assertNull(EnvironmentVariable.getPropertyVal("test2"));
	}

	@Test
	public void getPropertyValTest(){
		Assert.assertEquals("val1", EnvironmentVariable.getPropertyVal("test1"));
	}

	@Test
	public void getEnvPropertiesTest(){
		Assert.assertEquals(prop,EnvironmentVariable.getEnvProperties());
	}
}
