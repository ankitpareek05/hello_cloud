package com.trp.cfo.aumreporting.commonutils;

import org.junit.Assert;
import org.junit.Test;

public class GlobalVariableTest
{
	public static  int jobId=0;

	@Test
	public void getLayernameTest(){
		GlobalVariable globalVariable = new GlobalVariable();
		globalVariable.setLayername("test");
		String layerName = globalVariable.getLayername();
		Assert.assertEquals("test",layerName);
	}
}
