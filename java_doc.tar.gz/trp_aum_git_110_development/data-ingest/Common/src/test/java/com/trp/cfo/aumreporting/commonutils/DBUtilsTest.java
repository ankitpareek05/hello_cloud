package com.trp.cfo.aumreporting.commonutils;

import com.sun.rowset.JdbcRowSetImpl;
import com.trp.cfo.aumreporting.commonutils.exception.IngestException;
import net.snowflake.spark.snowflake.Utils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.spark.sql.DataFrameWriter;
import org.apache.spark.sql.Dataset;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static org.mockito.Mockito.mock;

@PrepareForTest({EnvironmentVariable.class, VaultUtils.class, Utils.class, DataFrameWriter.class})
@RunWith(PowerMockRunner.class)
public class DBUtilsTest
{
	private static final Logger logger      = LogManager.getLogger(DBUtilsTest.class);
	public static final  String TEST_SECRET = "test_secret";
	public static final  String SNOFLAKE    = "snoflake";
	public static final  String WAREHOUSR   = "testWarehousr";
	public static final  String TESTQUERY   = "testquery";
	public static final  String TEST_DB     = "testDB";
	public static final  String TEST_TABLE  = "testTable";


	@Test
	public void mergeTargetTest() {
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		PowerMockito.when(VaultUtils.getSnowflakeSecret()).thenReturn(
				TEST_SECRET);
		PowerMockito.mockStatic(Utils.class);
		PowerMockito.when(Utils.runQuery(Mockito.anyMap(), Mockito.anyString())).thenReturn(new JdbcRowSetImpl());
		try
		{
			Assert.assertNotNull(
					DBUtils.mergeTarget(WAREHOUSR, SNOFLAKE,
							TESTQUERY));
		}catch(Exception e)
		{
		  logger.error(e.getMessage());
		}
	}

	@Test
	public void mergeTargetTestWithNull() {
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		PowerMockito.when(VaultUtils.getSnowflakeSecret()).thenReturn(
				TEST_SECRET);
		PowerMockito.mockStatic(Utils.class);
		try
		{
			Assert.assertNull(DBUtils.mergeTarget(WAREHOUSR, SNOFLAKE,
					TESTQUERY));
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
	}

	@Test(expected = Exception.class)
	public void mergeTargetTestWithException()
			throws Exception
	{
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		PowerMockito.when(VaultUtils.getSnowflakeSecret()).thenThrow(RuntimeException.class);
		PowerMockito.mockStatic(Utils.class);
		Assert.assertNull(DBUtils.mergeTarget(WAREHOUSR, SNOFLAKE,TESTQUERY));
	}

	private Properties getProperties(){
		Properties properties = new Properties();
		properties.setProperty("VAULT_ADDRESS", "https://vault.dev.troweprice.io:8200");
		properties.setProperty("AWS_PROFILE_NAME", "trp-shared-dev");
		properties.setProperty("ORG", "aum-reporting");
		properties.setProperty("SERVICE_NAME", "data-ingest");
		properties.setProperty("ALLOW_APP_ROLE_OVERRIDE", "true");
		properties.setProperty("trp.dbName", TEST_DB);
		properties.setProperty("trp.userName", "user");
		properties.setProperty("trp.password", "psw");
		properties.setProperty("trp.driver", "org.postgresql.Driver");
		properties.setProperty("trp.host", "host");
		return properties;
	}

	@Test
	public void writeToSnowflakeTest() {
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		PowerMockito.when(VaultUtils.getSnowflakeSecret()).thenReturn(
				TEST_SECRET);
		Dataset dataset = mock(Dataset.class);
		try
		{
			DBUtils.writeToSnowflake(dataset, "testWarehouse", TEST_DB, "testSchema",
					TEST_TABLE, "local");
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		Assert.assertNotNull(dataset);
	}

	@Test
	public void readFromSnowflakeTest() {
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		PowerMockito.when(VaultUtils.getSnowflakeSecret()).thenReturn(
				TEST_SECRET);

		try
		{
			Assert.assertNull(DBUtils.readFromSnowflake("testWarehouse",
					TEST_DB, "testSchema", TEST_TABLE));
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
	}
	@Test
	public void readFromPostgresqlTest() {
		Map<String,String> detailsMap=new HashMap<>();
		detailsMap.put("username","");
		detailsMap.put("password","");
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		PowerMockito.when(VaultUtils.getPostgresqlSecret()).thenReturn(detailsMap);

		try
		{
			Assert.assertNull(DBUtils.readFromPostgresql("testSchema", TEST_TABLE));
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
	}
	@PrepareForTest({EnvironmentVariable.class, VaultUtils.class})
	@Test
	public void getConnectionPropertiesTest()
	{
		Mockito.reset();
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		Map<String,String> postgresVaultCreds=new HashMap<>();
		postgresVaultCreds.put("username","test");
		postgresVaultCreds.put("password","test");
		PowerMockito.when(VaultUtils.getPostgresqlSecret()).thenReturn(postgresVaultCreds);

		Properties props = DBUtils.getConnectionProperties();
		Assert.assertNotNull(props);
		Assert.assertEquals("unspecified", props.getProperty("stringtype"));
	}

	@PrepareForTest({EnvironmentVariable.class, VaultUtils.class, DataFrameWriter.class})
	@Test
	public void writeToTableTestAppend()
	{
		String mode = "APPEND";
		Dataset dataset = writeTableToTest();
		DataFrameWriter writer = Mockito.mock(DataFrameWriter.class);
		Mockito.when(dataset.write()).thenReturn(writer);
		Mockito.when(dataset.write().mode(mode)).thenReturn(writer);
		Mockito.doNothing().when(writer).jdbc(Mockito.anyString(), Mockito.anyString(), Mockito.any(Properties.class));
		try
		{
			DBUtils.writeToTable(dataset, TEST_TABLE, mode);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@PrepareForTest({EnvironmentVariable.class, VaultUtils.class, DataFrameWriter.class})
	@Test
	public void writeToTableTestOverwriteMode()
	{
		String mode = "OVERWRITE";
		Dataset dataset = writeTableToTest();
		DataFrameWriter writer = Mockito.mock(DataFrameWriter.class);
		Mockito.when(dataset.write()).thenReturn(writer);
		Mockito.when(dataset.write().mode(mode)).thenReturn(writer);
		Mockito.when(dataset.write().mode(mode).option(Mockito.anyString(), Mockito.anyString())).thenReturn(writer);
		Mockito.doNothing().when(writer).jdbc(Mockito.anyString(), Mockito.anyString(), Mockito.any(Properties.class));
		try
		{
			DBUtils.writeToTable(dataset, TEST_TABLE, mode);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@PrepareForTest({EnvironmentVariable.class, VaultUtils.class, DataFrameWriter.class})
	@Test
	public void writeToTableTestWithDefault()
	{
		String mode = "Default";
		Dataset dataset = writeTableToTest();
		DataFrameWriter writer = Mockito.mock(DataFrameWriter.class);
		Mockito.when(dataset.write()).thenReturn(writer);
		Mockito.when(dataset.write().mode(mode)).thenReturn(writer);
		Mockito.doNothing().when(writer).jdbc(Mockito.anyString(), Mockito.anyString(), Mockito.any(Properties.class));
		try
		{
			DBUtils.writeToTable(dataset, TEST_TABLE, mode);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	@Test(expected = IngestException.class)
	public void writeToTableTestWithException() throws IngestException
	{
		String mode = "Default";
		Dataset dataset = writeTableToTest();
		DataFrameWriter writer = Mockito.mock(DataFrameWriter.class);
		DBUtils.writeToTable(dataset, TEST_TABLE, mode);
	}

	private Dataset writeTableToTest()
	{
		Mockito.reset();
		PowerMockito.mockStatic(EnvironmentVariable.class);
		PowerMockito.when(EnvironmentVariable.getEnvProperties()).thenReturn(getProperties());
		PowerMockito.mockStatic(VaultUtils.class);
		Map<String,String> postgresVaultCreds=new HashMap<>();
		postgresVaultCreds.put("username","test");
		postgresVaultCreds.put("password","test");
		PowerMockito.when(VaultUtils.getPostgresqlSecret()).thenReturn(postgresVaultCreds);

		Dataset dataset = mock(Dataset.class, Mockito.RETURNS_DEEP_STUBS);
		return dataset;
	}
}
