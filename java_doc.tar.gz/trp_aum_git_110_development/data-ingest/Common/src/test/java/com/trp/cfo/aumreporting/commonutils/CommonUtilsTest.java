package com.trp.cfo.aumreporting.commonutils;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class CommonUtilsTest
{

	private ClassLoader classLoader = getClass().getClassLoader();
	private String  filedqConfigPath = "src/test/resources/DQ_CONFIG.csv";
	private SparkSession spark;

	@Before
	public void createSparkSession()
	{
		InitiateSparkSession.createSparkSession("local");
		spark = InitiateSparkSession.getSparkSession();
	}

	@Test
	public void writeToCSVFileTest(){
		boolean flag=true;
		try{
			Dataset<Row>
					dF1 = CommonUtils.readFromCSVFile("src/test/resources/EnvProperties.csv","true","");
			String  viewName = "test_view";
			dF1.createOrReplaceTempView(viewName);
			spark.sqlContext().cacheTable(viewName);
			Dataset<Row> df1 = spark.sql("select * from test_view");
			CommonUtils.writeToCSVFile(df1,"src/test/resources/csv_out/","true","overwrite");
		}catch(Exception e){
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void readFromCSVFileExceptionTest(){
		boolean flag=false;
		try{
			CommonUtils.readFromCSVFile("src/test/resources/1.csv","true","");
		}catch(Exception e){
			flag = true;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void getValueTest(){

		boolean flag=true;
		try{
			Map<String,String> inputMap = new HashMap<>();
			inputMap.put("one","value1");
			inputMap.put("two","value2");
			String value = CommonUtils.getValue("one", inputMap);
			if(!value.equalsIgnoreCase("value1")){
				flag = false;
			}
		}catch(Exception e){
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void getMapFromStringTest(){
		boolean flag=true;
		try{
			String ipString = "path=s3://aum-reporting-all-trp-dev-mft-staging/STAGING/DST/ff_IDM_TAUMD_RTL_TRN/ || file_format = delimited || header=true || view_name =ff_IDM_TAUMD_RTL_TRN || sep=| ||db_type = NA ||table_name=NA";
			CommonUtils.getMapFromString(ipString);
		}catch(Exception e){
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void parseConfigFileTest(){
		boolean flag=true;
		try{
			CommonUtils.parseConfigFile(filedqConfigPath,"ff_IDM_TAUMD_AGR_PTY","DST","LANDINGTOSTAGE");
		}catch(Exception e){
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void readFromDelimiterFileTest(){
		boolean flag=true;
		try{
			File  filePath = new File(classLoader.getResource("ff_IDM_TAUMD_AGR_PTY_20200107062033.txt").getFile());
			CommonUtils.readFromDelimiterFile(filePath.getPath(), "|","true","");
		}catch(Exception e){
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void readFromDelimiterFileExceptionTest(){
		boolean flag=false;
		try{
			CommonUtils.readFromDelimiterFile("1.csv", "|","true","");
		}catch(Exception e){
			flag = true;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void getPropertiesFromConfigTest(){
		boolean flag=true;
		try{
			CommonUtils.getPropertiesFromConfig(filedqConfigPath,"ff_IDM_TAUMD_AGR_PTY");
		}catch(Exception e){
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void saveHeaderInfoTest(){
		boolean flag=true;
		try{
			Properties confProp = CommonUtils.getPropertiesFromConfig("src/test/resources/config.csv", "ff_IDM_TAUMD_AGR_PTY");
			CommonUtils.saveHeaderInfo("ff_IDM_TAUMD_AGR_PTY",confProp);
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
		}
		Assert.assertTrue(flag);
	}

	@Test
	public void readFromDelimiterFileTest3(){
		File configPath5 = new File(classLoader.getResource("part-rtl-file.csv").getFile());
		Assert.assertNotNull(CommonUtils.readFromDelimiterFile(configPath5.getPath(),"|","true","_test"));
	}

}
