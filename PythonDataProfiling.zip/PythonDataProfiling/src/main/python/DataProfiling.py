'''
Created on Dec 4, 2019

@author: anpareek
'''
from pyspark.sql.session import SparkSession

spark = SparkSession.builder.getOrCreate()

df = spark.read.csv(r"C:\Users\anpareek\Desktop\users.csv")
df.show()