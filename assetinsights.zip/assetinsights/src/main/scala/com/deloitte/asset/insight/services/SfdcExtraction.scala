package com.deloitte.asset.insight.services

import scala.collection.Map

trait SfdcExtraction {
  def extractObjectFromSfdc(sfdcKeyValuesDF: Map[String, List[String]], layerName:String)
}