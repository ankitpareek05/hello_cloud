package com.deloitte.asset.insight.utils

import java.net.URI
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime

import scala.collection.Map
import scala.collection.mutable._

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.storage.StorageLevel

import com.deloitte.asset.insight.service.impl.RuleProcessImpl
import com.deloitte.asset.insight.service.impl.StagingImpl
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.services.RuleProcess
import org.apache.spark.sql.expressions.Window

case class BatchTable(ai_batch_id: Long, batch_file_name: String, batch_start_time: String, batch_step_name: String, step_start_time: String, step_end_time: String, batch_end_time: String, status: String)

/*
 * Common Utils for Utility functions
 * Developer: Ankit Pareek
 */

object CommonUtils extends Logging {

  // Getting sparkSession object
  val sparkSession = InitiateSparkContext.getSparkSession()

  // Getting sparkContext object
  val sparkContext = InitiateSparkContext.getSparkContext()

  // Getting sqlContext object
  val sqlContext = InitiateSparkContext.getSqlContext()

  import sparkSession.implicits._
  val debugFlag = GlobalVariables.getDebugFlag

  /**
   * Implicits methods
   */
  case class LookUpDataDf(From_Value: String)

  implicit class extraUtilityMethod(DF: DataFrame) {

    def showOrNoShow(debugFlag: String) = {
      if (debugFlag.equalsIgnoreCase("true")) {
        DF.show()
      }
    }
  }

  /**
   * @param df : original data frame
   * @param measureCols : columns list for tag value
   * @return : updated data frame with tag value columns added
   */
  def createMeasureNameValue(inputDF: DataFrame, measureCols: Seq[String]): DataFrame = {

    val tagValueCols = explode(array(
      measureCols.map(c => {
        struct(lit(c).alias(SchemaConstants.AI_MEASURE_NAME), col(c).cast(StringType).alias(SchemaConstants.AI_MEASURE_VALUE))
      }): _*))
    val measureColumn = measureCols.map(col(_)).toArray
    val initialCols = inputDF.columns.map(col(_)).diff(measureColumn)

    val modifiedDF = inputDF.select(initialCols :+ tagValueCols.alias("_kvs"): _*)
      .select(initialCols ++ Seq(col("_kvs." + SchemaConstants.AI_MEASURE_NAME), col("_kvs." + SchemaConstants.AI_MEASURE_VALUE)): _*)

    modifiedDF
  }

  /**
   * @param df : original data frame
   * @param measureCols : columns list for tag value
   * @param : Column Name for tag value Columns
   * @return : updated data frame with tag value columns added
   */
  def createMeasureNameValue(inputDF: DataFrame, measureNameCol: String, measureValueCol: String, measureCols: List[String]): DataFrame = {

    val tagValueCols = explode(array(
      measureCols.map(c => {
        struct(lit(c).alias(measureNameCol), col(c).cast(StringType).alias(measureValueCol))
      }): _*))
    val measureColumn = measureCols.map(col(_)).toArray
    val initialCols = inputDF.columns.map(col(_)).diff(measureColumn)

    val modifiedDF = inputDF.select(initialCols :+ tagValueCols.alias("_kvs"): _*)
      .select(initialCols ++ Seq(col("_kvs." + measureNameCol), col("_kvs." + measureValueCol)): _*)

    modifiedDF
  }

  /**
   * @input: array of column names
   * @return : array of columns
   */
  def getColumnsArray(keyColumns: Array[String]): Array[Column] = {
    val arrKeyColumns = keyColumns.map { column =>
      col(column)
    }
    arrKeyColumns
  }

  /**
   * Responsible for appending Primary Key to the existing DataFrame
   * @Input:Primary key columns, input Data frame
   * @return: updated DataFrame
   */

  def getDFWithPrimaryKey(keyCols: Array[String], inputDF: DataFrame): DataFrame = {

    val keyColumns = getColumnsArray(keyCols)
    val concatColumns = concat_ws("_", keyColumns: _*)
    val modifiedDF = inputDF.withColumn(CommonConstants.PRIMARY_KEY, concat(concatColumns))
    modifiedDF

    //modifiedDF

  }

  /**
   * Responsible for appending Batch ID to the existing DataFrame
   * @Input: Dataframe,ntimestamp
   * @return:DataFrame
   */

  def getDFWithBatchId(inputDF: DataFrame, unxTimeStamp: Long): DataFrame = {
    var batchIdColName = GlobalVariables.getCoreKeyBatchIdColName.mkString
    log.info("Adding Batch ID into Dataframe")
    val dfWithBatchId = inputDF.withColumn(batchIdColName, lit(unxTimeStamp))
    log.info("Added Batch ID into Dataframe")
    dfWithBatchId
  }

  def getDFWithEffDate(inputDF: DataFrame, effectiveDate: String, effectiveDateFormat: String, timeStamp: String): DataFrame = {

    val effDateColName = GlobalVariables.getCoreKeyAsOfDateColName.mkString
    log.info("Verifying if spark.effective.date is present in Config file or not")
    var format = ""
    if (!effectiveDateFormat.equalsIgnoreCase("NA")) {
      format = effectiveDateFormat
    } else
      format = "yyyyMMdd"

    if (effectiveDate.equalsIgnoreCase("na")) {
      log.info("Date to be mapped from Source file in Effective date not found in config file")

      log.info("Adding Date as mentioned in the file name ")
      val inputFilePath = inputDF.withColumn("Input_File", input_file_name).select("Input_File").head().getString(0)
      log.info("inputFilePath : " + inputFilePath)
      var inputFileNm = inputFilePath.split("/").last
      inputFileNm = inputFileNm.split('.').init.mkString(".")

      var extractedFileDt = CommonConstants.BLANK_STRING

      val dateFormat = "/d{1,9}".r
      dateFormat.findFirstMatchIn(inputFileNm) match {
        case Some(_) => {
          extractedFileDt = inputFileNm.split("_", 2)(0)

        }
        case None =>
          val dateFormat = "([a-zA-Z0-9]_*)[_][0-9]+".r
          dateFormat.findFirstIn(inputFileNm) match {
            case Some(_) => {
              extractedFileDt = CommonUtils.extractFileNameDate(inputFileNm, "_")
              //format = "yyyyMMdd"
            }
            case None => {
              extractedFileDt = timeStamp
              format = "yyyy-MM-dd hh:mm:ss"
            }

          }
      }

      //val frmt = "yyyy-MM-dd'T'HH:mm:ss"

      inputDF.withColumn(effDateColName, udfstandardizeDateYYYYMMDD(lit(extractedFileDt), lit(format)))
      //udfstandardizeDateYYYYMMDD(col(effDt),lit(frmt))
    } else {
      log.info("Date to be mapped from Source file in Effective date found in config file")
      log.info("Adding " + effectiveDate + " as Effective Date")
      if (!effectiveDateFormat.equalsIgnoreCase("NA")) {
        inputDF.withColumn(effDateColName, udfstandardizeDateYYYYMMDD(inputDF(effectiveDate), lit(effectiveDateFormat)))
      } else
        inputDF.withColumn(effDateColName, inputDF(effectiveDate))
    }
  }

  def udfstandardizeDateYYYYMMDD = udf { (dateColumn: String, format: String) =>
    {
      var dtCol = dateColumn
      var frmtlen = format.size
      if (dtCol.size < frmtlen) {
        val dtCol1 = dtCol.toInt
        dtCol = f"$dtCol1%08d"
      }
      val inputdateFormat = new SimpleDateFormat(format)
      val inputdate = inputdateFormat.parse(dateColumn)
      val dateFormatStr = "yyyy-MM-dd hh:mm:ss"

      val outputDateFormat = new SimpleDateFormat(dateFormatStr)
      val formattedDate = outputDateFormat.format(inputdate)
      formattedDate
    }
  }

  def getDFWithKnowledgeDate(inputDF: DataFrame, knowDate: String, knowDateFormat: String, Timestamp: String): DataFrame = {

    val knowDateColName = GlobalVariables.getCoreKeyAsOnDateColName
    if (!knowDate.equalsIgnoreCase("NA")) {
      log.info("Knowledge date Action found in Config file")
      log.info("Adding Knowledge date into DataFrame")
      //udfstandardizeDateYYYYMMDD(inputDF(effectiveDate), lit(effectiveDateFormat))
      if (!knowDateFormat.equalsIgnoreCase("NA")) {
        log.info("Knowledge date Standarization in Progress")
        inputDF.withColumn(CommonConstants.KNOWLEDGE_DT, udfstandardizeDateYYYYMMDD(inputDF(knowDate), lit(knowDateFormat)))
      } else {
        log.info("No Knowledge date format provided in Config file. Hence, adding knowledge date without Standarization")
        inputDF.withColumn(knowDateColName, inputDF(knowDate))
      }
    } else {
      log.info("Adding Process date as an knowledge date")
      val format = "yyyy-MM-dd hh:mm:ss"
      inputDF.withColumn(knowDateColName, udfstandardizeDateYYYYMMDD(lit(Timestamp), lit(format)))

    }

  }

  def getDFWithProcessedDate(inputDF: DataFrame, processDate: String): DataFrame = {
    //log.info("Adding Batch ID into Dataframe")
    val dfWithProcessedDate = inputDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(processDate))
    //log.info("Added Batch ID into Dataframe")
    dfWithProcessedDate
  }
  /**
   * Responsible for fetching selected Columns from Dataframe
   * @Input:Array[ String ], Dataframe
   * @return:DataFrame
   */
  def getDFWithSubsetCol(subsetcols: List[String], inputDF: DataFrame): DataFrame = {
    //val subsetColumns = getColumnsArray(subsetcols)
    val modifiedDF = inputDF.select(subsetcols.head, subsetcols.tail: _*)
    modifiedDF
  }

  /**
   * Read data from file and convert it into DataFrame
   * @Input:inputfilePath, delimiter, Header=True/False
   * @return:Dataframe
   */
  def readFromDelimiterFile(inputFile: String, delimiter: String, headerVal: String): DataFrame = {
    val dataFrame = sparkSession.read
      .option("inferSchema", "true")

      .option("delimiter", delimiter)
      .option("parserLib", "univocity")
      .option("header", headerVal)
      .option("nullValue", "null").csv(inputFile).toDF()
    dataFrame
  }

  /**
   * Read data from file and convert it into DataFrame
   * @Input:inputfilePath,delimiter,Header=True/False
   * @return:Dataframe
   */

  def readFromFFile(inputFile: String, headerVal: String, inferSchema: String): DataFrame = {
    val sparkSession = InitiateSparkContext.getSparkSession()
    val dataFrame = sparkSession.read
      .option("header", headerVal)
      .option("inferSchema", inferSchema)
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .csv(inputFile)
    dataFrame
  }

  /**
   * Writes data frame's data into S3 location
   * Developer : Kanika Sharma
   */
  def writeToS3(df: DataFrame, outputPath: String) = {

    df.write
      .option("header", "true")
      .option("nullValue", "N/A")
      .option("fileType", "csv")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("multiLine", "true")
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      //  .option("accessKey", CommonConstants.S3_ACCESS_KEY)
      //  .option("secretKey", CommonConstants.S3_SECRET_ACCESS_KEY)
      .mode("overwrite")
      .csv(outputPath)

  }

  /**
   * Validate whether Key Columns is null/Blank/empty
   * @input : column value
   * @returns : Map of validation details
   */
  def isValidationPassed(colValue: String): HashMap[String, String] = {
    val hashmap = new HashMap[String, String]()

    if ((colValue != null && !colValue.trim.isEmpty && !colValue.trim().equalsIgnoreCase("null"))) {
      hashmap.put("isValid", "true")
    } else {
      hashmap.put("isValid", "false")
    }
    hashmap
  }

  /**
   * Extract file name and Date from String
   * Developer: Ankit Pareek
   */
  def extractFileNameDate(fileNm: String, delimiter: String) = {
    val extractedFileName = fileNm.splitAt(fileNm.lastIndexOf(delimiter))._1
    val extractedDateFromFileName = fileNm.splitAt(fileNm.lastIndexOf(delimiter) + 1)._2
    //val extractedDateWoExt = extractedDateFromFileName.splitAt(extractedDateFromFileName.lastIndexOf("."))._1
    (extractedDateFromFileName)

  }

  /**
   * Extract file Date from String
   * Developer: Ankit Pareek
   */
  def extractDateFromFileName(fileName: String, delimiter: String): String = {

    val extractedDateFromFileNm = fileName.splitAt(fileName.lastIndexOf(delimiter) + 1)._2
    extractedDateFromFileNm
  }

  /**
   * Get current time stamp
   * Developer: Ankit Pareek
   */
  def getTimeStamp(): (String, Long) = {

    val unixTime: Long = System.currentTimeMillis
    val currentTimeStamp = new Timestamp(unixTime)
    (currentTimeStamp.toString(), unixTime)

  }

  /**
   * Add Source timeStamp to the dataframe
   * @return:Dataframe
   */
  def getDFwithSourceTimeStamp(inputDF: DataFrame, timeStamp: String): DataFrame = {

    val modifiedDF = inputDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(timeStamp))
    modifiedDF
  }

  /**
   * Reads config file & returns Key and array of associated values
   * Developer: Neeraj Kumar
   */
  def getConfigData(configFilePath: String) = {

    //val configFile = sparkSession.textFile(configFilePath)
    val configFile = sparkSession.read.textFile(configFilePath)

    val records = configFile.map(line => {
      var ruleName: String = ""
      var columnNames: Array[String] = Array()

      if (line.contains("=")) {
        val splitRecords = line.split("=")
        ruleName = splitRecords(0)
        if (splitRecords.length > 1) {
          if (splitRecords(1) != null)
            columnNames = splitRecords(1).split(",")
        }
      }

      (ruleName, columnNames.toList)
    }).collect().toMap

    records
  }

  /*
	 * @return: HiveContext with important properties set
	 *
	 */
  /*  def getHiveProperties(jobName: String) = {

    val hiveSession = InitiatesparkContext.getHiveContext()

    hiveContext.setConf("hive.execution.engine", "mr")
    hiveContext.setConf("hive.exec.parallel", "true")
    hiveContext.setConf("mapred.job.name", jobName)
    hiveContext.setConf("spark.sql.autoBroadcastJoinThreshold", "2048576000")
    hiveContext.setConf("spark.sql.hive.convertMetastoreOrc", "false")
    hiveContext.setConf("hive.exec.dynamic.partition", "true")
    hiveContext.setConf("hive.exec.dynamic.partition.mode", "nonstrict")

    hiveContext

  }*/

  def readFromS3Parquet(inputPath: String, headerRequired: String) = {

    var readParquetFromS3Df = sparkSession.read
      .option("header", headerRequired)
      .option("inferSchema", "true")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      //.option("mergeSchema", "false")
      //.option("x-amz-server-side-encryption", "AES256")
      .parquet(inputPath)
    readParquetFromS3Df
  }

  def writeToS3Parquet(df: DataFrame, outputPath: String, headerRequired: String, writeMode: String) = {
    df.coalesce(4)
      .write
      .option("header", headerRequired)
      .option("nullValue", "")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("multiLine", "true")
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      //.option("x-amz-server-side-encryption", "AES256")
      .mode(writeMode)
      .parquet(outputPath)
  }

  // Code for auto generated Sequence UDF
  def addAutoIncremetColumn(df: DataFrame, colName: String): DataFrame =
    {

      val yarnId = sparkContext.applicationId

      var df1 = df.withColumn("curr_timestamp", getcurrentTimestampUDF())
      df1 = df1.withColumn("mono_incr_id", monotonically_increasing_id())

      var df2 = df1.withColumn(colName, getAutoIncrementSeqUDF(col("curr_timestamp"), lit(yarnId), col("mono_incr_id")))

      val finalDF = df2.drop(col("curr_timestamp")).drop(col("mono_incr_id"))
      finalDF
    }

  val getcurrentTimestampUDF = udf[String](() => {

    var timestamp = ""
    timestamp = System.currentTimeMillis().toString()
    timestamp

    //    System.nanoTime()
  })

  val getAutoIncrementSeqUDF = udf((currentTimestamp: Long, yarnId: String, monoIncrId: Long) => {
    var yarnIdSeq = ""
    if (yarnId.contains("_"))
      yarnIdSeq = yarnId.split("_")(2)
    else if (yarnId.contains("-"))
      yarnIdSeq = yarnId.split("-")(1)

    var finalSeq = currentTimestamp + yarnIdSeq + monoIncrId
    finalSeq
  })

  //  // Code for auto generated Sequence UDF
  //  def addAutoIncremetColumn(df: DataFrame, colName: String): DataFrame =
  //    {
  //      //val sc =  sp InitiatesparkSession.getsparkSession()
  //      val yarnId = sparkSession.sparkContext.applicationId
  //
  //      //var df1 = df.withColumn("curr_timestamp", getcurrentTimestampUDF()).withColumn("mono_incr_id", monotonically_increasing_id())
  //      var finalDF = df.withColumn(colName, getAutoIncrementSeqUDF())
  //
  //      //val finalDF = df2
  //      finalDF
  //    }
  //
  //  val getcurrentTimestampUDF = udf[Long](() => {
  //    System.currentTimeMillis()
  //    //    System.nanoTime()
  //  })
  //
  //  val getAutoIncrementSeqUDF = udf(() => {
  //
  //    var eventid = randomUUID().toString
  //    eventid = eventid.replace("a", "1")
  //    eventid = eventid.replace("b", "2")
  //    eventid = eventid.replace("c", "3")
  //    eventid = eventid.replace("d", "4")
  //    eventid = eventid.replace("e", "5")
  //    eventid = eventid.replace("f", "6")
  //    eventid = eventid.replace("-", "")
  //    eventid
  //
  //  })
  //
  //  def getSrcId(inputDf: DataFrame, configData: Map[String, Array[String]]): DataFrame = {
  //
  //    val firmCd = configData.get(CommonConstants.KEY_FIRM_CD).get.mkString.trim()
  //    val fileNm = configData.get(CommonConstants.KEY_FILE_NM).get.mkString.trim().toUpperCase()
  //    val srcNm = configData.get(CommonConstants.KEY_SOURCE_NM).get.mkString.trim().toUpperCase()
  //    log.info("Adding Source ID into Dataframe based on :" + firmCd + " and " + fileNm)
  //
  //    //var recrd = CommonConstants.BLANK_STRING
  //    //var recrd=0
  //    var recrd = 0L
  //    log.info("Reading path of Lookup table mentioned in Config File")
  //    val lookupTable_path = configData.get(CommonConstants.KEY_SRCID_LOOKUP_TBL).get.mkString.trim()
  //    if (!lookupTable_path.isEmpty() || !lookupTable_path.equalsIgnoreCase("NA") || lookupTable_path != null) {
  //      log.info("Path found in Config file")
  //      log.info("Reading Lookup data into Dataframe")
  //
  //      var df_lookup = readFromCsvFile(lookupTable_path, CommonConstants.FALSE)
  //      df_lookup = df_lookup.toDF(SchemaConstants.LOOKUPTBLSCHEMA.map(_.trim().toUpperCase()): _*)
  //
  //      val list = df_lookup.where(col(CommonConstants.USER_CODE) === firmCd.trim() && col(CommonConstants.FILE_NAME) === fileNm && col(CommonConstants.SOURCE_NAME) === srcNm).select(col(CommonConstants.SOURCE_ID)).collectAsList()
  //      log.info("Source ID for " + firmCd + " and " + fileNm + " is: " + recrd)
  //      if (!list.isEmpty()) {
  //        recrd = list.get(0).getLong(0)
  //        log.info("Source ID for " + firmCd + " and " + fileNm + " is: " + recrd)
  //        log.info("Source ID for " + firmCd + " and " + fileNm + " is: " + recrd)
  //      }
  //      val dfWithSrcId = inputDf.withColumn(CommonConstants.SRC_ID, lit(recrd))
  //      log.info("Source ID is added into the DataFrame")
  //      dfWithSrcId
  //
  //    } else {
  //      log.info("Path not found in Config file. Hence, unable to add source ID Core key")
  //      inputDf
  //    }
  //
  //  }

  def getDfWithSrcId(inputDf: DataFrame): DataFrame = {

    val srcIdColName = GlobalVariables.getCoreKeySourceIdColName.mkString
    var expectedDf = inputDf.withColumn(srcIdColName, lit(GlobalVariables.getSourceId))
    expectedDf
  }

  def getS3ListOfFiles(s3Path: String): String = {
    val s3FS = FileSystem.get(new URI(s3Path), sparkContext.hadoopConfiguration)
    val filesList = s3FS.listFiles(new Path(s3Path), false)
    var path = "" //new org.apache.hadoop.fs.Path("")
    while (filesList.hasNext()) {
      path = filesList.next().getPath.toString()
    }
    path
  }

  def isS3FileExists(s3Path: String): String = {

    val s3FS = FileSystem.get(new URI(s3Path), sparkContext.hadoopConfiguration)
    var bool = ""
    try {
      val filesList = s3FS.listFiles(new Path(s3Path), true)
      if (filesList.hasNext()) {
        bool = "TRUE"
      }
    } catch {
      case e: Exception => {
        bool = "FALSE"
      }

    }
    bool

  }

  def getDfwithSchemaStandarized(inputDf: DataFrame, configData: Map[String, List[String]], layerName: String): DataFrame = {
    var stageProcess: StagingImpl = new StagingImpl()
    val stageStandardizedValidate = stageProcess.processSchemaStandarization(inputDf, configData, layerName)
    stageStandardizedValidate
  }

  //Author :Sunny for Cleansing and Standardization
  def getConfigDataStandardization(configFilePath: String) = {
    val configFile = sparkSession.read.textFile(configFilePath)
    val records = configFile.map(line => {
      val splitRecords = line.split(",")
      splitRecords
    }).collect()
    records
  }

  def getDeltaDf(structDataFrame: DataFrame, configData: Map[String, List[String]]): DataFrame = {
    val inputFileProcessed = configData.get(CommonConstants.S3_INPUT_PATH_PROCESSED).get.mkString
    log.info("Finding Delta Records if present at: " + inputFileProcessed)
    var deltaDF = sparkSession.emptyDataFrame
    if (CommonUtils.isS3FileExists(inputFileProcessed).equalsIgnoreCase("TRUE")) {
      log.info("Delta Records Found")
      var inputFileProcessedDF = CommonUtils.readFromCsvFile(inputFileProcessed, "true", "fasle")
      deltaDF = structDataFrame.except(inputFileProcessedDF)

    } else {
      log.info("No Delta Records found")
      deltaDF = structDataFrame
    }
    deltaDF
  }

  //  def getDfAfterKeyValidation(strutDF: DataFrame, configData: Map[String, List[String]]): DataFrame =
  //    {
  //      var ruleProcess: RuleProcess = new RuleProcessImpl()
  //      var keyValidatedDf = ruleProcess.processKeyValidationRule(strutDF, configData)
  //      keyValidatedDf
  //    }

  def updateBatchTable(ai_batch_id: Long, batch_file_name: String, batch_start_time: String, batch_step_name: String, step_start_time: String, step_end_time: String, batch_end_time: String, status: String): DataFrame =
    {
      //var seq: Seq[String] = Seq()
      var seq: Seq[Array[String]] = Seq(Array(ai_batch_id.toString(), batch_file_name, batch_start_time, batch_step_name, step_start_time, step_end_time, batch_end_time, status))
      val recordsRdd = sparkContext.parallelize(seq)
      var batchTableRdd = recordsRdd.map { col =>
        BatchTable(col(0).toLong, col(1), col(2), col(3), col(4), col(5), col(6), col(7))
      }
      val batchTableDf = batchTableRdd.toDF()
      batchTableDf
    }

  def convertStringToDate(value: String): Date = {
    var simpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    log.info("simpleDateFormat : " + simpleDateFormat)
    var date = simpleDateFormat.parse(value)
    log.info("date : " + date)
    var date1 = new SimpleDateFormat("MM/dd/YY").format(date)
    log.info("date1 : " + date1)
    var simpleDateFormat1 = new SimpleDateFormat("MM/dd/YY")
    val date2 = simpleDateFormat1.parse(date1)

    log.info("===>")
    log.info(date2)
    date
    /*
        val inputdateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    log.info(inputdateFormat)
    val inputdate = inputdateFormat.parse(dateColumn)
    val dateFormatStr = "MM-dd-YY"

    val outputDateFormat = new SimpleDateFormat(dateFormatStr)
    val formattedDate = outputDateFormat.format(inputdate)
    formattedDate*/

  }
  def setEnvVariables(fileName: String, srcName: String, layerName: String, configDf: DataFrame) {

    var sourceId = ""
    var effDateColName = ""
    var knowDateColName = ""
    var batchIdColName = ""
    var srcIdColName = ""
    var googleAPIQualityRating = ""
    var codeCodeLookupPath = ""

    log.info("Setting Environment Variable")

    val envDf = configDf.filter(configDf("TYPE") === "ENV" && configDf("FILE_NAME") === fileName.trim() && configDf("SOURCE_NAME") === srcName.trim() && configDf("ACTION") === "BUCKET_NAME").toDF()
    val rootPath = configDf.filter(configDf("TYPE") === "ENV" && configDf("ACTION") === "BUCKET_NAME").toDF().select("SRC_FIELD").head().getString(0)
    try {
      googleAPIQualityRating = configDf.filter(configDf("TYPE") === "ENV" && configDf("ACTION") === "GOOGLE_API_QUALITY_RATING").toDF().select("SRC_FIELD").head().getString(0)
    } catch {
      case ex: Exception => {
        log.warn("Action: GOOGLE_API_QUALITY_RATING  not found in Config File. Hence Setting Default as: 0")
        googleAPIQualityRating = "0"
      }
    }
    try {
      codeCodeLookupPath = rootPath + configDf.filter(configDf("TYPE") === "ENV" && configDf("ACTION") === "CODE_CODE_LOOKUP_PATH").toDF().select("SRC_FIELD").head().getString(0)
    } catch {
      case ex: Exception => {
        log.warn("Action: CODE CODE LOOKUP PATH  not found in Config File.")
      }
    }
    sourceId = envDf.select(envDf("SOURCE_ID")).head().get(0).toString()
    try {
      effDateColName = configDf.filter(configDf("TYPE") === "ENV" && configDf("SOURCE_NAME") === "ALL" && configDf("ACTION") === "CORE_KEY_EFFECTIVE_DATE_COL_NAME").toDF().select("SRC_FIELD").head().getString(0)
    } catch {
      case ex: Exception => {
        log.warn("Action: CORE_KEY_EFFECTIVE_DATE_COL_NAME  not found in Config File. Hence Setting Default as:" + CommonConstants.EFFECTIVE_DT)
        effDateColName = CommonConstants.EFFECTIVE_DT
      }
    }
    try {
      knowDateColName = configDf.filter(configDf("TYPE") === "ENV" && configDf("SOURCE_NAME") === srcName.trim() && configDf("ACTION") === "CORE_KEY_KNOWLEDGE_DATE_COL_NAME").toDF().select("SRC_FIELD").head().getString(0)
    } catch {
      case ex: Exception => {
        log.warn("Action: CORE_KEY_KNOWLEDGE_DATE_COL_NAME  not found in Config File. Hence Setting Default as: " + CommonConstants.KNOWLEDGE_DT)
        knowDateColName = CommonConstants.KNOWLEDGE_DT
      }
    }
    try {
      batchIdColName = configDf.filter(configDf("TYPE") === "ENV" && configDf("SOURCE_NAME") === srcName.trim() && configDf("ACTION") === "CORE_KEY_BATCHID_COL_NAME").toDF().select("SRC_FIELD").head().getString(0)
    } catch {
      case ex: Exception => {
        log.warn("Action: CORE_KEY_BATCHID_COL_NAME  not found in Config File. Hence Setting Default as: " + CommonConstants.BATCH_ID)
        batchIdColName = CommonConstants.BATCH_ID
      }
    }

    try {
      srcIdColName = configDf.filter(configDf("TYPE") === "ENV" && configDf("SOURCE_NAME") === srcName.trim() && configDf("ACTION") === "CORE_KEY_SOURCEID_COL_NAME").toDF().select("SRC_FIELD").head().getString(0)

    } catch {
      case ex: Exception => {
        log.warn("Action: CORE_KEY_SOURCEID_COL_NAME  not found in Config File. Hence Setting Default as: " + CommonConstants.SRC_ID)
        srcIdColName = CommonConstants.SRC_ID
      }
    }

    log.info("Setting BucketName as: " + rootPath)
    GlobalVariables.setRootPath(rootPath)

    log.info("Setting SourceId as: " + sourceId)
    GlobalVariables.setSourceId(sourceId)

    log.info("Setting filename as: " + fileName)
    GlobalVariables.setFileName(fileName)

    log.info("Setting Source Name as: " + srcName)
    GlobalVariables.setSourceName(srcName)

    log.info("Setting Layer Name as: " + layerName)
    GlobalVariables.setLayerName(layerName)

    log.info("Setting Effective Date Column Name as: " + effDateColName)
    GlobalVariables.setCoreKeyAsOfDateColName(effDateColName)

    log.info("Setting Knowledge Date Column Name as" + knowDateColName)
    GlobalVariables.setCoreKeyAsOnDateColName(knowDateColName)

    log.info("Setting Batch ID Column Name as" + batchIdColName)
    GlobalVariables.setCoreKeyBatchIdColName(batchIdColName)

    log.info("Setting Source ID Column Name as" + srcIdColName)
    GlobalVariables.setCoreKeySourceIdColName(srcIdColName)

    log.info("Setting GoogleAPI Quality Rating as: " + googleAPIQualityRating)
    GlobalVariables.setGoogleAPIQualityRating(googleAPIQualityRating)

    log.info("Setting Code Code lookup path as: " + codeCodeLookupPath)
    GlobalVariables.setLookUpFilePath(codeCodeLookupPath)

  }

  def parseConfigFile(inputPath: String, fileName: String = "NA", srcName: String = "NA", layerName: String = "NA"): Map[String, List[String]] = {

    log.info("Parsing config file")
    var configDF = CommonUtils.readFromCsvFile(inputPath, "true", "false").na.fill("NA")
    //configDF.show()
    //Assign variable globally
    setEnvVariables(fileName, srcName, layerName, configDF)
    // filter based on file
    configDF = configDF.filter(configDF("FILE_NAME") === fileName.trim().toUpperCase())
    //configDF.show()

    log.info("Converting Config file as Key-Value Pair ")
    // Add columm as key
    configDF = configDF.withColumn("KEY", concat(configDF("ARCHITECTURE_LAYER"), lit("_"), configDF("TARGET_TABLE"), lit("_"), configDF("ACTION")))
    //    configDF.show()
    configDF = configDF.withColumn("VALUE", fieldConcatenation(configDF("SRC_FIELD"), configDF("TARGET_O"), configDF("TARGET_C")))
    //    configDF.show()

    var mappedDF = configDF.groupBy("KEY").agg((collect_list("VALUE")).alias("VALUE"))
    //    mappedDF.printSchema()
    //    mappedDF.show(false)

    var configRdd = mappedDF.rdd.map(x => {
      (x(0).toString().trim().toLowerCase().replace("_", "."), x(1).asInstanceOf[Seq[String]].toList.map(x => {
        if (x == null || x == "") { "NA" }
        else (x)
      }))

    }).collectAsMap()

    log.info("Config file parsed")
    configRdd
  }

  def queryBuilder(selectColumns: Map[String, List[String]], joinColumns: Map[String, List[String]], tablesList: Map[String, List[String]],
                   whereColumns: Map[String, List[String]]): String = {
    var query = "select "

    // putting together the columns to display
    if (!selectColumns.isEmpty) {
      query = query + queryConcatenation(selectColumns, " , ")
    } else {
      log.info("There are no select columns so select all the columns from all the tables ")
      query = query + " * "
    }

    // adding tables and join conditions
    var fromTables = " from "
    // TODO Need to handle type of join
    // if the joinconditions are not there that means its a straight forward select from one table
    if (!joinColumns.isEmpty) {
      //var i = 0
      for (i <- 1 to tablesList.size) {

        val tables = tablesList.get("standardization.join.table." + i).get.toList(0).split(":")
        val JoinConditionList = joinColumns.get("standardization." + tables(0).toLowerCase() + ".join.condition." + i).get.toList

        var joinCondition = ""
        for (eachJoinCondition <- JoinConditionList) {
          joinCondition = joinCondition + eachJoinCondition.replaceAll(":", " = ") + " and "
        }
        // Removing the last 'and' keyword
        joinCondition = joinCondition.splitAt(joinCondition.lastIndexOf(" and "))._1

        // Handling the table joins as for the first time the query looks like 'table1 join table2' and then onwards 'join table3'
        if (i == 1) {
          fromTables = fromTables + tables(0) + " left join " + tables(1) + " on " + joinCondition
        } else {
          fromTables = fromTables + " left join " + tables(1) + " on " + joinCondition
        }
      }
    } else {
      fromTables = fromTables + tablesList.head._2(0)
    }

    // checking if the where conditions are there or not
    var whereCondition = " "
    if (!whereColumns.isEmpty) {
      whereCondition = " where " + queryConcatenation(whereColumns, " and ")
    }

    query = query + fromTables + whereCondition
    query

  }

  def queryConcatenation(elementList: Map[String, List[String]], keyWord: String): String = {

    var querySnippet = ""
    for (eachList <- elementList.values) {
      for (eachElement <- eachList) {
        if (eachElement.split(":").size == 2) {
          querySnippet = querySnippet + eachElement.split(":")(0) + " AS " + eachElement.split(":")(1) + keyWord
        } else {
          querySnippet = querySnippet + eachElement + keyWord
        }
      }
    }
    querySnippet = querySnippet.splitAt(querySnippet.lastIndexOf(keyWord))._1
    querySnippet
  }

  def matchProcess(inputSourceDF: DataFrame, matchKey: String, matchPriority: String, matchRules: Map[String, List[String]], outputPath: String, pivotInputPath: String, hiveContext: SQLContext, curr_time_stamp: String) = {

    var matchResultDF: DataFrame = null
    var matchResultDFForPivot: DataFrame = null

    //var inputSourceDF_masked = inputSourceDF.na.fill("NA_INVALID")
    inputSourceDF.createOrReplaceTempView("df1")
    inputSourceDF.createOrReplaceTempView("df2")
    import scala.collection.immutable.ListMap

    val matchRulesSorted = ListMap(matchRules.toSeq.sortWith(_._1 > _._1): _*)

    log.info("\n matchRulesSorted ")
    matchRulesSorted.foreach(data => { log.info(data) })

    matchRulesSorted.foreach(data => {

      var ruleName = ""
      if (data._1.split("\\.").size == 7) {
        ruleName = data._1.split("\\.")(5) + "." + data._1.split("\\.")(6)
      } else {
        ruleName = data._1.split("\\.")(5)
      }

      log.info("Started executing rule :" + ruleName + "\n")
      var matchConditionList = new ListBuffer[String]()
      var whereConditionList = new ListBuffer[String]()
      var selectColumnsList = new ListBuffer[String]()
      var fieldsForMatchDim = new ListBuffer[String]()
      var fieldsForMatchFact = new ListBuffer[String]()
      var fieldsForMatchDimAndFact = new ListBuffer[String]()
      var whereClause = ""
      var innerQuery = ""
      var innerQueryExists = false

      for (i <- 0 to (data._2.size - 1)) {
        data._2(i).split(":")(1) match {

          case "FUZZY" =>
            var master_field = data._2(i).split(":")(0).split("\\|")(0).trim()
            var match_field = data._2(i).split(":")(0).split("\\|")(1).trim()

            matchConditionList += "soundex(" + master_field + ") = soundex( " + match_field + ")"
            if (data._2(i).split(":").size > 2) {
              master_field = master_field + " AS " + data._2(i).split(":")(2).split("\\|")(0).trim().split("\\.")(1).trim()
              match_field = match_field + " AS " + data._2(i).split(":")(2).split("\\|")(1).trim().split("\\.")(1).trim() + "_MATCHED"

              selectColumnsList += master_field + ", " + match_field
              fieldsForMatchFact += data._2(i).split(":")(2).split("\\|")(0).trim().split("\\.")(1).trim()
              fieldsForMatchFact += data._2(i).split(":")(2).split("\\|")(1).trim().split("\\.")(1).trim() + "_MATCHED"
            } else {
              selectColumnsList += master_field + ", " + match_field + " AS " + match_field.split("\\.")(1).trim() + "_MATCHED"
              fieldsForMatchFact += match_field.split("\\.")(1).trim()
              fieldsForMatchFact += match_field.split("\\.")(1).trim() + "_MATCHED"
            }

          case "EXACT" =>
            var master_field = data._2(i).split(":")(0).split("\\|")(0).trim()
            var match_field = data._2(i).split(":")(0).split("\\|")(1).trim()
            matchConditionList += master_field + " = " + match_field
            if (data._2(i).split(":").size > 2) {
              master_field = master_field + " AS " + data._2(i).split(":")(2).split("\\|")(0).trim().split("\\.")(1).trim()
              match_field = match_field + " AS " + data._2(i).split(":")(2).split("\\|")(1).trim().split("\\.")(1).trim() + "_MATCHED"

              selectColumnsList += master_field + ", " + match_field
              fieldsForMatchFact += data._2(i).split(":")(2).split("\\|")(0).trim().split("\\.")(1).trim()
              fieldsForMatchFact += data._2(i).split(":")(2).split("\\|")(1).trim().split("\\.")(1).trim() + "_MATCHED"
            } else {
              selectColumnsList += master_field + ", " + match_field + " AS " + match_field.split("\\.")(1).trim() + "_MATCHED"
              fieldsForMatchFact += match_field.split("\\.")(1).trim()
              fieldsForMatchFact += match_field.split("\\.")(1).trim() + "_MATCHED"
            }

          case "FILTER_CONDITION" =>
            whereConditionList += data._2(i).split(":")(0).trim()

          case "SELECT_COLUMN_FOR_DIM" =>
            var select_field = data._2(i).split(":")(0).trim()
            var select_field_with_out_alias = select_field.split("\\.")(1).trim()
            if (select_field.contains("MATCH_SET")) {
              select_field_with_out_alias = select_field.split("\\.")(1).trim() + "_MATCHED"
              select_field = select_field + " AS " + select_field.split("\\.")(1).trim() + "_MATCHED"
            }
            selectColumnsList += select_field
            fieldsForMatchDim += select_field_with_out_alias

          case "SELECT_COLUMN_FOR_FACT" =>
            var select_field = data._2(i).split(":")(0).trim()
            var select_field_with_out_alias = select_field.split("\\.")(1).trim()
            if (select_field.contains("MATCH_SET")) {
              select_field_with_out_alias = select_field.split("\\.")(1).trim() + "_MATCHED"
              select_field = select_field + " AS " + select_field.split("\\.")(1).trim() + "_MATCHED"
            }
            selectColumnsList += select_field
            fieldsForMatchFact += select_field_with_out_alias

          case "SELECT_COLUMN_FOR_DIM_AND_FACT" =>
            var select_field = data._2(i).split(":")(0).trim()
            var select_field_with_out_alias = select_field.split("\\.")(1).trim()
            if (select_field.contains("MATCH_SET")) {
              select_field_with_out_alias = select_field.split("\\.")(1).trim() + "_MATCHED"
              select_field = select_field + " AS " + select_field.split("\\.")(1).trim() + "_MATCHED"
            }
            selectColumnsList += select_field
            fieldsForMatchDimAndFact += select_field_with_out_alias

          case "QUERY" =>
            innerQueryExists = true
            innerQuery += data._2(i).split(":")(0).trim()

          case _ => ""
        }
      }

      val matchConditions = matchConditionList.mkString(" AND ")
      whereClause = whereConditionList.mkString(" ")
      val selectColumns = selectColumnsList.mkString(", ")

      /*      if (!whereClause.isEmpty) {
        whereClause = " AND (" + whereClause + ") "
      }*/

      //var static_columns_for_dim = ListBuffer("AI_MATCH_RULE_ID", "AI_MATCH_ID" ,"AI_PARTY_ID", "AI_PARTY_ID_MATCHED")
      //fieldsForMatchDim = static_columns_for_dim ++ fieldsForMatchDim

      log.info("\n Match Dim Fields : " + fieldsForMatchDim)
      log.info("\n Match Pivot Fields : " + fieldsForMatchFact)
      log.info("\n All select fields for Match : " + selectColumnsList)

      log.info("Sub query exists for the currect rule : " + innerQueryExists)

      var matchTable = ""
      if (innerQueryExists) {
        matchTable = " ( " + innerQuery + " df1) MASTER_SET JOIN " + " ( " + innerQuery + " df2) MATCH_SET "
      } else {
        matchTable = " df1 MASTER_SET JOIN df2 MATCH_SET "
      }

      log.info("matchTable : " + matchTable)

      val matchQuery =
        "SELECT MASTER_SET." + matchKey + " AS AI_PARTY_ID,  MATCH_SET." + matchKey + " AS AI_PARTY_ID_MATCHED, '" +
          ruleName + "' AS AI_MATCH_RULE_ID, " +
          selectColumns + " FROM " + matchTable + " ON " +
          matchConditions +
          " WHERE " + whereClause
      //" WHERE MASTER_SET." + matchKey + " > MATCH_SET." + matchKey + whereClause

      log.info("\n matchQuery :" + matchQuery + "\n")

      matchResultDF = hiveContext.sql(matchQuery).distinct()
      matchResultDF = addAutoIncremetColumn(matchResultDF, "AI_MATCH_ID")
      matchResultDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

      if (matchResultDF.count() >= 1) {
        val matchResultDFSchema = matchResultDF.schema
        log.info("matchResultDFSchema : " + matchResultDFSchema)

        val matchWideMaster = matchResultDF.where("cast(ai_effective_date as timestamp) >= cast(ai_effective_date_matched as timestamp)").select(matchResultDF.columns.head, matchResultDF.columns.tail: _*)

        val matchWideSwap = matchResultDF.where("cast(ai_effective_date as timestamp) < cast(ai_effective_date_matched as timestamp)").select(matchResultDF.columns.head, matchResultDF.columns.tail: _*)
        matchWideSwap.createOrReplaceTempView("matchWideSwap")

        val matchWideSchema = matchWideSwap.schema
        log.info("matchWideSchema : " + matchWideSchema)
        val comma = " , "
        var measureNames = ""
        var measureNamesMatch = ""

        matchWideSchema.foreach(eachField => {
          if (eachField.name.toString().toLowerCase().endsWith("_matched")) {
            measureNames = measureNames + eachField.name.toString().toLowerCase().replace("_matched", "") + " AS " + eachField.name.toString().toLowerCase() + comma + eachField.name.toString() + " AS " + eachField.name.toString().toLowerCase().replace("_matched", "") + comma
          }
        })
        measureNames = measureNames.splitAt(measureNames.lastIndexOf(comma))._1
        val swapQuery = "select ai_match_id, ai_match_rule_id, " + measureNames + " from matchWideSwap "
        log.info("swapQuery ::::  " + swapQuery)

        val swappedColumns = sqlContext.sql(swapQuery).select(matchWideSwap.columns.head, matchWideSwap.columns.tail: _*)
        matchResultDF = matchWideMaster.union(swappedColumns).select(matchWideSwap.columns.head, matchWideSwap.columns.tail: _*)

        //log.info(" Output Match Dim size : " + matchResultDF.count())

        var matchResultDFForDim = matchResultDF.drop(fieldsForMatchFact: _*)
        var matchResultDFForPivot = matchResultDF.drop(fieldsForMatchDim: _*)

        matchResultDFForDim = matchResultDFForDim.withColumn("AI_MERGE_ACTION", lit(1))

        //log.info(" Writing matched data for Dim table generation, count of records : " + matchResultDFForDim.count())
        var currentRuleOutputPath = outputPath + "rule_" + ruleName + "_" + curr_time_stamp
        CommonUtils.writeToS3Parquet(matchResultDFForDim, currentRuleOutputPath, "true", "overwrite")

        log.info(" Writing matched data for Pivot table generation, count of records : ")
        var currentRulePivotDataOutputPath = pivotInputPath + "rule_" + ruleName + "_" + curr_time_stamp
        CommonUtils.writeToS3Parquet(matchResultDFForPivot, currentRulePivotDataOutputPath, "true", "overwrite")
      } else {
        log.info("\n No matched were found")
      }

      log.info("Completed executing rule :" + ruleName + "\n")
    })
  }

  def fieldConcatenation = udf((col1: String, col2: String, col3: String) => {
    //var concatDf=sparkSession.emptyDataFrame
    var colSeq = Seq(col1, col2, col3)
    colSeq = colSeq.filter(_ != "NA")
    colSeq.mkString(":")

  })

  def getDfAfterKeyValidation(strutDF: DataFrame, configData: Map[String, List[String]]): DataFrame =
    {
      var ruleProcess: RuleProcess = new RuleProcessImpl()
      var keyValidatedDf = ruleProcess.processKeyValidationRule(strutDF, configData)
      keyValidatedDf
    }

  // Method to replace \n to space(" ")
  def replaceNewLine(mainDF: DataFrame): DataFrame = {
    var dataFrame = mainDF
    val schema = dataFrame.schema

    schema.map(field => {

      if (field.dataType.equals(StringType)) {
        log.info("Replace New Line Rule Called for : " + field.name)
        dataFrame = dataFrame.withColumn((field.name), replaceNewLineUdf(col(field.name)))
      }
    })
    dataFrame
  }

  def singleSpace(col: Column): Column = {
    trim(regexp_replace(col, " +", " "))
  }

  def replaceNewLineUdf = udf((cols: String) => {

    if (cols != null) {
      cols.replaceAll("\n", " ").replaceAll("\n\r", " ").replaceAll("\r", " ").replaceAll(" +", " ").trim()
    } else {
      cols
    }
  })

  def createEmptyDF(columns: Array[String]): DataFrame = {

    val schema_rdd = StructType(columns.map(fieldName => StructField(fieldName, StringType, true)))

    var emptyDF = sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row], schema_rdd)

    return emptyDF
  }

  def addColumnBasedNewValue = udf((colValue: String, newValue: String) => {
    var newColValue = "NA"
    val additionalType = newValue.split(",").toList
    val additionalTypeMap = additionalType.map { col =>
      val split = col.split(":")
      (split(0), split(1))

    }.toMap

    //    val keySet = relTypeMap
    additionalTypeMap.map { x =>
      if (colValue.equalsIgnoreCase(x._1)) {
        newColValue = additionalTypeMap.getOrElse(x._1, "NA")
        //log.info(relValue)
      }

    }
    newColValue

  })

  def hashRemove = udf((colName: String) => {
    if ((colName != null) && (colName.contains('#'))) {
      colName.split("#").init.mkString
    } else {
      colName
    }
  })

  def writeSFDCObjects(data: DataFrame, instance: String, userName: String, password: String, objectName: String) = {
    data.write.format("com.springml.spark.salesforce").
      //mode(SaveMode.Append).
      option("login", instance).
      option("username", userName).
      option("password", password).
      //option("datasetName", "Account").
      option("sfObject", objectName).
      option("version", "43.0")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL").
      save()

  }

  def CodecodeValueLookUp(operation_type: String, from_source: String, to_source: String, data: String): DataFrame = {
    return CodecodeValueLookUp(operation_type, from_source, to_source, Array(data))
  }

  def CodecodeValueLookUp(operation_type: String, from_source: String, to_source: String, data: Array[String]): DataFrame = {
    val Df = data.map(x => {
      LookUpDataDf(x)
    })

    val dataDf = sparkSession.createDataFrame(Df)
    return CodecodeValueLookUp(operation_type, from_source, to_source, dataDf)
  }

  def getLatestData(tableLocation: String, groupByColumns: List[String], sortByColumns: List[String], tableName: String, recentDataPath: String): DataFrame = {

    // reading the parquet file into a daraframe
    var inuputDf = CommonUtils.readFromS3Parquet(tableLocation, "true")
    log.info("IinuputDf before schema : " + inuputDf.schema)

    // TODO this if condition can be removed when we start using the standadization data which contains 'INACTIVE_FLAG' in its schema
    if (!inuputDf.columns.contains("INACTIVE_FLAG")) {
      log.info("The table in location " + tableLocation + " is not having inactive_flag column. So adding it with 0 as default value.")
      inuputDf = inuputDf.withColumn("INACTIVE_FLAG", lit(0))
    }
    log.info("InuputDf after schema : " + inuputDf.schema)

    // filtering out the ai_party_ids and ai_rel_party_id which has inactive_flag set to '1' atleast once
    if (!tableLocation.contains("ai_phone") && !tableLocation.contains("ai_address")) {
      var inactiveDf: DataFrame = null
      var query = ""
      if (tableLocation.contains("ai_rel_party_party")) {
        inactiveDf = inuputDf.select(col("AI_REL_PARTY_ID"), col("AI_PARTY_ID"), col("REL_TYPE")).filter(col("INACTIVE_FLAG") === 1).distinct()
        query = "select df1.* from df1 left outer join df2 on df1.AI_REL_PARTY_ID = df2.AI_REL_PARTY_ID and df1.AI_PARTY_ID=df2.AI_PARTY_ID and df1.REL_TYPE=df2.REL_TYPE where df2.AI_REL_PARTY_ID is null and df2.AI_PARTY_ID is null and df2.REL_TYPE is null"
      } else {
        inactiveDf = inuputDf.select(col("AI_PARTY_ID")).filter(col("INACTIVE_FLAG") === 1)
        query = "select df1.* from df1 left outer join df2 on (df1.AI_PARTY_ID = df2.AI_PARTY_ID) where df2.AI_PARTY_ID is null"
      }
      inuputDf.createOrReplaceTempView("df1")
      inactiveDf.createOrReplaceTempView("df2")
      inuputDf = sqlContext.sql(query)
    }

    log.info("InuputDf after ignoring inactive records : " + inuputDf.schema)

    // getting the latest record
    val sortByColumnsWithOrder = sortByColumns.map(name => col(name).desc)
    val resultDF = inuputDf.withColumn("latest_record", row_number().over(
      Window.partitionBy(groupByColumns map col: _*).orderBy(sortByColumnsWithOrder: _*))).filter(col("latest_record") === 1)

    var activeLatestDf: DataFrame = null
    if (!tableLocation.contains("ai_phone") && !tableLocation.contains("ai_address")) {
      activeLatestDf = resultDF
    } else {
      log.info("Dropping the INACTIVE_FLAG column for : " + tableLocation)
      activeLatestDf = resultDF.drop("INACTIVE_FLAG")
    }

    log.info("location most recent record :::::::::: " + recentDataPath + tableName + "/")
    if (debugFlag.equalsIgnoreCase("true")) {
      log.info("Writing most recent data to s3 at : " + recentDataPath + tableName + "/")
      //CommonUtils.writeToS3Parquet(activeLatestDf.drop("latest_record"), recentDataPath + tableName + "/", "true", "overwrite")
    }
    activeLatestDf.drop("latest_record")

  }
  def getLatestDataForMerge(tableLocation: String, columnName: String, groupByColumns: List[String], sortByColumns: List[String], items: Array[String]): DataFrame = {

    // reading the parquet file into a daraframe
    var inputDf = CommonUtils.readFromS3Parquet(tableLocation, "true").filter(col(columnName).isin(items: _*)) //.na.fill("DEFAULT_MERGE")
    log.info("IinuputDf before schema : " + inputDf.schema)

    // TODO this if condition can be removed when we start using the standadization data which contains 'INACTIVE_FLAG' in its schema
    if (!inputDf.columns.contains("INACTIVE_FLAG")) {
      log.info("The table in location " + tableLocation + " is not having inactive_flag column. So adding it with 0 as default value.")
      inputDf = inputDf.withColumn("INACTIVE_FLAG", lit(0))
    }
    log.info("InuputDf after schema : " + inputDf.schema)

    // filtering out the ai_party_ids which has inactive_flag set to '1' atleast once
    if (!tableLocation.contains("ai_phone") && !tableLocation.contains("ai_address")) {
      val inactiveDf = inputDf.select(col(columnName)).filter(col("INACTIVE_FLAG") === 1)
      inputDf.createOrReplaceTempView("df1")
      inactiveDf.createOrReplaceTempView("df2")
      // as the dataframes left join is not giving the result correctly written the same logic in a query
      val query = "select df1.* from df1 left outer join df2 on (df1." + columnName + "= df2." + columnName + ") where df2." + columnName + " is null"
      /*      val joinColumns = List("AI_PARTY_ID").toSeq
      inuputDf = inuputDf.as("df1").join(inactiveDf, joinColumns, "left_outer").select($"df1.*").filter(inactiveDf("AI_PARTY_ID").isNull)*/
      inputDf = sqlContext.sql(query)
    }

    log.info("InuputDf after ignoring inactive records : " + inputDf.schema)

    // getting the latest record
    val sortByColumnsWithOrder = sortByColumns.map(name => col(name).desc)
    val resultDF = inputDf.withColumn("latest_record", row_number().over(
      Window.partitionBy(groupByColumns map col: _*).orderBy(sortByColumnsWithOrder: _*))).filter(col("latest_record") === 1)

    var activeLatestDf: DataFrame = null
    if (!tableLocation.contains("ai_phone") && !tableLocation.contains("ai_address")) {
      activeLatestDf = resultDF
    } else {
      log.info("Dropping the INACTIVE_FLAG column for : " + tableLocation)
      activeLatestDf = resultDF.drop("INACTIVE_FLAG")
    }
    activeLatestDf.drop("latest_record")

  }

  def getSFDCObjects(instance: String, userName: String, password: String, soql: String, sfdcApiVersion: String, actualObjectName: String): Dataset[Row] =
    {
      return sparkSession.read.format("com.springml.spark.salesforce").option("login", instance).option("username", userName).option("password", password).option("soql", soql).option("version", "43.0").option("sfObject", actualObjectName).option("ignoreLeadingWhiteSpace", "true").option("ignoreTrailingWhiteSpace", "true").option("multiLine", true).option("bulk", "true").option("pkChunking", "true").option("chunkSize", "10000").option("upsert", "true").option("externalIdFieldName", "ID").load();
    }

  def CodecodeValueLookUp(operation_type: String, from_source: String, to_source: String, data: DataFrame): DataFrame = {
    var outputDf = CommonUtils.createEmptyDF(CommonConstants.LOOKUP_SCHEMA)
    val lookUp_file_path = GlobalVariables.getLookUpFilePath
    val isLookUpFileExist = CommonUtils.isS3FileExists(lookUp_file_path)
    if (isLookUpFileExist.trim().equalsIgnoreCase("True")) {
      val lookUpDf = CommonUtils.readFromCsvFile(lookUp_file_path, "true", "true")
      val filteredLookUp = lookUpDf.filter(lookUpDf("Operation_Type") === operation_type && lookUpDf("From_Source") === from_source && lookUpDf("to_Source") === to_source)
        .select("From_Value", "To_Value", "EffectiveDate")

      val joinedDf = data.join(filteredLookUp, filteredLookUp("From_Value") === data("From_Value"))
        .drop(filteredLookUp("From_Value"))

      val maxEffectiveDateDf = joinedDf.groupBy("From_Value").agg(max("EffectiveDate").alias("max_effective_date"))

      /*println("=========== max effective date ==================")

      maxEffectiveDateDf.show(false)*/

      val matchedLookUpDf = joinedDf.join(maxEffectiveDateDf, joinedDf("From_Value") === maxEffectiveDateDf("From_Value") && joinedDf("EffectiveDate") === maxEffectiveDateDf("max_effective_date"))
        .drop(maxEffectiveDateDf("From_Value"))
        .drop(maxEffectiveDateDf("max_effective_date"))
        .drop(joinedDf("EffectiveDate"))
        .withColumn("status", lit(1))
        .select(CommonConstants.LOOKUP_SCHEMA.head, CommonConstants.LOOKUP_SCHEMA.tail: _*)

      /*println("=========== matched effective date ==================")

       matchedLookUpDf.show(false)*/

      val topRecord = filteredLookUp.filter(filteredLookUp("From_Value") === "Default").head(1)
      if (!topRecord.isEmpty) {
        val defaultValue = topRecord(0).getAs[String]("To_Value")

        val unmatchedRecords = data.except(joinedDf.select("From_Value")).withColumn("To_Value", lit(defaultValue))
          .withColumn("Status", lit(0))
        outputDf = matchedLookUpDf.union(unmatchedRecords)
      } else {
        val unmatchedRecords = data.except(joinedDf.select("From_Value")).withColumn("To_Value", lit("No default Value"))
          .withColumn("Status", lit(-1))
        outputDf = matchedLookUpDf.union(unmatchedRecords)
      }

    }
    return outputDf
  }

}