package com.deloitte.asset.insight.rules

import java.text.SimpleDateFormat

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.udf
import scala.collection.Map

import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.pratik.General.GenricRules
import com.deloitte.asset.insight.geocoding.api.GeocodingDriver
import com.deloitte.asset.insight.standardization.PhoneLibraryDriver
import org.apache.spark.sql.functions._
import com.deloitte.asset.insight.utils.GlobalVariables
import org.apache.spark.sql.Row
import com.deloitte.asset.insight.services.Logging

object FieldStandardization extends Serializable with Logging {
  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = InitiateSparkContext.getSqlContext()

  val genricRules = new GenricRules()

  def ruleTitleCase(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF

    standardData = standardData.withColumnRenamed(colName1, colName2)

    standardData = standardData.withColumn(colName3, udfTitleCase(col(colName2)))

    standardData
  }

  def udfTitleCase = udf((colName: String) => {

    colName.toLowerCase().split(" ").map(_.capitalize).mkString(" ")

  })

  def ruleStandardizeDateMMDDYY(mainDF: DataFrame, colName1: String, colName2: String, colName3: String) = {
    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)

    standardData = standardData.withColumn(colName3, udfstandardizeDateMMDDYY(col(colName2)))
    standardData

  }

  def udfstandardizeDateMMDDYY = udf((dateColumn: String) => {

    val inputdateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    //log.info(inputdateFormat)
    val inputdate = inputdateFormat.parse(dateColumn)
    val dateFormatStr = "MM-dd-YY"

    val outputDateFormat = new SimpleDateFormat(dateFormatStr)
    val formattedDate = outputDateFormat.format(inputdate)
    formattedDate
  })
  def udfstandardizeDateDDMMYY = udf((dateColumn: String) => {

    val inputdateFormat = new SimpleDateFormat("yyyyMMddhhmmss")
    val inputdate = inputdateFormat.parse(dateColumn)
    val dateFormatStr = "dd-MM-YY"

    val outputDateFormat = new SimpleDateFormat(dateFormatStr)
    val formattedDate = outputDateFormat.format(inputdate)
    formattedDate
  })

  def ruleStandardizeDateYYMMDD(mainDF: DataFrame, colName1: String, colName2: String, colName3: String) = {
    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)

    standardData = standardData.withColumn(colName3, udfstandardizeDateYYMMDD(col(colName2)))
    standardData

  }

  def udfstandardizeDateYYMMDD = udf((dateColumn: String) => {

    val inputdateFormat = new SimpleDateFormat("yyyyMMddhhmmss")
    val inputdate = inputdateFormat.parse(dateColumn)
    val dateFormatStr = "YY-MM-dd"

    val outputDateFormat = new SimpleDateFormat(dateFormatStr)
    val formattedDate = outputDateFormat.format(inputdate)
    formattedDate
  })

  def ruleStandardizeUpperCase(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {
    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)

    standardData = standardData.withColumn(colName3, udfstandardizeUpperCase(col(colName2)))
    standardData

  }

  def udfstandardizeUpperCase = udf((colName2: String) => {
    colName2.toUpperCase()
  })

  def ruleStandardizeLowerCase(mainDF: DataFrame, colName1: String, colName2: String, colName3: String) = {
    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)

    standardData = standardData.withColumn(colName3, udfstandardizeLowerCase(col(colName2)))
    standardData

  }

  def udfstandardizeLowerCase = udf((colName2: String) => {
    colName2.toLowerCase()
  })

  def rule_Replace_Slashes_With_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfReplace_Slashes_With_Space(col(colName2)))
    standardData

  }

  def udfReplace_Slashes_With_Space = udf((colName: String) => {
    genricRules.replaceSlashesWithSpace(colName).get(colName)
  })

  def rule_Replace_Punctuation_with_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfReplace_Punctuation_with_Space(col(colName2)))
    standardData

  }

  def udfReplace_Punctuation_with_Space = udf((colName: String) => {
    genricRules.rule_Replace_Punctuation_with_Space(colName)

  })

  def rule_Replace_Period_With_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfReplace_Period_With_Space(col(colName2)))
    standardData

  }

  def udfReplace_Period_With_Space = udf((colName: String) => {
    genricRules.rule_Replace_Period_With_Space(colName)

  })

  def ruleStandardizeAddress(preProcessedDF: DataFrame, dimTypeName: String, dimConfigData: Map[String, List[String]]): DataFrame = {

    val bucketName = GlobalVariables.getRootPath
    var standardizationInputCols = List[String]()
    var target_o = ""
    var target_c = ""

    var street_number_col: String = null
    var city_col: String = null
    var state_col: String = null
    var postal_code_col: String = null

    val standadizeAddressAction = dimConfigData.getOrElse(dimTypeName + ".standardize.address", List("FALSE"))(0).trim()

    val standadizeAddressValues = standadizeAddressAction.split(":")

    val values = List[String]()

    if (standadizeAddressValues.size >= 3) {
      standardizationInputCols = standadizeAddressValues(0).split('|').toList
      target_o = standadizeAddressValues(1).trim()
      target_c = standadizeAddressValues(2).trim()
    }

    val dimOutputPath = bucketName + dimConfigData.get(dimTypeName + ".output.path").get(0).trim()
    val addressStdLoggingPath = bucketName + dimConfigData.get(dimTypeName + ".standardization.logging.path").get(0).trim()
    val autoIncrColName = dimConfigData.get(dimTypeName + ".autoincrement.column").get(0).trim().toUpperCase()

    val callToGoogleAPIActive = dimConfigData.get(dimTypeName + ".call.to.google.api.active").get(0).trim().toBoolean
    val minQualityThresholdStr = dimConfigData.get(dimTypeName + ".standardization.min.quality.threshold").get(0).trim()
    val gooleApiURI = dimConfigData.get(dimTypeName + ".google.api.uri").get(0).trim()
    val googleApiKey = dimConfigData.get(dimTypeName + ".google.api.key").get(0).trim()
    val googleApiDelayStr = dimConfigData.getOrElse(dimTypeName + ".google.api.delay.in.ms", List("0"))(0).trim()
    val address_dim_schema = dimConfigData.get(dimTypeName + ".schema").get.map(_.toLowerCase().trim()).toArray
    val address_logging_schema = dimConfigData.get(dimTypeName + ".logging.schema").get.map(_.toLowerCase().trim()).toArray

    val minQualityThreshold = minQualityThresholdStr.toInt
    val googleApiDelay = googleApiDelayStr.toInt

    val mappingCols = dimConfigData.get(dimTypeName + ".mapping.column").get.toList.map(_.trim().toUpperCase())

    for (mappingCol <- mappingCols) {
      val colDetails = mappingCol.split(":")
      var srcCol = colDetails(0).trim()
      var destCol = colDetails(1).trim()
      if (destCol.equalsIgnoreCase("street_number"))
        street_number_col = srcCol
      if (destCol.equalsIgnoreCase("locality"))
        city_col = srcCol
      if (destCol.equalsIgnoreCase("administrative_area_level_1"))
        state_col = srcCol
      if (destCol.equalsIgnoreCase("postal_code"))
        postal_code_col = srcCol

    }

    val addressDFWithSpaces = preProcessedDF.select(standardizationInputCols.head, standardizationInputCols.tail: _*).na.fill(" ").distinct()

    var addressColsForAPI = standardizationInputCols.map(colName => col(colName))

    /*
     * Removing spaces from input addresses before concating
     */
    var addressDF = addressDFWithSpaces.select(addressDFWithSpaces.columns.map {
      x =>
        trim(col(x)).alias(x)
    }: _*)

    addressDF = addressDF.withColumn(target_o, trim(concat_ws(" ", addressColsForAPI: _*)))

    var addressDimLoggingDF = GeocodingDriver.standardizeAddresses(addressDF.distinct, target_o, target_c, callToGoogleAPIActive, minQualityThreshold, autoIncrColName, dimOutputPath, addressStdLoggingPath, gooleApiURI, googleApiKey, googleApiDelay, street_number_col, city_col, state_col,postal_code_col, address_dim_schema, address_logging_schema)

    return addressDimLoggingDF
  }

  def ruleStandardizePhone(stagingDF: DataFrame, dimTypeName: String, dimConfigData: Map[String, List[String]]): DataFrame = {
    // to be implemented for phone standardization
    val bucketName = GlobalVariables.getRootPath
    var standardizationInputCols = List[String]()
    var target_o = ""
    var target_c = ""

    val standadizePhoneAction = dimConfigData.getOrElse(dimTypeName + ".standardize.phone", List("FALSE"))(0).trim()
    println(standadizePhoneAction)
    val standadizePhoneValues = standadizePhoneAction.split(":")
    standadizePhoneValues.foreach(println)
    val values = List[String]()

    if (standadizePhoneValues.size >= 3) {
      standardizationInputCols = standadizePhoneValues(0).split('|').toList
      target_o = standadizePhoneValues(1).trim()
      target_c = standadizePhoneValues(2).trim()
    }

    print(dimConfigData.get(dimTypeName + ".output.path"))
    val dimOutputPath = bucketName + dimConfigData.get(dimTypeName + ".output.path").get(0).trim()
    val dimInputPath = bucketName + dimConfigData.get(dimTypeName + ".input.path").get(0).trim()
    val phoneStdLoggingPath = bucketName + dimConfigData.get(dimTypeName + ".standardization.logging.path").get(0).trim()
    val autoIncrColName = dimConfigData.get(dimTypeName + ".autoincrement.column").get(0).trim() //.toUpperCase()
    val phoneFormat = dimConfigData.get(dimTypeName + ".phone.format").get(0).trim().toUpperCase()
    val code_operationType = dimConfigData.get(dimTypeName + ".code.code.operation.type").get(0).trim()
    //val standardizedOutputPath=dimConfigData.get(dimTypeName + ".standardized.output.path").get(0).trim()

    val callToGoogleAPIActive = dimConfigData.get(dimTypeName + ".call.to.google.api.active").get(0).trim().toBoolean
    val minQualityThresholdStr = dimConfigData.get(dimTypeName + ".standardization.min.quality.threshold").get(0).trim()

    val phone_dim_schema = dimConfigData.get(dimTypeName + ".schema").get.map(_.toUpperCase().trim()).toArray
    val phone_logging_schema = dimConfigData.get(dimTypeName + ".logging.schema").get.map(_.toUpperCase().trim()).toArray

    val minQualityThreshold = minQualityThresholdStr.toInt

    val phoneDFWithSpaces = stagingDF.select(standardizationInputCols.head, standardizationInputCols.tail: _*) //.na.fill(" ").distinct()

    //var addressColsForAPI = standardizationInputCols.map(colName => col(colName))

    var phoneDF = phoneDFWithSpaces.select(phoneDFWithSpaces.columns.map {
      x =>
        trim(col(x)).alias(x)
    }: _*)
    phoneDF.show()

    var phoneDimLoggingDF = PhoneLibraryDriver.standardizePhone(phoneDF, target_o, target_c, callToGoogleAPIActive, minQualityThreshold, autoIncrColName, dimOutputPath, phoneStdLoggingPath, phone_dim_schema, phone_logging_schema, phoneFormat, code_operationType, dimInputPath)

    return phoneDimLoggingDF

  }

  def rule_UrlToStartWithHttps(mainDF: DataFrame, ruleValue: String): DataFrame = {

    var standardData = mainDF
    val colName = ruleValue.split(":")
    standardData = standardData.withColumnRenamed(colName(0), colName(1))
    standardData = standardData.withColumn(colName(2), udfUrlToStartWithHttps(lit(colName(2))))

    standardData
  }

  def udfUrlToStartWithHttps = udf((colName: String) => {
    var modifiedVal = ""
    if ((!colName.startsWith("https://") || colName.startsWith("http://")) && (!colName.equals("NA") && !colName.equals("N/A") && !colName.isEmpty())) {
      modifiedVal = "https://" + colName.replaceAll("http://", "")
    } else {
      modifiedVal = colName
    }
    modifiedVal
  })

  def rule_addAddionalColumnWithDefaultValue(mainDF: DataFrame, ruleValue: String): DataFrame =
    {
      var standardData = mainDF
      val colSplit = ruleValue.split(":")
      standardData = standardData.withColumn(colSplit(0), lit(colSplit(1)))
      standardData
    }

}