package com.deloitte.asset.insight.utils

import com.deloitte.asset.insight.services.Logging
import scala.collection.Map
import org.apache.spark.sql.DataFrame

object Hierarchy extends Serializable with Logging {

  import DataFrameOperation.implicits._
  val sparkSession = InitiateSparkContext.getSparkSession()
  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = InitiateSparkContext.getSqlContext()

  val bucketName = GlobalVariables.getRootPath
  val debugFlag = GlobalVariables.getDebugFlag

  def genericHierarchy(hierarchyConfigData: Map[String, List[String]], hierarchyLayerName: String) = {

    val expectedInputPath = hierarchyConfigData.keySet.filter(_.contains(".input.path")).toList
    val expectedTable = hierarchyConfigData.keySet.filter(_.contains(".table.name")).toList

    val outputPath = bucketName + hierarchyConfigData.get(hierarchyLayerName + ".output.path").get(0).trim()

    val expectedSqlQuery = hierarchyConfigData.keySet.filter(_.contains(".sql.query")).toList

    val hierarchySchema = hierarchyConfigData.get(hierarchyLayerName + ".schema").get.toList.map(_.trim().toUpperCase())

    var inputPathAndTableName: List[(String, String)] = List()
    for (i <- 1 to expectedInputPath.length) {
      inputPathAndTableName = inputPathAndTableName :+ (hierarchyConfigData.get(hierarchyLayerName + ".input.path" + i).get(0), hierarchyConfigData.get(hierarchyLayerName + ".table.name" + i).get(0))

    }
    log.info(inputPathAndTableName.toString())

    inputPathAndTableName.map(hierarchyData => {

      val inputPath = bucketName + hierarchyData._1
      val tableName = hierarchyData._2

      val dataFrame = CommonUtils.readFromS3Parquet(inputPath, "true")
      dataFrame.createOrReplaceTempView(tableName)
      sqlContext.cacheTable(tableName)

    })

    expectedSqlQuery.map(queryKey => {

      val query = hierarchyConfigData.getOrElse(queryKey, List("NA"))(0)
      log.info("SQL Query - " + query)
      var sqlDF = sqlContext.sql(query)
      sqlDF = sqlDF.select(hierarchySchema.head, hierarchySchema.tail: _*)
      log.info("Writing DF to : " + outputPath)
      CommonUtils.writeToS3Parquet(sqlDF, outputPath, "true", "append")

    })

    //    log.info("Count = " + unionDF.count())

    sqlContext.clearCache()
  }

}