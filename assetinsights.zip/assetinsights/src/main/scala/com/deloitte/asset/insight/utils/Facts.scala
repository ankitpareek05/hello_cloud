package com.deloitte.asset.insight.utils

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.functions._
import scala.collection.Map
import org.apache.spark.storage.StorageLevel
import com.deloitte.asset.insight.service.impl.RuleProcessImpl
import com.deloitte.asset.insight.services.Logging

/*
 * Author:Kanika & Sunny
 */

object Facts extends Logging {
  import DataFrameOperation.implicits._
  val sqlContext = InitiateSparkContext.getSqlContext()
  val debugFlag = GlobalVariables.getDebugFlag
  import sqlContext.implicits._

  /*
     * Generic Fact tables
     */
  def generateFacts(preProcessedDF: DataFrame, factName: String, factConfigData: Map[String, List[String]]) = {
    for ((k, v) <- factConfigData) printf("key: %s, value: %s\n", k, v)
    log.info("config print")
    val bucketName = GlobalVariables.getRootPath

    val partyXrefPath = bucketName + factConfigData.get(factName + ".partyxref.path").get(0).trim() //.toLowerCase()
    val productXrefPath = bucketName + factConfigData.get(factName + ".productxref.path").get(0).trim() //.toLowerCase()
    val dimFactPath = bucketName + factConfigData.get(factName + ".dimfact.path").get(0).trim() //.toLowerCase()

    val factOutputPath = bucketName + factConfigData.get(factName + ".fact.path").get(0).trim() //.toLowerCase()
    val factSchema = factConfigData.get(factName + ".schema").get.toList.map(_.trim().toUpperCase())

    val mainSelectedColumn = factConfigData.getOrElse(factName + ".main.selected.column", List("NA")).map(_.trim().toUpperCase())
    val partyXrefSelectedColumn = factConfigData.get(factName + ".partyxref.selected.column").get.toList.map(_.trim().toUpperCase())
    val productXrefSelectedColumn = factConfigData.get(factName + ".productxref.selected.column").get.toList.map(_.trim().toUpperCase())
    val dimFactSelectedColumn = factConfigData.get(factName + ".dimfact.selected.column").get.toList.map(_.trim().toUpperCase())

    val xRefTagValueCols = factConfigData.get(factName + ".xref.tag.value.column").get.toList.map(_.toUpperCase())
    val xRefTagValueColName = factConfigData.get(factName + ".xref.tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())

    val tagValueCols = factConfigData.get(factName + ".tag.value.column").get.toList.map(_.toUpperCase())
    val tagValueColName = factConfigData.get(factName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())

    val firstLookupCols = factConfigData.get(factName + ".first.lookup.column").get.toList.map(_.toUpperCase())
    val secondLookupCols = factConfigData.get(factName + ".second.lookup.column").get.toList.map(_.toUpperCase())

    val firstLookup = factConfigData.get(factName + ".first.lookup").get(0).trim()
    val secondLookup = factConfigData.get(factName + ".second.lookup").get(0).trim()

    val autoIncrementColName = factConfigData.get(factName + ".autoincrement.column").get(0).trim().toUpperCase()

    val mappingColumns = factConfigData.get(factName + ".mapping.column").get.toList.map(_.trim().toUpperCase())

    log.info("Fact Fucntion Called : " + factName)
    // Creating Empty DataFrame

    var mainDF: DataFrame = preProcessedDF.na.fill("")
    mainDF.showOrNoShow(debugFlag)
    if (!mainSelectedColumn(0).equalsIgnoreCase("NA")) {
      mainDF = preProcessedDF.na.fill("").select(mainSelectedColumn.head, mainSelectedColumn.tail: _*)
    }

    var selectedDF: DataFrame = null
    var partyXrefDF: DataFrame = null
    var productXrefDF: DataFrame = null
    var dimFactDF: DataFrame = null
    var joinedDFOne: DataFrame = null
    var joinedDFTwo: DataFrame = null
    var tagDF: DataFrame = null
    var finalDF: DataFrame = null

    // Fetching the Column Names to be Tag-Value to Join with XREF, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME
    val xRefTagValue = xRefTagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME to Join with XREF
    xRefTagValueCols.map(elem => {
      val cols = elem.split(":")
      mainDF = mainDF.withColumnRenamed(cols(0).trim().toUpperCase(), cols(1).trim().toUpperCase())
    })

    // Tag Value Pair Generation for XREF
    selectedDF = CommonUtils.createMeasureNameValue(mainDF, xRefTagValueColName(0), xRefTagValueColName(1), xRefTagValue)
    selectedDF.showOrNoShow(debugFlag)
    // Fetching the Column Names to be Tag-Value, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME
    val tagValue = tagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME
    tagValueCols.map(elem => {
      val cols = elem.split(":")
      selectedDF = selectedDF.withColumnRenamed(cols(0).trim().toUpperCase(), cols(1).trim().toUpperCase())
    })

    // Read Party XREF if the path is NOT NA or NOT Empty
    if ((!partyXrefPath.equalsIgnoreCase("na") || !partyXrefPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(partyXrefPath.replace("*", ""))
      if (fileExist.equalsIgnoreCase("true")) {
        val srcIdValue = GlobalVariables.getSourceId.mkString.substring(0, 7)
        partyXrefDF = CommonUtils.readFromS3Parquet(partyXrefPath, "true").select(partyXrefSelectedColumn.head, partyXrefSelectedColumn.tail: _*).filter(col("AI_SRC_ID").startsWith(srcIdValue))
        partyXrefDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
        partyXrefDF.showOrNoShow(debugFlag)
      } else { log.info("Party XREF doesn't exists") }
    }

    // Read Party XREF if the path is NOT NA or NOT Empty
    if ((!productXrefPath.equalsIgnoreCase("na") || !productXrefPath.isEmpty())) {

      val fileExist = CommonUtils.isS3FileExists(productXrefPath.replace("*", ""))
      if (fileExist.equalsIgnoreCase("true")) {
        productXrefDF = CommonUtils.readFromS3Parquet(productXrefPath, "true").select(productXrefSelectedColumn.head, productXrefSelectedColumn.tail: _*)
        productXrefDF.showOrNoShow(debugFlag)
      } else { log.info("Product XREF doesn't exists") }

    }

    // Read the Dimension if the path is NOT NA or NOT Empty
    if ((!dimFactPath.equalsIgnoreCase("na") || !dimFactPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(dimFactPath.replace("*", ""))
      if (fileExist.equalsIgnoreCase("true")) {
        dimFactDF = CommonUtils.readFromS3Parquet(dimFactPath, "true").select(dimFactSelectedColumn.head, dimFactSelectedColumn.tail: _*)
        dimFactDF.showOrNoShow(debugFlag)
      } else { log.info("DimFact doesn't exists") }
    }

    /*
     * First Lookup/Join
     */

    // Create first lookup/join if the first join tag is not NA
    if (!firstLookup.equalsIgnoreCase("na")) {

      log.info("First Lookup statement called")

      // Renaming the columns to join from XREF/DIMFACT @Return :: Seq() of Join Columns
      firstLookupCols.map(col => {
        val cols = col.split(":")
        selectedDF = selectedDF.withColumnRenamed(cols(0).trim(), cols(1).trim())
      })

      // Sequence of Join Columns
      val joinColsFirst = firstLookupCols.map(col => {
        val cols = col.split(":")(1).trim()
        cols
      }).toSeq

      // First Joining with XREF (Party/Product) OR DIMFACT

      if (firstLookup.equalsIgnoreCase("partyxref")) {
        joinedDFOne = selectedDF.join(partyXrefDF, joinColsFirst, "left_outer")

      } else if (firstLookup.equalsIgnoreCase("productxref")) {
        joinedDFOne = selectedDF.join(productXrefDF, joinColsFirst, "left_outer")

      } else if (firstLookup.equalsIgnoreCase("dimfact")) {
        joinedDFOne = selectedDF.join(dimFactDF, joinColsFirst, "left_outer")
      }
      //      log.info("JoinedDFOne")
      joinedDFOne.showOrNoShow(debugFlag)

      // Renaming the columns to original name after Joining from XREF/DIMFACT
      firstLookupCols.map(col => {
        val cols = col.split(":")
        joinedDFOne = joinedDFOne.withColumnRenamed(cols(1).trim(), cols(0).trim())
      })
      //      joinedDFOne.show()
      joinedDFOne.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }

    /*
     * Second Lookup/Join
     */

    // Create Second lookup/join if the Second join tag is not NA

    if (!secondLookup.equalsIgnoreCase("na")) {
      log.info("Second Lookup statement called")

      // Renaming the columns to join from XREF/DIMFACT @Return :: Seq() of Join Columns
      secondLookupCols.map(col => {
        val cols = col.split(":")
        joinedDFOne = joinedDFOne.withColumnRenamed(cols(0).trim(), cols(1).trim())
      })

      // Sequence of Join Columns
      val joinColsSecond = secondLookupCols.map(col => {
        val cols = col.split(":")(1).trim()
        cols
      }).toSeq

      // Second Joining with XREF (Party/Product) OR DIMFACT

      if (secondLookup.equalsIgnoreCase("partyxref")) {
        joinedDFTwo = joinedDFOne.join(partyXrefDF, joinColsSecond, "left_outer")

      } else if (secondLookup.equalsIgnoreCase("productxref")) {
        joinedDFTwo = joinedDFOne.join(productXrefDF, joinColsSecond, "left_outer")

      } else if (secondLookup.equalsIgnoreCase("dimfact")) {
        joinedDFTwo = joinedDFOne.join(dimFactDF, joinColsSecond, "left_outer")
      }

      // Renaming the columns to original name after Joining from XREF/DIMFACT
      secondLookupCols.map(col => {
        val cols = col.split(":")
        joinedDFTwo = joinedDFTwo.withColumnRenamed(cols(1).trim(), cols(0).trim())
      })
      joinedDFTwo.showOrNoShow(debugFlag)
      joinedDFTwo.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }

    // Tag Value Pair Generation

    if (!firstLookup.equalsIgnoreCase("na")) {

      log.info("Tag Value statement called after First Lookup")

      tagDF = CommonUtils.createMeasureNameValue(joinedDFOne, tagValueColName(0), tagValueColName(1), tagValue)

    } else if (!secondLookup.equalsIgnoreCase("na")) {

      log.info("Tag Value statement called after Second Lookup")

      tagDF = CommonUtils.createMeasureNameValue(joinedDFTwo, tagValueColName(0), tagValueColName(1), tagValue)
    } else {

      log.info("No Lookup specified, Tag - Value statement will not be called")

    }
    tagDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    log.info("Tag - Value DF")
    tagDF.showOrNoShow(debugFlag)

    var tagFilterDF = tagDF.filter(tagDF(tagValueColName(1)).isNotNull).filter(tagDF(tagValueColName(1)) !== "")

    //    log.info("Tag - Value Null Filter DF")
    //    tagFilterDF.show()

    // AutoIncrement Sequence Generation
    if (!autoIncrementColName.equalsIgnoreCase("na")) {
      finalDF = CommonUtils.addAutoIncremetColumn(tagFilterDF, autoIncrementColName).persist(StorageLevel.MEMORY_AND_DISK_SER)
    } else {
      finalDF = tagFilterDF
    }

    // Mapping the columns to Fact
    if (!mappingColumns(0).equalsIgnoreCase("na")) {
      mappingColumns.map(col => {
        val oldCol = col.split(":")(0).trim()
        val newCol = col.split(":")(1).trim()
        finalDF = finalDF.withColumnRenamed(oldCol, newCol)
      })
    }

    // Adding Blanks to the Extra Column

    val factSchema_c = factSchema.filterNot(x => x.toLowerCase().endsWith("_o"))
    //    factSchema.foreach(println)
    val additionalColumnInSchema = factSchema_c diff (finalDF.schema.fieldNames)

    // Setting missing columns to blank
    additionalColumnInSchema.map(col => {
      finalDF = finalDF.withColumn(col, lit(CommonConstants.BLANK_STRING).cast(StringType))
    })

    // Ordering DF

    finalDF.persist(StorageLevel.DISK_ONLY_2)
    log.info("Field Stadarization calling")

    val fieldStandarization = new RuleProcessImpl
    finalDF = fieldStandarization.processFactFieldStandardization(finalDF, factName, factConfigData)

    finalDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

    log.info("field standarization done")
    finalDF = finalDF.select(factSchema.head, factSchema.tail: _*)

    /*
     * Adding Run timestamp and Inactive Flag in data.
     */
    val runTimeStamp = CommonUtils.getTimeStamp()._1
    finalDF = finalDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
    finalDF.showOrNoShow(debugFlag)
    CommonUtils.writeToS3Parquet(finalDF, factOutputPath, "true", "append")

    joinedDFOne.unpersist()

    if (!secondLookup.equalsIgnoreCase("na")) {
      joinedDFTwo.unpersist()
    }
    tagDF.unpersist()
    finalDF.unpersist()
    log.info("Fact Fucntion Completed : " + factName)

  }

}