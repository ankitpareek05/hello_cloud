package com.deloitte.asset.insight.geocoding.api

import scala.reflect.api.materializeTypeTag

import org.apache.spark.sql.Column
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.types.{ StructType, StructField, StringType }
import org.apache.spark.sql.Row
import com.deloitte.asset.insight.utils.CommonConstants
import com.deloitte.asset.insight.services.Logging
import org.apache.spark.storage.StorageLevel
import com.deloitte.asset.insight.utils.DataFrameOperation
import com.google.i18n.phonenumbers._
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat
import org.json.simple.JSONObject
import org.json.simple.JSONArray
import org.apache.spark.rdd.RDD

object AddressValidation extends Logging {
  import DataFrameOperation.implicits._

  case class ConcatAddressDF(formatted_address_o: String)

  var sparkSession = InitiateSparkContext.getSparkSession()

  val DELM = CommonConstants.CTRL_A

  def main(args: Array[String]) = {

  }

  /**
   * @param address
   * @param gooleApiURI
   * @param googleApiKey
   * @param googleApiDelay
   * @return
   */
  def validateAddressWithGoogleApi(address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]): DataFrame = {
    return validateAddressWithGoogleApi(Array(address), gooleApiURI, googleApiKey, googleApiDelay, invalid_chars)
  }

  /**
   * @param addresses
   * @param gooleApiURI
   * @param googleApiKey
   * @param googleApiDelay
   * @return
   */
  def validateAddressWithGoogleApi(addresses: Array[String], gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]): DataFrame = {

    var addressesForDF = addresses.map(address => {
      ConcatAddressDF(address)
    })

    var addressDF = sparkSession.createDataFrame(addressesForDF)
    return validateAddressWithGoogleApi(addressDF, gooleApiURI, googleApiKey, googleApiDelay, invalid_chars)
  }
  
  def validateAddressWithGoogleApiStoreJson(addressDF: DataFrame, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]): RDD[String] = {
    val addressComponentsColName = "API_ADDRESS_COMPONENTS"
    var newArr = Array[JSONObject]()
    
    log.info("Delay between API requestes : " + googleApiDelay)

    val addressColName = addressDF.columns(0)
    val colnameForId = addressDF.columns(1)
    val Schema = StructType(Array(
        StructField(colnameForId, StringType),
        StructField(addressColName, StringType),
        StructField("api_response",StringType)))
    val addressRdd = addressDF.rdd.map{
      row =>
        val address = row.getAs[String](addressColName)
        val id = row.getAs[String](colnameForId)
        val APIResult = GoogleAPI2.getAddressFromGoogleApi(id,address, gooleApiURI, googleApiKey, googleApiDelay,invalid_chars)
        APIResult
       // Row(id,address,APIResult) 
//        newArr = newArr :+ APIResult
//        println(newArr.size)
    }
    
    //val df = sqlContext.createDataFrame(addressRdd,Schema)
    
    //df
    addressRdd
    /*println("--------")
addressRdd.foreach(println)*/    
//    println(addressRdd.count())
    
  }
    

  /**
   * @param addressDF
   * @param gooleApiURI
   * @param googleApiKey
   * @param googleApiDelay
   * @return
   */
  def validateAddressWithGoogleApi(addressDF: DataFrame, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]): DataFrame = {
    val addressComponentsColName = "API_ADDRESS_COMPONENTS"

    log.info("Delay between API requestes : " + googleApiDelay)

    val addressColName = addressDF.columns(0)
    val colnameForId = addressDF.columns(1)
    
    val Schema = StructType(Array(
        StructField(addressColName, StringType),
        StructField(colnameForId, StringType),
        StructField(addressComponentsColName,StringType)))
    
    val addressRdd = addressDF.rdd.map{
      row =>
        val address = row.getAs[String](addressColName)
        val id = row.getAs[String](colnameForId)
        val APIResult = GoogleAPI.getAddressFromGoogleApi(address, gooleApiURI, googleApiKey, googleApiDelay,invalid_chars)
        Row(address,id,APIResult)
    }
    
    var updatedDF = sparkSession.createDataFrame(addressRdd,Schema)
    
//    var updatedDF = addressDF.withColumn(addressComponentsColName, GoogleAPI.getAddressFromGoogleApiUdf(col(addressColName), lit(gooleApiURI), lit(googleApiKey), lit(googleApiDelay)))
//    updatedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

    var udfColsForRename = (CommonConstants.PARTIAL_MATCH +: CommonConstants.GOOGLE_API_DF_SCHEMA)  diff Array(addressColName)

    for (index <- 0 until udfColsForRename.size) {
      updatedDF = updatedDF.withColumn(udfColsForRename(index), split(col(addressComponentsColName), DELM)(index))
    }

    updatedDF = updatedDF.drop(col(addressComponentsColName))

    var apiComponentsFinal =  colnameForId +: CommonConstants.PARTIAL_MATCH +: CommonConstants.GOOGLE_API_DF_SCHEMA

    updatedDF = updatedDF.select(apiComponentsFinal.head, apiComponentsFinal.tail: _*)

    return updatedDF
  }

  /**
   * @param concatenatedAddress
   * @param addressDimdf
   * @param mactchSrcCol
   * @param mactchDestCol
   * @param autoSeqColName
   * @return
   */
  def validateAddressInAI(concatenatedAddress: String, addressDimdf: DataFrame, mactchSrcCol: String, mactchDestCol: String, autoSeqColName: String,address_dim_schema:Array[String]): DataFrame = {
    return validateAddressInAI(Array(concatenatedAddress), addressDimdf, mactchSrcCol, mactchDestCol, autoSeqColName,address_dim_schema)
  }

  /**
   * @param concatenatedAddress
   * @param addressDimdf
   * @param mactchSrcCol
   * @param mactchDestCol
   * @param autoSeqColName
   * @return
   */
  def validateAddressInAI(concatenatedAddress: Array[String], addressDimdf: DataFrame, mactchSrcCol: String, mactchDestCol: String, autoSeqColName: String,address_dim_schema:Array[String]): DataFrame = {
    var concatAddressesForDF = concatenatedAddress.map(concatAddress => {
      ConcatAddressDF(concatAddress)
    })

    var concatAddressesDF = sparkSession.createDataFrame(concatAddressesForDF)
    return validateAddressInAI(concatAddressesDF, addressDimdf, mactchSrcCol, mactchDestCol, autoSeqColName,address_dim_schema)
  }

  /**
   * @param inputDF
   * @param addressDimdf
   * @param mactchSrcCol
   * @param mactchDestCol
   * @param autoSeqColName
   * @return
   */
  def validateAddressInAI(inputDF: DataFrame, addressDimdf: DataFrame, mactchSrcCol: String, mactchDestCol: String, autoSeqColName: String,address_dim_schema: Array[String]): DataFrame = {

    val addressDimSchema = autoSeqColName +: address_dim_schema

    var outputDF = CommonUtils.createEmptyDF(addressDimSchema)

    if (addressDimdf == null) {
      return outputDF
    } else {

      var matchedAddressDF = inputDF.join(addressDimdf, inputDF(mactchSrcCol) === addressDimdf(mactchDestCol)).drop(addressDimdf(mactchSrcCol))
      
      /*println("======= match 1 --------------------")
      
      matchedAddressDF.show(false)*/
      
      var maxQualityRatingDF = matchedAddressDF.groupBy(mactchSrcCol).agg(max(CommonConstants.API_QUALITY_RATING).alias("max_quality_rating"))
      
      /*println("=========== max quality ==================")
      
      maxQualityRatingDF.show(false)*/
      
      matchedAddressDF = matchedAddressDF.join(maxQualityRatingDF, matchedAddressDF(mactchSrcCol) === maxQualityRatingDF(mactchSrcCol) && matchedAddressDF(CommonConstants.API_QUALITY_RATING) === maxQualityRatingDF("max_quality_rating")).drop(maxQualityRatingDF(mactchSrcCol)).drop(maxQualityRatingDF("max_quality_rating"))

      /*println("================== match address Df - final out ================================")
      
      matchedAddressDF.show(false)*/
      
      outputDF = matchedAddressDF
    }

    return outputDF
  }
  
  /**/
  
  
}