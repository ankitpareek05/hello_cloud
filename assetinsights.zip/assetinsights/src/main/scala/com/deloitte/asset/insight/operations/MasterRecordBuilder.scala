package com.deloitte.asset.insight.operations

import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.row_number
import scala.collection.Map

import com.deloitte.asset.insight.utils.CommonUtils
import org.apache.spark.sql.Dataset
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.Row
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
/*
 * Creates master records based on
 * trust factor and Quality ratings
 */

class MasterRecordBuilder extends Logging with Serializable {

  // Getting sqlContext object
  val sqlContext = InitiateSparkContext.getSqlContext()
  
  /*
   * Add direction to the Dataframe based on Object name 
   * mentioned in Trust table
   */
  
  def addDirectiontoParty(aiPartyDf: Dataset[Row], trustTable: Dataset[Row], objectDirection: String, objectName: String): Dataset[Row] = {
    var directionalDf = aiPartyDf
    log.info("Adding direction in " + objectName)
    var direction: String = trustTable.select(trustTable("object_trust_level")).where(trustTable("type") === lit("direction") && trustTable("object") === lit(objectName)).first().getAs("object_trust_level")

    if (direction.equalsIgnoreCase("<")) {
      log.info("Adding direction as  " + direction + " for: "+objectName )
      directionalDf = directionalDf.withColumn("OBJECT_DIRECTION", lit(direction))
    } else {
      log.info("Adding direction as  " + direction + " for: "+objectName )
      directionalDf = directionalDf.withColumn("OBJECT_DIRECTION", lit(objectDirection))
    }
    directionalDf
  }


  def getTrustLevel(aiPartyDf: Dataset[Row], controlTable: Dataset[Row]): Dataset[Row] = {
    var trustLevelDf = aiPartyDf
    log.info("Adding Object level trust ")
    val finalColumns = trustLevelDf.columns :+ "OBJECT_TRUST_LEVEL"

    trustLevelDf = trustLevelDf.join(controlTable, trustLevelDf("AI_SRC_ID").substr(0, 7) === controlTable("SOURCE_CODE"), "inner").where(controlTable("OBJECT") === lit("ai_party"))
      .select(finalColumns.head, finalColumns.tail: _*)

    trustLevelDf
  }

   /*
   * Add the trust level priority based on Object name
   * to the Data frame as a seperate column
   */
  def getObjectTrustLevel(aiPartyDf: Dataset[Row], controlTable: Dataset[Row], objectType: String): Dataset[Row] = {
    var trustLevelDf = aiPartyDf
    log.info("Adding Object level trust for: " + objectType)
    val finalColumns = trustLevelDf.columns :+ "OBJECT_TRUST_LEVEL"
    
    trustLevelDf = trustLevelDf.join(controlTable, trustLevelDf("AI_SRC_ID").substr(0, 7) === controlTable("SOURCE_CODE"), "inner").where(controlTable("OBJECT") === lit(objectType))
      .select(finalColumns.head, finalColumns.tail: _*)

    trustLevelDf
  }
  
   /*
   * Add the measure level trust priority based on Object name
   * to the Dataframe as a seperate coloumn
   */

  def getMeasureTrustLevel(inputDf: Dataset[Row], controlTable: Dataset[Row], objectType: String): Dataset[Row] = {

    log.info("Adding measure level trust for: " + objectType)

    var trustLevelDf = inputDf
    val finalColumns = trustLevelDf.columns :+ "MEASURE_TRUST_LEVEL" //MEASURE_TRUST_LEVEL

    val cTable = controlTable.filter(controlTable("OBJECT") === lit(objectType))

    trustLevelDf = trustLevelDf.join(cTable, trustLevelDf.col("AI_MEASURE_NAME").equalTo(cTable.col("MEASURE")), "left_outer")

    trustLevelDf

  }

   /*
   * Add the measure direction based on Object name
   * to the Dataframe as a seperate coloumn
   */

  def getMeasureDirection(factTable: Dataset[Row], measureTable: Dataset[Row], objectType: String): DataFrame = {
    var trustLevelDf = factTable
    log.info("Adding measure direction  for: " + objectType)
    // var selectedMeasureTable=measureTable.select()
    val finalColumns = trustLevelDf.columns :+ "AI_MEASURE_NAME"

    trustLevelDf = trustLevelDf.join(measureTable, trustLevelDf("AI_SRC_ID").substr(0, 7) === measureTable("SOURCE_CODE") && (trustLevelDf("AI_MEASURE_NAME") === measureTable("MEASURE")), "left_outer").drop(measureTable.col("MEASURE_TRUST_LEVEL"))
    val grpByCols = List("AI_SRC_ID", "AI_MEASURE_NAME")
    trustLevelDf
  }

  /*
   * Create master data based on trust factor and Direction
   * 
   */
  def getMasterRecord(tableName: Dataset[Row], groupByColumns: List[String], sortByColumnsDesc: List[String], sortByColumnsAsc: List[String], objectName: String): Dataset[Row] = {

    println("Creating master record based on direction and effective date")
    var inuputDf = tableName
    inuputDf.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    inuputDf = inuputDf.withColumn("AI_CONTRIBUTING_SRC_ID", inuputDf("AI_SRC_ID"))

    val sortByColumnsWithDescOrder = sortByColumnsDesc.map(name => col(name).desc)
    val sortByColumnsWithAscOrder = sortByColumnsAsc.map(name => col(name).asc)

    var resultDF: Dataset[Row] = null
    val objectDirection: String = inuputDf.first().getAs("OBJECT_DIRECTION")
    val objdi = ">"
    log.info("Object direction ======" + objectDirection)

    if (objectName.equalsIgnoreCase("ai_rel_party_address") || objectName.equalsIgnoreCase("ai_rel_party_phone")) {

      if (!sortByColumnsDesc(0).equalsIgnoreCase("NA") && !sortByColumnsAsc(0).equalsIgnoreCase("NA") && objectDirection.equalsIgnoreCase(">")) { 
        log.info("Considering latest Effective date in master dataset based on direction " + objectDirection)

        
          var resultDF_dr=inuputDf.withColumn("latest_record_qr", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc).orderBy(col("QUALITY_RATING").desc))).filter(col("latest_record_qr") === 1)
          
          resultDF_dr=resultDF_dr.withColumn("latest_record_trust_factor", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc).orderBy(col("OBJECT_TRUST_LEVEL").asc))).filter(col("latest_record_trust_factor") === 1)
          
          resultDF_dr=resultDF_dr.withColumn("dense_eff", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc))).filter(col("dense_eff") === 1)
                   
          resultDF=resultDF_dr.withColumn("row_num", row_number().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_KNOWLEDGE_DATE").desc))).filter(col("row_num") === 1)


       } else if (!sortByColumnsDesc(0).equalsIgnoreCase("NA") && !sortByColumnsAsc(0).equalsIgnoreCase("NA") && objectDirection.equalsIgnoreCase("<")) {
        log.info("Considering latest Effective date in master dataset based on direction " + objectDirection)

          var resultDF_dr=inuputDf.withColumn("latest_record_qr", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc).orderBy(col("QUALITY_RATING").desc))).filter(col("latest_record_qr") === 1)
          
          resultDF_dr=resultDF_dr.withColumn("latest_record_trust_factor", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc).orderBy(col("OBJECT_TRUST_LEVEL").asc))).filter(col("latest_record_trust_factor") === 1)
          
          resultDF_dr=resultDF_dr.withColumn("dense_eff", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").asc))).filter(col("dense_eff") === 1)
                   
          resultDF=resultDF_dr.withColumn("row_num", row_number().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_KNOWLEDGE_DATE").desc))).filter(col("row_num") === 1)

      } else {

        log.info("considering default process to create Master Dataset")

          var resultDF_dr=inuputDf.withColumn("latest_record_qr", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc).orderBy(col("QUALITY_RATING").desc))).filter(col("latest_record_qr") === 1)
          
          resultDF_dr=resultDF_dr.withColumn("latest_record_trust_factor", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc).orderBy(col("OBJECT_TRUST_LEVEL").asc))).filter(col("latest_record_trust_factor") === 1)
          
          resultDF_dr=resultDF_dr.withColumn("dense_eff", dense_rank().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc))).filter(col("dense_eff") === 1)
                   
          resultDF=resultDF_dr.withColumn("row_num", row_number().over(
          Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_KNOWLEDGE_DATE").desc))).filter(col("row_num") === 1)

      }

      resultDF.drop("latest_record_qr").drop("latest_record_trust_factor")

    } else {
      if (!sortByColumnsDesc(0).equalsIgnoreCase("NA") && !sortByColumnsAsc(0).equalsIgnoreCase("NA") && objectDirection.equalsIgnoreCase(">")) { //&& objectDirection.equalsIgnoreCase("<")
        log.info("Considering older Effective date in master dataset based on direction " + objectDirection)

        var resultDF_new=inuputDf.withColumn("latest_record", dense_rank().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("OBJECT_TRUST_LEVEL").asc))).filter(col("latest_record") === 1)
      
        resultDF_new= resultDF_new.withColumn("dense_eff", dense_rank().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").desc))).filter(col("dense_eff") === 1)
       
        
       resultDF= resultDF_new.withColumn("dense_know", row_number().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_KNOWLEDGE_DATE").desc))).filter(col("dense_know") === 1)
       
        //resultDF.show()
      } else if (!sortByColumnsDesc(0).equalsIgnoreCase("NA") && !sortByColumnsAsc(0).equalsIgnoreCase("NA") && objectDirection.equalsIgnoreCase("<")) {
        log.info("Considering latest Effective date in master dataset based on direction " + objectDirection)

           var resultDF_new=inuputDf.withColumn("latest_record", dense_rank().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("OBJECT_TRUST_LEVEL").asc))).filter(col("latest_record") === 1)
      
        resultDF_new= resultDF_new.withColumn("dense_eff", dense_rank().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").asc))).filter(col("dense_eff") === 1)
       
        
       resultDF= resultDF_new.withColumn("dense_know", row_number().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_KNOWLEDGE_DATE").desc))).filter(col("dense_know") === 1)

      } else {

        log.info("considering default process to create Master Dataset")

           var resultDF_new=inuputDf.withColumn("latest_record", dense_rank().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("OBJECT_TRUST_LEVEL").asc))).filter(col("latest_record") === 1)
      
        resultDF_new= resultDF_new.withColumn("dense_eff", dense_rank().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_EFFECTIVE_DATE").asc))).filter(col("dense_eff") === 1)
       
        
       resultDF= resultDF_new.withColumn("dense_know", row_number().over(
        Window.partitionBy(groupByColumns map col: _*).orderBy(col("AI_KNOWLEDGE_DATE").desc))).filter(col("dense_know") === 1)
      }

      resultDF.drop("latest_record").drop("dense_eff")
    }

  }

  def getPartyAndRelMasterData(objectLayer: String, trustTable: Dataset[Row], inputConfigData: Map[String, List[String]], objectName: String): Dataset[Row] = {

    log.info("Generating Master Records for Object: " + objectName.toUpperCase())
    val masterId = GlobalVariables.getSourceId.trim() // Should be config driven
    val rootPath = GlobalVariables.getRootPath

    val schema = inputConfigData.get(objectLayer + ".schema").get
    log.info("Object Schema: " + schema)

    val dimPath = rootPath + inputConfigData.get(objectLayer + ".input.path").get.mkString
    log.info("Input path: " + dimPath)

    val groupByColumns = inputConfigData.get(objectLayer + ".group.by.column").get
    val sortByColumnsDesc = inputConfigData.get(objectLayer + ".sort.by.desc").get
    val sortByColumnsAsc = inputConfigData.get(objectLayer + ".sort.by.asc").get

    log.info("Reading object from input path")
    var aiPartyDf = CommonUtils.readFromS3Parquet(dimPath, "true")
    aiPartyDf = aiPartyDf.select(aiPartyDf.columns.map(x => col(x).as(x.toUpperCase())): _*) //.filter(col("INACTIVE_FLAG")===lit(0))

    log.info("Filtering out Inactive Records")
    val inactiveDf = aiPartyDf.select(col("AI_PARTY_ID")).filter(col("INACTIVE_FLAG") === 1)
    aiPartyDf.createOrReplaceTempView("df1")
    inactiveDf.createOrReplaceTempView("df2")

    val query = "select df1.* from df1 left outer join df2 on (df1.AI_PARTY_ID = df2.AI_PARTY_ID) where df2.AI_PARTY_ID is null"

    aiPartyDf = sqlContext.sql(query)

    aiPartyDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

    aiPartyDf = aiPartyDf.filter(aiPartyDf("AI_SRC_ID") =!= masterId)

    aiPartyDf = addDirectiontoParty(aiPartyDf, trustTable, ">", objectName)

    aiPartyDf = getTrustLevel(aiPartyDf, trustTable)
    log.info("Trust Level added")

    val outputPath = rootPath + inputConfigData.get(objectLayer + ".output.path").get.mkString

    aiPartyDf = getMasterRecord(aiPartyDf, groupByColumns, sortByColumnsDesc, sortByColumnsAsc, objectName)
    aiPartyDf.persist(StorageLevel.MEMORY_ONLY_SER)

    val timeStamp = CommonUtils.getTimeStamp()
    val processDate = timeStamp._1

    aiPartyDf = aiPartyDf.withColumn("AI_KNOWLEDGE_DATE", lit(processDate)).withColumn("AI_SRC_ID", lit(masterId)).withColumn("AI_RUN_DATETIME", lit(processDate))

    aiPartyDf = aiPartyDf.select(schema.head, schema.tail: _*)
    CommonUtils.writeToS3Parquet(aiPartyDf, outputPath, "true", "append") //-- Write again in append mode into the S3
    aiPartyDf

  }

  def getRelationMasterData(objectLayer: String, trustTable: Dataset[Row], inputConfigData: Map[String, List[String]], objectName: String): Dataset[Row] = {

    var query: String = null

    val masterId = GlobalVariables.getSourceId.trim() // Should be config driven
    val rootPath = GlobalVariables.getRootPath

    val schema = inputConfigData.get(objectLayer + ".schema").get
    val dimPath = rootPath + inputConfigData.get(objectLayer + ".input.path").get.mkString
    var addressDimPath = inputConfigData.getOrElse(objectLayer + ".address.dim.input.path",List("NA")).mkString
    
    val groupByColumns = inputConfigData.get(objectLayer + ".group.by.column").get // -- Config Driven
    val sortByColumnsDesc = inputConfigData.get(objectLayer + ".sort.by.desc").get //List("ai_effective_date", "ai_knowledge_date") // -- Config Driven
    val sortByColumnsAsc = inputConfigData.get(objectLayer + ".sort.by.asc").get //List("Value") // -- Config Driven

    var aiPartyDf = CommonUtils.readFromS3Parquet(dimPath, "true")

    var inputDim:DataFrame=null
    if(!addressDimPath.equalsIgnoreCase("NA"))
    {
      addressDimPath =rootPath+addressDimPath
      inputDim = CommonUtils.readFromS3Parquet(addressDimPath, "true")
    }
    aiPartyDf = aiPartyDf.select(aiPartyDf.columns.map(x => col(x).as(x.toUpperCase())): _*) //.filter(col("INACTIVE_FLAG")===lit(0))

    if (objectName.equalsIgnoreCase("ai_rel_party_address")) {
      val addQuery = "select ai_address_id, max(quality_rating) as quality_rating from ai_address_std group by ai_address_id order by quality_rating desc"
      inputDim.createOrReplaceTempView("ai_address_std")
      aiPartyDf.createOrReplaceTempView("ai_rel_party_address_std")

      val aiAddressDf = sqlContext.sql(addQuery)
      aiAddressDf.createOrReplaceTempView("ai_address_with_QR")
      val addressReljoinQuery = "select a.*,b.quality_rating from ai_rel_party_Address_std a JOIN ai_address_with_QR b on (a.ai_address_id=b.ai_address_id)"
      val addressRelJoinDf = sqlContext.sql(addressReljoinQuery)
      addressRelJoinDf.createOrReplaceTempView("ai_rel_party_address_std_qr")
      query = "select rpps.* from ai_rel_party_address_std_qr rpps JOIN (select ai_party_id, ai_address_id, rel_type, max(inactive_flag) maxflag  from ai_rel_party_address_std_qr group by ai_party_id, ai_address_id, rel_type having max(inactive_flag)=0) maxparty ON (rpps.ai_party_id = maxparty.ai_party_id AND rpps.ai_address_id = maxparty.ai_address_id AND rpps.rel_type = maxparty.rel_type AND rpps.inactive_flag = maxparty.maxflag )"
      sqlContext.cacheTable("ai_rel_party_address_std_qr")
    } else if (objectName.equalsIgnoreCase("ai_rel_party_party")) {
      query = "select rpps.* from ai_rel_party_party_std rpps JOIN (select ai_party_id, ai_rel_party_id, rel_type, max(inactive_flag) maxflag from ai_rel_party_party_std group by ai_party_id, ai_rel_party_id, rel_type having max(inactive_flag)=0) maxparty ON (rpps.ai_party_id = maxparty.ai_party_id AND rpps.ai_rel_party_id = maxparty.ai_rel_party_id AND rpps.rel_type = maxparty.rel_type AND rpps.inactive_flag = maxparty.maxflag)"
      aiPartyDf.createOrReplaceTempView("ai_rel_party_party_std")
      sqlContext.cacheTable("ai_rel_party_party_std")
    } else if (objectName.equalsIgnoreCase("ai_rel_party_phone")) {
      val phoneQuery = "select ai_phone_id, max(quality_rating) as quality_rating from ai_phone_std group by ai_phone_id order by quality_rating desc"
      inputDim.createOrReplaceTempView("ai_phone_std")
      aiPartyDf.createOrReplaceTempView("ai_rel_party_phone_std")

      val aiphoneDf = sqlContext.sql(phoneQuery)
      aiphoneDf.createOrReplaceTempView("ai_phone_with_QR")
      val phoneReljoinQuery = "select a.*,b.quality_rating from ai_rel_party_phone_std a JOIN ai_phone_with_QR b on (a.ai_phone_id=b.ai_phone_id)"
      val phoneRelJoinDf = sqlContext.sql(phoneReljoinQuery)
      phoneRelJoinDf.createOrReplaceTempView("ai_rel_party_phone_std_qr")
      query = "select rpps.* from ai_rel_party_phone_std_qr rpps JOIN (select ai_party_id, ai_phone_id, rel_type, max(inactive_flag) maxflag from ai_rel_party_phone_std_qr group by ai_party_id, ai_phone_id, rel_type having max(inactive_flag)=0) maxparty ON (rpps.ai_party_id = maxparty.ai_party_id AND rpps.ai_phone_id = maxparty.ai_phone_id AND rpps.rel_type = maxparty.rel_type AND rpps.inactive_flag = maxparty.maxflag)"
      sqlContext.cacheTable("ai_rel_party_phone_std_qr")
      aiPartyDf.createOrReplaceTempView("ai_rel_party_phone_std")
      sqlContext.cacheTable("ai_rel_party_phone_std")
    } else if (objectName.equalsIgnoreCase("ai_rel_party_email")) {
      query = "select rpps.* from ai_rel_party_email_std rpps JOIN (select ai_party_id, ai_email_id, rel_type, max(inactive_flag) maxflag from ai_rel_party_email_std group by ai_party_id, ai_email_id, rel_type having max(inactive_flag)=0) maxparty ON (rpps.ai_party_id = maxparty.ai_party_id AND rpps.ai_email_id = maxparty.ai_email_id AND rpps.rel_type = maxparty.rel_type AND rpps.inactive_flag = maxparty.maxflag)"
      aiPartyDf.createOrReplaceTempView("ai_rel_party_email_std")
      sqlContext.cacheTable("ai_rel_party_email_std")
    } else if (objectName.equalsIgnoreCase("ai_rel_party_url")) {
      query = "select rpps.* from ai_rel_party_url_std rpps JOIN (select ai_party_id, ai_url_id, rel_type, max(inactive_flag) maxflag from ai_rel_party_url_std group by ai_party_id, ai_url_id, rel_type having max(inactive_flag)=0) maxparty ON (rpps.ai_party_id = maxparty.ai_party_id AND rpps.ai_url_id = maxparty.ai_url_id AND rpps.rel_type = maxparty.rel_type AND rpps.inactive_flag = maxparty.maxflag)"
      aiPartyDf.createOrReplaceTempView("ai_rel_party_url_std")
      sqlContext.cacheTable("ai_rel_party_url_std")
    }

    aiPartyDf = sqlContext.sql(query)

    aiPartyDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

    aiPartyDf = aiPartyDf.filter(aiPartyDf("AI_SRC_ID") =!= masterId)

    aiPartyDf = addDirectiontoParty(aiPartyDf, trustTable, ">", objectName)

    aiPartyDf = getObjectTrustLevel(aiPartyDf, trustTable,objectName)

    log.info("Trust Level added")

    val outputPath = rootPath + inputConfigData.get(objectLayer + ".output.path").get.mkString

    aiPartyDf = getMasterRecord(aiPartyDf, groupByColumns, sortByColumnsDesc, sortByColumnsAsc, objectName)
    aiPartyDf.persist(StorageLevel.MEMORY_ONLY_SER)

    val timeStamp = CommonUtils.getTimeStamp()
    val processDate = timeStamp._1

    aiPartyDf = aiPartyDf.withColumn("AI_KNOWLEDGE_DATE", lit(processDate)).withColumn("AI_SRC_ID", lit(masterId)).withColumn("AI_RUN_DATETIME", lit(processDate))

    aiPartyDf = aiPartyDf.select(schema.head, schema.tail: _*)
 
    CommonUtils.writeToS3Parquet(aiPartyDf, outputPath, "true", "append") //-- Write again in append mode into the S3
    sqlContext.clearCache()
    aiPartyDf

  }

  def getXrefMasterData(objectLayer: String, trustTable: Dataset[Row], inputConfigData: Map[String, List[String]]): Dataset[Row] = {
    log.info("Generating Master records for XREF")
    val masterId = GlobalVariables.getSourceId.trim()
    val rootPath = GlobalVariables.getRootPath

    val xrefInputPath = rootPath + inputConfigData.get(objectLayer + ".input.path").get.mkString
    log.info("XREF input path: " + xrefInputPath)

    val xrefOutputPath = rootPath + inputConfigData.get(objectLayer + ".output.path").get.mkString
    log.info("XREF output path: " + xrefOutputPath)

    val xrefDistinctColSeq = inputConfigData.get(objectLayer + ".distinct.column").get.toSeq
    log.info("Distinct Columns for XREF: " + xrefDistinctColSeq)

    var schema = inputConfigData.getOrElse(objectLayer + ".schema", List("NA"))
    log.info("Schema for Master XREF: " + schema)

    val groupByColumns = List("AI_PARTY_ID", "ID_VALUE", "ID_NAME")
    val sortByColumns = List("AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE", "AI_BATCH_ID")

    var xrefDf = getLatestData(xrefInputPath, groupByColumns, sortByColumns) //.filter(col("INACTIVE_FLAG")===lit(0))
    val distinctXrefDf = xrefDf.filter(xrefDf("AI_SRC_ID") =!= masterId).select(xrefDistinctColSeq.head, xrefDistinctColSeq.tail: _*).distinct()

    xrefDf = xrefDf.join(distinctXrefDf, xrefDistinctColSeq, "inner")
    val timeStamp = CommonUtils.getTimeStamp()
    val processDate = timeStamp._1

    log.info("Setting AI_RUN_DATETIME as: " + processDate)
    log.info("Setting AI_SRC_ID for MASTER data as: " + masterId)

    xrefDf = xrefDf.withColumn("AI_SRC_ID", lit(masterId)).withColumn("AI_RUN_DATETIME", lit(processDate))

    //.dropDuplicates(xrefDistinctCol.head,xrefDistinctCol.tail:_*).withColumn("AI_SRC_ID", lit(masterId))

    if (!schema(0).equalsIgnoreCase("NA")) {
      xrefDf = xrefDf.select(schema.head, schema.tail: _*)
    } else {
      val xrefSchema = xrefDf.columns
      xrefDf = xrefDf.select(xrefSchema.head, xrefSchema.tail: _*)
    }

    log.info("Writing XREF Master data into path: " + xrefOutputPath)
    CommonUtils.writeToS3Parquet(xrefDf, xrefOutputPath, "true", "append")
    log.info("Master Records generation for XREF is completed")
    xrefDf
  }

  def generateFactMasterData(objectLayer: String, trustTable: Dataset[Row], measureTable: Dataset[Row], inputConfigData: Map[String, List[String]], objectName: String) = {
    log.info("Generating Master Records for Object: " + objectName.toUpperCase())
    val masterId = GlobalVariables.getSourceId.trim()
    val rootPath = GlobalVariables.getRootPath
    var query: String = null

    val factPath = rootPath + inputConfigData.get(objectLayer + ".input.path").get.mkString
    log.info("Fact output path: " + factPath)
    val outputPath = rootPath + inputConfigData.get(objectLayer + ".output.path").get.mkString

    var factTable = CommonUtils.readFromS3Parquet(factPath, "true")
    factTable = factTable.select(factTable.columns.map(x => col(x).as(x.toUpperCase())): _*)

    factTable = factTable.filter(col("INACTIVE_FLAG") === lit(0)).filter(col("AI_SRC_ID") =!= masterId)
    if (objectName.equalsIgnoreCase("ai_contact_fct")) {
      query = "select * from (select a.*, row_number()over(partition by a.ai_src_id, a.ai_party_id, a.ai_measure_name order by ai_effective_date desc, ai_knowledge_date desc, ai_batch_id desc, ai_run_datetime desc) as row_number from (select * from ai_contact_fct where ai_party_id not in (select ai_party_id from ai_contact_fct where inactive_flag=1) ) a )b where row_number = 1"
      factTable.createOrReplaceTempView("ai_contact_fct")
      sqlContext.cacheTable("ai_contact_fct")

    } else if (objectName.equalsIgnoreCase("ai_company_fct")) {
      query = "select * from (select a.*, row_number()over(partition by a.ai_src_id, a.ai_party_id, a.ai_measure_name order by ai_effective_date desc, ai_knowledge_date desc, ai_batch_id desc, ai_run_datetime desc) as row_number from (select * from ai_company_fct where ai_party_id not in (select ai_party_id from ai_company_fct where inactive_flag=1) ) a )b where row_number = 1"
      factTable.createOrReplaceTempView("ai_company_fct")
      sqlContext.cacheTable("ai_company_fct")
    }

    factTable = sqlContext.sql(query)

    factTable.persist()
    factTable = factTable.withColumn("AI_CONTRIBUTING_SRC_ID", factTable("AI_SRC_ID"))

    factTable = addDirectiontoParty(factTable, trustTable, ">", objectName)

    factTable = getObjectTrustLevel(factTable, trustTable, objectName)

    factTable = getMeasureDirection(factTable, measureTable, objectName)

    factTable.persist()

    factTable = getMeasureTrustLevel(factTable, measureTable, objectName)

    //        val groupByColumns = inputConfigData.get(objectLayer+".group.by.column").get // -- Config Driven
    //        val sortByColumnsDesc = inputConfigData.get(objectLayer+".sort.by.desc").get //List("ai_effective_date", "ai_knowledge_date") // -- Config Driven
    //        val sortByColumnsAsc = inputConfigData.get(objectLayer+".sort.by.asc").get//List("Value") // -- Config Driven
    //

    val groupByColumns = List("AI_PARTY_ID", "AI_MEASURE_NAME") // -- Config Driven
    val sortByColumnsDesc = List("AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE") // -- Config Driven
    val sortByColumnsAsc = List("MEASURE_TRUST_LEVEL") // -- Config Driven

    factTable.show()
    var notNullFactTable = factTable.filter(col("MEASURE_TRUST_LEVEL").isNotNull)

    var notNullMasterFactTable: DataFrame = null
    var schema1 = List("AI_BATCH_ID", "AI_SRC_ID", "AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE", "AI_PARTY_ID", "AI_MEASURE_NAME", "AI_MEASURE_VALUE", "INACTIVE_FLAG", "AI_CONTRIBUTING_SRC_ID", "AI_RUN_DATETIME")

    val timeStamp = CommonUtils.getTimeStamp() //AI_CONTRIBUTING_SRC_ID
    val processDate = timeStamp._1

    if (!notNullFactTable.head(1).isEmpty) {
      log.info("Processing based on measure name level trust")
      notNullMasterFactTable = getMasterRecord(notNullFactTable, groupByColumns, sortByColumnsDesc, sortByColumnsAsc, objectName)
      notNullMasterFactTable.show()

      notNullMasterFactTable = notNullMasterFactTable.select(schema1.head, schema1.tail: _*)
      CommonUtils

      notNullMasterFactTable = notNullMasterFactTable.withColumn("AI_KNOWLEDGE_DATE", lit(processDate)).withColumn("AI_SRC_ID", lit(masterId)).withColumn("AI_RUN_DATETIME", lit(processDate))
      notNullMasterFactTable.persist()
      notNullMasterFactTable.printSchema()
      //schema1 = schema1 :+ "AI_CONTRIBUTING_SRC_ID" :+ "AI_RUN_DATETIME"
      val notNullMasterFactTableWrite = notNullMasterFactTable.select(schema1.head, schema1.tail: _*)
      CommonUtils.writeToS3Parquet(notNullMasterFactTableWrite, outputPath, "true", "append")

    }

    var nullValuesFactTable = factTable.filter(col("MEASURE_TRUST_LEVEL").isNull).drop("MEASURE_DIRECTION").drop("MEASURE_TRUST_LEVEL")

    nullValuesFactTable.persist()
    println("object level filter")
    log.info("Processing based on object level trust")

    //    val objLevelGroupByColumns = inputConfigData.get(objectLayer+".group.by.column").get // -- Config Driven
    //    val objLevelSortByColumnsDesc = inputConfigData.get(objectLayer+".sort.by.desc").get //List("ai_effective_date", "ai_knowledge_date") // -- Config Driven
    //    val objLevelSortByColumnsAsc = inputConfigData.get(objectLayer+".sort.by.asc").get//List("Value") // -- Config Driven
    //

    val nullGroupByCols = List("AI_PARTY_ID", "AI_MEASURE_NAME")
    val nullSortByColsDesc = List("AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE")
    val nullSortByColsAsc = List("MEASURE_TRUST_LEVEL")
    //AI_CONTRIBUTING_SRC_ID
    notNullMasterFactTable = getMasterRecord(nullValuesFactTable, nullGroupByCols, nullSortByColsDesc, nullSortByColsAsc, objectName)
    val updatedSrcId: String = notNullMasterFactTable.first().getAs("AI_SRC_ID")
    notNullMasterFactTable = notNullMasterFactTable.withColumn("AI_KNOWLEDGE_DATE", lit(processDate)).withColumn("AI_CONTRIBUTING_SRC_ID", lit(updatedSrcId)).withColumn("AI_SRC_ID", lit(masterId)).withColumn("AI_RUN_DATETIME", lit(processDate))

    notNullMasterFactTable = notNullMasterFactTable.select(schema1.head, schema1.tail: _*)

    CommonUtils.writeToS3Parquet(notNullMasterFactTable, outputPath, "true", "append")
    sqlContext.clearCache()
    log.info("Master Records generation for Object " + objectName.toUpperCase() + " is completed")

  }

  def getLatestData(tableLocation: String, groupByColumns: List[String], sortByColumns: List[String]): DataFrame = {

    log.info("Getting Latest Records")
    var inuputDf = CommonUtils.readFromS3Parquet(tableLocation, "true")

    inuputDf = inuputDf.select(inuputDf.columns.map(x => col(x).as(x.toUpperCase())): _*) //.filter("INACTIVE_FLAG=1")

    log.info("Filtering out Inactive Records")
    val inactiveDf = inuputDf.select(col("AI_PARTY_ID")).filter("INACTIVE_FLAG=1")
    inuputDf.createOrReplaceTempView("df1")
    inactiveDf.createOrReplaceTempView("df2")

    val query = "select df1.* from df1 left outer join df2 on (df1.AI_PARTY_ID = df2.AI_PARTY_ID) where df2.AI_PARTY_ID is null"
    inuputDf = sqlContext.sql(query)
    inuputDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

    // getting the latest record
    val sortByColumnsWithOrder = sortByColumns.map(name => col(name).desc)
    val resultDF = inuputDf.withColumn("latest_record", row_number().over(
      Window.partitionBy(groupByColumns map col: _*).orderBy(sortByColumnsWithOrder: _*))).filter(col("latest_record") === 1)

    log.info("Fetched Latest Records")
    resultDF

  }

}