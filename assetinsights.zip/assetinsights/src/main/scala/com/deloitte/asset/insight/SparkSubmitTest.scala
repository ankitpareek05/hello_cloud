package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.CommonUtils

object SparkSubmitTest {
  def main(args: Array[String]) {

    val inputPath = "s3a://ai-0068800-processing/Staging/dimsandfacts/ai_phone/"
    val outputPath = "s3a://ai-0068800-processing/Staging/dimsandfacts/spark_submit_test_op"

    var df = CommonUtils.readFromS3Parquet(inputPath, "true")
    df.show(10, false)

    var finalDF = CommonUtils.addAutoIncremetColumn(df, "test_auto_incr_col")

    finalDF.show(10, false)

    CommonUtils.writeToS3(finalDF, outputPath)
  }
}