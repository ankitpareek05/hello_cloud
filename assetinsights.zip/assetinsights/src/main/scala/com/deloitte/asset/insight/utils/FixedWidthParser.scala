package com.deloitte.asset.insight.utils
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

import com.typesafe.config.Config

/* Class is responsible for Creating Dataframe from
 * Fixed width Input files
 * Developer: Ankit Pareek
 */

class FixedWidthParser {

  /* Reads config file and perform transformtion
	 * as per config file
	 * @Input: Config File , @return  DataFrame
	 * Developer:Ankit Pareek
	 * Modified By : Vishal Agrawal
	 */

  def dataFileParser(inputPathConfig: String): DataFrame = {
    val sparkContext = InitiateSparkContext.getSparkContext()
    val sqlContext = InitiateSparkContext.getSqlContext()
    //import sqlContext.implicits._
    val configData = CommonUtils.getConfigData(inputPathConfig)

    // Reading path of input file from config file
    val inputFileName = configData.get(CommonConstants.KEY_LANDING_INPUT).get(0)

    // Reading path of Substring Config file
    val substrCfileName = configData.get(CommonConstants.KEY_SUBSTR).get(0)

    // Reading Input File
    val inputFileData = sparkContext.textFile(inputFileName)

    // Reading Substring Config file
    var substrCfileData = sparkContext.textFile(substrCfileName) //.toArray()

    // Removing header from Substring Config file and creating tuple for schema, startIndex, endIndex
    val config = substrCfileData.filter(header => !header.startsWith("#")).map(line => {
      val splitLine = line.split(',')
      val schemaValue = splitLine(1).mkString
      val startIndex = splitLine(2).toInt
      val endIndex = splitLine(3).toInt

      (schemaValue, startIndex, endIndex)
    }).collect()

    //Creating Schema
    val schema = StructType(config.map(col => StructField(col._1, StringType, true)))

    // Creating dataframe from input file
    val inputParseDataRDD = inputFileData.map(inputRecord => {
      var seq: Seq[String] = Seq()
      config.map(cfileRecord => {
        val startIndex = cfileRecord._2.toInt
        val endIndex = cfileRecord._3.toInt
        try {
          seq = seq :+ (inputRecord.substring(startIndex, endIndex).trim().mkString) // add try catch
        } catch {
          case e: Exception => seq = seq :+ ""
        }
      })
      var inputStucturedRDD = Row.fromSeq(seq)
      inputStucturedRDD
    })

    val dataFrame = sqlContext.createDataFrame(inputParseDataRDD, schema)
    dataFrame

  } //End of dataFileParser()

} // End of class FixedWidthParser

