package com.deloitte.asset.insight.services
import org.apache.spark.sql.DataFrame
import scala.collection.Map
trait PreProcessing {
  
  def processPreprocessingLayer(preprocessingInputDf:Map[String, List[String]],layerName:String) :DataFrame
  
}