package com.deloitte.asset.insight.service.impl

import com.deloitte.asset.insight.services.Standardization
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils._

import scala.collection.Map
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SQLContext
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.expressions.Window

import java.time.format.DateTimeFormatter
import java.time.LocalDateTime
import scala.collection.Map
import scala.collection.immutable.ListMap

class StandardizationImpl extends Standardization with Logging {

  val sparkSession = InitiateSparkContext.getSparkSession()
  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = new SQLContext(sparkContext)
  val curr_time_stamp = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH_mm").format(LocalDateTime.now)

  import sqlContext.implicits._

  val debugFlag = GlobalVariables.getDebugFlag
  import DataFrameOperation.implicits._

  override def match_data_preparation(standardizationConfigData: Map[String, List[String]]): DataFrame = {
    val layerName = GlobalVariables.getLayerName

    //val inputTables = standardizationConfigData.filter(x => x._1.toLowerCase().contains("source.input.path"))
    val selectColumns = standardizationConfigData.filter(x => x._1.toLowerCase().contains("select.column"))
    val joinConditions = standardizationConfigData.filter(x => x._1.toLowerCase().contains("join.condition"))
    val whereColumns = standardizationConfigData.filter(x => x._1.toLowerCase().contains("filter.condition"))
    val joinTables = standardizationConfigData.filter(x => x._1.toLowerCase().contains("join.table"))
    val recentDataPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("most.recent.data.path")).head._2(0)

    val inputTablePath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("source.input.path"))
    val outputTablePath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("table.output.path"))
    val groupByColumns = standardizationConfigData.filter(x => x._1.toLowerCase().contains("group.by.columns.table"))
    val sortByColumns = standardizationConfigData.filter(x => x._1.toLowerCase().contains("sort.by.columns.table"))

    val inputTablePathSorted = ListMap(inputTablePath.toSeq.sortWith(_._1.split("\\.").last.toInt < _._1.split("\\.").last.toInt): _*)
    //val outputTablePathSorted = ListMap(outputTablePath.toSeq.sortWith(_._1.split("\\.").last.toInt < _._1.split("\\.").last.toInt): _*)
    val groupByColumnsSorted = ListMap(groupByColumns.toSeq.sortWith(_._1.split("\\.").last.toInt < _._1.split("\\.").last.toInt): _*)
    val sortByColumnsSorted = ListMap(sortByColumns.toSeq.sortWith(_._1.split("\\.").last.toInt < _._1.split("\\.").last.toInt): _*)

    log.info("\n inputTables \n" + inputTablePathSorted)
    log.info("\n selectColumns \n" + selectColumns)
    log.info("\n joinTables \n" + joinTables)
    log.info("\n joinConditions \n" + joinConditions)
    log.info("\n whereColumns \n" + whereColumns)

    val outputRelativePath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("output.path")).head._2(0)
    val dynamic_query = CommonUtils.queryBuilder(selectColumns, joinConditions, joinTables, whereColumns)
    log.info("\n dynamic_query \n " + dynamic_query)

    //log.info(":::::::: outputTablePathSorted ::::::::::: " + outputTablePathSorted)
    //log.info(":::::::: inputTablePathSorted ::::::::::: " + inputTablePathSorted)
    //log.info(":::::::: groupByColumnsSorted ::::::::::: " + groupByColumnsSorted)
    //log.info(":::::::: sortByColumnsSorted ::::::::::: " + sortByColumnsSorted)

    val bucketName = GlobalVariables.getRootPath
    var i = 1
    inputTablePathSorted.map { x =>
      val tableName = (x._1).split("\\.")(1)
      log.info("Reading data from table : " + tableName)
      val tableLocation = bucketName + x._2(0)
      log.info("Input path : " + tableLocation)
      //val tableNameDF = CommonUtils.readFromS3Parquet(tableLocation, "true")

      val tablePath = bucketName + x._2(0)
      val groupByColumns = groupByColumnsSorted.get("standardization.group.by.columns.table." + i).get.toList
      val sortByColumns = sortByColumnsSorted.get("standardization.sort.by.columns.table." + i).get.toList
      //val outputPath = outputTablePathSorted.get("standardization.table.output.path." + i).get(0)
      //log.info("outputPath ::::::::: " + bucketName + outputPath)
      var tableNameDF: DataFrame = null

      if (groupByColumns(0).equalsIgnoreCase("na")) {
        //log.info("::::: if tableLocation ::::: ")
        tableNameDF = CommonUtils.readFromS3Parquet(tableLocation, "true")
      } else {
        //log.info("::::: else tableLocation ::::: ")
        tableNameDF = CommonUtils.getLatestData(tablePath, groupByColumns, sortByColumns, tableName, bucketName + recentDataPath)
      }

      tableNameDF.createOrReplaceTempView(tableName)
      tableNameDF = tableNameDF.repartition(500)
      //log.info("Records fetched from " + tableName + " : " + tableNameDF.count() + "\n")
      i = i + 1
    }

    val outputPath = bucketName + outputRelativePath
    val dataPrepTableName = "data_prep_with_duplicates"

    // TODO distinct can be removed after validating the data
    val query_output = sqlContext.sql(dynamic_query).distinct()
    //.na.fill("NA_INVALID")
    query_output.createOrReplaceTempView(dataPrepTableName)

    //query_output.persist(StorageLevel.MEMORY_AND_DISK_SER)
    log.info("Writing the master data to s3 : " + outputPath)

    // writing the data preparation output to s3

    query_output.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    
    if (debugFlag.equalsIgnoreCase("true")) {
      CommonUtils.writeToS3Parquet(query_output, outputPath, "true", "overwrite")
    }
    query_output
  }

  override def match_data(inputDf: DataFrame, standardizationConfigData: Map[String, List[String]]) = {

    val layerName = GlobalVariables.getLayerName
    //val inputTable = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.input.path"))
    val outputRelativePath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.output.path")).head._2(0)
    val matchPivotInputPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.pivot.input.path")).head._2(0)
    val matchRules = standardizationConfigData.filter(x => x._1.toLowerCase().contains("active.match.rule"))
    val matchKey = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.key")).head._2(0)
    val matchPriority = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.priority")).head._2(0)

    val matchSchema = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.schema"))

    var inputSourceDF = inputDf
    var outputPath: String = null
    var pivotInputPath: String = null

    val bucketName = GlobalVariables.getRootPath

    //log.info("\n Input data size : " + inputSourceDF.count())
    outputPath = bucketName + outputRelativePath
    pivotInputPath = bucketName + matchPivotInputPath
    log.info("\n Output Path : " + outputPath)
    CommonUtils.matchProcess(inputSourceDF, matchKey, matchPriority, matchRules, outputPath, pivotInputPath, sqlContext, curr_time_stamp)
  }

  override def matchDataFactSchema(standardizationConfigData: Map[String, List[String]]) {

    val bucketName = GlobalVariables.getRootPath
    val matchFlatModelPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.pivot.input.path")).head._2(0)
    val matchFactModelPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.fact.path")).head._2(0)
    val matchSchema = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.schema")).head._2

    val matchFlatDf = CommonUtils.readFromS3Parquet(bucketName + matchFlatModelPath + "/*" + curr_time_stamp, "true")
    matchFlatDf.createOrReplaceTempView("match_flat_table")

    val matchFlatSchema = matchFlatDf.schema
    log.info("matchFlatSchema : " + matchFlatSchema)
    val comma = " , "
    var measureNames = ""
    var measureNamesMatch = ""

    // appending the column names and its values to create the map of column names and its values in the query
    matchFlatSchema.foreach(eachField => {
      if (eachField.name.toString().toLowerCase().endsWith("_matched")) {
        measureNames = measureNames + "'" + eachField.name.toString().toLowerCase().replace("_matched", "") + "'" + comma + eachField.name.toString().toLowerCase().replace("_matched", "") + comma
        measureNamesMatch = measureNamesMatch + "'" + eachField.name.toString() + "'" + " , " + eachField.name.toString() + comma
      }
    })
    measureNames = measureNames.splitAt(measureNames.lastIndexOf(comma))._1
    measureNamesMatch = measureNamesMatch.splitAt(measureNamesMatch.lastIndexOf(comma))._1

    val query = "select AI_MATCH_ID, measure_name1 AS AI_OUTPUT_MEASURE, output_measure_value AS AI_OUTPUT_VALUE, match_measure_value AS AI_MATCH_OUTPUT_VALUE from ( select AI_MATCH_ID,  map(" + measureNames + " ) as output_val ,map( " + measureNamesMatch + ") as match_output_val from match_flat_table )tmp lateral view posexplode(output_val) tab1 as pos1, measure_name1, output_measure_value lateral view posexplode(match_output_val) tab2 as pos2, measure_name2, match_measure_value WHERE pos1 = pos2 "

    log.info("match flat model to fact model conversion query : " + query)
    log.info("Writing the fact model data to s3 location at : " + bucketName + matchFactModelPath)

    var matchFactModelDf = sqlContext.sql(query)

    //Dropping the null values
    matchFactModelDf = matchFactModelDf.filter(col("AI_OUTPUT_VALUE").isNotNull && col("AI_MATCH_OUTPUT_VALUE").isNotNull)

    // writing the match data in the fact model to s3
    CommonUtils.writeToS3Parquet(matchFactModelDf.distinct(), bucketName + matchFactModelPath, "true", "append")
  }

  override def stageToStandardization(inputConfigData: Map[String, List[String]]) = {
    val layerName = GlobalVariables.getLayerName
    val expectedStandardization = inputConfigData.get(layerName + ".standard.tables.list").getOrElse(List("NA")).map(_.trim().toLowerCase().replaceAll("_", "."))
    log.info("List of tables for standardization : " + expectedStandardization.toString())

    if (!expectedStandardization(0).equalsIgnoreCase("na")) {

      expectedStandardization.map(standardName => {

        val standardNameLayer = layerName + "." + standardName

        val standardConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(standardNameLayer))

        log.info("===> Running Standardization for : " + standardNameLayer)

        stageToStandard(standardNameLayer, standardConfigData)

      })
    } else {
      log.info("===> No Standardization List Available, Exiting the process ")
    }

  }

  def stageToStandard(stageToStandardLayerName: String, stageToStandardConfigData: Map[String, List[String]]) = {

    log.info("Key - Value Pair : ")
    log.info(stageToStandardConfigData.foreach(println))

    val bucketName = GlobalVariables.getRootPath
    log.info("Bucekt Name : " + bucketName)

    val debugFlag = GlobalVariables.getDebugFlag
    log.info("Debug Flag : " + debugFlag)

    val expectedInputPath = stageToStandardConfigData.keySet.filter(_.contains(".input.path")).toList

    log.info("Expected Input Path : " + expectedInputPath.toString())

    val expectedTable = stageToStandardConfigData.keySet.filter(_.contains(".table.name")).toList
    log.info("Expected Table Name : " + expectedTable.toString())

    val outputPath = bucketName + stageToStandardConfigData.get(stageToStandardLayerName + ".output.path").get(0).trim()

    val expectedSqlQuery = stageToStandardConfigData.keySet.filter(_.contains(".sql.query")).toList

    val stageToStandardSchema = stageToStandardConfigData.get(stageToStandardLayerName + ".schema").get.toList.map(_.trim().toUpperCase())

    var inputPathAndTableName: List[(String, String)] = List()
    for (i <- 1 to expectedInputPath.length) {
      inputPathAndTableName = inputPathAndTableName :+ (stageToStandardConfigData.get(stageToStandardLayerName + ".input.path" + i).get(0), stageToStandardConfigData.get(stageToStandardLayerName + ".table.name" + i).get(0))
    }

    log.info(inputPathAndTableName.toString())
    try {
      inputPathAndTableName.map(stageToStandardData => {

        val inputPath = bucketName + stageToStandardData._1
        val tableName = stageToStandardData._2

        log.info("Data in Input Path : " + inputPath + " is linked to Table with Name : " + tableName)

        val dataFrame = CommonUtils.readFromS3Parquet(inputPath, "true")
        //        val dataFrame = CommonUtils.readFromCsvFile(inputPath, "true", "true")

        dataFrame.createOrReplaceTempView(tableName)
        sqlContext.cacheTable(tableName)
      })

      expectedSqlQuery.map(queryKey => {

        val query = stageToStandardConfigData.getOrElse(queryKey, List("NA"))(0)
        log.info("SQL Query - " + query)

        var sqlDF = sqlContext.sql(query)

        sqlDF = sqlDF.select(stageToStandardSchema.head, stageToStandardSchema.tail: _*)

        // Adding the Run Date Time Stamp
        val runTimeStamp = CommonUtils.getTimeStamp()._1
        sqlDF = sqlDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp))

        log.info("Writing DF to : " + outputPath)

        sqlDF.showOrNoShow(debugFlag)
        CommonUtils.writeToS3Parquet(sqlDF, outputPath, "true", "append")

      })
    } catch {
      case e: Exception =>
        log.error("Unable to execute the method, Please check below message")
        e.printStackTrace()
        System.exit(1)
    }

    sqlContext.clearCache()

    /*val inputPath = bucketName + standardConfigData.get(standardNameLayer + ".input.path").get(0).trim() //.toLowerCase
    log.info("input path : " + inputPath)
    log.info(standardNameLayer)

    val outputPath = bucketName + standardConfigData.get(standardNameLayer + ".match.output.path").get(0).trim().toLowerCase
    log.info("Output path : " + outputPath)
    val mappingColumn = standardConfigData.get(standardNameLayer + ".mapping.column").get.toList.map(_.trim().toUpperCase())
    log.info(mappingColumn)
    val fileExist = CommonUtils.isS3FileExists(inputPath.replace("*", ""))

    if (fileExist.equalsIgnoreCase("true")) {

      log.info(inputPath + " fileExists")
      // Step:3 Reading XRef data from S3.
      var existingDF = CommonUtils.readFromS3Parquet(inputPath, "true")
      //      existingDF.printSchema()
      if (!mappingColumn(0).equalsIgnoreCase("na")) {

        val schema = mappingColumn.map(cols => {
          val oldCol = cols.split(":")(0)
          val newCol = cols.split(":")(1)
          existingDF = existingDF.withColumnRenamed(oldCol, newCol)
          newCol
        })
        existingDF = existingDF.select(schema.head, schema.tail: _*)
        //        existingDF.show()
        CommonUtils.writeToS3Parquet(existingDF, outputPath, "true", "append")
        log.info("Completed " + standardNameLayer)
      } else {
        log.info("No Mapping Column Found, Straight copying all the columns to standardization")
        CommonUtils.writeToS3Parquet(existingDF, outputPath, "true", "append")
        log.info("===> Completed " + standardNameLayer)
      }

    } else { log.info("Location Not Found") }
*/
  }

} // Main Bracket