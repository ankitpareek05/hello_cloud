package com.deloitte.asset.insight.geocoding.api

class Address(_addressLine1: String, _city: String, _state: String, _postalCode: String, _country: String) {
  var addressLine1 = _addressLine1
  var city = _city
  var state = _state
  var postalCode = _postalCode
  var country = _country

  override def toString(): String = {
    var ctrlA = "\u0001"
    var address = "" + addressLine1 + ctrlA + city + ctrlA + state + ctrlA + postalCode + ctrlA + country

    return address
  }
}

