package com.deloitte.asset.insight.service.impl

import org.apache.spark.sql.DataFrame

import com.deloitte.asset.insight.utils._
import com.deloitte.asset.insight.rules._
import com.deloitte.asset.insight.services.RuleProcess
import com.typesafe.config.{ Config, ConfigFactory }

import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import scala.collection.Map
import com.deloitte.asset.insight.services.Logging
import org.apache.spark.sql.functions._
import java.io.File
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types.StringType

class RuleProcessImpl extends RuleProcess with Logging {

  val sqlContext = InitiateSparkContext.getSqlContext()
  import sqlContext.implicits._
  import DataFrameOperation.implicits._
  val debugFlag = GlobalVariables.getDebugFlag
  override def processFinancialRule(mainDF: DataFrame, inputPathConfig: String): DataFrame = {

    val transformationRules = CommonUtils.getConfigData(inputPathConfig)

    val financialTransformationRules = transformationRules.filter(rule => rule._1.startsWith(RulesConstants.FINANCIAL_RULES))

    val mainRDD = mainDF.rdd

    mainRDD.map(row => {
      financialTransformationRules.map(rules => {
        val ruleName = rules._1
        val colNames = rules._2.toArray

        ruleName match {
          //by:sunny
          case "financial.transformation.rule_Credit_Card_Expiry_Check"              => FinancialRules.creditCardExpiryCheck(colNames, row)
          case "financial.transformation.rule_Annual_Revenue_Validation"             => FinancialRules.annualRevenueValidationCheck(colNames, row)
          case "financial.transformation.rule_Gamma_Validation"                      => FinancialRules.gammaValidationCheck(colNames, row)
          case "financial.transformation.rule_Positive_Close_Price_Value_Validation" => FinancialRules.positiveClosePriceValueValidation(colNames, row)
          case "financial.transformation.rule_Accrual_Period_Validation"             => FinancialRules.accuralPeriodValidation(colNames, row)
          case "financial.transformation.rule_Beta_Coefficient_Validation"           => FinancialRules.betaCoefficientValidation(colNames, row)
          case "financial.transformation.rule_Currency_Code_Validation"              => FinancialRules.currencyCodeValidation(colNames, row)
          case "financial.transformation.rule_CUSIP_Validation"                      => FinancialRules.cUSIPValidation(colNames, row)
          case "financial.transformation.rule_Dividend_Yield_Validation"             => FinancialRules.dividendYieldValidation(colNames, row)
          case "financial.transformation.rule_EAD_Drawn_Balance_Validation"          => FinancialRules.eADDrawnBalanceValidation(colNames, row)
          case "financial.transformation.rule_EAD_Validation"                        => FinancialRules.eADValidation(colNames, row)
          case "financial.transformation.rule_EPS_Validation"                        => FinancialRules.ePSValidation(colNames, row)
          case "financial.transformation.rule_GBR_Bank_Sort_Code_Parse"              => FinancialRules.gBRBankSortCodeParse(colNames, row)
          case "financial.transformation.rule_GBR_Bank_Sort_Code_Standardize"        => FinancialRules.gBRBankSortCodeStandardize(colNames, row)
          case "financial.transformation.rule_GBR_Bank_Sort_Code_Validation"         => FinancialRules.gBRBankSortCodeValidation(colNames, row)
          case "financial.transformation.rule_IBAN_Validition"                       => FinancialRules.iBANValidition(colNames, row)
          case "financial.transformation.rule_Interest_Rate_Within_Range"            => FinancialRules.interestRateWithinRange(colNames, row)
          case "financial.transformation.rule_ISIN_Code_Validation"                  => FinancialRules.iSINCodeValidation(colNames, row)
          case "financial.transformation.rule_Loan_to_Value_Ratio"                   => FinancialRules.loanToValueRatio(colNames, row)
          case "financial.transformation.rule_Loss_Given_Default_Validation"         => FinancialRules.lossGivenDefaultValidation(colNames, row)
          case "financial.transformation.rule_Market_Cap_Validation"                 => FinancialRules.marketCapValidation(colNames, row)
          case "financial.transformation.rule_Maturity_Date_Validation"              => FinancialRules.maturityDateValidation(colNames, row)
          case "financial.transformation.rule_Positive_Coupon_Percent_Validation"    => FinancialRules.positiveCouponPercentValidation(colNames, row)
          case "financial.transformation.rule_Positive_Last_Price_Value_Validation"  => FinancialRules.positiveLastPriceValueValidation(colNames, row)
          case "financial.transformation.rule_Positive_Open_Price_Validation"        => FinancialRules.positiveOpenPriceValidation(colNames, row)
          case "financial.transformation.rule_Positive_Volume_Validation"            => FinancialRules.positiveVolumeValidation(colNames, row)
          //by:neeraj
          case "financial.transformation.rule_Price_Earnings_Ratio_Validation"       => FinancialRules.priceEarningsRatioValidation(colNames, row)
          case "financial.transformation.rule_Probability_of_Default_Validation"     => FinancialRules.probabilityOfDefaultValidation(colNames, row)
          case "financial.transformation.rule_Rating_Code_Validation"                => FinancialRules.ratingCodeValidation(colNames, row)
          case "financial.transformation.rule_Rating_Date_Validation"                => FinancialRules.ratingDateValidation(colNames, row)
          case "financial.transformation.rule_Risk_Weighted_Asset_Validation"        => FinancialRules.riskWeightedAssetValidation(colNames, row)
          case "financial.transformation.rule_SEDOL_Validation"                      => FinancialRules.sedolValidation(colNames, row)
          case "financial.transformation.rule_Stock_Exchange_Validation"             => FinancialRules.stockExchangeValidation(colNames, row)
          case "financial.transformation.rule_USA_Routing_Number_Validation"         => FinancialRules.usaRoutingNumberValidation(colNames, row)
          case "financial.transformation.rule_Volatility_Validation"                 => FinancialRules.volatilityValidation(colNames, row)
          case "financial.transformation.rule_Positive"                              => FinancialRules.isPositive(colNames, row)
          case "financial.transformation.rule_GBR_Bank_Account_Validation"           => FinancialRules.gbrBankAccountValidation(colNames, row)
          case "financial.transformation.rule_Age_For_Account_Validation"            => FinancialRules.ageForAccountValidation(colNames, row)
          case "financial.transformation.rule_Delta_Validation"                      => FinancialRules.deltaValidation(colNames, row)
          case "financial.transformation.rule_Ex_Dividend_Date_Validation"           => FinancialRules.exDividendDateValidation(colNames, row)
          case "financial.transformation.rule_Currency_Code_Country_Validation"      => FinancialRules.currencyodeCountryValidation(colNames, row)
          case "financial.transformation.rule_CAN_Transit_Number_Validation"         => FinancialRules.canTransitNumberValidation(colNames, row)
          case "financial.transformation.rule_BIC_SWIFT_Code_Validation"             => FinancialRules.bicSwiftCodeValidation(colNames, row)
          case "financial.transformation.rule_Credit_Card_Security_Code_Validation"  => FinancialRules.creditCardSecurityCodeValidation(colNames, row)
          case "financial.transformation.GBR_Bank_Account_Parse"                     => FinancialRules.gbrBankAccountParse(colNames, row)
        }

      }).filter(_ != null)

    }).flatMap(data => data).toDF()
  }
  //By Kanika Start
  override def processKeyValidationRule(sourceDataDF: DataFrame, inputConfigData: Map[String, List[String]]): DataFrame = {

    log.info("Starting Key Validation Process")
    val layerName = GlobalVariables.getLayerName
    val keyFieldValidationObject = new KeyFieldValidation()

    var errorColumn = inputConfigData.get(layerName + CommonConstants.KEY_FIELD_VALIDATION).get
    log.info("validate col:" + errorColumn.foreach(println))
    //log.info(errorColumn(0) + errorColumn(0).equalsIgnoreCase("na"))

    // if(!errorColumn(0).equalsIgnoreCase("na") || errorColumn(0).isEmpty()){
    log.info("Performing KeyValidation on Column(s): " + errorColumn)
    //var firmName = inputConfigData.get(CommonConstants.KEY_FIRM_CD).get(0)
    var firmName = ""

    val mainRDD = sourceDataDF.rdd
    val names = sourceDataDF.columns
    val schema = StructType(names.map(col => StructField(col, StringType, true)))

    var result = mainRDD.map(row => {

      errorColumn.map(col =>

        keyFieldValidationObject.fieldValidationCheck(col, row, inputConfigData)) //.filter(_ != null)

    }).flatMap(data => data).distinct()

    import sqlContext.implicits._
    var errorTable = result.map(line => line._2).filter(_ != null).toDF()

    errorTable.showOrNoShow(debugFlag)

    var junkRow = result.map(_._1).filter(_ != null)
    var junkRecords = sourceDataDF.sqlContext.createDataFrame(junkRow, sourceDataDF.schema)
    var finalRecords = sourceDataDF.except(junkRecords)
    log.info("Done with Key Validation Process")
    finalRecords
    /* }
    else{
         log.info("Done with Key Validation Process,there were no columns for validation")
      sourceDataDF
    }*/

  }

  def processStandardizationGeneric(mainDF: DataFrame, dimLayer: String, standradizeRuleName: String, inputConfigData: Map[String, List[String]]): DataFrame = {
    var standardizedDF: DataFrame = null

    log.info("dimLayer : " + dimLayer)
    log.info("standradizeRuleName : " + standradizeRuleName)

    val ruleStandardizeAddress = "standardize.address"
    val ruleStandardizePhone = "standardize.phone"
    val ruleStandardizeEmail = "standardize.email"

    standradizeRuleName match {
      case `ruleStandardizeAddress` => standardizedDF = FieldStandardization.ruleStandardizeAddress(mainDF, dimLayer, inputConfigData)
      case `ruleStandardizePhone`   => standardizedDF = FieldStandardization.ruleStandardizePhone(mainDF, dimLayer, inputConfigData)
      case `ruleStandardizeEmail`   => // Call for email standardization

      case _                        => log.info("Standarization rule not found")

    }

    standardizedDF
  }

  //By Kanika end
  /*
 * Dimension fields stadarization
 * @input: Dataframe,Processing layer, Config file
 * @output: Standardized Dataframe
 */
  override def processDimFieldStandardization(mainDF: DataFrame, dimLayer: String, inputConfigData: Map[String, List[String]]): DataFrame = {
    log.info("Entering ")

    var standardDf = mainDF
    var modifiedcolumns = List("AI_BATCH_ID", "AI_SRC_ID", "AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE", "AI_PROCESSED_DATE")
    var mainColumns = mainDF.columns
    val ruleActionList = inputConfigData.keySet.filter(x => x.contains(dimLayer + ".rule")).map(x => x.toLowerCase())

    ruleActionList.foreach(println)

    val actionRuletitle = (dimLayer + ".rule.TitleCase").toLowerCase()
    val actionRuleUpper = (dimLayer + ".rule.standardizeuppercase").toLowerCase()
    val actionRuleLower = (dimLayer + ".rule.standardizelowercase").toLowerCase()
    val actionCountryCodeRemove = (dimLayer + ".rule.countrycoderemoval").toLowerCase()
    log.info(actionRuleUpper)

    val actionArray = Array(actionRuleUpper)

    ruleActionList.map { name =>
      val rule = inputConfigData.get(name).get
      rule.map { col =>
        val colSplit = col.split(":")
        val colName1 = colSplit(0)
        val colName2 = colSplit(1)
        val colName3 = colSplit(2)
        modifiedcolumns = modifiedcolumns :+ colName1

        name match {
          case `actionRuleUpper`         => standardDf = FieldStandardization.ruleStandardizeUpperCase(standardDf, colName1, colName2, colName3)
          case `actionRuleLower`         => standardDf = FieldStandardization.ruleStandardizeLowerCase(standardDf, colName1, colName2, colName3)
          case `actionRuletitle`         => standardDf = FieldStandardization.ruleTitleCase(standardDf, colName1, colName2, colName3)
          case `actionCountryCodeRemove` => standardDf = CleanseRule.rule_removeCountryCode(standardDf, col)
          case _                         => "No field standarization"

        }

      }

    }
    modifiedcolumns.foreach(println)
    var unchangedColumns = mainColumns.diff(modifiedcolumns)
    unchangedColumns.map(column => {
      standardDf = standardDf.withColumn(column + "_O", col(column))
    })

    standardDf.printSchema()

    standardDf
  }

  /*
 * Facts fields stadarization
 * @input: Dataframe,Processing layer, Config file
 * @output: Standardized Dataframe
 */

  override def processFactFieldStandardization(mainDF: DataFrame, factLayer: String, inputConfigData: Map[String, List[String]]): DataFrame = {
    log.info("Entering Facts")
    var standardDf = mainDF
    var unionDf = List[DataFrame]()
    var modifiedcolumns = List("AI_BATCH_ID", "AI_SRC_ID", "AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE")
    //var mainColumns = mainDF.columns
    val ruleActionList = inputConfigData.keySet.filter(x => x.contains(factLayer + ".rule"))
    ruleActionList.foreach(println)
    val actionRuletitle = factLayer + ".ruleTitleCase".toLowerCase()
    val actionRuleUpper = factLayer + ".rulestandardizeuppercase".toLowerCase()
    ruleActionList.map { name =>
      val rule = inputConfigData.get(name).get

      rule.map { col =>
        val colSplit = col.split(":")
        val colName1 = colSplit(0)
        val colName2 = colSplit(1)
        val colName3 = colSplit(2)
        modifiedcolumns = modifiedcolumns :+ colName1
        standardDf = mainDF.where(mainDF("AI_MEASURE_NAME") === colName1)
        name match {
          case `actionRuleUpper` => standardDf = FieldStandardization.ruleStandardizeUpperCase(standardDf, "AI_MEASURE_VALUE", "AI_MEASURE_VALUE_O", "AI_MEASURE_VALUE")
          case `actionRuletitle` => standardDf = FieldStandardization.ruleTitleCase(standardDf, "AI_MEASURE_VALUE", "AI_MEASURE_VALUE_O", "AI_MEASURE_VALUE")
          //case `actionRuleLower`      => standardDf = FieldStandardization.ruleStandardizeLowerCase(standardDf, colName1, colName2, colName3)
          //            case actionRuleSpace      => standardDf = FieldStandardization.rule_Replace_Slashes_With_Space(standardDf, colName1, colName2, colName3)
          //            case actionRuleDateFormat => standardDf = FieldStandardization.ruleStandardizeDateMMDDYY(standardDf, colName1, colName2, colName3)
          //case _  => "No field standarization"

        }
        unionDf = unionDf :+ standardDf

        standardDf

      }

    }

    unionDf.foreach(println)
    log.info("unionDf size : " + unionDf.size)
    // var mainColumns = mainDF.select("AI_MEASURE_NAME").rdd.map(row => row.getAs[String]("AI_MEASURE_NAME")).collect()
    var mainColumns = inputConfigData.get(factLayer + ".tag.value.column").get.toList.map(_.toUpperCase())
    mainColumns = mainColumns.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })
    mainColumns.foreach(println)

    var unchangedColumns = mainColumns diff (modifiedcolumns)
    val finalDF = mainDF.where(mainDF("AI_MEASURE_NAME").isin(unchangedColumns: _*)).toDF()
    finalDF.showOrNoShow(debugFlag)
    standardDf = finalDF.withColumn("AI_MEASURE_VALUE" + "_O", col("AI_MEASURE_VALUE"))
    unionDf = unionDf :+ standardDf
    standardDf = unionDf.reduce(_ union _)
    standardDf.showOrNoShow(debugFlag)

    standardDf
  }

  override def processUtilityRule(mainDF: DataFrame, layerName: String, inputConfigData: Map[String, List[String]]): DataFrame = {

    var standardDf = mainDF
    val ruleAction = inputConfigData.keySet.filter(x => x.contains(layerName + ".rule"))

    if (!ruleAction.isEmpty) {

      //val actionRuleConcatenate = (layerName + ".rulestandardizeconcatenate").toLowerCase()
      val actionFilterColumnValue = (layerName + ".rule.filterbasedoncolumnvalue").toLowerCase()
      val actionRuleConcatNullCheck = (layerName + ".rule.concatnullcheck").toLowerCase()
      val actionAddColumnBasedOnColValue = (layerName + ".rule.DerivedColBasedOnColValue").toLowerCase()
      val actionFilterOnColumnIfMultipleKeys = (layerName + ".rule.FilterOnColumnIfMultipleKeys").toLowerCase()
      val actionRuleHttpsCheck = (layerName + ".rule.urltostartwithhttps").toLowerCase()
      val actionPhoneSeperator = (layerName + ".rule.phoneseperator").toLowerCase()
      val actionRuleConcatWithPipe = (layerName + ".rule.standardizeconcatenatewithpipe").toLowerCase()
      val actionRuleConcatWithComma = (layerName + ".rule.standardizeconcatenatewithcomma").toLowerCase()
      val actionRuleConcatWithSpace = (layerName + ".rule.standardizeconcatenatewithspace").toLowerCase()
      val actionRuleConcatWithHyphen = (layerName + ".rule.standardizeconcatenatewithhyphen").toLowerCase()
      val actionRuleAddDefaultValue = (layerName + ".rule.addAddionalcolumnwithdefaultvalue").toLowerCase()
      val actionRuleCreateDuplicateColumn = (layerName + ".rule.createDuplicateColumn").toLowerCase()
      val actionRuleSplitName=(layerName + ".rule.splitnames").toLowerCase()
      val lookupValues = inputConfigData.getOrElse(layerName + ".derived.col.lookup.basedon.colvalue", List("NA")).mkString(",")
      ruleAction.map { rule =>
        log.info("Rule running : " + rule)
        val ruleValue = inputConfigData.getOrElse(rule, List("NA"))
        if (!ruleValue(0).equalsIgnoreCase("NA")) {
          ruleValue.map({ col =>

            rule match {
              case `actionRuleConcatWithPipe`           => standardDf = CleanseRule.rule_concatColumnsWithPipe(standardDf, col, "|")
              case `actionRuleConcatWithComma`          => standardDf = CleanseRule.rule_concatColumnsWithComma(standardDf, col, ",")
              case `actionRuleConcatWithSpace`          => standardDf = CleanseRule.rule_concatColumnsWithSpace(standardDf, col, " ")
              case `actionRuleConcatWithHyphen`         => standardDf = CleanseRule.rule_concatColumnsWithHyphen(standardDf, col, "-")
              case `actionFilterColumnValue`            => standardDf = CleanseRule.rule_filterBasedOnColumnValue(standardDf, ruleValue)
              case `actionRuleConcatNullCheck`          => standardDf = CleanseRule.rule_concatColumnWithOneNullAlways(standardDf, col)
              case `actionAddColumnBasedOnColValue`     => standardDf = CleanseRule.rule_derivedcolbasedoncolvalue(standardDf, col, lookupValues)
              case `actionRuleHttpsCheck`               => standardDf = FieldStandardization.rule_UrlToStartWithHttps(standardDf, col)
              case `actionFilterOnColumnIfMultipleKeys` => standardDf = CleanseRule.rule_filterOnColumnIfMultipleKeys(standardDf, col)
              case `actionPhoneSeperator`               => standardDf = CleanseRule.rule_seperatePhoneNumber(standardDf, col)
              case `actionRuleAddDefaultValue`          => standardDf = FieldStandardization.rule_addAddionalColumnWithDefaultValue(standardDf, col)
              case `actionRuleCreateDuplicateColumn`    => standardDf = CleanseRule.rule_createDuplicateColumn(standardDf, col)
              case `actionRuleSplitName`                => standardDf= CleanseRule.rule_splitname(standardDf,col)
              case _                                    => "No rules applicable"

            }

          })
          //val delimeter = inputConfigData.getOrElse((layerName + ".concatenatedelimeter").trim(), List("NA")).mkString
          //log.info("delimeter : " + delimeter)

        }

      }

    }
    standardDf
  }

  override def processCleanseRule(mainDF: DataFrame, inputPathConfig: String): DataFrame = {
    log.info("Entering")
    val transformationRules = CommonUtils.getConfigDataStandardization(inputPathConfig)
    //transformationRules.collect().foreach(x=>println(x.mkString))

    // val standardization = transformationRules.filter(rule => rule._1.startsWith(RulesConstants.FINANCIAL_RULES))

    var standardDf = mainDF
    var modifiedcolumns = Array[String]()
    var mainColumns = mainDF.columns
    mainColumns.foreach(println)
    transformationRules.map(rules => {

      val ruleName = rules(1)
      val colName1 = rules(2)
      val colName2 = rules(3)
      val colName3 = rules(4)

      modifiedcolumns = modifiedcolumns :+ colName1

      ruleName match {

        case "rule_All_Trim"                         => standardDf = CleanseRule.rule_All_Trim(standardDf, colName1, colName2, colName3)
        case "rule_replaceSlashesWithSpace"          => standardDf = CleanseRule.rule_replaceSlashesWithSpace(standardDf, colName1, colName2, colName3)
        case "rule_ReplacePunctuationWithSpace"      => standardDf = CleanseRule.rule_Replace_Punctuation_with_Space(standardDf, colName1, colName2, colName3)
        case "rule_ReplacePeriodWithSpace"           => standardDf = CleanseRule.rule_Replace_Period_With_Space(standardDf, colName1, colName2, colName3)
        case "rule_ReplaceNonAlphabeticwith_Space"   => standardDf = CleanseRule.rule_Replace_Non_Alphabetic_with_Space(standardDf, colName1, colName2, colName3)
        case "rule_RemoveAllLeadingZeros"            => standardDf = CleanseRule.rule_Remove_All_Leading_Zeros(standardDf, colName1, colName2, colName3)
        case "rule_ReplaceHyphenUnderscorewithSpace" => standardDf = CleanseRule.rule_Replace_Hyphen_Underscore_with_Space(standardDf, colName1, colName2, colName3)
        case "rule_RemoveNonNumbers"                 => standardDf = CleanseRule.rule_Remove_Non_Numbers(standardDf, colName1, colName2, colName3)
        case "rule_TranslateDiacriticCharacters"     => standardDf = CleanseRule.rule_Translate_Diacritic_Characters(standardDf, colName1, colName2, colName3)
        case _                                       => log.info("Cleanse Rule not found" + ruleName)

      }
    })

    // modifiedcolumns.foreach(println)
    var unchangedColumns = mainColumns.diff(modifiedcolumns)
    unchangedColumns.map(column => {
      standardDf = standardDf.withColumn(column + "_O", col(column))
    })

    //standardDf.showOrNoShow(debugFlag)
    standardDf
  }
}