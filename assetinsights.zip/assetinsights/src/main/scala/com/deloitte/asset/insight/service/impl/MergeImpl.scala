package com.deloitte.asset.insight.service.impl

import java.text.SimpleDateFormat
import java.util.Date

import scala.collection.Map
import scala.util.Try

import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat

import com.deloitte.asset.insight.bean.MatchApprovalBean
import com.deloitte.asset.insight.operations.MergeHelper
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.services.Merge
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.Encoders
import org.apache.spark.rdd.RDD
import com.deloitte.asset.insight.utils.GlobalVariables
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.types.StringType

class MergeImpl extends Merge with Serializable with Logging {
  val joinColumnsForRel = Seq("AI_BATCH_ID", "AI_SRC_ID", "AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE", "AI_PARTY_ID")
  val genericColumns = Seq[String]("AI_BATCH_ID", "AI_SRC_ID", "AI_EFFECTIVE_DATE", "AI_KNOWLEDGE_DATE", "AI_PARTY_ID", "AI_ORIGINAL_SRC_ID", "AI_ORIGINAL_PARTY_ID", "AI_SRC_ID_MATCHED", "AI_PARTY_ID_MATCHED", "AI_MATCH_ID", "AI_MATCH_RULE_ID")
  val matchApprovalOriginalCols = Seq[String]("AI_MATCH_ID", "AI_MATCH_RULE_ID", "AI_EFFECTIVE_DATE", "AI_SRC_ID", "AI_PARTY_ID", "AI_SRC_ID_MATCHED", "AI_PARTY_ID_MATCHED", "AI_EFFECTIVE_DATE_MATCHED", "AI_MERGE_ACTION")
  val deletionColumns = Array("AI_MATCH_ID", "AI_MATCH_RULE_ID", "AI_SRC_ID_MATCHED", "AI_PARTY_ID_MATCHED")
  val sparkSession = InitiateSparkContext.getSparkSession()
  val mergeHelper = new MergeHelper(joinColumnsForRel, genericColumns, sparkSession)
  val dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss")
  val updateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
  val failureDateTime = updateFormat.format(new Date())
  val updatedDate = updateFormat.format(new Date())
  val mergeDateTime = dateFormat.format(new Date())
  import sparkSession.implicits._

  override def mergeDataFromSources(mergeKeyValuesDF: Map[String, List[String]], layerName: String) = {
    var sourceInfo = mergeKeyValuesDF.get(layerName + ".merge.same.source").get(0)
    val isSameSource = Try(sourceInfo.toBoolean).getOrElse(false)
    val matchTable = mergeKeyValuesDF.get(layerName + ".ai.match.output.match.table").get.map(_.trim())
    val matchTablePath = GlobalVariables.getRootPath + "/" + matchTable(0)
    val matchApprovalDataset = mergeHelper.getMatchTableData(matchTablePath, isSameSource)
    matchApprovalDataset.show(false)
    var sourceIds: List[String] = null
    /*try{
      sourceIds = mergeKeyValuesDF.get(layerName + ".merge.same.source").get(0)
    } catch {
      case e: Exception{
        
      }
    }*/
    val originalPartyIds = matchApprovalDataset.select("AI_ORIGINAL_PARTY_ID").as[String].collect()
    val matchedPartyIds = matchApprovalDataset.select("AI_PARTY_ID_MATCHED").as[String].collect()
    val partyIds = originalPartyIds ++ matchedPartyIds 
    val matchDsCols = matchApprovalDataset.columns

    val matchApprovalDS = matchApprovalDataset.drop("AI_EFFECTIVE_DATE", "AI_MERGE_ACTION", "AI_EFFECTIVE_DATE_MATCHED").persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val partyTablePath = GlobalVariables.getRootPath + "/" + mergeKeyValuesDF.get(layerName + ".dimension.party.input.path").get(0)
    val partyTableGroupByColumns = mergeKeyValuesDF.get(layerName + ".dimension.party.group.by.columns.table").get.toList
    val partyTableSortByColumns = mergeKeyValuesDF.get(layerName + ".dimension.party.sort.by.columns.table").get.toList
    var resultantDf: Dataset[Row] = null
   
    try {
      val objectNames = mergeKeyValuesDF.get(layerName + ".merge.tables.list").get.toList
      if (!objectNames(0).equalsIgnoreCase("na")) {
        objectNames.map(objectName => {
          val tableName = objectName.toLowerCase().replace("_", ".")
          val childTable = layerName + "." + tableName

          val childTableInputPath = GlobalVariables.getRootPath + "/" + mergeKeyValuesDF.get(layerName + "." + tableName + ".input.path").get(0)
          println("^^^^^^^^^^^^^^^ " + tableName + " ^^^^^^^^^^^^^: " + childTableInputPath)

          var childTableOutputPath = GlobalVariables.getRootPath + "/" + mergeKeyValuesDF.get(layerName + "." + tableName + ".output.path").get(0) + "/merged_records_" + mergeDateTime
          //val latestDataset = sparkSession.read.option("header", "true").csv(childTableInputPath)

          val groupByColumns = mergeKeyValuesDF.get(layerName + "." + tableName + ".group.by.columns.table").get.toList
          val sortByColumns = mergeKeyValuesDF.get(layerName + "." + tableName + ".sort.by.columns.table").get.toList
          
          var partyTable = CommonUtils.getLatestDataForMerge(partyTablePath, "AI_PARTY_ID", partyTableGroupByColumns, partyTableSortByColumns, partyIds)
          var latestDataset = CommonUtils.getLatestDataForMerge(childTableInputPath, "AI_PARTY_ID", groupByColumns, sortByColumns, partyIds)
          var mergeEligibleMatchApproval = matchApprovalDS.alias("matchApproval").join(partyTable, col("AI_ORIGINAL_PARTY_ID").equalTo(col("AI_PARTY_ID"))).select("matchApproval.*").dropDuplicates().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
          /*
          mergeEligibleMatchApproval.createOrReplaceTempView("MergeEligibleDF")
          matchApprovalDS.createOrReplaceTempView("MatchApprovalDS")
          
          val inactiveParties = sparkSession.sql("SELECT AI_ORIGINAL_PARTY_ID, AI_PARTY_ID_MATCHED FROM MatchApprovalDS EXCEPT SELECT AI_ORIGINAL_PARTY_ID, AI_PARTY_ID_MATCHED FROM MergeEligibleDF")
          
          CommonUtils.writeToS3Parquet(inactiveParties, GlobalVariables.getRootPath + "/standardization/unmerged_records/unmerged_records_" + mergeDateTime, "true", "append")*/
          
          println("--------------- The size of the actual match approval dataset is " + mergeEligibleMatchApproval.count())

          var dfCols = "AI_MATCH_ID" +: "AI_MATCH_RULE_ID" +: "AI_SRC_ID_MATCHED" +: "AI_PARTY_ID_MATCHED" +: latestDataset.columns.dropWhile(p => p.equals("AI_PARTY_ID"))
          dfCols = Array(Set(dfCols)).flatMap(x => x).flatMap(x => x)

          log.info("Applying Merge on table : '" + childTable + "'")
          if (tableName.contains("xref")) {
            log.info("-------- MERGING PARTY XREF --------")
            resultantDf = mergeHelper.mergeXrefRecords(mergeEligibleMatchApproval, latestDataset, dfCols, isSameSource).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
            println("Number of records in Resultant DF:" + resultantDf.count())
            //childTableOutputPath = GlobalVariables.getRootPath + "/" + mergeKeyValuesDF.get(layerName + "." + tableName + ".output.path").get(0) + "/"
            resultantDf.show(false)
            resultantDf.printSchema()
          } else if (tableName.contains("relation.party.party")) {
            log.info("-------- MERGING RELATION PARTY PARTY --------")
            log.info("-------- Executing First Pass on Left Hand Side -------")
            
            resultantDf = mergeHelper.mergeRelPartyPartyRecords(mergeEligibleMatchApproval, latestDataset, dfCols, isSameSource).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
            resultantDf = resultantDf.drop("AI_MATCH_ID", "AI_MATCH_RULE_ID", "AI_SRC_ID_MATCHED", "AI_PARTY_ID_MATCHED")
            resultantDf = resultantDf.drop("AI_RUN_DATETIME").withColumn("AI_RUN_DATETIME", lit(updateFormat.format(new Date())))
            println("Number of records in Resultant DF:" + resultantDf.count())
            log.info("----- Inserting Left Hand Side Pass into the Table -----")
            CommonUtils.writeToS3Parquet(resultantDf, childTableOutputPath, "true", "append")
            latestDataset = CommonUtils.getLatestDataForMerge(childTableInputPath, "AI_REL_PARTY_ID", groupByColumns, sortByColumns, partyIds)            
            
            log.info("-------- Executing Second Pass on Right Hand Side --------")
            var flippedDataset = latestDataset.withColumnRenamed("AI_PARTY_ID", "A1").withColumnRenamed("AI_REL_PARTY_ID", "AI_PARTY_ID").withColumnRenamed("A1","AI_REL_PARTY_ID")
            var flippedResultantDf = mergeHelper.mergeRelPartyPartyRecords(mergeEligibleMatchApproval, flippedDataset, dfCols, isSameSource).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
            flippedResultantDf = flippedResultantDf.withColumnRenamed("AI_PARTY_ID","A1").withColumnRenamed("AI_REL_PARTY_ID","AI_PARTY_ID").withColumnRenamed("A1","AI_REL_PARTY_ID")
            println("Number of records in Flipped Resultant DF:" + flippedResultantDf.count())
            resultantDf = resultantDf.unpersist()
            resultantDf = flippedResultantDf
            flippedResultantDf.unpersist()
          } else if(tableName.contains("dimension.party")) {
            resultantDf = mergeHelper.mergePartyRecords(mergeEligibleMatchApproval, latestDataset, dfCols, isSameSource).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
            println("Number of records in Resultant DF:" + resultantDf.count())
          } else {
            resultantDf = mergeHelper.mergeRecords(mergeEligibleMatchApproval, latestDataset, dfCols, isSameSource).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
            println("Number of records in Resultant DF:" + resultantDf.count())
          }
          resultantDf = resultantDf.drop("AI_MATCH_ID", "AI_MATCH_RULE_ID", "AI_SRC_ID_MATCHED", "AI_PARTY_ID_MATCHED")
          resultantDf = resultantDf.drop("AI_RUN_DATETIME").withColumn("AI_RUN_DATETIME", lit(updatedDate))
          //resultantDf.show(false)
          CommonUtils.writeToS3Parquet(resultantDf, childTableOutputPath, "true", "append")
          println("--------- DATA WRITTEN AT :" + childTableOutputPath)
          resultantDf.unpersist()
          mergeEligibleMatchApproval.unpersist()
        })
      }
      
      val matchApprovalUpdateDf = matchApprovalDS
        .withColumnRenamed("AI_ORIGINAL_SRC_ID", "AI_SRC_ID")
        .withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID")
        .withColumn("AI_MERGE_ACTION", lit(3))
        .withColumn("AI_EFFECTIVE_DATE", lit(updatedDate))
        .withColumn("AI_EFFECTIVE_DATE_MATCHED", lit(updatedDate))
        .select(matchApprovalOriginalCols.head, matchApprovalOriginalCols.tail: _*)
      updateMatchApprovalTable(mergeKeyValuesDF, layerName, matchApprovalUpdateDf)
    } catch {
      case e: Exception =>
        log.info("Merge Failure... Please have a look at the error description below and retry after correction");
        e.printStackTrace();
        
        val matchApprovalUpdateDf = matchApprovalDS
          .withColumnRenamed("AI_ORIGINAL_SRC_ID", "AI_SRC_ID")
          .withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID")
          .withColumn("AI_MERGE_ACTION", lit(-1))
          .withColumn("AI_EFFECTIVE_DATE", lit(failureDateTime))
          .withColumn("AI_EFFECTIVE_DATE_MATCHED", lit(failureDateTime))
          .select(matchApprovalOriginalCols.head, matchApprovalOriginalCols.tail: _*)
        updateMatchApprovalTable(mergeKeyValuesDF, layerName, matchApprovalUpdateDf)
    }
    matchApprovalDS.unpersist()
  }

  /*
   * Unused method
   * 
   */
  override def getEligibleRecordsFromMatchTable(mergeKeyValuesDF: Map[String, List[String]], layerName: String): Dataset[MatchApprovalBean] = {
    val matchTable = mergeKeyValuesDF.get(layerName + ".ai.match.output.match.table").get.map(_.trim())
    try {
      val matchTablePath = GlobalVariables.getRootPath + "/" + matchTable(0)
      log.info("=== Loading the Match Table ===")

      var matchDataDF = mergeHelper.getMatchTableData(matchTablePath, false)
      return matchDataDF
    } catch {
      case ex: Exception => {
        log.error("Unable to find Match Output Config Entry... Cannot proceed with Merge... Terminating Job!")
        log.error("Returning NULL Dataframe and exiting !!")
      }
    }
    return null
  }

  def updateMatchApprovalTable(mergeKeyValuesDF: Map[String, List[String]], layerName: String, matchUpdateDataset: Dataset[Row]) = {
    val matchTable = mergeKeyValuesDF.get(layerName + ".ai.match.output.result.path.match.table").get.map(_.trim())
    //val matchTable = mergeKeyValuesDF.get(layerName + ".ai.match.output.match.table").get.map(_.trim())
    try {
      val matchTablePath = GlobalVariables.getRootPath + "/" + matchTable(0)
      println("=========== Path of Match Table:" + matchTablePath)
      CommonUtils.writeToS3Parquet(matchUpdateDataset, matchTablePath, "true", "append")
    } catch {
      case ex: Exception => {
        log.error("Unable to write updated match approval table entry!")
        ex.printStackTrace()
      }
    }
  }
}