package com.deloitte.asset.insight.utils

import org.apache.spark.sql.types._
import org.apache.spark.sql.types.StructField

/*
 * Common Constants for Error/Warning Codes.
 */

object CommonConstants {

  val STANDARD_SCHEMA = "standard.schema"
  val BLANK_STRING = ""
  val TAG_VALUE = "tag.value.transfacts"
  val S3_ACCESS_KEY = "AKIAI7KL5GPRKX633QJA"
  val S3_SECRET_ACCESS_KEY = "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"

  val S3_INPUT_PATH_PREPROCESSED = "preprocessing.input.path"
  val S3_INPUT_PATH_PROCESSED = "preprocessing.processed.path"
  val KEY_SRCID_LOOKUP_TBL = "preprocessing.source.lookup.table.path"
  //val S3_INPUT_PATH_SCHEMA_STANDARDIZATION = "spark.schema.standarization.input.path"
  val S3_INPUT_PATH_DIMFACT = "spark.dimfact.input.path"

  //added by Vishal for XREF
  val S3_INPUT_PATH_PARTY_XREF = "spark.party.xref.input.path"
  val S3_OUTPUT_PATH_PARTY_XREF = "spark.party.xref.output.path"
  val S3_INPUT_PATH_PRODUCT_XREF = "spark.product.xref.input.path"
  val S3_OUTPUT_PATH_PRODUCT_XREF = "spark.product.xref.output.path"

  val S3_OUTPUT_PATH_PREPROCESSED = "preprocessing.output.path"
  val S3_OUTPUT_PATH_SCHEMA_STANDARDIZATION = "spark.schema.standarization.output.path"

  val S3_OUTPUT_PATH_COMPANYFACTS = "spark.dimfact.output.path.companyfacts"
  val S3_OUTPUT_PATH_TRANSFACTS = "spark.dimfact.output.path.transfacts"
  val S3_OUTPUT_PATH_ASSETFACTS = "spark.dimfact.output.path.assetfacts"
  val S3_OUTPUT_PATH_PRODUCTFACTS = "spark.dimfact.output.path.productfacts"
  val S3_OUTPUT_PATH_CONTACTFACTS = "spark.dimfact.output.path.contactfacts"
  val S3_OUTPUT_PATH_PARTYINFO = "spark.dimfact.output.path.party_info"
  val S3_OUTPUT_PATH_PHONE = "spark.dimfact.output.path.phone"
  val S3_OUTPUT_PATH_REGION = "spark.dimfact.output.path.region"
  val S3_OUTPUT_PATH_RELATIONSHIP = "spark.dimfact.output.path.relationship"
  val S3_OUTPUT_PATH_SEC = "spark.dimfact.output.path.sec"

  // Dimensions output paths
  val S3_OUTPUT_PATH_PRODUCTS_DIM = "spark.dimfact.output.path.products"
  val S3_OUTPUT_PATH_PARTY_DIM = "spark.dimfact.output.path.party"
  val S3_OUTPUT_PATH_ADDRESS_DIM = "spark.dimfact.output.path.address"
  val S3_OUTPUT_PATH_EMAIL_DIM = "spark.dimfact.output.path.email"
  val S3_OUTPUT_PATH_PHONE_DIM = "spark.dimfact.output.path.phone"

  // Rel table output paths
  val S3_OUTPUT_PATH_PARTY_PHONE_RELATION = "spark.relation.output.path.party.phone"

  val PRIMARY_KEY = "SRC_PRIMARY_KEY"
  val LINEAGE_KEY = "AI_LINEAGE_KEY"
  val BATCH_ID = "AI_BATCH_ID"
  val SRC_ID = "AI_SRC_ID"
  val EFFECTIVE_DT = "AI_EFFECTIVE_DATE"
  val KNOWLEDGE_DT = "AI_KNOWLEDGE_DATE"
  val SRC_TIMESTAMP = "AI_RUN_DATETIME"
  val INACTIVE_FLAG = "INACTIVE_FLAG"
  val TRAN = "TRAN"
  val ASSET = "ASSET"
  val KEY_SOURCE_NM = "preprocessing.source.name"
  val KEY_EFFECTIVE_DT = "preprocessing.effective.date"
  val KEY_EFFDATE_INPUT_FORMAT = "preprocessing.effective.date.input.format"
  val KEY_KNOWDATE_INPUT_FORMAT = "preprocessing.knowledge.date.input.format"
  val KEY_KNOWLEDGE_DT = "preprocessing.knowledge.date"
  val KEY_LANDING_INPUT = "spark.landing.input.path"
  val KEY_LANDING_OUTPUT = "spark.landing.output.path"
  val KEY_LINEAGE_COLS = "preprocessing.lineage.key"
  val KEY_PRIMARY_COLS = "preprocessing.primary.key"
  val KEY_SUBSET_COLS = "preprocessing.subset.column"
  val KEY_READ_DELIMITER = "preprocessing.read.delimiter"
  val KEY_WRITE_DELIMITER = "preprocessing.write.delimiter"
  val KEY_SUBSTR = "spark.substr.conf.absolutepath"
  val KEY_FIRM_CD = ".firm.code"
  val KEY_SRC_CD = ".source.code"
  val KEY_FILE_NM = ".file.name"
  val KEY_BATCH_TABLE = ".batchtable.path"
  val KEY_ERROR_CODE = "spark.error.code"
  val KEY_FIELD_VALIDATION = ".key.field.validation"
  val KEY_ERROR_DESCRIPTION = "spark.error.description"
  val KEY_ERROR_RECORDS = "spark.error.records"
  val KEY_FIELD_VALIDATION_CATEGORY = ""
  val USER_CODE = "USER_CODE"
  val FILE_NAME = "FILE_NAME"
  val SOURCE_NAME = "SOURCE_NAME"
  val SOURCE_CODE = "SOURCE_CODE"
  val SOURCE_ID = "SRC_ID"
  val FALSE = "false"
  val TRUE = "true"

  // Delimeters
  val CTRL_A = "\u0001"
  val API_STATUS = "status"
  val PARTIAL_MATCH = "partial_match"
  val API_ERROR_MESSAGE = "error_message"
  val API_WARNING = "WAR-100001"
  val API_WARNING_2 = "WAR-100002"
  val API_QUALITY_RATING = "quality_rating"
  val PHONE_API_VALIDITY = "VALIDITY"
  val API_WARNING_3 = "INVALID_PHONE_NUMBER"
  val API_COUNTRY = "COUNTRY"
  val PHONE_DIM = "staging.dimension.phone"
  val PHONE_DIM_COUNTRY_CODE = "COUNTRY_CODE"
  val PHONE_DIM_EXTENSION = "EXTENSION"
  val PHONE_DIM_NATIONAL_NUMBER = "NATIONAL_NUMBER"
  val PHONE_DIM_QUALITY_RATING = "QUALITY_RATING"

  val INVALID_CHARS = Array("\n", "<", ">", "#", "%", "{", "}", "|", "\\", "^", "[", "]", "`", "~", ";", "/", "?", ":", "@", "&", "=", "+", "$")

  val GOOGLE_API_DF_SCHEMA = Array("formatted_address_o", "formatted_address", "status", "error_message", "street_number", "route", "locality", "administrative_area_level_2", "administrative_area_level_1", "country", "postal_code", "postal_code_suffix", "latitude", "longitude","sub_premise","premise")
  //  val ADDRESS_DIM_SCHEMA = Array("formatted_address_o", "formatted_address", "street_number", "route", "locality", "administrative_area_level_2", "administrative_area_level_1", "country", "postal_code", "postal_code_suffix", "latitude", "longitude", "quality_rating")
  //  val ADDRESS_STD_LOGGING_COLS = Array("formatted_address_o", "status", "error_message", "quality_rating")

  val PHONE_LIB_COLS = Array(
    StructField("phone", StringType),
    StructField("country_code", StringType),
    StructField("country", StringType),
    StructField("national_number", StringType),
    StructField("validity", BooleanType))

  val PHONE_SCHEMA = Array("PHONE", "PHONE_O", "EXTENSION", "COUNTRY", "COUNTRY_CODE", "NATIONAL_NUMBER")
  val PHONE_LIB_SCHEMA = Array("PHONE", "PHONE_O", "EXTENSION", "COUNTRY", "COUNTRY_CODE", "NATIONAL_NUMBER", "VALIDITY", "ERROR_MESSAGE")

  val COLLECTIONS = "collections"

  val LOOKUP_SCHEMA = Array("From_Value", "To_Value", "Status")

  val DATA_FOR_LOOKUP = Array("From_Value")

}