package com.deloitte.asset.insight.bean

import java.sql.Date

case class MatchApprovalBean(
    AI_MATCH_ID: String,
    AI_MATCH_RULE_ID: String,
    AI_EFFECTIVE_DATE: String,
    AI_ORIGINAL_SRC_ID: String,
    AI_ORIGINAL_PARTY_ID: String,
    AI_SRC_ID_MATCHED: String,
    AI_PARTY_ID_MATCHED: String,
    AI_EFFECTIVE_DATE_MATCHED: String,
    AI_MERGE_ACTION: String
    )