package com.deloitte.asset.insight.geocoding.api

case class AddressResponse(status: String, errorMessage: String, addressList: List[AddressComponent])
