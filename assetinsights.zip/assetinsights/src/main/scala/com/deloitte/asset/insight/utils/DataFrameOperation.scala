package com.deloitte.asset.insight.utils

import org.apache.spark.sql.DataFrame
import com.deloitte.asset.insight.services.Logging

object DataFrameOperation extends Logging {

  object implicits {

    // Getting sparkSession object
    val sparkSession = InitiateSparkContext.getSparkSession()

    // Getting sparkContext object
    val sparkContext = InitiateSparkContext.getSparkContext()

    // Getting sqlContext object
    val sqlContext = InitiateSparkContext.getSqlContext()

    import sparkSession.implicits._

    implicit class extraDataFrameMethod(DF: DataFrame) {

      def showOrNoShow(debugFlag: String) = {

        if (debugFlag.equalsIgnoreCase("true")) {
          log.info("Debug Flag is : " + debugFlag)
          DF.show()
        }
      }
    }
  }
}