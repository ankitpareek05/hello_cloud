package com.deloitte.asset.insight

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import org.apache.spark.sql.functions.col

import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.types.IntegerType

object UpdateMatchDimMain extends Logging {

  val sparkSession = InitiateSparkContext.getSparkSession()
  val sparkContext = sparkSession.sparkContext
  val sqlContext = sparkSession.sqlContext

  val curr_time_stamp = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH_mm").format(LocalDateTime.now)
  def main(args: Array[String]) {

    val inputPathConfig = args(0)
    val layerName = "STANDARDIZATION".toLowerCase()
    val fileName: String = "NA"
    val srcName: String = "NA"

    val standardizationConfigData = CommonUtils.parseConfigFile(inputPathConfig, fileName, srcName, layerName = layerName)
      .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })

    val bucketName = GlobalVariables.getRootPath
    val matchDimPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.output.path")).head._2(0)
    val matchClientApprovedPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.client.approved.path")).head._2(0)

    val matchDim = CommonUtils.readFromS3Parquet(bucketName + matchDimPath + "/*", "true")
    val matchOutputColumns = matchDim.columns

    //val inutDf = CommonUtils.readFromCsvFile(bucketName + matchClientApprovedPath, "true", "false")
    val inutDf = sparkSession.read.option("header", "true").option("inferSchema", "false").option("ignoreLeadingWhiteSpace", "true").
      option("ignoreTrailingWhiteSpace", "true").option("escape", "\"").option("quoteAll", true).option("quote", "\'").option("multiLine", true).
      option("nullValue", "").option("nullValue", null).option("nullValue", "NULL").
      csv(bucketName + matchClientApprovedPath)

    inutDf.show(false)

    log.info("inutDf schema ::::::::: " + inutDf.schema)
    var matchMergerDf = inutDf.filter(col("AI_MERGE_ACTION") !== 1).select(matchOutputColumns.head, matchOutputColumns.tail: _*)

    matchMergerDf = matchMergerDf.withColumn("AI_MERGE_ACTION_TMP", matchMergerDf.col("AI_MERGE_ACTION").cast(IntegerType))
      .drop("AI_MERGE_ACTION")
      .withColumnRenamed("AI_MERGE_ACTION_TMP", "AI_MERGE_ACTION")

    log.info("matchMergerDf schema ::::: " + matchMergerDf.schema)

    val newActionRecords = matchMergerDf.except(matchDim)

    CommonUtils.writeToS3Parquet(newActionRecords, bucketName + matchDimPath + "Match_Approved_" + curr_time_stamp, "true", "append")

  }

}