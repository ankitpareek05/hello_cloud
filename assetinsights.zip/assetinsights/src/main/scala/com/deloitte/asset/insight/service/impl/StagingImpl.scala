package com.deloitte.asset.insight.service.impl

import com.deloitte.asset.insight.services.Staging
import org.apache.spark.sql.DataFrame
import com.deloitte.asset.insight.utils._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.functions._
import scala.collection.Map
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.geocoding.api.GeocodingDriver

class StagingImpl extends Staging with Logging {

  val sparkSession = InitiateSparkContext.getSparkSession()
  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = InitiateSparkContext.getSqlContext()

  import sqlContext.implicits._

  /**
   * @todo Add Document comments
   */
  override def processSchemaStandarization(preProcessedDF: DataFrame, configData: Map[String, List[String]], layerName: String): DataFrame = {

    var standardDF = preProcessedDF
    log.info("Schema Standarization for Dataframe")

    val standarizationSchemaConfig = configData.get(layerName + "." + CommonConstants.STANDARD_SCHEMA).get
    // val outputPath =configData.get(CommonConstants.S3_OUTPUT_PATH_SCHEMA_STANDARDIZATION).get(0)

    log.info("Schema Standarization Started.." + standardDF.schema)
    standarizationSchemaConfig.map(elem =>
      {
        val value = elem.split(":")
        standardDF = standardDF.withColumnRenamed(value(0), value(1))
      })

    log.info("Schema Standarization Completed.." + standardDF.schema)
    //CommonUtils.writeToS3Parquet(standardDF, outputPath, "true", "overwrite")
    standardDF
  }

  /**
   * <b>Generic XREF Logic</b>
   * <p>
   * The Generic XREF logic is used to create the Cross
   * Reference Tables of the Party Model. Implementation from Service layer.
   * <p>
   * @return Nothing
   * @author  Deloitte
   * @see com.deloitte.asset.insight.utils.XRef.genericXRef}
   * @version 1.0
   * @since   2018-04-07
   */

  /*
   * XRef Table Logic
   * @Developer - Vishal Agrawal
   * @Developer - Ankit Pareek
   */

  override def enrichXrefGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {

    val layerName = GlobalVariables.getLayerName
    val expectedXref = inputConfigData.getOrElse((layerName + ".xref.tables.list"), List("NA")).map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!expectedXref(0).equalsIgnoreCase("na")) {
      expectedXref.map(xrefName => {
        val xrefNameLayer = layerName + "." + xrefName
        val xRefConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(xrefNameLayer))
        log.info("Running XREf for : " + xrefNameLayer)

        XRef.genericXRef(preProcessedDF, xrefNameLayer, xRefConfigData)
      })
    } else {
      log.info("No XREF List Available ")
    }
  }

  /*
   * Dimension Table Logic
   * @Developer - Vishal Agrawal
   */

  override def enrichDimensionsGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {
    val layerName = GlobalVariables.getLayerName
    val expectedDimensions = inputConfigData.getOrElse((layerName + ".dimension.tables.list"), List("NA")).map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!expectedDimensions(0).equalsIgnoreCase("na")) {
      expectedDimensions.map(dimName => {
        val dimNameLayer = layerName + "." + dimName
        log.info("Running Dimension for : " + dimNameLayer)
        val dimConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(dimNameLayer))

        dimName match {
          case "dimension.product"  => Dimensions.generateDimensionGroup1(preProcessedDF, dimNameLayer, dimConfigData)
          case "dimension.party"    => Dimensions.generateDimensionGroup1(preProcessedDF, dimNameLayer, dimConfigData)
          case "dimension.email"    => Dimensions.generateDimensionGroup2(preProcessedDF, dimNameLayer, dimConfigData)
          case "dimension.phone"    => Dimensions.generateDimensionGroup2(preProcessedDF, dimNameLayer, dimConfigData)
          case "dimension.url"      => Dimensions.generateDimensionGroup2(preProcessedDF, dimNameLayer, dimConfigData)
          case "dimension.address"  => Dimensions.generateDimensionGroup3(preProcessedDF, dimNameLayer, dimConfigData)
          case "dimension.address1" => Dimensions.generateDimensionGroup3(preProcessedDF, dimNameLayer, dimConfigData)
          case _                    => log.info("No match found for : " + dimNameLayer)
        }

      })
    } else {
      log.info("No DIM List Available ")
    }
  }

  def enrichDimensionsGeneric2(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {
    val layerName = GlobalVariables.getLayerName

    val expectedDimensions = inputConfigData.get(layerName + ".dimension.tables.list").get.map(_.trim().toLowerCase().replaceAll("_", "."))

    expectedDimensions.map(dimDetail => {

      val dimDetails = dimDetail.split(":")
      val dimName = dimDetails(0)
      val dimGroup = dimDetails(1)

      val dimNameLayer = layerName + "." + dimName

      log.info("Running Dimension for : " + dimNameLayer)

      val dimConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(dimNameLayer))

      dimGroup match {
        case "group1" => Dimensions.generateDimensionGroup1(preProcessedDF, dimNameLayer, dimConfigData)
        case "group2" => Dimensions.generateDimensionGroup2(preProcessedDF, dimNameLayer, dimConfigData)
        case "group3" => Dimensions.generateDimensionGroup3(preProcessedDF, dimNameLayer, dimConfigData)

        case _        => log.info("No group found for : " + dimName)
      }

    })

  }

  /*
   * Fact Table Logic
   * @Developer - Vishal Agrawal
   */

  override def enrichFactsGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {
    val layerName = GlobalVariables.getLayerName
    val expectedFacts = inputConfigData.getOrElse((layerName + ".fact.tables.list"), List("NA")).map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!expectedFacts(0).equalsIgnoreCase("na")) {
      expectedFacts.map(factName => {
        val factNameLayer = layerName + "." + factName
        log.info("Running Facts for : " + factNameLayer)
        val factConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(factNameLayer))

        Facts.generateFacts(preProcessedDF, factNameLayer, factConfigData)
      })
    } else {
      log.info("No Facts List Available ")
    }
  }

  /*
   * Relation Table Logic
   * @Developer - Vishal Agrawal
   */

  override def enrichRelationsGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {

    val layerName = GlobalVariables.getLayerName
    val expectedRelations = inputConfigData.getOrElse((layerName + ".relation.tables.list"), List("NA")).map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!expectedRelations(0).equalsIgnoreCase("na")) {
      expectedRelations.map(relationName => {
        val relationNameLayer = layerName + "." + relationName
        log.info("Running Relations for : " + relationNameLayer)
        val relationConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(relationNameLayer))

        Relations.generateRelations(preProcessedDF, relationNameLayer, relationConfigData)

      })
    } else {
      log.info("No Relation List Available ")
    }

  }

  override def enrichRelationsGeneric2(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {

    val layerName = "staging" // GlobalVariables.getLayerName
    val expectedRelations = inputConfigData.get(layerName + ".relation.tables.list").get.map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!expectedRelations(0).equalsIgnoreCase("na")) {
      expectedRelations.map(relationName => {
        val relationNameLayer = layerName + "." + relationName
        log.info("Running Relations for : " + relationNameLayer)
        val relationConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(relationNameLayer))

        Relations.generateRelations2(preProcessedDF, relationNameLayer, relationConfigData)

      })
    } else {
      log.info("No Relation List Available ")
    }

  }

  override def enrichRelationsGeneric3(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]]) {

    val layerName = "staging" // GlobalVariables.getLayerName
    val expectedRelations = inputConfigData.get(layerName + ".relation.tables.list").get.map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!expectedRelations(0).equalsIgnoreCase("na")) {
      expectedRelations.map(relationName => {
        val relationNameLayer = layerName + "." + relationName
        log.info("Running Relations for : " + relationNameLayer)
        val relationConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(relationNameLayer))

        Relations.generateRelations3(preProcessedDF, relationNameLayer, relationConfigData)

      })
    } else {
      log.info("No Relation List Available ")
    }

  }

  override def enrichHierarchy(inputConfigData: Map[String, List[String]]) {
    val layerName = GlobalVariables.getLayerName // layerName = staging

    val hierarchyLayerName = layerName + ".hierarchy"
    // hierarchyLayerName = staging.hierarchy

    val hierarchyConfigData = inputConfigData.filter(x => x._1.toLowerCase().startsWith(hierarchyLayerName))

    log.info("Hierarchy Config Data : " + hierarchyConfigData.foreach(println))

    Hierarchy.genericHierarchy(hierarchyConfigData, hierarchyLayerName)

  }

}