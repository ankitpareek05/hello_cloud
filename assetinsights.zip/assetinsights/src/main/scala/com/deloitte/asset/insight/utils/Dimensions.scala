package com.deloitte.asset.insight.utils

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.StringType
import org.apache.spark.storage.StorageLevel
import com.deloitte.asset.insight.geocoding.api.GeocodingDriver
import com.deloitte.asset.insight.service.impl.RuleProcessImpl

import org.apache.spark.sql.functions._
import com.deloitte.asset.insight.service.impl.RuleProcessImpl
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.rules.FieldStandardization
import scala.collection.Map
import java.sql.Timestamp

/**
 * @author Kanika & Sunny
 *
 */
object Dimensions extends Logging {
  import DataFrameOperation.implicits._
  val bucketName = GlobalVariables.getRootPath
  val debugFlag = GlobalVariables.getDebugFlag

  def generateDimensionGroup1(preProcessedDF: DataFrame, dimName: String, dimConfigData: Map[String, List[String]]) {

    val xRefDFPath = bucketName + dimConfigData.get(dimName + ".xref.path").get(0).trim() //.toLowerCase()
    val dimDFInputPath = bucketName + dimConfigData.get(dimName + ".input.path").get(0).trim() //.toLowerCase()
    val dimDFPath = bucketName + dimConfigData.get(dimName + ".output.path").get(0).trim() //.toLowerCase()

    val mainDataSelectedColumn = dimConfigData.get(dimName + ".main.selected.columns").get.toList.map(_.trim().toUpperCase())
    val xrefSelectedColumn = dimConfigData.get(dimName + ".xref.selected.column").get.toList.map(_.trim().toUpperCase())

    val tagValueCols = dimConfigData.get(dimName + ".xref.tag.value.column").get.toList.map(_.toUpperCase())
    val tagValueColName = dimConfigData.get(dimName + ".xref.tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())

    val xrefTYpe = dimConfigData.get(dimName + ".first.lookup").get(0).trim()

    val lookupColumns = dimConfigData.get(dimName + ".first.lookup.columns").get.toList.map(_.trim().toUpperCase())
    val mappingColumns = dimConfigData.get(dimName + ".mapping.column").get.toList.map(_.trim().toUpperCase())
    val additionalCols = dimConfigData.get(dimName + ".additional.columns").get.toList.map(_.trim().toUpperCase())
    val additionalcolNameLookup = dimConfigData.get(dimName + ".additional.column.name.lookup").getOrElse(List("NA"))
    val dimensionSchema = dimConfigData.get(dimName + ".schema").get.toList.map(_.trim().toUpperCase())
    val dimDeltaColumns = dimConfigData.get(dimName + ".except.column").get.toSeq.map(_.trim().toUpperCase())

    log.info("Dimension Group 1 Called : " + dimName)

    val srcIdValue = GlobalVariables.getSourceId.mkString.substring(0, 7)
    var xRefDF = CommonUtils.readFromS3Parquet(xRefDFPath, "true").select(xrefSelectedColumn.head, xrefSelectedColumn.tail: _*).filter(col("AI_SRC_ID").startsWith(srcIdValue)).na.fill(" ")
    xRefDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

    // Step 1 : Select the specific columns
    var standardDF = preProcessedDF.select(mainDataSelectedColumn.head, mainDataSelectedColumn.tail: _*).na.fill(" ")

    // Renaming the col to map with party dimension cols.
    //    mappingColumns.map(col => {
    //      val cols = col.split(":")
    //      standardDF = standardDF.withColumnRenamed(cols(0).trim(), cols(1).trim())
    //    })

    try {

      val fileExist = CommonUtils.isS3FileExists(dimDFInputPath.replace("*", ""))
      if (fileExist.equalsIgnoreCase("true")) {
        mappingColumns.map(col => {
          val cols = col.split(":")
          standardDF = standardDF.withColumnRenamed(cols(0).trim(), cols(1).trim())
        })
        var existingDimDF = CommonUtils.readFromS3Parquet(dimDFInputPath, "true")
        existingDimDF = existingDimDF.select(dimDeltaColumns.head, dimDeltaColumns.tail: _*)
        standardDF = standardDF.join(existingDimDF, dimDeltaColumns, "leftanti")
        mappingColumns.map(col => {
          val cols = col.split(":")
          standardDF = standardDF.withColumnRenamed(cols(1).trim(), cols(0).trim())

        })

      }
    } catch {
      case ex: Exception => {
        mappingColumns.map(col => {
          val cols = col.split(":")
          standardDF = standardDF.withColumnRenamed(cols(1).trim(), cols(0).trim())

        })
        log.info("Super Set of party schema is not available")
      }
    }

    //Adidng tag-value columns for lookup from XRef
    val tagValue = tagValueCols.map(cols => {
      log.info("tagValueCols :" + cols)
      val col = cols.split(":")
      standardDF = standardDF.withColumnRenamed(col(0).trim(), col(1).trim())
      col(1).trim()
    })

    standardDF = CommonUtils.createMeasureNameValue(standardDF, tagValueColName(0).trim(), tagValueColName(1).trim(), tagValue)

    var joinedDF = standardDF
    if (xrefTYpe.equalsIgnoreCase("partyXref")) {
      val joinColsSeq = lookupColumns.map(col => {
        val cols = col.split(":")
        standardDF = standardDF.withColumnRenamed(cols(0).trim(), cols(1).trim())
        cols(1).trim()
      }).toSeq

      // Step 3 : Left Outer join with XRef table
      joinedDF = standardDF.join(xRefDF, joinColsSeq, "LEFT_OUTER")

      // Step 4 : Rename column back to original names
      lookupColumns.map(col => {
        val cols = col.split(":")
        joinedDF = joinedDF.withColumnRenamed(cols(1).trim(), cols(0).trim())
      })
    }

    // Step 5 : Adding additional columns
    var additionalColNames = Array[String]()
    if (!additionalCols(0).equalsIgnoreCase("NA")) {
      additionalColNames = additionalCols.map(col => {
        val cols = col.split(":")
        log.info("Additional cols : " + col)
        joinedDF = joinedDF.withColumn(cols(0), lit(cols(1)))
        cols(0).trim()
      }).toArray
    } else if (!additionalcolNameLookup(0).equalsIgnoreCase("NA")) {
      val additionalColValueLookup = dimConfigData.get(dimName + ".additional.column.value.lookup").getOrElse(List("NA")).mkString(",")
      additionalcolNameLookup.map { col =>
        val colSplit = col.split(":")
        additionalColValueLookup.foreach(println)
        joinedDF = joinedDF.withColumn(colSplit(1), CommonUtils.addColumnBasedNewValue(joinedDF(colSplit(0)), lit(additionalColValueLookup)))
        joinedDF.showOrNoShow(debugFlag)
        joinedDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
      }

    }
    // Renaming the col to map with party dimension cols.
    mappingColumns.map(col => {
      val cols = col.split(":")
      joinedDF = joinedDF.withColumnRenamed(cols(0).trim(), cols(1).trim())
    })

    //    // Step 6 : Getting missing columns names
    //    val missingColumns = dimensionSchema diff (joinedDF.schema.fieldNames)
    //
    //    //Step 7 : Setting missing columns to blank
    //   missingColumns.map(col => {
    //    joinedDF = joinedDF.withColumn(col, lit(CommonConstants.BLANK_STRING).cast(StringType))
    //   })
    joinedDF.showOrNoShow(debugFlag)

    val fieldStandarization = new RuleProcessImpl
    var standardDF1 = fieldStandarization.processDimFieldStandardization(joinedDF, dimName, dimConfigData)
    standardDF1.showOrNoShow(debugFlag)
    // Step 8: Arranging columns in given sequence
    joinedDF = standardDF1.select(dimensionSchema.head, dimensionSchema.tail: _*)
    //joinedDF.show()

    // Step 9 : Writting final output into S3
    //joinedDF.show()

    /*
     * Adding Run timestamp and Inactive Flag in data.
     */
    val runTimeStamp = CommonUtils.getTimeStamp()._1
    joinedDF = joinedDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
    joinedDF.show()
    CommonUtils.writeToS3Parquet(joinedDF, dimDFPath, "true", "append")
  }

  def generateDimensionGroup2(preProcessedDF: DataFrame, dimTypeName: String, dimConfigData: Map[String, List[String]]) = {

    // val xRefDFPath = dimConfigData.get(dimTypeName + ".xref.party.path").get(0).trim()
    val dimOutputPath = bucketName + dimConfigData.get(dimTypeName + ".output.path").get(0).trim() //.toLowerCase()
    val dimInputPath = bucketName + dimConfigData.get(dimTypeName + ".input.path").get(0).trim() //.toLowerCase()
    val mainDataSelectedColumn = dimConfigData.get(dimTypeName + ".main.selected.columns").get.toList.map(_.trim().toUpperCase())
    //val xrefJoinCol = dimConfigData.get(dimTypeName + ".to.partyXref.join.columns").get(0).trim()
    val dimSchema = dimConfigData.get(dimTypeName + ".schema").get.toList.map(_.trim().toUpperCase())
    val mappingCols = dimConfigData.getOrElse(dimTypeName + ".mapping.column", List("FALSE")).map(_.trim().toUpperCase())
    //val dimFactSelectedColumn = relationConfigData.get(relationName + ".dimfact.selected.column").get.toList.map(_.trim().toUpperCase())

    val tagValue = dimConfigData.get(dimTypeName + ".tag.value.column").get.toList.map(_.toUpperCase())
    val tagValueColName = dimConfigData.get(dimTypeName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())

    val exceptCol = dimConfigData.get(dimTypeName + ".except.column").get
    val uniqIdentifier = dimConfigData.get(dimTypeName + ".autoincrement.column").get(0).trim().toUpperCase()
    val standadizePhoneAction = dimConfigData.getOrElse(dimTypeName + ".standardize.phone", List("FALSE"))(0).trim()
    log.info("Dimension Group 2 Called : " + dimTypeName)

    val dimName = CommonConstants.PHONE_DIM

    if (standadizePhoneAction.equals("FALSE")) {
      val tagValueCols = tagValue.map(elem => {
        val value = elem.split(":")
        value(0)
      }).toList

      var standardDF = preProcessedDF.select(mainDataSelectedColumn.head, mainDataSelectedColumn.tail: _*).na.fill(" ")

      if (!(mappingCols(0).equalsIgnoreCase("na"))) {
        mappingCols.map(col => {
          val cols = col.split(":")
          standardDF = standardDF.withColumnRenamed(cols(0).trim(), cols(1).trim())
        })
      }

      standardDF = CommonUtils.createMeasureNameValue(standardDF, tagValueColName(0), tagValueColName(1), tagValueCols) //.na.drop()
      standardDF = standardDF.filter(standardDF(tagValueColName(1)).isNotNull).filter(standardDF(tagValueColName(1)) !== "").filter(standardDF(tagValueColName(1)) !== " ")

      val fileExist = CommonUtils.isS3FileExists(dimInputPath.replace("*", ""))

      //Get or else
      /*    val standadizePhoneAction = dimConfigData.getOrElse(dimTypeName + ".standardize.phone", List("FALSE"))(0).trim()

	if (standadizePhoneAction.equals("TRUE")) {

      // call standardization logic
      val standardizeRuleName = "standardize.phone"

      val ruleStandarization = new RuleProcessImpl
      //val phoneFinalDf = ruleStandarization.processStandardizationGeneric(standardDF, dimTypeName, standardizeRuleName, dimConfigData)
    }
    else {*/

      standardDF = standardDF.select(exceptCol.head, exceptCol.tail: _*).na.fill(" ").distinct()

      if (fileExist.equalsIgnoreCase("TRUE")) {
        var previousDimDF = CommonUtils.readFromS3Parquet(dimInputPath, "true").na.fill(" ")
        var diffCol = dimSchema diff previousDimDF.columns.toList
        diffCol.map(x => {
          previousDimDF = previousDimDF.withColumn(x, lit(" "))
        })
        //previousDimDF.select("email")//SchemaConstants.EMAIL)
        previousDimDF = previousDimDF.select(exceptCol.head, exceptCol.tail: _*)
        standardDF = standardDF.except(previousDimDF)
      }

      standardDF = CommonUtils.addAutoIncremetColumn(standardDF, uniqIdentifier) //.persist()
      standardDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
      val fieldStandarization = new RuleProcessImpl
      standardDF = fieldStandarization.processDimFieldStandardization(standardDF, dimTypeName, dimConfigData)
      standardDF.showOrNoShow(debugFlag)
      if (dimTypeName == dimName) {
        var COUNTRY_CODE = CommonConstants.PHONE_DIM_COUNTRY_CODE
        var EXTENSION = CommonConstants.PHONE_DIM_EXTENSION
        var NATIONAL_NUMBER = CommonConstants.PHONE_DIM_NATIONAL_NUMBER
        var QUALITY_RATING = CommonConstants.PHONE_DIM_QUALITY_RATING

        standardDF = standardDF.withColumn(COUNTRY_CODE, lit("")).withColumn(EXTENSION, lit("")).withColumn(NATIONAL_NUMBER, lit("")).withColumn(QUALITY_RATING, lit("0"))
      }
      standardDF = standardDF.select(dimSchema.head, dimSchema.tail: _*)

      //	}

      //    standardDF.show(false)

      /*
     * Adding Run timestamp and Inactive Flag in data.
     */
      val runTimeStamp = CommonUtils.getTimeStamp()._1
      if (standardDF != null && !standardDF.head(1).isEmpty) {
        standardDF = standardDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
        CommonUtils.writeToS3Parquet(standardDF, dimOutputPath, "true", "append")
      } else {
        log.info("No records added for phone dimension")
      }
    } else {
      val fieldStandarization = new RuleProcessImpl
      var standardDF = CommonUtils.readFromS3Parquet(dimInputPath, "true")
      fieldStandarization.processStandardizationGeneric(standardDF, dimTypeName, "standardize.phone", dimConfigData)
      log.info("====> Completed")
    }

  }

  def generateDimensionGroup3(preProcessedDF: DataFrame, dimTypeName: String, dimConfigData: Map[String, List[String]]) = {

    val timestamp = CommonUtils.getTimeStamp()._1
    var dimOutputPath = bucketName + dimConfigData.get(dimTypeName + ".output.path").get(0).trim() //.toLowerCase()
    val autoIncrColName = dimConfigData.get(dimTypeName + ".autoincrement.column").get(0).trim().toUpperCase()

    val standadizeAddressAction = dimConfigData.getOrElse(dimTypeName + ".standardize.address", List("FALSE"))(0).trim()

    if (standadizeAddressAction.equals("FALSE")) {

      val mappingCols = dimConfigData.get(dimTypeName + ".mapping.column").get.toList.map(_.trim().toUpperCase())
      val exceptCols = dimConfigData.get(dimTypeName + ".except.column").get.toList.map(_.trim().toUpperCase())
      val concatOutputColumn = dimConfigData.get(dimTypeName + ".concat.output.columns").get(0).trim()
      val address_dim_schema = dimConfigData.get(dimTypeName + ".schema").get.map(_.toLowerCase().trim()).toArray

      val target_o = concatOutputColumn.split(":")(0).toLowerCase()
      val target_c = concatOutputColumn.split(":")(1).toLowerCase()

      val selectedCol = mappingCols.map(_.split(":")(0))

      val inputDFWithSpaces = preProcessedDF.select(selectedCol.head, selectedCol.tail: _*).na.fill(" ").distinct()

      var colsForConcat = exceptCols.map(colName => col(colName))

      /*
     * Removing spaces from input addresses before concating
     */
      var inputDF = inputDFWithSpaces.select(inputDFWithSpaces.columns.map {
        x =>
          trim(col(x)).alias(x)
      }: _*)

      inputDF = inputDF.withColumn(target_o, trim(concat_ws(" ", colsForConcat: _*)))
      inputDF = inputDF.withColumn(target_c, trim(concat_ws(" ", colsForConcat: _*)))

      var newAddressInputDF: DataFrame = null

      val fileExist = CommonUtils.isS3FileExists(dimOutputPath.replace("*", ""))

      if (fileExist.equals("FALSE")) {
        newAddressInputDF = inputDF
      } else {
        var previousDimDF = CommonUtils.readFromS3Parquet(dimOutputPath, "true")

        var inputDFForCompare = inputDF.select(target_o).distinct

        var newAddressesDF = inputDFForCompare.except(previousDimDF.select(target_o))
        newAddressInputDF = inputDF.join(newAddressesDF, inputDF(target_o) === newAddressesDF(target_o)).drop(newAddressesDF(target_o))
      }

      for (mappingCol <- mappingCols) {
        val colDetails = mappingCol.split(":")
        var srcCol = colDetails(0).trim()
        var destCol = colDetails(1).trim()
        if (destCol.contains("|")) {
          var destCols = destCol.split("|")

          for (i <- 0 until destCols.size) {
            newAddressInputDF = newAddressInputDF.withColumn(destCols(i).toLowerCase(), split(col(srcCol), "|")(i))
          }

          newAddressInputDF = newAddressInputDF.drop(srcCol)

        } else
          newAddressInputDF = newAddressInputDF.withColumnRenamed(srcCol, destCol.toLowerCase())
      }

      var blankCols = address_dim_schema diff newAddressInputDF.columns

      for (blankCol <- blankCols) {
        newAddressInputDF = newAddressInputDF.withColumn(blankCol, lit(" "))
      }

      // Adding quality rating as 0 for not standardized addresses
      newAddressInputDF = newAddressInputDF.withColumn(CommonConstants.API_QUALITY_RATING, lit("1"))

      newAddressInputDF = CommonUtils.addAutoIncremetColumn(newAddressInputDF, autoIncrColName)
      newAddressInputDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

      var finalAddDimColms = autoIncrColName +: address_dim_schema
      newAddressInputDF = newAddressInputDF.select(finalAddDimColms.head, finalAddDimColms.tail: _*)
        /* .withColumn("timestamp", timestamp)*/
        .withColumn(CommonConstants.SRC_TIMESTAMP, lit(timestamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit("0"))

      if (newAddressInputDF != null && !newAddressInputDF.head(1).isEmpty) {
        newAddressInputDF.showOrNoShow(debugFlag)
        val fileName = GlobalVariables.getFileName
        val sourceName = GlobalVariables.getSourceName
        dimOutputPath = dimOutputPath.replaceAllLiterally("*", "") + sourceName.toLowerCase() + "_" + fileName.toLowerCase()
        CommonUtils.writeToS3Parquet(newAddressInputDF, dimOutputPath, "true", "append")
      } else {
        log.info("No records to be inserted while API OFF")
      }
    } else {
      // Calling Address standardization

      val ruleStandarization = new RuleProcessImpl
      ruleStandarization.processStandardizationGeneric(preProcessedDF, dimTypeName, "standardize.address", dimConfigData)

    }

    log.info("Dimension Group3 is completed !!!")
  }

}