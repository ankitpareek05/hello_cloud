package com.deloitte.asset.insight.utils

import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.lit
import com.deloitte.asset.insight.services.Logging

class EndDatingUtility extends Logging with Serializable {
  def getSourcePartyIds(filePath: String): Dataset[Row] = {
    var sourceIdDf = CommonUtils.readFromCsvFile(filePath, "true", "true")
    var col = sourceIdDf.columns
    sourceIdDf = sourceIdDf.withColumnRenamed(col(0), "SRC_PARTY_ID")
    return sourceIdDf
  }
  
  def getPartyIdsFromCSV(filePath: String): Dataset[Row] = {
    var aiPartyIdDF = CommonUtils.readFromCsvFile(filePath, "true", "true")
    var col = aiPartyIdDF.columns
    aiPartyIdDF = aiPartyIdDF.withColumnRenamed(col(0), "AI_PARTY_ID")
    return aiPartyIdDF
  }
  
  def getPartyIdsFromSourceIds(sourcePartyIds: Dataset[Row], dimPartyTablePath: String): Dataset[Row] ={
    val dimPartyDataset = CommonUtils.readFromS3Parquet(dimPartyTablePath, "true")
    return dimPartyDataset.join(sourcePartyIds, "SRC_PARTY_ID").select("AI_PARTY_ID")
  }
  
  def getRecordsPostMerge(aiPartyIdDataset: Dataset[Row], matchOutputTablePath: String):Dataset[Row] = {
    val matchOutputTable = CommonUtils.readFromS3Parquet(matchOutputTablePath, "true").select("AI_PARTY_ID")
    val nonMergedPartyIds = aiPartyIdDataset.except(matchOutputTable)
    return nonMergedPartyIds
  }
  
  def inactivateRecords(inactiveEligibleRecords: Dataset[Row], tablePath: String, folderDate: String, inactivationDate: String) {
    val tableData = CommonUtils.readFromS3Parquet(tablePath, "true")
    if(tablePath.contains("ai_rel_party_party")){
      val relPartyInactivatedRecords = tableData.join(inactiveEligibleRecords, inactiveEligibleRecords.col("AI_PARTY_ID").equalTo(tableData.col("AI_REL_PARTY_ID")), "inner")
                .drop(inactiveEligibleRecords.col("AI_PARTY_ID"))
                .withColumn("INACTIVE_FLAG", lit(1))
                .withColumn("AI_EFFECTIVE_DATE", lit(inactivationDate))
                .withColumn("AI_KNOWLEDGE_DATE",lit(inactivationDate))
                .withColumn("AI_RUN_DATETIME", lit(inactivationDate))
      val pathForInactivatedRecords = tablePath.replace("*", "") + "/rel_party_id_inactivatedRecords_" + folderDate + "/"
      CommonUtils.writeToS3Parquet(relPartyInactivatedRecords, pathForInactivatedRecords, "true", "append")
      log.info("----- Write Complete on the REL PARTY ID side for '" + tablePath + "' -----")
    } 
    val inactivatedRecords = tableData.join(inactiveEligibleRecords, Seq("AI_PARTY_ID"), "inner")
                .withColumn("INACTIVE_FLAG", lit(1))
                .withColumn("AI_EFFECTIVE_DATE", lit(inactivationDate))
                .withColumn("AI_KNOWLEDGE_DATE",lit(inactivationDate))
                .withColumn("AI_RUN_DATETIME", lit(inactivationDate))
    
    inactivatedRecords.printSchema()
    val pathForInactivatedRecords = tablePath.replace("*", "") + "/inactivatedRecords_" + folderDate + "/"
    CommonUtils.writeToS3Parquet(inactivatedRecords, pathForInactivatedRecords, "true", "append")
    log.info("----- Write Complete for '" + tablePath + "' -----")
  }
  
  def getRecordsForEndDating(): Dataset[Row] = {
    return null
  }
}