package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.services.Standardization
import com.deloitte.asset.insight.service.impl.StandardizationImpl
import com.deloitte.asset.insight.services.Logging

object StandardizationMain extends Logging with Serializable {
  def main(args: Array[String]) = {

    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    val sqlContext = InitiateSparkContext.getSqlContext()

    /*    val inputPathConfig = "src\\main\\resources\\MMRELATIONS.csv"
    val layerName = "STANDARDIZATION".toLowerCase()*/
    val fileName: String = "NA"
    val srcName: String = "NA"

    val inputPathConfig = args(0)
    val layerName = args(1)

    if (args.length == 3) {
      GlobalVariables.setDebugFlag(args(2))
    } else {
      log.info("Debug Level is set to FALSE")
      GlobalVariables.setDebugFlag("false")
    }

    log.info(" ------- Into Standardization -------\n")
    val standardizationConfigData = CommonUtils.parseConfigFile(inputPathConfig, fileName, srcName, layerName = layerName)
      .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })

    val standardization: Standardization = new StandardizationImpl()

    log.info("\n STARTING MATCH DATA PREPARATION \n")
    val matchDataPrepDf = standardization.match_data_preparation(standardizationConfigData)
    log.info("\n MATCH DATA PREPARATION COMPLETED \n")

    log.info("\n STARTING MATCHING ON RULES \n")
    standardization.match_data(matchDataPrepDf, standardizationConfigData)
    log.info("\n MATCHING COMPLETED \n")

    log.info("\n STORING DATA IN PIVOT FORMAT \n")
    standardization.matchDataFactSchema(standardizationConfigData)

    log.info("\n JOB COMPLETED SUCESSFULLY \n")

  }
}