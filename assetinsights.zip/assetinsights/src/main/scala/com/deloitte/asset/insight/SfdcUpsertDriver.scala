package com.deloitte.asset.insight

import com.deloitte.asset.insight.operations.SfdcBulkUpdateHelper

object SfdcUpsertDriver {
  /*
   * Argument Details:
   * args(0): SFDC Object Name
   * args(1): SFDC User Name
   * args(2): Password + Security Token
   * args(3): SFDC Login URL
   * args(4): S3 Bucket Name
   * args(5): S3 File Location within Bucket
   */
  def main(args: Array[String]) {
    val bulkLoad = new SfdcBulkUpdateHelper(args(0), args(1), 
        args(2), args(3), args(4), args(5))
    /*val bulkLoad = new BulkExample(args(0), "assetinsight@nuveen.com.comdev", 
        "Deloitte@143V1hPyoQXQqCasW8WrqA0MRDF", "https://test.salesforce.com/services/Soap/u/36.0", args(1), args(2))*/
    
    bulkLoad.runSample(args(2) + "/")
  }
}