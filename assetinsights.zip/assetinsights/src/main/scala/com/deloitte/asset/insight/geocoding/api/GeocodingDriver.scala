package com.deloitte.asset.insight.geocoding.api

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions._

import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils._
import java.sql.Timestamp

object GeocodingDriver extends Logging {

  import DataFrameOperation.implicits._

  case class ConcatAddressDF(formatted_address_o: String)

  var sparkSession = InitiateSparkContext.getSparkSession()

  def main(args: Array[String]) = {

  }

  /**
   * @param concatenatedAddress
   * @param target_o
   * @param target_c
   * @param callToGoogleAPIActive
   * @param minQualityThreshold
   * @param autoSeqColName
   * @param addressDimTablePath
   * @param addStdLoggingPath
   * @param gooleApiURI
   * @param googleApiKey
   * @param googleApiDelay
   * @return
   */
  def standardizeAddresses(concatenatedAddress: String, target_o: String, target_c: String, callToGoogleAPIActive: Boolean, minQualityThreshold: Int, autoSeqColName: String, addressDimTablePath: String, addStdLoggingPath: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, street_number_col: String, city_col: String, state_col: String,postal_code_col:String, address_dim_schema: Array[String], address_logging_schema: Array[String]): DataFrame = {
    return standardizeAddresses(Array(concatenatedAddress), target_o, target_c, callToGoogleAPIActive, minQualityThreshold, autoSeqColName, addressDimTablePath, addStdLoggingPath, gooleApiURI, googleApiKey, googleApiDelay, street_number_col, city_col, state_col,postal_code_col, address_dim_schema, address_logging_schema)
  }

  /**
   * @param concatenatedAddresses
   * @param target_o
   * @param target_c
   * @param callToGoogleAPIActive
   * @param minQualityThreshold
   * @param autoSeqColName
   * @param addressDimTablePath
   * @param addStdLoggingPath
   * @param gooleApiURI
   * @param googleApiKey
   * @param googleApiDelay
   * @return
   */
  def standardizeAddresses(concatenatedAddresses: Array[String], target_o: String, target_c: String, callToGoogleAPIActive: Boolean, minQualityThreshold: Int, autoSeqColName: String, addressDimTablePath: String, addStdLoggingPath: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, street_number_col: String, city_col: String, state_col: String, postal_code_col:String,address_dim_schema: Array[String], address_logging_schema: Array[String]): DataFrame = {

    var concatAddressesForDF = concatenatedAddresses.map(concatAddress => {
      ConcatAddressDF(concatAddress)
    })

    var concatAddressesDF = sparkSession.createDataFrame(concatAddressesForDF)

    return standardizeAddresses(concatAddressesDF, target_o, target_c, callToGoogleAPIActive, minQualityThreshold, autoSeqColName, addressDimTablePath, addStdLoggingPath, gooleApiURI, googleApiKey, googleApiDelay, street_number_col, city_col, state_col,postal_code_col, address_dim_schema, address_logging_schema)
  }

  /**
   * @param inputAddressesDF
   * @param target_o
   * @param target_c
   * @param callToGoogleAPIActive
   * @param minQualityThreshold
   * @param autoSeqColName
   * @param addressDimTablePath
   * @param gooleApiURI
   * @param googleApiKey
   * @param googleApiDelay
   * @return
   */
  def standardizeAddresses(inputAddresses: DataFrame, target_o: String, target_c: String, callToGoogleAPIActive: Boolean, minQualityThreshold: Int, autoSeqColName: String, addressDimTablePath: String, addStdLoggingPath: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, street_number_col: String, city_col: String, state_col: String,postal_code_col:String, address_dim_schema: Array[String], address_logging_schema: Array[String]): DataFrame =
    {

      val timestamp = CommonUtils.getTimeStamp()._1

      val invalid_chars = CommonConstants.INVALID_CHARS

      inputAddresses.persist(StorageLevel.MEMORY_AND_DISK_SER)

      val inputAddressesDF = inputAddresses.select(target_o).distinct  // foramated_o only

      var addressDimdf: DataFrame = null
      var addressDimFilter: DataFrame = null

      val isDimTableExist = CommonUtils.isS3FileExists(addressDimTablePath.replace("*",""))

      if (isDimTableExist.trim().equalsIgnoreCase("True")) {
        addressDimdf = CommonUtils.readFromS3Parquet(addressDimTablePath, "true")
        addressDimFilter = addressDimdf.filter(addressDimdf(CommonConstants.API_QUALITY_RATING) === 0)
        addressDimdf.persist(StorageLevel.MEMORY_AND_DISK)
      }

      val googleAPIQualityRating = GlobalVariables.getGoogleAPIQualityRating
      val debugFlag = GlobalVariables.getDebugFlag

      val addDimWithLoggingSchema = autoSeqColName +: CommonConstants.GOOGLE_API_DF_SCHEMA :+ CommonConstants.API_QUALITY_RATING
      val address_std_logging_cols = autoSeqColName +: address_logging_schema
      val addressDimSchema = autoSeqColName +: address_dim_schema

      var dimensionDf = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var checkedBefore_o_withHighRating = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var googleApiRetriedOkDF: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var RetriedAddressPartialMatch: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var RetriedAddressesInvalidKey: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var RetriedAddressesLimitExceeded: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var checkedBefore_c: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var unionDf: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var finalAddNotMeetingStdCriteria: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var retriedAddressesNotMeetingStdCriteria: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var loggingDf = CommonUtils.createEmptyDF(address_std_logging_cols)
      var checkedBefore_o_low_rating_matching_c: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var new_addresses_matching_c: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)

      var googleAPIDF = CommonUtils.createEmptyDF(CommonConstants.GOOGLE_API_DF_SCHEMA)
      var googleApiNewOkDF = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var newAddressPartialMatch = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var googleApiRetriedZeroRecordsDF = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var googleApiNewZeroRecordsDF = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var newAddressesInvalidKey = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var newAddressesLimitExceed: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var newAddressDF: DataFrame = CommonUtils.createEmptyDF(addDimWithLoggingSchema)
      var checkedBefore_o_low_rating: DataFrame = null
      var googleApiDFForRetriedAddress: DataFrame = null
      var pre_checkedBefore_c: DataFrame = null
      var retriedAddressesMeetingStdCriteria: DataFrame = null
      val sql = "select * from retried_addresses where ("+street_number_col+" is null or trim("+street_number_col+") = '') and "+
                      "(("+city_col+" is null or trim("+city_col+") = '') or "+
                      "("+state_col+" is null or trim("+state_col+") = '') or "+
                      "("+postal_code_col+" is null or trim("+postal_code_col+") = ''))"
                      
      val sql2 = "select * from new_addresses where ("+street_number_col+" is null or trim("+street_number_col+") = '') and "+
                      "(("+city_col+" is null or trim("+city_col+") = '') or "+
                      "("+state_col+" is null or trim("+state_col+") = '') or "+
                      "("+postal_code_col+" is null or trim("+postal_code_col+") = ''))"
      log.info("sql......."+ sql)

      //Checking if input address is already existing in formatted_address_o column of Address Dimension
      var checkedBefore_o = AddressValidation.validateAddressInAI(inputAddressesDF, addressDimdf, target_o, target_o, autoSeqColName, address_dim_schema).distinct

      if (callToGoogleAPIActive) {
        log.info("Google API Flag is active")

        if (!checkedBefore_o.head(1).isEmpty) {
          log.info("Retrying Matched Addresses with _o........")
          // Filtering the addresses which needs to be reformatted with Google API as they have quality_rating < threshold
          val checkedBefore_o_low_rating_full = checkedBefore_o.filter(checkedBefore_o(CommonConstants.API_QUALITY_RATING) < minQualityThreshold)

          if (addressDimFilter != null && !(addressDimFilter.head(1).isEmpty) && !(checkedBefore_o_low_rating_full.head(1).isEmpty)) {
            checkedBefore_o_low_rating = checkedBefore_o_low_rating_full.select(target_o).except(addressDimFilter.select(target_o))

            checkedBefore_o_low_rating = checkedBefore_o_low_rating_full.join(checkedBefore_o_low_rating, checkedBefore_o_low_rating_full(target_o) === checkedBefore_o_low_rating(target_o)).drop(checkedBefore_o_low_rating(target_o))
          } else {
            checkedBefore_o_low_rating = checkedBefore_o_low_rating_full
          }

          val checkedBefore_o_low_rating_selected = checkedBefore_o_low_rating.select(autoSeqColName, target_o)
          checkedBefore_o_low_rating_matching_c = AddressValidation.validateAddressInAI(checkedBefore_o_low_rating_selected, addressDimdf.drop(autoSeqColName), target_o, target_c, autoSeqColName, address_dim_schema).distinct.filter(col(CommonConstants.API_QUALITY_RATING) >= minQualityThreshold)
            .select(addressDimSchema.head, addressDimSchema.tail: _*)
          

          if (addressDimFilter != null && !(addressDimFilter.head(1).isEmpty)) {
            val address_with_partial_match = addressDimFilter.drop(autoSeqColName)
            val checkedBefore_c_partial_match = checkedBefore_o_low_rating_selected.join(address_with_partial_match, checkedBefore_o_low_rating_selected(target_o) === address_with_partial_match(target_c)).drop(address_with_partial_match(target_o))
              .select(addressDimSchema.head, addressDimSchema.tail: _*)
            checkedBefore_o_low_rating_matching_c = checkedBefore_o_low_rating_matching_c.union(checkedBefore_c_partial_match)
          }

          checkedBefore_o_low_rating_matching_c = checkedBefore_o_low_rating_matching_c
            .withColumn(CommonConstants.API_STATUS, lit("AI-INSERT"))
            .withColumn(CommonConstants.API_ERROR_MESSAGE, lit(""))
            .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

            
          log.info("Retrying addresses matching c............")
          checkedBefore_o_low_rating_matching_c.showOrNoShow(debugFlag)
          checkedBefore_o_low_rating = checkedBefore_o_low_rating.join(checkedBefore_o_low_rating_matching_c, Seq(autoSeqColName), "left_anti")
          log.info("Retrying addresses not matching c........")
          checkedBefore_o_low_rating.showOrNoShow(debugFlag)

          if (!checkedBefore_o_low_rating.head(1).isEmpty) {

            checkedBefore_o_low_rating = checkedBefore_o_low_rating.join(inputAddresses, inputAddresses(target_o) === checkedBefore_o_low_rating(target_o)).drop(inputAddresses(target_o)).distinct()

            checkedBefore_o_low_rating.registerTempTable("retried_addresses")
            
            retriedAddressesNotMeetingStdCriteria = sqlContext.sql(sql)

            retriedAddressesMeetingStdCriteria = checkedBefore_o_low_rating.select(target_o, autoSeqColName).except(retriedAddressesNotMeetingStdCriteria.select(target_o, autoSeqColName))

            retriedAddressesNotMeetingStdCriteria = retriedAddressesNotMeetingStdCriteria.select(target_o, autoSeqColName)
              .withColumn(CommonConstants.API_QUALITY_RATING, lit("-1"))
              .withColumn(target_c, retriedAddressesNotMeetingStdCriteria(target_o))
              .withColumn(CommonConstants.API_STATUS, lit(CommonConstants.API_WARNING_2))
              .withColumn(CommonConstants.API_ERROR_MESSAGE, concat_ws(" ", lit("<"), col(target_o), lit("> is not standardized because one of the mandatory fields are empty.")))

            var blankCols = CommonConstants.GOOGLE_API_DF_SCHEMA diff retriedAddressesNotMeetingStdCriteria.columns

            for (blankCol <- blankCols) {
              // Adding blank values to other address components of Address Dimesion
              retriedAddressesNotMeetingStdCriteria = retriedAddressesNotMeetingStdCriteria.withColumn(blankCol, lit(" "))
            }

            retriedAddressesNotMeetingStdCriteria = retriedAddressesNotMeetingStdCriteria.select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

            log.info("Addresses not meeting standardization requirements")
            retriedAddressesNotMeetingStdCriteria.showOrNoShow(debugFlag)

            log.info("Addresses meeting standardization requirements")
            retriedAddressesMeetingStdCriteria.showOrNoShow(debugFlag)

            if (retriedAddressesMeetingStdCriteria != null && !retriedAddressesMeetingStdCriteria.head(1).isEmpty) {
              // Calling Google API for existing address having quality_rating < threshold
              retriedAddressesMeetingStdCriteria.persist(StorageLevel.MEMORY_AND_DISK_SER)
              googleApiDFForRetriedAddress = AddressValidation.validateAddressWithGoogleApi(retriedAddressesMeetingStdCriteria, gooleApiURI, googleApiKey, googleApiDelay, invalid_chars)
              googleApiDFForRetriedAddress.persist(StorageLevel.MEMORY_AND_DISK_SER)

              //Filtering standardized addresses with OK status
              googleApiRetriedOkDF = googleApiDFForRetriedAddress.filter(googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "OK" && googleApiDFForRetriedAddress(CommonConstants.PARTIAL_MATCH) === "false")
              // Adding quality rating as 1 for standardized addresses
              googleApiRetriedOkDF = googleApiRetriedOkDF.withColumn(CommonConstants.API_QUALITY_RATING, lit(googleAPIQualityRating))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              RetriedAddressPartialMatch = googleApiDFForRetriedAddress.filter(googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "OK" && googleApiDFForRetriedAddress(CommonConstants.PARTIAL_MATCH) === "true")
              RetriedAddressPartialMatch = RetriedAddressPartialMatch.withColumn(CommonConstants.API_QUALITY_RATING, lit("0"))
                                                                      .withColumn(CommonConstants.API_ERROR_MESSAGE, lit("PARTIAL MATCH"))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)
              /*
           * Quality_rating values
           * Addresses for which we send valid requests but API gives error - -1
           * Addresses for which we haev issue in our requests like invalid key - 0
           */

              googleApiRetriedZeroRecordsDF = googleApiDFForRetriedAddress
                .filter(!(googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "OK"
                  || googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "REQUEST_DENIED"
                  || googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "OVER_QUERY_LIMIT"))
              googleApiRetriedZeroRecordsDF = googleApiRetriedZeroRecordsDF.withColumn(CommonConstants.API_QUALITY_RATING, lit("-2")).withColumn(target_c, googleApiRetriedZeroRecordsDF(target_o))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              // Filtering standardized addresses with not OK status
              RetriedAddressesInvalidKey = googleApiDFForRetriedAddress
                .filter(googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "REQUEST_DENIED")
              RetriedAddressesInvalidKey = RetriedAddressesInvalidKey.withColumn(CommonConstants.API_QUALITY_RATING, lit("-3")).withColumn(target_c, RetriedAddressesInvalidKey(target_o))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              RetriedAddressesLimitExceeded = googleApiDFForRetriedAddress.filter(googleApiDFForRetriedAddress(CommonConstants.API_STATUS) === "OVER_QUERY_LIMIT")
              RetriedAddressesLimitExceeded = RetriedAddressesLimitExceeded.withColumn(CommonConstants.API_QUALITY_RATING, lit("-4")).withColumn(target_c, RetriedAddressesLimitExceeded(target_o))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)
            }
          }
        }

        val match_1 = checkedBefore_o.select(target_o)

        newAddressDF = inputAddressesDF.except(match_1).distinct()

        if (!newAddressDF.head(1).isEmpty) {

          log.info("Checking new addresses with c..........")
          new_addresses_matching_c = AddressValidation.validateAddressInAI(newAddressDF, addressDimdf, target_o, target_c, autoSeqColName, address_dim_schema).distinct.filter(col(CommonConstants.API_QUALITY_RATING) >= minQualityThreshold)
            .select(address_dim_schema.head, address_dim_schema.tail: _*)

          if (addressDimFilter != null && !(addressDimFilter.head(1).isEmpty)) {
            val address_with_partial_match = addressDimFilter.drop(autoSeqColName)
            val new_addresess_c_partial_match = newAddressDF.join(address_with_partial_match, newAddressDF(target_o) === address_with_partial_match(target_c)).drop(address_with_partial_match(target_o))
              .select(address_dim_schema.head, address_dim_schema.tail: _*)
            new_addresses_matching_c = new_addresses_matching_c.union(new_addresess_c_partial_match)
          }

          new_addresses_matching_c = new_addresses_matching_c
            .withColumn(CommonConstants.API_STATUS, lit("AI-INSERT"))
            .withColumn(CommonConstants.API_ERROR_MESSAGE, lit(""))

          new_addresses_matching_c = CommonUtils.addAutoIncremetColumn(new_addresses_matching_c, autoSeqColName)
          new_addresses_matching_c.persist(StorageLevel.MEMORY_AND_DISK_SER)
          new_addresses_matching_c = new_addresses_matching_c.select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

          log.info("New addresses matching c............")
          new_addresses_matching_c.showOrNoShow(debugFlag)
          
          newAddressDF = newAddressDF.join(new_addresses_matching_c, Seq(target_o), "left_anti")
          log.info("Remaining new addresses after matching c........")
          
          newAddressDF.showOrNoShow(debugFlag)

          if (!newAddressDF.head(1).isEmpty) {

            log.info("Running for new address................")
            newAddressDF = newAddressDF.join(inputAddresses, inputAddresses(target_o) === newAddressDF(target_o)).drop(inputAddresses(target_o)).distinct()

            newAddressDF.registerTempTable("new_addresses")
            
            var newAddressesNotMeetingStdCriteria = sqlContext.sql(sql2)
                
            log.info("Addresses not meeting standardization requirements")
            newAddressesNotMeetingStdCriteria.showOrNoShow(debugFlag)

            val newAddressesMeetingStdCriteria = newAddressDF.except(newAddressesNotMeetingStdCriteria)

            log.info("Addresses meeting standardization requirements")
            newAddressesMeetingStdCriteria.showOrNoShow(debugFlag)

            if (!newAddressesNotMeetingStdCriteria.head(1).isEmpty) {

              val addressWithOnlyTarget_o = newAddressesNotMeetingStdCriteria.select(target_o)

              finalAddNotMeetingStdCriteria = addressWithOnlyTarget_o.withColumn(target_c, col(target_o))

              // Adding the status for logging purpose
              finalAddNotMeetingStdCriteria = finalAddNotMeetingStdCriteria.withColumn(CommonConstants.API_STATUS, lit(CommonConstants.API_WARNING_2))

              // Adding the error message for logging purpose
              finalAddNotMeetingStdCriteria = finalAddNotMeetingStdCriteria.withColumn(CommonConstants.API_ERROR_MESSAGE, concat_ws(" ", lit("<"), col(target_o), lit("> is not standardized because one of the mandatory fields are empty.")))

              // Adding ai_address_id for new addresses
              finalAddNotMeetingStdCriteria = CommonUtils.addAutoIncremetColumn(finalAddNotMeetingStdCriteria, autoSeqColName)
              finalAddNotMeetingStdCriteria.persist(StorageLevel.MEMORY_AND_DISK_SER)
              var blankCols = CommonConstants.GOOGLE_API_DF_SCHEMA diff finalAddNotMeetingStdCriteria.columns

              for (blankCol <- blankCols) {
                // Adding blank values to other address components of Address Dimesion
                finalAddNotMeetingStdCriteria = finalAddNotMeetingStdCriteria.withColumn(blankCol, lit(" "))
              }

              // Adding quality rating as 0 for not standardized addresses
              finalAddNotMeetingStdCriteria = finalAddNotMeetingStdCriteria.withColumn(CommonConstants.API_QUALITY_RATING, lit("-1"))
              finalAddNotMeetingStdCriteria = finalAddNotMeetingStdCriteria.select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

            }

            log.info("newAddressesMeetingStdCriteria count : " + newAddressesMeetingStdCriteria.count())

            if (!newAddressesMeetingStdCriteria.head(1).isEmpty) {

              newAddressDF = CommonUtils.addAutoIncremetColumn(newAddressesMeetingStdCriteria.select(target_o), autoSeqColName)
              newAddressDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
              // Calling Google API for new addresses
              googleAPIDF = AddressValidation.validateAddressWithGoogleApi(newAddressDF, gooleApiURI, googleApiKey, googleApiDelay, invalid_chars)
              googleAPIDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

              googleAPIDF.showOrNoShow(debugFlag)

              //Filtering standardized addresses with OK status
              googleApiNewOkDF = googleAPIDF.filter(googleAPIDF(CommonConstants.API_STATUS) === "OK" && googleAPIDF(CommonConstants.PARTIAL_MATCH) === "false")
              // Adding quality rating as 1 for standardized addresses
              googleApiNewOkDF = googleApiNewOkDF.withColumn(CommonConstants.API_QUALITY_RATING, lit(googleAPIQualityRating))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              newAddressPartialMatch = googleAPIDF.filter(googleAPIDF(CommonConstants.API_STATUS) === "OK" && googleAPIDF(CommonConstants.PARTIAL_MATCH) === "true")
              newAddressPartialMatch = newAddressPartialMatch.withColumn(CommonConstants.API_QUALITY_RATING, lit("0"))
                                                              .withColumn(CommonConstants.API_ERROR_MESSAGE, lit("PARTIAL MATCH"))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              // Filtering standardized addresses with zero records status - populate quality_rating = 0
              googleApiNewZeroRecordsDF = googleAPIDF.filter(!(googleAPIDF(CommonConstants.API_STATUS) === "OK"
                || googleAPIDF(CommonConstants.API_STATUS) === "REQUEST_DENIED"
                || googleAPIDF(CommonConstants.API_STATUS) === "OVER_QUERY_LIMIT"))
              googleApiNewZeroRecordsDF = googleApiNewZeroRecordsDF.withColumn(CommonConstants.API_QUALITY_RATING, lit("-2")).withColumn(target_c, googleApiNewZeroRecordsDF(target_o))
              googleApiNewZeroRecordsDF = googleApiNewZeroRecordsDF.select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              // Adding quality rating as -1 for standardized addresses with not OK status
              newAddressesInvalidKey = googleAPIDF.filter(googleAPIDF(CommonConstants.API_STATUS) === "REQUEST_DENIED")
              newAddressesInvalidKey = newAddressesInvalidKey.withColumn(CommonConstants.API_QUALITY_RATING, lit("-3")).withColumn(target_c, newAddressesInvalidKey(target_o))
              newAddressesInvalidKey = newAddressesInvalidKey.select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

              newAddressesLimitExceed = googleAPIDF.filter(googleAPIDF(CommonConstants.API_STATUS) === "OVER_QUERY_LIMIT")
              newAddressesLimitExceed = newAddressesLimitExceed.withColumn(CommonConstants.API_QUALITY_RATING, lit("-4")).withColumn(target_c, newAddressesLimitExceed(target_o))
                .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)

            }
          }
        }
        /*println("Printing Schemas for all required dataframes")
        println("============= Existing addresses with OK - googleApiRetriedOkDF" + googleApiRetriedOkDF.count)
        googleApiRetriedOkDF.printSchema
        println("============= Existing addresses with Not OK - googleApiRetriedNotOkDF" + googleApiRetriedNotOkDF.count)
        googleApiRetriedNotOkDF.printSchema
        println("============= New addresses with Not OK - googleApiNewNotOkDF" + googleApiNewNotOkDF.count)
        googleApiNewNotOkDF.printSchema
        println("============= New addresses with OK - googleApiNewOkDF" + googleApiNewOkDF.count)
        googleApiNewOkDF.printSchema
        println("============= Existing addresses matching with formatted_c - checkedBefore_c" + checkedBefore_c.count)
        checkedBefore_c.printSchema
        println("============= New records with zero status from API - googleApiNewZeroRecordsDF" + googleApiNewZeroRecordsDF.count)
        googleApiNewZeroRecordsDF.printSchema*/

        unionDf = googleApiRetriedOkDF
          .union(RetriedAddressPartialMatch)
          .union(googleApiRetriedZeroRecordsDF)
          .union(retriedAddressesNotMeetingStdCriteria)
          .union(checkedBefore_o_low_rating_matching_c)
          .union(googleApiNewOkDF)
          .union(newAddressPartialMatch)
          //          .union(newAddressesInvalidKey)
          //          .union(newAddressesLimitExceed)
          .union(googleApiNewZeroRecordsDF)
          .union(finalAddNotMeetingStdCriteria)
          .union(new_addresses_matching_c)
          .distinct
          .select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)
          /*.withColumn("timestamp", timestamp)*/

      } else {
        log.info("Google API Flag is not active")

        var alreadyExistingAddressDF = checkedBefore_o.union(checkedBefore_c).select(target_o).distinct()

        alreadyExistingAddressDF.showOrNoShow(debugFlag)

        newAddressDF = inputAddressesDF.except(alreadyExistingAddressDF).distinct()

        log.info("New address")
        newAddressDF.showOrNoShow(debugFlag)

        // Adding formatted_address same as formatted_address_o
        newAddressDF = newAddressDF.withColumn(target_c, col(target_o))

        // Adding the status for logging purpose
        newAddressDF = newAddressDF.withColumn(CommonConstants.API_STATUS, lit(CommonConstants.API_WARNING))

        // Adding the error message for logging purpose
        newAddressDF = newAddressDF.withColumn(CommonConstants.API_ERROR_MESSAGE, concat_ws(" ", lit("<"), col(target_o), lit("> is not standardized.")))

        // Adding ai_address_id for new addresses
        newAddressDF = CommonUtils.addAutoIncremetColumn(newAddressDF, autoSeqColName)
        newAddressDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

        var blankCols = CommonConstants.GOOGLE_API_DF_SCHEMA diff newAddressDF.columns

        for (blankCol <- blankCols) {
          // Adding blank values to other address components of Address Dimesion
          newAddressDF = newAddressDF.withColumn(blankCol, lit(" "))
        }

        // Adding quality rating as 0 for not standardized addresses
        unionDf = newAddressDF.withColumn(CommonConstants.API_QUALITY_RATING, lit("1")).select(addDimWithLoggingSchema.head, addDimWithLoggingSchema.tail: _*)/*.withColumn("timestamp", timestamp)*/
      }

      unionDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

      if (!unionDf.head(1).isEmpty) {

        dimensionDf = unionDf.select(addressDimSchema.head, addressDimSchema.tail: _*)
                             .withColumn(CommonConstants.SRC_TIMESTAMP, lit(timestamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit("0"))

        log.info("=================== Newly added schema and records =================== " /*+ dimensionDf.count*/ )
        dimensionDf.showOrNoShow(debugFlag)

        log.info("Writing Address dimension data")
        val fileName = GlobalVariables.getFileName
        val sourceName = GlobalVariables.getSourceName
        val DimTablePath = addressDimTablePath.replace("*","") + sourceName.toLowerCase() + "_" + fileName.toLowerCase() + "_std"
        CommonUtils.writeToS3Parquet(dimensionDf, DimTablePath, "true", "append")
      } else {
        log.info("No record added in Address dimension table")
      }

      // Selected specific column for logging purpose
      loggingDf = unionDf
        //                    .union(RetriedAddressPartialMatch)
        //                    .union(googleApiRetriedZeroRecordsDF)
        /*.union(RetriedAddressesInvalidKey.withColumn("timestamp", timestamp))
        .union(RetriedAddressesLimitExceeded.withColumn("timestamp", timestamp))
        .union(newAddressesInvalidKey.withColumn("timestamp", timestamp))
        .union(newAddressesLimitExceed.withColumn("timestamp", timestamp))*/
        .union(RetriedAddressesInvalidKey)
        .union(RetriedAddressesLimitExceeded)
        .union(newAddressesInvalidKey)
        .union(newAddressesInvalidKey)
        //                    .union(retriedAddressesNotMeetingStdCriteria)
        .select(address_std_logging_cols.head, address_std_logging_cols.tail: _*)
        .withColumn(CommonConstants.SRC_TIMESTAMP, lit(timestamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit("0"))

      if (!loggingDf.head(1).isEmpty) {

        log.info("==================== Logging Dataframe =================================")
        loggingDf.showOrNoShow(debugFlag)

        log.info("Writing Address standardization logging at " + addStdLoggingPath)
        CommonUtils.writeToS3Parquet(loggingDf, addStdLoggingPath, "true", "append")

      } else {
        log.info("No record added in Logging table")
      }
//      unionDf.unpersist()
      if (addressDimdf != null)
        addressDimdf.unpersist()

      googleAPIDF.unpersist()

      if (googleApiDFForRetriedAddress != null)
        googleApiDFForRetriedAddress.unpersist()

      inputAddresses.unpersist()
      finalAddNotMeetingStdCriteria.unpersist()
      new_addresses_matching_c.unpersist()
      newAddressDF.unpersist()
      
      if(retriedAddressesMeetingStdCriteria != null)
        retriedAddressesMeetingStdCriteria.unpersist

      return loggingDf
    }

}