package com.deloitte.asset.insight.services

import org.apache.spark.sql.DataFrame
import scala.collection.Map

trait Standardization {
  def match_data_preparation(inputConfigData: Map[String, List[String]]): DataFrame
  def match_data(inputDf: DataFrame, inputConfigData: Map[String, List[String]])
  def matchDataFactSchema(inputConfigData: Map[String, List[String]])
  def stageToStandardization(inputConfigData: Map[String, List[String]])

}