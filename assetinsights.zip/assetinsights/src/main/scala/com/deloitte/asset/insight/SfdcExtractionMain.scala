package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.{ CommonUtils, InitiateSparkContext, CommonConstants}
import org.apache.spark.sql.DataFrame
import scala.collection.Map
import org.apache.log4j.{ Level, Logger }
import org.apache.spark.sql.SparkSession
import com.deloitte.asset.insight.service.impl.SfdcExtractionImpl

/**
 * <b>Collections Reference</b>
 * <p>
 * Below Reads Source File from S3 location into a Dataframe and then:
 * </p>
 *
 * 1. Parse Config file in MAP
 * 2. Identify Sfdc Objects
 * 3. Select needed columns from the Sfdc Object
 * 4. Pull the Sfdc Object from Sfdc into Spark Dataset
 * 5. Save the dataset as csv on S3
 * </p>
 * @see [[com.deloitte.asset.insight.service.impl.SfdcExtractionImpl]]
 * @author nemannur
 *
 */

object SfdcExtractionMain extends Serializable {
  case class ConfigException(smth1: String, code: String) extends Exception(smth1)
  
  private[this] val LOGGER = Logger.getLogger(getClass())

  def main(args: Array[String]) {
    LOGGER.info("Sfdc Extraction Application")
    LOGGER.info("Initiating Spark Application")

    val sparkSession = InitiateSparkContext.getSparkSession()

    // Path of parent Config file
    try {

//      val config = "C:/AssetInsightsDocuments/SFDC/MSD/MSD_SFDC_READ_CONFIG.csv"
//      val fileName = "SFDC_READ"
//      val sourceName = "DYNAMICS"
//      val layerName = "SFDCREAD".toLowerCase()
//      val debugFlag = "true"
      val debugFlag = args(4).toLowerCase()

      val config = args(0)
      val fileName = args(1).toUpperCase()
      val sourceName = args(2).toUpperCase()
      val layerName = args(3).toLowerCase()

      LOGGER.info("***Logging Started for file: " + fileName + "***")
      LOGGER.info("Loading Config file")
      var sfdcConfigData = CommonUtils.parseConfigFile(config, fileName, sourceName, layerName)
        .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })

      var collections: SfdcExtractionImpl = new SfdcExtractionImpl()

      // Calling Extraction Functionality
      collections.extractObjectFromSfdc(sfdcConfigData, layerName)

    } catch {
      case ex: ConfigException => {
        LOGGER.error(ex.code + " - " + ex.smth1)
      }
      case ex: Exception => {
        ex.printStackTrace()
        LOGGER.error(ex.getMessage)
      }
    }
  }

}