package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.InitiateSparkContext

object CreateStdBatches {
  
  def main(args: Array[String]) {
    
    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    
    val df = sparkSession.read
                         .option("header", "true")
                         .option("nullValue", "")
                          .option("nullValue", null)
                          .option("nullValue", "NULL")
                         .parquet(args(0))
    println("Schmea...........")
    df.printSchema()
    
    df.repartition(args(2).toInt).write.option("header", "true").option("nullValue", "")
    .option("ignoreLeadingWhiteSpace", "true").option("ignoreTrailingWhiteSpace", "true")
    .option("multiLine", "true").option("nullValue", "").option("nullValue", null).option("nullValue", "NULL")
    .mode("overwrite")
    .parquet(args(1))
    
    println("Batches created successfully.")
    
  }
}