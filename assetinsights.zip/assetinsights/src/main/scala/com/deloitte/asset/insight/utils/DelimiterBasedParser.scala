package com.deloitte.asset.insight.utils

import com.typesafe.config.{ Config, ConfigFactory }
import org.apache.spark.sql.{ SQLContext, Row, DataFrame }
import scala.collection.Map

/*
 * Class is responsible for Creating Dataframe from
 * Delimited source Input files
 *
 */
class DelimiterBasedParser {

  /* Reads config file and perform transformtion
	 * as per config file
	 * @Input: Config File , @return  DataFrame
	 * Developer:Ankit Pareek
	 */

  def dataFileParser(configFile: Map[String, List[String]]): DataFrame = {
    // Reading input file name from config file
    val inputFile = configFile.get(CommonConstants.S3_INPUT_PATH_PREPROCESSED).get.mkString
    /*
		val delimiter = configFile.getString( CommonConstants.KEY_READ_DELIMITER )
		 reading input file and creating Dataframe*/

    // Reading CSV file in Dataframe
    val csvDataFrame = CommonUtils.readFromCsvFile(inputFile, "true","true")
    val uprCaseDataFrame = csvDataFrame.toDF(csvDataFrame.columns.map(_.toUpperCase): _*)
    uprCaseDataFrame
  } // End of dataFileParser()
} // End of DelimiterBasedParser