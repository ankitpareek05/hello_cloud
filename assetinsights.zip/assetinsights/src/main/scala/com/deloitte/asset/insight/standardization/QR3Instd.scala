package com.deloitte.asset.insight.standardization

import com.deloitte.asset.insight.utils.InitiateSparkContext

object QR3Instd {
  def main(args: Array[String]) {

    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    val address_dim = sparkSession.read.option("header", "true").option("ignoreLeadingWhiteSpace", "true")
    .option("ignoreTrailingWhiteSpace", "true").option("quote","\u0000")
                  .option("escape","\u0000").option("multiLine", true)
    .option("nullValue", "").option("nullValue", null).option("nullValue", "NULL").option("mergeSchema", "true")
    .parquet(args(0))
    val address_std = sparkSession.read.option("header", "true").option("ignoreLeadingWhiteSpace", "true")
    .option("ignoreTrailingWhiteSpace", "true").option("quote","\u0000")
                  .option("escape","\u0000").option("multiLine", true)
    .option("nullValue", "").option("nullValue", null).option("nullValue", "NULL").option("mergeSchema", "true")
    .parquet(args(1))
    address_dim.createOrReplaceTempView("ai_address")
    address_std.createOrReplaceTempView("ai_address_std")
    val sql1 = sparkSession.sqlContext.sql("SELECT * FROM ai_address_std WHERE ai_address_id IN  (SELECT DISTINCT ai_address_id FROM ai_address_std  EXCEPT (SELECT DISTINCT address_std.ai_address_id FROM (  (SELECT * FROM ai_address) address JOIN  (SELECT * FROM ai_address_std) address_std ON address.ai_address_id = address_std.ai_address_id)))")
    sql1.printSchema
    println("not to fix: "+sql1.count)
    val sql2 = sparkSession.sql("SELECT address.AI_ADDRESS_ID AS AI_ADDRESS_ID,  address.formatted_address AS FORMATTED_ADDRESS,  address.premise AS PREMISE,  address.sub_premise AS SUB_PREMISE,  address.street_number AS STREET_NUMBER,  address.route AS ROUTE,  address.locality AS LOCALITY,  address.administrative_area_level_2 AS ADMINISTRATIVE_AREA_LEVEL_2,  address.administrative_area_level_1 AS ADMINISTRATIVE_AREA_LEVEL_1,  address.country AS COUNTRY,  address.postal_code AS POSTAL_CODE,  address.postal_code_suffix AS POSTAL_CODE_SUFFIX,  address.latitude AS LATITUDE,  address.longitude AS LONGITUDE,  address.quality_rating AS QUALITY_RATING,  address.INACTIVE_FLAG AS INACTIVE_FLAG,  address.AI_RUN_DATETIME AS AI_RUN_DATETIME  FROM (   (SELECT *  FROM ai_address) address  JOIN   (SELECT *  FROM ai_address_std) address_std  ON address.ai_address_id = address_std.ai_address_id)")
    println("fix: "+sql2.count)
    sql2.printSchema
    val finalDf = sql1.union(sql2)
    finalDf.printSchema
    println("final count:"+finalDf.count)
    finalDf.write.option("header", "true").option("nullValue", "").option("ignoreLeadingWhiteSpace", "true")
    .option("ignoreTrailingWhiteSpace", "true").option("multiLine", "true").option("nullValue", "")
    .option("nullValue", null).option("nullValue", "NULL").mode("overwrite")
    .parquet(args(2))
  }
}