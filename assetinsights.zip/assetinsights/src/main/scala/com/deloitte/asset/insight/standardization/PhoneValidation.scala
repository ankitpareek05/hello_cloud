package com.deloitte.asset.insight.standardization

import com.deloitte.asset.insight.services.Logging
import org.apache.spark.sql.DataFrame
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.functions._
import com.deloitte.asset.insight.utils.CommonConstants
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.Row
import com.google.i18n.phonenumbers._
import com.google.i18n.phonenumbers.PhoneNumberUtil.PhoneNumberFormat

object PhoneValidation extends Logging {
  
  val sparkSession = InitiateSparkContext.getSparkSession()
  
  
  
  def validatePhoneWithGoogleLibrary(phoneDim:DataFrame,target_o: String,phone_dim_schema: Array[String],country:String,phoneFormat:String):DataFrame={

   
    var df=phoneDim.withColumn(phone_dim_schema(5), udfExtension(col(target_o),trim(col(country)))).withColumn(phone_dim_schema(4), udfCountryCode(col(target_o),trim(col(country)))).withColumn(phone_dim_schema(6), udfNationalNumber(col(target_o),trim(col(country))))
    
   
    var df1=df.withColumn(CommonConstants.PHONE_API_VALIDITY, udfValidity(col(target_o),trim(col(country)))).withColumn(CommonConstants.API_ERROR_MESSAGE, udfErrorReason(col(target_o),trim(col(country)))).withColumn(phone_dim_schema(1), udfPhoneFormat(col(target_o),trim(col(country)),lit(phoneFormat)))
     
    
    df1
    
    
  }
  def udfValidity = udf((colName: String,countryName:String) => {
//print(colName +" " + countryName)
  try{
   val phoneNumberUtil = PhoneNumberUtil.getInstance()
  
  val a=phoneNumberUtil.parse(colName, countryName)
  val b=phoneNumberUtil.isValidNumber(a)
  print(colName +"" + countryName)
  b.toString()
  }
  catch{
      case ex: Exception => {
        println("Exception occured : " + ex.getMessage)
        println("Affected Phone : " + colName)
        "false"
      }
    }

  }) 
  def udfCountryCode = udf((colName: String,countryName:String) => {
    //print(colName +" " + countryName)
    try{
   val phoneNumberUtil = PhoneNumberUtil.getInstance()
  
  val a=phoneNumberUtil.parse(colName, countryName)
  a.getCountryCode
    }
    catch{
      case ex: Exception => {
        println("Exception occured : " + ex.getMessage)
        println("Affected Phone : " + colName)
        0
      }
    }
  }) 

  def udfNationalNumber = udf((colName: String,countryName:String) => {
//print(colName +" " + countryName)
  try{
   val phoneNumberUtil = PhoneNumberUtil.getInstance()
  
  val a=phoneNumberUtil.parse(colName, countryName)
  print(colName +" " + countryName)
  a.getNationalNumber.toString()
  }
  catch{
      case ex: Exception => {
        println("Exception occured : " + ex.getMessage)
        println("Affected Phone : " + colName)
        ""
      }
    }
  }) 
  def udfExtension = udf((colName: String,countryName:String) => {
    try{
    //print(colName +" " + countryName)
   val phoneNumberUtil = PhoneNumberUtil.getInstance()
  val a=phoneNumberUtil.parse(colName, countryName)
 a.getExtension
    }
    catch{
      case ex: Exception => {
        println("Exception occured : " + ex.getMessage)
        println("Affected Phone : " + colName)
        ""
      }
    }
    
  }) 
  def udfPhoneFormat = udf((colName: String,countryName:String,phoneFormat:String) => {
    /*println("****************PHONE FORMAT********************8")
    println(colName +" " + countryName)*/
    try{
   val phoneNumberUtil = PhoneNumberUtil.getInstance()
  val a=phoneNumberUtil.parse(colName, countryName)
  val b=phoneNumberUtil.isValidNumber(a)
  
  if(b==true){
   // println("Completed")
    phoneNumberUtil.format(a, PhoneNumberFormat.valueOf(phoneFormat))
  }
  else colName
    }
    catch{
      case ex: Exception => {
        println("Exception occured : " + ex.getMessage)
        println("Affected Phone : " + colName)
        colName
      }
    }
    
   

  }) 
  
  def udfErrorReason = udf((colName: String,countryName:String) => {
    //print(colName +" " + countryName)
    try{
   val phoneNumberUtil = PhoneNumberUtil.getInstance()
  val a=phoneNumberUtil.parse(colName, countryName)
 phoneNumberUtil.isPossibleNumberWithReason(a).toString()
    }
    catch{
      case ex: Exception => {
        println("Exception occured : " + ex.getMessage)
        println("Affected Phone : " + colName)
        "NOT A VALID NUMBER"
      }
    }
  }) 
  

  
}