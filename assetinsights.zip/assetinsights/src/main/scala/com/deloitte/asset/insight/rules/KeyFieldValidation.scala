package com.deloitte.asset.insight.rules

import org.apache.spark.sql.SQLContext
import scala.collection.Map
import org.apache.spark.sql.Row
import com.deloitte.asset.insight.utils.RulesConstants
import com.deloitte.asset.insight.utils.CommonConstants
import com.deloitte.asset.insight.utils.GlobalVariables

class KeyFieldValidation extends Serializable {
  //By Kanika start
  def isValidationPassed(colValue: String): String = {

    if ((colValue != null && !colValue.trim.isEmpty && !colValue.trim().equalsIgnoreCase("null")))
      return "true";
    else
      return "false";
  }

  def fieldValidationCheck(colName: String, row: Row, inputConfigData: Map[String, List[String]]) = {
    
    var source = GlobalVariables.getSourceName
    var firmName = GlobalVariables.getSourceId
    var fileName = GlobalVariables.getFileName
    var errorCode = ""
    var errorCategoery = ""
    var errorColumn = colName
    var errorDescription = ""
    var errorRecords = ""
    errorCode = RulesConstants.keyFieldValidation
    errorRecords = row.mkString("|")

    try {

      val colValue = row.getAs[String](colName)

      val fieldValidationCheckOutput = isValidationPassed(colValue)

      
      if (fieldValidationCheckOutput.equalsIgnoreCase("false")) {

        errorDescription = fieldValidationCheckOutput.toString()

        (row, ErrorTable(source, firmName, fileName, errorCode, errorCategoery, errorColumn, errorDescription, errorRecords))

      } else {

        (null, null)

      }

    } catch {
      case e: Exception => {
        errorDescription = "Exception: =>  " + e.getMessage
        (row, ErrorTable(source, firmName, fileName, errorCode, errorCategoery, errorColumn, errorDescription, errorRecords))
      }
    }
  }
  //by Kanika end

}