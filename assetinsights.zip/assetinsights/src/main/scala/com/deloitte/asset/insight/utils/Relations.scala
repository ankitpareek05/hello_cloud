package com.deloitte.asset.insight.utils

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import scala.collection.Map
import org.apache.spark.storage.StorageLevel
import com.deloitte.asset.insight.services.Logging

object Relations extends Logging {

  import DataFrameOperation.implicits._

  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = InitiateSparkContext.getSqlContext()
  val sc = InitiateSparkContext.getSparkContext()
  val debugFlag = GlobalVariables.getDebugFlag

  import sqlContext.implicits._
  /*
   * Generic Relation Logic
   */
  def generateRelations(preProcessedDF: DataFrame, relationName: String, relationConfigData: Map[String, List[String]]) = {
    //relationConfigData.foreach(println)

    for ((k, v) <- relationConfigData) printf("key: %s, value: %s\n", k, v)
    log.info("config print")
    val bucketName = GlobalVariables.getRootPath
    val xRefDFPath = bucketName + relationConfigData.get(relationName + ".xref.path").get(0).trim() //.toLowerCase()
    val dimFactDFPath = bucketName + relationConfigData.get(relationName + ".dimfact.path").get(0).trim() //.toLowerCase()
    val relationPath = bucketName + relationConfigData.get(relationName + ".relation.path").get(0).trim() //.toLowerCase()

    val relTypeTablePath = bucketName + relationConfigData.get(relationName + ".reltypetable.path").get(0).trim() //.toLowerCase()
    val relTypeLookupColumn = relationConfigData.get(relationName + ".reltype.lookup.column").get.toList.map(_.trim().toUpperCase())

    val relationSchema = relationConfigData.get(relationName + ".schema").get.toList.map(_.trim().toUpperCase())

    val dimFactSelectedColumn = relationConfigData.get(relationName + ".dimfact.selected.column").get.toList.map(_.trim().toUpperCase())
    val mainDataSelectedColumn = relationConfigData.get(relationName + ".main.selected.column").get.toList.map(_.trim().toUpperCase())
    val xrefSelectedColumn = relationConfigData.get(relationName + ".xref.selected.column").get.toList.map(_.trim().toUpperCase())

    val xRefTagValueCols = relationConfigData.get(relationName + ".xref.tag.value.column").get.toList.map(_.toUpperCase())
    val xRefTagValueColName = relationConfigData.get(relationName + ".xref.tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    //val xRefTagValueColName = relationConfigData.get(relationName + ".xref.tag.value.measure.columnme").get.toList.map(_.trim().toUpperCase())

    val tagValueCols = relationConfigData.get(relationName + ".tag.value.column").get.toList.map(_.toUpperCase())
    val tagValueColName = relationConfigData.get(relationName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    //val tagValueColName = relationConfigData.get(relationName + ".tag.value.measure.columnme").get.toList.map(_.trim().toUpperCase())

    val firstLookupCols = relationConfigData.get(relationName + ".first.lookup.column").get.toList.map(_.trim().toUpperCase())
    val secondLookupCols = relationConfigData.get(relationName + ".second.lookup.column").get.toList.map(_.trim().toUpperCase())

    val firstLookup = relationConfigData.get(relationName + ".first.lookup").get(0).trim()
    val secondLookup = relationConfigData.get(relationName + ".second.lookup").get(0).trim()
    val relValueList = relationConfigData.getOrElse(relationName + ".rel.value.lookup", List("NA")).mkString(",")
    val relValueColName = relationConfigData.getOrElse(relationName + ".rel.column.name.lookup", List("NA"))

    val firstLookupRenameCol = relationConfigData.get(relationName + ".first.lookup.column.rename").get.toList.map(_.trim().toUpperCase())
    val secondLookupRenameCol = relationConfigData.get(relationName + ".second.lookup.column.rename").get.toList.map(_.trim().toUpperCase())

    val autoIncrementColName = relationConfigData.get(relationName + ".autoincrement.column").get(0).trim().toUpperCase()
    var addFieldsForAPI = Array[String]()
    var secondLookupRenameColNew = ""
    if (relationName contains "address") {
      addFieldsForAPI = relationConfigData.get(relationName + ".concat.columns").get(0).trim().split('|').map(_.toUpperCase())
      secondLookupRenameColNew = relationConfigData.get(relationName + ".second.lookup.column.new").get(0).mkString
    }
    //  secondLookupRenameColNew = relationConfigData.get(relationName + ".second.lookup.column.new").get(0).mkString

    log.info("Relation Function called : " + relationName)

    // Assign the DataFrame Argument to variable
    var mainDF = preProcessedDF.select(mainDataSelectedColumn.head, mainDataSelectedColumn.tail: _*).na.fill(" ")
    mainDF.showOrNoShow(debugFlag)
    var selectedDF = sqlContext.emptyDataFrame
    var xRefDF = sqlContext.emptyDataFrame
    var dimFactDF = sqlContext.emptyDataFrame

    // selectedDF.showOrNoShow(debugFlag)

    // Fetching the Column Names to be Tag-Value to Join with XREF, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME
    val xRefTagValue = xRefTagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME to Join with XREF
    xRefTagValueCols.map(elem => {
      val cols = elem.split(":")
      mainDF = mainDF.withColumnRenamed(cols(0).trim().toUpperCase(), cols(1).trim().toUpperCase())
    })

    // Tag Value Pair Generation for XREF
    val xRefTagValueColumnName = xRefTagValueColName(0).split(":")
    selectedDF = CommonUtils.createMeasureNameValue(mainDF, xRefTagValueColumnName(0), xRefTagValueColumnName(1), xRefTagValue)
    selectedDF.showOrNoShow(debugFlag)

    // Read RELTYPE Table
    var relTypeTbl = CommonUtils.readFromCsvFile(relTypeTablePath, "true", "true").na.fill(" ")
    relTypeTbl.showOrNoShow(debugFlag)

    // Read the XREF if the path is NOT NA or NOT Empty
    if ((!xRefDFPath.equalsIgnoreCase("na") || !xRefDFPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(xRefDFPath.replace("*", ""))

      if (fileExist.equalsIgnoreCase("true")) {
        val srcIdValue = GlobalVariables.getSourceId.mkString.substring(0, 7)
        xRefDF = CommonUtils.readFromS3Parquet(xRefDFPath, "true").select(xrefSelectedColumn.head, xrefSelectedColumn.tail: _*).filter(col("AI_SRC_ID").startsWith(srcIdValue)).na.fill(" ")
        xRefDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
        //xRefDF.showOrNoShow(debugFlag)
      }
    }

    // Read the DIMFACT if the path is NOT NA or NOT Empty
    if ((!dimFactDFPath.equalsIgnoreCase("na") || !dimFactDFPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(dimFactDFPath.replace("*", ""))

      if (fileExist.equalsIgnoreCase("true")) {
        dimFactDF = CommonUtils.readFromS3Parquet(dimFactDFPath, "true").select(dimFactSelectedColumn.head, dimFactSelectedColumn.tail: _*).na.fill(" ")
        //dimFactDF.showOrNoShow(debugFlag)
      }
    }

    // Fetching the Column Names to be Tag-Value, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME, col value to be taken from config file
    val tagValue = tagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME, values to be taken from config file
    tagValueCols.map(elem => {
      val col = elem.split(":")
      selectedDF = selectedDF.withColumnRenamed(col(0).trim(), col(1).trim())
      col(1).trim()
    })

    // Convert the data into Tag-Value
    val tagValueColumnName = tagValueColName(0).split(":")
    var tagDF = CommonUtils.createMeasureNameValue(selectedDF, tagValueColumnName(0), tagValueColumnName(1), tagValue).na.fill(" ")
    log.info("tagDF transpose")
    tagDF.showOrNoShow(debugFlag)
    tagDF = tagDF.withColumn(tagValueColumnName(0), CommonUtils.hashRemove(col(tagValueColumnName(0))))

    log.info("tagDf rename column")
    tagDF.showOrNoShow(debugFlag)

    if (!relValueList.equalsIgnoreCase("NA")) {
      val colName = relValueColName.mkString(",").split(":")
      /*println("Before udf.........")
      colName.foreach(println)
      var EmptyRelTypeDf = tagDF.filter(trim(tagDF(colName(0))) === "" || trim(tagDF(colName(0))) === null)
      var filteredTagDf = tagDF.except(EmptyRelTypeDf)
      println("filteredTagDf..............")
      filteredTagDf.show(false)
      EmptyRelTypeDf = EmptyRelTypeDf.withColumn(colName(1), lit("NA"))
      EmptyRelTypeDf.show(false)
      filteredTagDf = filteredTagDf.withColumn(colName(1), relType(col(colName(0)), lit(relValueList)))
      tagDF = EmptyRelTypeDf.union(filteredTagDf)*/
      tagDF = tagDF.withColumn(colName(1), relType(col(colName(0)), lit(relValueList)))
    }
    tagDF.showOrNoShow(debugFlag)

    /*
     * First Lookup/Join
     */

    log.info("First Lookup statement called")

    // Renaming the cols to do first Lookup/Join
    firstLookupCols.map(col => {
      val cols = col.split(":")
      tagDF = tagDF.withColumnRenamed(cols(0).trim(), cols(1).trim())

    })

    // Sequence of Join Columns , @Return :: Seq() of Join Columns
    var joinColsFirst = firstLookupCols.map(col => {
      val cols = col.split(":")(1).trim()
      cols
    }).toSeq

    log.info("Befor first lookup")
    xRefDF.showOrNoShow(debugFlag)

    // First Lookup/Join with XREF/DIM FACT DF
    var joinedDFOne = sqlContext.emptyDataFrame

    if (firstLookup.equalsIgnoreCase("xref")) {
      joinedDFOne = tagDF.join(xRefDF, joinColsFirst, "inner") //TO-DO Validate the Result
    } else if (firstLookup.equalsIgnoreCase("dimfact")) {
      joinedDFOne = tagDF.join(dimFactDF, joinColsFirst, "inner") //TO-DO Validate the Result

    }

    // Renaming the columns to original name after Joining from XREF/DIMFACT
    firstLookupCols.map(col => {
      val cols = col.split(":")
      joinedDFOne = joinedDFOne.withColumnRenamed(cols(1).trim(), cols(0).trim())
    })

    joinedDFOne.showOrNoShow(debugFlag)

    // Renaming ID's col if required
    firstLookupRenameCol.map(col => {
      if (!col.equalsIgnoreCase("na")) {
        val cols = col.split(":")
        joinedDFOne = joinedDFOne.withColumnRenamed(cols(0).trim(), cols(1).trim())
      }
    })

    joinedDFOne.persist(StorageLevel.MEMORY_AND_DISK_SER)

    if (relationName contains "phone") {
      dimFactDF = dimFactDF.filter(trim(dimFactDF(CommonConstants.API_QUALITY_RATING)) === 0)
    }

    if (relationName contains "address") {
      dimFactDF = dimFactDF.filter(trim(dimFactDF(CommonConstants.API_QUALITY_RATING)) === 1)
      var colList = addFieldsForAPI.map(x => col(x))
      joinedDFOne = joinedDFOne.select(joinedDFOne.columns.map {
        x =>
          if (!x.equalsIgnoreCase("ai_batch_id"))
            trim(col(x)).alias(x)
          else
            col(x).alias(x)
      }: _*)
      joinedDFOne = joinedDFOne.withColumn(secondLookupRenameColNew, trim(concat_ws(" ", colList: _*))) //.select("dim_formatted_address_O")
    }
    log.info("Second Lookup statement called")
    log.info("after col concat show")
    joinedDFOne.showOrNoShow(debugFlag)

    /*
     * Second Lookup/Join
     */

    log.info("Second Lookup statement called")

    // Renaming the cols to do first Lookup/Join

    secondLookupCols.map(col => {
      val cols = col.split(":")
      joinedDFOne = joinedDFOne.withColumnRenamed(cols(0).trim(), cols(1).trim())
    })

    // Sequence of Join Columns, @Return :: Seq() of Join Columns
    val joinColsSecond = secondLookupCols.map(col => {
      val cols = col.split(":")(1).trim()
      cols

    }).toSeq

    // Second Lookup/Join with XREF/DIM FACT DF
    var joinedDFTwo = sqlContext.emptyDataFrame

    println("dimfact before join")
    dimFactDF.showOrNoShow(debugFlag)

    println("joined before dimfact join.....")
    joinedDFOne.showOrNoShow(debugFlag)
    if (secondLookup.equalsIgnoreCase("xref")) {
      joinedDFTwo = joinedDFOne.join(xRefDF, joinColsSecond, "inner") // TO-DO Validate the Result
    } else if (secondLookup.equalsIgnoreCase("dimfact")) {
      joinedDFTwo = joinedDFOne.join(dimFactDF, joinColsSecond, "inner") // TO-DO Validate the Result

    }
    joinedDFTwo.showOrNoShow(debugFlag)

    // Renaming ID's col if required
    secondLookupRenameCol.map(col => {
      if (!col.equalsIgnoreCase("na")) {
        val cols = col.split(":")
        joinedDFTwo = joinedDFTwo.withColumnRenamed(cols(0).trim(), cols(1).trim())
      }
    })

    joinedDFTwo.persist(StorageLevel.MEMORY_AND_DISK_SER)

    // Renaming Column to do Lookup on RelType Table
    relTypeLookupColumn.map(col => {
      val cols = col.split(":")
      joinedDFTwo = joinedDFTwo.withColumnRenamed(cols(0).trim(), cols(1).trim())
    })

    // Sequence of Join Columns, @Return :: Seq() of Join Columns
    val relTypeJoinCol = relTypeLookupColumn.map(col => {
      val cols = col.split(":")(1).trim()
      cols

    }).toSeq

    var finalDF = sqlContext.emptyDataFrame
    var relTypeDF = sqlContext.emptyDataFrame

    relTypeDF = joinedDFTwo.join(relTypeTbl, relTypeJoinCol, "left_outer")
    // Sequence ID Generation
    if (!autoIncrementColName.equalsIgnoreCase("na")) {
      finalDF = CommonUtils.addAutoIncremetColumn(relTypeDF, autoIncrementColName)
      finalDF.persist(StorageLevel.MEMORY_AND_DISK_SER)
    } else {
      finalDF = relTypeDF
    }
    // Ordering DF
    finalDF = finalDF.select(relationSchema.head, relationSchema.tail: _*)
    finalDF.showOrNoShow(debugFlag)
    log.info("relationPath : " + relationPath)

    /*
     * Adding Run timestamp and Inactive Flag in data.
     */
    val runTimeStamp = CommonUtils.getTimeStamp()._1
    finalDF = finalDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
    CommonUtils.writeToS3Parquet(finalDF, relationPath, "true", "append")

    joinedDFOne.unpersist()
    joinedDFTwo.unpersist()
    finalDF.unpersist()
    xRefDF.unpersist()
    log.info("Relation Function Completed : " + relationName)

  } // one

  def generateRelations2(preProcessedDF: DataFrame, relationName: String, relationConfigData: Map[String, List[String]]) = {
    //used invmgr_mm2hdrs config-old format -address relation for testing
    val bucketName = GlobalVariables.getRootPath
    val xRefDFPath = bucketName + relationConfigData.get(relationName + ".xref.path").get(0).trim()
    val dimFactDFPath = bucketName + relationConfigData.get(relationName + ".dimfact.path").get(0).trim()
    val relationPath = bucketName + relationConfigData.get(relationName + ".relation.path").get(0).trim()
    val relTypeTablePath = bucketName + relationConfigData.get(relationName + ".reltypetable.path").get(0).trim()
    val relTypeLookupColumn = relationConfigData.get(relationName + ".reltype.lookup.column").get.toList.map(_.trim().toUpperCase())
    val relationSchema = relationConfigData.get(relationName + ".schema").get.toList.map(_.trim().toUpperCase())
    val xRefTagValueCols = relationConfigData.get(relationName + ".xref.tag.value.column").get.toList.map(_.toUpperCase())
    val xRefTagValueColName = relationConfigData.get(relationName + ".xref.tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    val tagValueCols = relationConfigData.get(relationName + ".tag.value.column").get.toList.map(_.toUpperCase())
    val tagValueColName = relationConfigData.get(relationName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    val firstLookupCols = relationConfigData.get(relationName + ".first.lookup.column").get.toList.map(_.trim().toUpperCase())
    val secondLookupCols = relationConfigData.get(relationName + ".second.lookup.column").get.toList.map(_.trim().toUpperCase())
    val autoIncrementColName = relationConfigData.get(relationName + ".autoincrement.column").get(0).trim().toUpperCase()
    val firstLookup = relationConfigData.get(relationName + ".first.lookup").get(0).trim()
    val secondLookup = relationConfigData.get(relationName + ".second.lookup").get(0).trim()
    val addFieldsForAPI = relationConfigData.get(relationName + ".googleapi.column").get.toArray.map(_.toUpperCase())
    //for google api
    //    val addFieldsForAPI = relationConfigData.get(relationName + ".googleapi.column").get.toArray.map(_.toUpperCase())
    //    val secondLookupRenameColNew = relationConfigData.get(relationName + ".second.lookup.column.new").get(0).mkString

    log.info("Relation Function called : " + relationName)
    log.info("preprocess data show")
    preProcessedDF.showOrNoShow(debugFlag)

    //1 Assign the DataFrame Argument to variable
    var mainDF = preProcessedDF
    var selectedDF = sqlContext.emptyDataFrame
    var xRefDF = sqlContext.emptyDataFrame
    var dimFactDF = sqlContext.emptyDataFrame
    var joinedDFOne = sqlContext.emptyDataFrame
    var joinedDFTwo = sqlContext.emptyDataFrame
    var finalDF = sqlContext.emptyDataFrame
    var relTypeDF = sqlContext.emptyDataFrame

    //2 ==> Read DIm and Xref if the path is NOT NA or NOT Empty

    if ((!xRefDFPath.equalsIgnoreCase("na") || !xRefDFPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(xRefDFPath.replace("*", ""))

      if (fileExist.equalsIgnoreCase("true")) {
        xRefDF = CommonUtils.readFromS3Parquet(xRefDFPath, "true").na.fill(" ")
        log.info("xrefDf" + xRefDF.showOrNoShow(debugFlag))
      }
    }

    if ((!dimFactDFPath.equalsIgnoreCase("na") || !dimFactDFPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(dimFactDFPath.replace("*", ""))

      log.info("dim address show")
      CommonUtils.readFromS3Parquet(dimFactDFPath, "true").showOrNoShow(debugFlag)
      if (fileExist.equalsIgnoreCase("true")) {
        dimFactDF = CommonUtils.readFromS3Parquet(dimFactDFPath, "true").na.fill("")

      }
    }
    dimFactDF.showOrNoShow(debugFlag)

    // 3==> append main. to preproces olcumns ,xerf. to xref columns and dim. to dim columns
    var mainprefix = "MAIN_"

    var mainDataSelectedColumn = mainDF.columns.map(c => mainDF(c).as(s"$mainprefix$c"))
    mainDF = mainDF.select(mainDataSelectedColumn: _*)
    //    mainDF.show(2)

    var dimFactDataSelectedColumn = dimFactDF.columns.map(c => dimFactDF(c).as(s"DIM_$c"))
    dimFactDF = dimFactDF.select(dimFactDataSelectedColumn: _*)
    //    dimFactDF.show(2)

    var xrefDataSelectedColumn = xRefDF.columns.map(c => xRefDF(c).as(s"XREF_$c"))
    xRefDF = xRefDF.select(xrefDataSelectedColumn: _*)
    //    xRefDF.show(2)

    //Fetching the Column Names to be Tag-Value to Join with XREF, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME
    val xRefTagValue = xRefTagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME to Join with XREF
    xRefTagValueCols.map(elem => {
      val cols = elem.split(":")
      mainDF = mainDF.withColumnRenamed(cols(0).trim().toUpperCase(), cols(1).trim().toUpperCase())
    })
    log.info("Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME to Join with XREF" + xRefTagValueCols.foreach(println))

    // Tag Value Pair Generation for XREF
    selectedDF = CommonUtils.createMeasureNameValue(mainDF, xRefTagValueColName(0), xRefTagValueColName(1), xRefTagValue)
    log.info("show after  Tag Value Pair Generation for XREF " + selectedDF.showOrNoShow(debugFlag))

    // Read RELTYPE Table
    var relTypeTbl = CommonUtils.readFromCsvFile(relTypeTablePath, "true", "true")

    // Fetching the Column Names to be Tag-Value, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME, col value to be taken from config file
    val tagValue = tagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME, values to be taken from config file
    tagValueCols.map(elem => {
      val col = elem.split(":")
      selectedDF = selectedDF.withColumnRenamed(col(0).trim(), col(1).trim())
    })

    // Convert the data into Tag-Value
    var tagDF = CommonUtils.createMeasureNameValue(selectedDF, tagValueColName(0), tagValueColName(1), tagValue).na.fill(" ")

    log.info("First Lookup statement called")

    // Sequence of Join Columns , @Return :: Seq() of Join Columns
    var firstlookupMaincols = Array[String]()
    var firstlookupXrefDimcols = Array[String]()

    var joinFirstCols = firstLookupCols.map(col => {
      val cols = col.split(":")(0).trim()
      val cols1 = col.split(":")(1).trim()
      firstlookupMaincols = firstlookupMaincols :+ cols
      firstlookupXrefDimcols = firstlookupXrefDimcols :+ cols1
    }).toArray

    // First Lookup/Join with XREF/DIM FACT DF
    if (firstLookup.equalsIgnoreCase("xref")) {

      val joinXrefExprs = firstlookupMaincols
        .zip(firstlookupXrefDimcols)
        .map { case (c1, c2) => tagDF(c1) === xRefDF(c2) }
        .reduce(_ && _)

      joinedDFOne = tagDF.join(xRefDF, joinXrefExprs)

    } //tagDF.join(xRefDF, joinColsFirst, "left_outer") //TO-DO Validate the Result
    else if (firstLookup.equalsIgnoreCase("dimfact")) {

      val joinDimExprs = firstlookupMaincols
        .zip(firstlookupXrefDimcols)
        .map { case (c1, c2) => tagDF(c1) === dimFactDF(c2) }
        .reduce(_ && _)
      joinedDFOne = tagDF.join(dimFactDF, joinDimExprs)

    }

    log.info("First Lookup completed...")

    //for google api -do not remove
    //    var colList = addFieldsForAPI.map(x => col(x))
    //    if (relationName contains "address") {
    //      joinedDFOne = joinedDFOne.withColumn(secondLookupRenameColNew, trim(concat_ws(" ", colList: _*))) //.select("dim_formatted_address_O")
    //    }
    //    log.info("after col concat show" +joinedDFOne.showOrNoShow(debugFlag))

    log.info("Second Lookup statement called")

    var secondlookupMaincols = Array[String]()
    var secondlookupXrefDimcols = Array[String]()

    var joinSecondCols = secondLookupCols.map(col => {
      val cols = col.split(":")(0).trim()
      val cols1 = col.split(":")(1).trim()
      secondlookupMaincols = secondlookupMaincols :+ cols
      secondlookupXrefDimcols = secondlookupXrefDimcols :+ cols1
    }).toArray

    log.info("second join" + secondlookupMaincols.foreach(println))
    log.info("second join dim cond" + secondlookupXrefDimcols.foreach(println))
    if (secondLookup.equalsIgnoreCase("xref")) {

      val joinXrefExprs = secondlookupMaincols
        .zip(secondlookupXrefDimcols)
        .map { case (c1, c2) => joinedDFOne(c1) === xRefDF(c2) }
        .reduce(_ && _)

      log.info("joinXrefExprs : " + joinXrefExprs)

      joinedDFTwo = joinedDFOne.join(xRefDF, joinXrefExprs)
    } //tagDF.join(xRefDF, joinColsFirst, "left_outer") //TO-DO Validate the Result
    else if (secondLookup.equalsIgnoreCase("dimfact")) {

      val joinDimExprs = secondlookupMaincols
        .zip(secondlookupXrefDimcols)
        .map { case (c1, c2) => joinedDFOne(c1) === dimFactDF(c2) }
        .reduce(_ && _)

      joinedDFTwo = joinedDFOne.join(dimFactDF, joinDimExprs)
    }
    //    joinedDFTwo.persist(StorageLevel.DISK_ONLY_2)

    // Renaming Column to do Lookup on RelType Table
    relTypeLookupColumn.map(col => {
      val cols = col.split(":")
      joinedDFTwo = joinedDFTwo.withColumnRenamed(cols(0).trim(), cols(1).trim())
    })

    // Sequence of Join Columns, @Return :: Seq() of Join Columns
    val relTypeJoinCol = relTypeLookupColumn.map(col => {
      val cols = col.split(":")(1).trim()
      cols

    }).toSeq

    relTypeDF = joinedDFTwo.join(relTypeTbl, relTypeJoinCol, "left_outer")
    // relTypeDF.show(2)

    // Sequence ID Generation
    if (!autoIncrementColName.equalsIgnoreCase("na")) {
      finalDF = CommonUtils.addAutoIncremetColumn(relTypeDF, autoIncrementColName)
    } else {
      finalDF = relTypeDF
    }
    //    finalDF.show(2)

    // Ordering DF
    finalDF = finalDF.select(relationSchema.head, relationSchema.tail: _*)
    finalDF.showOrNoShow(debugFlag)

    var finalDFcols = finalDF.columns.map(line => line.replaceAll("MAIN_", ""))
      .map(line => line.replaceAll("DIM_", ""))
      .map(line => line.replaceAll("XREF_", ""))

    finalDFcols.foreach(println)
    finalDF = finalDF.toDF(finalDFcols: _*)
    finalDF.showOrNoShow(debugFlag)
    //CommonUtils.writeToS3Parquet(finalDF, relationPath, "true", "append")

    // joinedDFOne.unpersist()
    //joinedDFTwo.unpersist()
    log.info("Relation Function Completed : " + relationName)

  }
  def relType = udf((colValue: String, relTypeV: String) => {
    var relValue = "NA"
    val relType = relTypeV.split(",").toList
    val relTypeMap = relType.map { col =>
      val split = col.split(":")
      (split(0), split(1))

    }.toMap

    //    val keySet = relTypeMap
    relTypeMap.foreach { x =>
      if ((x._1 != null || colValue != null || x._1.trim() != "" || colValue.trim() != "") && colValue.equalsIgnoreCase(x._1)) {
        relValue = relTypeMap.getOrElse(x._1, "NA")
      }
    }
    relValue

  })
  def generateRelations3(preProcessedDF: DataFrame, relationName: String, relationConfigData: Map[String, List[String]]) = {
    //relationConfigData.foreach(println)

    for ((k, v) <- relationConfigData) printf("key: %s, value: %s\n", k, v)
    log.info("config print")
    val bucketName = GlobalVariables.getRootPath
    val xRefDFPath = bucketName + relationConfigData.get(relationName + ".xref.path").get(0).trim()
    val dimFactDFPath = bucketName + relationConfigData.get(relationName + ".dimfact.path").get(0).trim()
    val relationPath = bucketName + relationConfigData.get(relationName + ".relation.path").get(0).trim()

    val relTypeTablePath = bucketName + relationConfigData.get(relationName + ".reltypetable.path").get(0).trim()
    val relTypeLookupColumn = relationConfigData.get(relationName + ".reltype.lookup.column").get.toList.map(_.trim().toUpperCase())

    val relationSchema = relationConfigData.get(relationName + ".schema").get.toList.map(_.trim().toUpperCase())

    val dimFactSelectedColumn = relationConfigData.get(relationName + ".dimfact.selected.column").get.toList.map(_.trim().toUpperCase())
    val mainDataSelectedColumn = relationConfigData.get(relationName + ".main.selected.column").get.toList.map(_.trim().toUpperCase())
    val xrefSelectedColumn = relationConfigData.get(relationName + ".xref.selected.column").get.toList.map(_.trim().toUpperCase())

    val xRefTagValueCols = relationConfigData.get(relationName + ".xref.tag.value.column").get.toList.map(_.toUpperCase())
    val xRefTagValueColName = relationConfigData.get(relationName + ".xref.tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    //val xRefTagValueColName = relationConfigData.get(relationName + ".xref.tag.value.measure.columnme").get.toList.map(_.trim().toUpperCase())

    val tagValueCols = relationConfigData.get(relationName + ".tag.value.column").get.toList.map(_.toUpperCase())
    val tagValueColName = relationConfigData.get(relationName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    //val tagValueColName = relationConfigData.get(relationName + ".tag.value.measure.columnme").get.toList.map(_.trim().toUpperCase())

    val firstLookupCols = relationConfigData.get(relationName + ".first.lookup.column").get.toList.map(_.trim().toUpperCase())
    val secondLookupCols = relationConfigData.get(relationName + ".second.lookup.column").get.toList.map(_.trim().toUpperCase())

    val firstLookup = relationConfigData.get(relationName + ".first.lookup").get(0).trim()
    val secondLookup = relationConfigData.get(relationName + ".second.lookup").get(0).trim()

    val firstLookupRenameCol = relationConfigData.get(relationName + ".first.lookup.column.rename").get.toList.map(_.trim().toUpperCase())
    val secondLookupRenameCol = relationConfigData.get(relationName + ".second.lookup.column.rename").get.toList.map(_.trim().toUpperCase())

    val autoIncrementColName = relationConfigData.get(relationName + ".autoincrement.column").get(0).trim().toUpperCase()
    var multiRelTypeFlag = relationConfigData.get(relationName + ".multi.reltype.flag").getOrElse("FALSE").toString().trim() //"false"

    log.info("multiRelTypeFlag" + multiRelTypeFlag)

    var addFieldsForAPI = Array[String]()
    var secondLookupRenameColNew = ""
    if (relationName contains "address") {
      addFieldsForAPI = relationConfigData.get(relationName + ".googleapi.column").get.toArray.map(_.toUpperCase())
      secondLookupRenameColNew = relationConfigData.get(relationName + ".second.lookup.column.new").get(0).mkString
    }
    //  secondLookupRenameColNew = relationConfigData.get(relationName + ".second.lookup.column.new").get(0).mkString

    log.info("Relation Function called : " + relationName)

    // Assign the DataFrame Argument to variable
    var mainDF = preProcessedDF.select(mainDataSelectedColumn.head, mainDataSelectedColumn.tail: _*).na.fill(" ")
    var selectedDF = sqlContext.emptyDataFrame
    var xRefDF = sqlContext.emptyDataFrame
    var dimFactDF = sqlContext.emptyDataFrame
    var tagDF = sqlContext.emptyDataFrame

    // selectedDF.showOrNoShow(debugFlag)

    // Fetching the Column Names to be Tag-Value to Join with XREF, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME
    val xRefTagValue = xRefTagValueCols.map(elem => {
      val value = elem.split(":")(1).trim().toUpperCase()
      value
    })

    // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME to Join with XREF
    xRefTagValueCols.map(elem => {
      val cols = elem.split(":")
      mainDF = mainDF.withColumnRenamed(cols(0).trim().toUpperCase(), cols(1).trim().toUpperCase())
    })

    // Tag Value Pair Generation for XREF
    selectedDF = CommonUtils.createMeasureNameValue(mainDF, xRefTagValueColName(0), xRefTagValueColName(1), xRefTagValue)
    // Read RELTYPE Table
    var relTypeTbl = CommonUtils.readFromCsvFile(relTypeTablePath, "true", "true")

    // Read the XREF if the path is NOT NA or NOT Empty
    if ((!xRefDFPath.equalsIgnoreCase("na") || !xRefDFPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(xRefDFPath.replace("*", ""))

      if (fileExist.equalsIgnoreCase("true")) {
        xRefDF = CommonUtils.readFromS3Parquet(xRefDFPath, "true").select(xrefSelectedColumn.head, xrefSelectedColumn.tail: _*).na.fill(" ")
        //xRefDF.showOrNoShow(debugFlag)
      }
    }

    log.info("dim fact path " + dimFactDFPath)
    // Read the DIMFACT if the path is NOT NA or NOT Empty
    if ((!dimFactDFPath.equalsIgnoreCase("na") || !dimFactDFPath.isEmpty())) {
      val fileExist = CommonUtils.isS3FileExists(dimFactDFPath.replace("*", ""))

      if (fileExist.equalsIgnoreCase("true")) {
        dimFactDF = CommonUtils.readFromS3Parquet(dimFactDFPath, "true").na.fill("").select(dimFactSelectedColumn.head, dimFactSelectedColumn.tail: _*).na.fill(" ")
        //dimFactDF.showOrNoShow(debugFlag)
      }
    }

    //===>Create Inter Reltype table for mapping of short rel value to long value and adding long value of reltype to main df

    if (multiRelTypeFlag.==(multiRelTypeFlag)) {
      log.info("entering the multiflag")

      //var key = Array("P:Planmanager", "M:Manager")
      var relTypeMapping = relationConfigData.get(relationName + ".reltype.mapping.column").get.toArray.map(_.toUpperCase())

      var rel_type = relTypeMapping.map(elem => {
        val cols = elem.split(":")
        cols(0)
      })

      rel_type.foreach(println)

      var value = relTypeMapping.map(elem => {
        val cols = elem.split(":")
        cols(1)
      })

      value.foreach(println)

      var reltTypeInterDFSchema = relationConfigData.get(relationName + ".reltype.inter.df.schema").get.toList.map(_.trim().toUpperCase())
      //"rel_type", "value"
      log.info("schema print" + reltTypeInterDFSchema.foreach(println))

      val relTypeInterDf = sc.parallelize(rel_type zip value).toDF(reltTypeInterDFSchema(0), reltTypeInterDFSchema(1)) //relinterDFCols.head,relinterDFCols.tail: _* )
      log.info("inter reldf show" + relTypeInterDf.showOrNoShow(debugFlag))

      var relTypeJoinCol = relationConfigData.get(relationName + ".reltype.inter.join.column").get.toArray.map(_.toUpperCase())
      //var reltypejoincol = Array("rel_type:rel_type")

      var mainDfCol = relTypeJoinCol.map(elem => {
        val cols = elem.split(":")
        cols(0)
      })

      var relTypeCol = relTypeJoinCol.map(elem => {
        val cols = elem.split(":")
        cols(1)
      })
      mainDfCol.foreach(println)
      relTypeCol.foreach(println)

      val joinRelExprs = mainDfCol
        .zip(relTypeCol)
        .map { case (c1, c2) => selectedDF(c1) === relTypeInterDf(c2) }
        .reduce(_ && _)

      log.info("join cols condition" + joinRelExprs)

      tagDF = selectedDF.join(relTypeInterDf, joinRelExprs, "left_outer")
      tagDF = tagDF.drop("REL_TYPE")
      tagDF.showOrNoShow(debugFlag)

    } else {
      // Fetching the Column Names to be Tag-Value, 0 being the Source column, 1 being the Name to be put on AI_MEAUSRE_NAME, col value to be taken from config file
      val tagValue = tagValueCols.map(elem => {
        val value = elem.split(":")(1).trim().toUpperCase()
        value
      })

      // Renaming the Main DF to change the column name which will eventually become AI_MEAUSRE_NAME, values to be taken from config file
      tagValueCols.map(elem => {
        val col = elem.split(":")
        selectedDF = selectedDF.withColumnRenamed(col(0).trim(), col(1).trim())
        col(1).trim()
      })

      // Convert the data into Tag-Value
      tagDF = CommonUtils.createMeasureNameValue(selectedDF, tagValueColName(0), tagValueColName(1), tagValue).na.fill(" ")
    }
    /*
     * First Lookup/Join
     */
    tagDF.showOrNoShow(debugFlag)
    log.info("First Lookup statement called")

    // Renaming the cols to do first Lookup/Join
    firstLookupCols.map(col => {
      val cols = col.split(":")
      tagDF = tagDF.withColumnRenamed(cols(0).trim(), cols(1).trim())

    })
    log.info(" tag prinlnt" + firstLookupCols.foreach(println))

    // Sequence of Join Columns , @Return :: Seq() of Join Columns
    var joinColsFirst = firstLookupCols.map(col => {
      val cols = col.split(":")(1).trim()
      cols
    }).toSeq

    log.info(" first join col " + joinColsFirst.foreach(println))

    // First Lookup/Join with XREF/DIM FACT DF
    var joinedDFOne = sqlContext.emptyDataFrame

    if (firstLookup.equalsIgnoreCase("xref")) {
      joinedDFOne = tagDF.join(xRefDF, joinColsFirst, "inner") //TO-DO Validate the Result
    } else if (firstLookup.equalsIgnoreCase("dimfact")) {
      joinedDFOne = tagDF.join(dimFactDF, joinColsFirst, "inner") //TO-DO Validate the Result

    }

    // Renaming the columns to original name after Joining from XREF/DIMFACT
    firstLookupCols.map(col => {
      val cols = col.split(":")
      joinedDFOne = joinedDFOne.withColumnRenamed(cols(1).trim(), cols(0).trim())
    })

    //joinedDFOne.showOrNoShow(debugFlag)

    // Renaming ID's col if required
    firstLookupRenameCol.map(col => {
      if (!col.equalsIgnoreCase("na")) {
        val cols = col.split(":")
        joinedDFOne = joinedDFOne.withColumnRenamed(cols(0).trim(), cols(1).trim())
      }
    })

    joinedDFOne.persist(StorageLevel.DISK_ONLY_2)

    if (relationName contains "address") {

      joinedDFOne = joinedDFOne.select(joinedDFOne.columns.map {
        x =>
          trim(col(x)).alias(x)
      }: _*)

      var colList = addFieldsForAPI.map(x => col(x))
      joinedDFOne = joinedDFOne.withColumn(secondLookupRenameColNew, trim(concat_ws(" ", colList: _*))) //.select("dim_formatted_address_O")
    }
    log.info("Second Lookup statement called")
    log.info("after col concat show")
    joinedDFOne.showOrNoShow(debugFlag)

    /*
     * Second Lookup/Join
     */

    log.info("Second Lookup statement called")

    // Renaming the cols to do first Lookup/Join

    secondLookupCols.map(col => {
      val cols = col.split(":")
      joinedDFOne = joinedDFOne.withColumnRenamed(cols(0).trim(), cols(1).trim())
    })

    // Sequence of Join Columns, @Return :: Seq() of Join Columns
    val joinColsSecond = secondLookupCols.map(col => {
      val cols = col.split(":")(1).trim()
      cols

    }).toSeq

    // Second Lookup/Join with XREF/DIM FACT DF
    var joinedDFTwo = sqlContext.emptyDataFrame

    if (secondLookup.equalsIgnoreCase("xref")) {
      joinedDFTwo = joinedDFOne.join(xRefDF, joinColsSecond, "inner") // TO-DO Validate the Result
    } else if (secondLookup.equalsIgnoreCase("dimfact")) {
      joinedDFTwo = joinedDFOne.join(dimFactDF, joinColsSecond, "inner") // TO-DO Validate the Result

    }
    //joinedDFTwo.showOrNoShow(debugFlag)

    // Renaming ID's col if required
    secondLookupRenameCol.map(col => {
      if (!col.equalsIgnoreCase("na")) {
        val cols = col.split(":")
        joinedDFTwo = joinedDFTwo.withColumnRenamed(cols(0).trim(), cols(1).trim())
      }
    })

    joinedDFTwo.persist(StorageLevel.DISK_ONLY_2)
    log.info("second df " + joinedDFTwo.showOrNoShow(debugFlag))
    // Renaming Column to do Lookup on RelType Table
    relTypeLookupColumn.map(col => {
      val cols = col.split(":")
      joinedDFTwo = joinedDFTwo.withColumnRenamed(cols(0).trim(), cols(1).trim())
    })

    // Sequence of Join Columns, @Return :: Seq() of Join Columns
    val relTypeJoinCol = relTypeLookupColumn.map(col => {
      val cols = col.split(":")(1).trim()
      cols

    }).toSeq

    var finalDF = sqlContext.emptyDataFrame
    var relTypeDF = sqlContext.emptyDataFrame

    relTypeDF = joinedDFTwo.join(relTypeTbl, relTypeJoinCol, "inner")
    log.info("reltype join" + relTypeDF.showOrNoShow(debugFlag))

    // Sequence ID Generation
    if (!autoIncrementColName.equalsIgnoreCase("na")) {
      finalDF = CommonUtils.addAutoIncremetColumn(relTypeDF, autoIncrementColName)
    } else {
      finalDF = relTypeDF
    }
    // Ordering DF
    finalDF = finalDF.select(relationSchema.head, relationSchema.tail: _*)
    finalDF.showOrNoShow(debugFlag)
    log.info("relationPath : " + relationPath)
    CommonUtils.writeToS3Parquet(finalDF, relationPath, "true", "append")

    joinedDFOne.unpersist()
    joinedDFTwo.unpersist()
    log.info("Relation Function Completed : " + relationName)

  }
}