package com.deloitte.asset.insight.services

import scala.collection.Map
import org.apache.spark.sql.Dataset
import com.deloitte.asset.insight.bean.MatchApprovalBean
import org.apache.spark.sql.Row


trait Merge {
  def mergeDataFromSources(mergeKeyValuesDF: Map[String, List[String]], layerName: String)
  def getEligibleRecordsFromMatchTable(mergeKeyValuesDF: Map[String, List[String]], layerName: String) : Dataset[MatchApprovalBean]
}