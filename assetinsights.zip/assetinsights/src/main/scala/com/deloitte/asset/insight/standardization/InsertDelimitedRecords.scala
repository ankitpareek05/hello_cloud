package com.deloitte.asset.insight.standardization

import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.types._
import scala.collection.mutable.Queue

object InsertDelimitedRecords {
  
  def main(args: Array[String]) {
    
    val inputPathConfig = args(0)
    val env = args(1).toLowerCase()
    val tableName = args(2).toLowerCase()
    val layerName = args(3).toLowerCase()
    
    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    
    val config = CommonUtils.parseConfigFile(inputPathConfig, "NA", "NA", layerName)
      .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na.", "."), x._2) })
      
    val bucketName = config.get(layerName + "." + env +"."+ "bucket.name").get(0)
    val outputPath = bucketName + config.get(layerName + "." + tableName +"."+ "output.path").get(0)
    val inputPath =  bucketName + config.get(layerName + "." + "input.path").get(0)
    val delimiter =  config.get(layerName + "." + "delimiter").get(0)
    val schema = config.get(layerName + "." + tableName +"."+ "schema").get
    var schemaList = Queue[StructField]()
    
    schema.foreach{
      x =>
        val colName = x.split(":")(0)
        val dataType = x.split(":")(1)
        dataType match {
            case "String" => {
              schemaList += StructField(colName,StringType)
            }
            case "Integer" => {
              schemaList +=  StructField(colName,IntegerType)
            }
            case "Double" => {
              schemaList +=  StructField(colName,DoubleType)
            }
            case "Long" => {
              schemaList +=  StructField(colName,LongType)
            }
        }
  
    }
    
    val finalSchema = StructType(schemaList)
    
//    finalSchema.fields.foreach(println)
    
    println("reading data from input path: " + inputPath + " delimited by " + delimiter)

    var inputDf = sparkSession.read
                  .option("delimiter",delimiter)
                  .option("header", "true")
//                  .option("inferSchema", "true")
                  .option("nullValue", "")
                  .option("quote","\u0000")
                  .option("escape","\u0000")
                  .option("multiLine", true)
                  .option("nullValue", null)
                  .option("nullValue", "NULL")
                  .schema(finalSchema)
                  .csv(inputPath)
//                  .csv(inputPath)
                  .na.fill("")
                  
   /* val a = inputDf.groupBy("AI_ADDRESS_ID").count
    a.filter(a("count") > 1).show(false)*/
                  
    inputDf.printSchema()
    inputDf.show(10)
    println(inputDf.count)
    
    println("Writing to path: "+ outputPath)
    CommonUtils.writeToS3Parquet(inputDf, outputPath, "true", "append")
    
  }
  
}