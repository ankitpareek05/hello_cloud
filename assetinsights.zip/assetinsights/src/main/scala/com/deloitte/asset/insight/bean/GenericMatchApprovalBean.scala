package com.deloitte.asset.insight.bean

case class GenericMatchApprovalBean (
  AI_BATCH_ID: String,
  AI_SRC_ID: String,
  AI_EFFECTIVE_DATE: String,
  AI_KNOWLEDGE_DATE: String,
  AI_PARTY_ID: String,
  AI_ORIGINAL_SRC_ID: String,
  AI_ORIGINAL_PARTY_ID: String,
  AI_SRC_ID_MATCHED: String,
  AI_PARTY_ID_MATCHED: String,
  AI_MATCH_ID: String,
  AI_MATCH_RULE_ID: String
)