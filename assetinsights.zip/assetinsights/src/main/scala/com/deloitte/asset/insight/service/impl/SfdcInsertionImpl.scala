package com.deloitte.asset.insight.service.impl

import scala.collection.Map

import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.services.SfdcInsertion
import com.deloitte.asset.insight.operations.SfdcObjectInsertion

class SfdcInsertionImpl extends SfdcInsertion with Logging {

  override def insertObjectToSfdc(sfdcKeyValues: Map[String, List[String]], layerName: String) = {
    val sfdcTables = sfdcKeyValues.get(layerName + ".sfdc.tables.list").get.map(_.trim().toLowerCase().replaceAll("_", "."))

    // calling the sfdc insertion as may times as the number of items in the list
    if (!sfdcTables(0).equalsIgnoreCase("na")) {
      sfdcTables.map(objectName => {
        val sfdcObjectName = layerName + "." + objectName
        log.info("Running sfdc push for : " + sfdcObjectName)
        SfdcObjectInsertion.processSfdcInsertion(sfdcKeyValues, sfdcObjectName)
      })
    } else {
      log.info("===> No SFDC Insertion List Available ")
    }
  }
}