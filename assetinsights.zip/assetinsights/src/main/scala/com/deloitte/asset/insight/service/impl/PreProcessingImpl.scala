package com.deloitte.asset.insight.service.impl
import org.apache.spark.sql.DataFrame

/**
 * <b>Preprocess Object</b>
 * <p>
 * Below Reads Source File from S3 location into a Dataframe and then:
 * </p>
 *
 * 1. Parse Config file in MAP
 * 2. Identify Delta Records
 * 3. PerForm Key Validation
 * 4. Perform Cleansing and Standarization task
 * 5. Add four Core keys
 * 6 Write preprocessed DF into S3
 * </p>
 * @see [[com.deloitte.asset.insight.service.impl.StagingImpl]]
 * @author anpareek
 * @input
 */

import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.services.PreProcessing
import scala.collection.Map
import com.deloitte.asset.insight.utils.DataFrameOperation

class PreProcessingImpl extends PreProcessing with Logging {

  import DataFrameOperation.implicits._
  val debugFlag = GlobalVariables.getDebugFlag
  def processPreprocessingLayer(configData: Map[String, List[String]], layerName: String): DataFrame = {
    val rootPath = GlobalVariables.getRootPath

    val inputPath = rootPath + configData.get(layerName + ".input.path").get(0) //.toLowerCase()
    log.info("Source File Input path: " + inputPath)

    val processedPath = rootPath + configData.get(layerName + ".processed.path").get(0) //.toLowerCase()
    log.info("processedPath is : " + processedPath)

    val knowledgeDateFormat = configData.get(layerName + ".knowledge.date.input.format").getOrElse(List("NA")).mkString.trim()
    log.info("KnowledgeDateFormat is : " + knowledgeDateFormat)

    val effectiveDateFormat = configData.get(layerName + ".effective.date.input.format").getOrElse(List("NA")).mkString.trim()
    log.info("EffectiveDateFormat is : " + knowledgeDateFormat)

    val knowledgeDate = configData.get(layerName + ".map.knowledge.date").getOrElse(List("NA")).mkString.trim()
    log.info("Knowledge data needs to be mapped as: " + knowledgeDateFormat)

    val effectiveDate = configData.get(layerName + ".map.effective.date").getOrElse(List("NA")).mkString.trim()
    log.info("Effective data needs to be mapped as: " + knowledgeDateFormat)

    val keyFieldValidationCol = configData.get(layerName + ".key.field.validation").getOrElse(List("NA")).mkString.trim()
    log.info("Key Validatation column(s) : " + keyFieldValidationCol)

    val subsetColumns = configData.get(layerName + ".map.subset.column").getOrElse(List("NA")).mkString.trim()
    log.info("Subset Column(s) are: " + subsetColumns)

    val timeStamp = CommonUtils.getTimeStamp()
    val processDate = timeStamp._1
    val unxTimeStamp = timeStamp._2

    log.info("Reading Source file from path: " + inputPath)

    var structDataFrame = CommonUtils.readFromCsvFile(inputPath, "true", "false")
    structDataFrame = structDataFrame.toDF(structDataFrame.columns.map(_.toUpperCase()): _*)
    structDataFrame = CommonUtils.replaceNewLine(structDataFrame)
    structDataFrame.showOrNoShow(debugFlag)

    if (!keyFieldValidationCol.equalsIgnoreCase("NA")) {
      log.info("Key Validatation column(s) found in Config file")
      structDataFrame = CommonUtils.getDfAfterKeyValidation(structDataFrame, configData)
    }

    // structDataFrame = CommonUtils.getDeltaDf(structDataFrame, configData)

    //Adding Source ID
    log.info("Adding four Core keys into Source data")
    structDataFrame = CommonUtils.getDfWithSrcId(structDataFrame)
    log.info("Added Source Id into DataFrame")
    //Adding Batch ID
    structDataFrame = CommonUtils.getDFWithBatchId(structDataFrame, unxTimeStamp)
    log.info("Added Batch ID into DataFrame")
    //Adding Effective Date
    structDataFrame = CommonUtils.getDFWithEffDate(structDataFrame, effectiveDate, effectiveDateFormat, processDate)
    log.info("Added Effective Date into DataFrame")
    //Adding Knowledge Date
    structDataFrame = CommonUtils.getDFWithKnowledgeDate(structDataFrame, knowledgeDate, knowledgeDateFormat, processDate)
    log.info("Added Knowledge Date into DataFrame")
    //Adding Process Date
    structDataFrame = CommonUtils.getDFWithProcessedDate(structDataFrame, processDate)

    val ruleAction = configData.keySet.filter(x => x.contains(layerName + ".rule"))
    if (!ruleAction.isEmpty) {
      log.info("Calling Rules Based on Config File")
      val ruleCall = new RuleProcessImpl
      structDataFrame = ruleCall.processUtilityRule(structDataFrame, layerName, configData)

    }
    structDataFrame.showOrNoShow(debugFlag)

    log.info("Preprocessing layer task completed")
    structDataFrame

  }
}