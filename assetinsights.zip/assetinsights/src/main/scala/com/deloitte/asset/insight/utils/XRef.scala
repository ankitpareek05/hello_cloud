package com.deloitte.asset.insight.utils

import scala.collection.Map

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import com.deloitte.asset.insight.services.Logging

object XRef extends Serializable with Logging {

  import DataFrameOperation.implicits._
  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = InitiateSparkContext.getSqlContext()

  def genericXRef(mainDF: DataFrame, xrefName: String, xrefConfigData: Map[String, List[String]]) = {
    //    log.info("Inside Xref")

    val bucketName = GlobalVariables.getRootPath
    val debugFlag = GlobalVariables.getDebugFlag

    val xRefInputS3Path = bucketName + xrefConfigData.get(xrefName + ".input.path").get(0).trim() //.toLowerCase()
    val xRefOutputS3Path = bucketName + xrefConfigData.get(xrefName + ".output.path").get(0).trim() //.toLowerCase()
    val xRefSchema = xrefConfigData.get(xrefName + ".schema").get.toList.map(_.trim().toUpperCase())
    val mainDataSelectedCols = xrefConfigData.get(xrefName + ".main.selected.columns").get.toList.map(_.trim().toUpperCase())
    val tagValueCols = xrefConfigData.get(xrefName + ".tag.value.column").get.toList.map(_.trim().toUpperCase())
    val tagValueColName = xrefConfigData.get(xrefName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    val exceptColumn = xrefConfigData.get(xrefName + ".except.column").get.toList.map(_.trim().toUpperCase())
    val autoIncrementColName = xrefConfigData.get(xrefName + ".autoincrement.column").get(0).trim().toUpperCase()

    log.info("XREF Function called for ===" + xrefName)

    var selectedMainDF = mainDF

    selectedMainDF = selectedMainDF.select(mainDataSelectedCols.head, mainDataSelectedCols.tail: _*)

    // Step:1 Renaming Column for tag-value
    var tagValue: List[String] = List()
    if (!tagValueCols(0).equalsIgnoreCase("NA")) {
      tagValue = tagValueCols.map(cols => {
        var oldCol = cols.split(":")(0)
        var newCol = cols.split(":")(1)

        selectedMainDF = selectedMainDF.withColumnRenamed(oldCol, newCol)
        newCol
      })
    }

    var tagValueDF = CommonUtils.createMeasureNameValue(selectedMainDF, tagValueColName(0), tagValueColName(1), tagValue).na.drop().toDF()

    tagValueDF = tagValueDF.withColumn(tagValueColName(0), hashRemove(col(tagValueColName(0))))

    var arr = Array(tagValueColName(0), tagValueColName(1))
    tagValueDF = tagValueDF.dropDuplicates(arr.head, arr.tail: _*)

    tagValueDF.showOrNoShow(debugFlag)
    val timeStamp = CommonUtils.getTimeStamp()
    val processDate = timeStamp._1
    tagValueDF = tagValueDF.withColumn("AI_EFFECTIVE_DATE", lit(processDate)).withColumn("AI_KNOWLEDGE_DATE", lit(processDate))

    // Step:2 Checking Previous XRef Data
    val fileExist = CommonUtils.isS3FileExists(xRefInputS3Path.replace("*", ""))

    if (fileExist.equalsIgnoreCase("true")) {

      // Step:3 Reading XRef data from S3
      var existingXRefDF = CommonUtils.readFromS3Parquet(xRefInputS3Path, "true")

      var srcIdValue = mainDF.select((substring(col("AI_SRC_ID"), 0, 7))).first().getString(0)

      existingXRefDF = existingXRefDF.filter(col("AI_SRC_ID").startsWith(srcIdValue))

      // Step:4 Selecting Except columns from tag value pair
      var exceptMainDF = tagValueDF.select(exceptColumn.head, exceptColumn.tail: _*)
      var selectedExistingXRefDF = existingXRefDF.select(exceptColumn.head, exceptColumn.tail: _*)

      // Step:5 Except to find out new values
      var exceptNewDF = exceptMainDF.except(selectedExistingXRefDF)
      tagValueDF = exceptNewDF.join(tagValueDF, exceptColumn)
    }

    // Step:6 Adding AutoIncrement columns to the DF
    var finalDF = CommonUtils.addAutoIncremetColumn(tagValueDF, autoIncrementColName)
    finalDF = finalDF.select(xRefSchema.head, xRefSchema.tail: _*)

    finalDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    log.info("Final DF")
    finalDF.showOrNoShow(debugFlag)

    // Step:7 Synonym Column Logic
    val synonymColumn = xrefConfigData.get(xrefName + ".synonym.column").get.toList.map(_.trim().toUpperCase())
    val synonymColumnName = xrefConfigData.get(xrefName + ".synonym.column.name").get.toList.map(_.trim().toUpperCase())
    val synonymColumnLookup = xrefConfigData.get(xrefName + ".synonym.lookup.column").get.toList.map(_.trim().toUpperCase())
    val synonymColumnSubset = xrefConfigData.get(xrefName + ".synonym.subset.column").get.toList.map(_.trim().toUpperCase())
    val synonymColumnUnionRename = xrefConfigData.get(xrefName + ".synonym.union.rename").get.toList.map(_.trim().toUpperCase())

    val synonymSelectedColumn = xrefConfigData.get(xrefName + ".synonym.selected.column").get.toList.map(_.trim().toUpperCase())
    var unionDF: DataFrame = null

    if (!synonymColumn(0).equalsIgnoreCase("na")) {
      var completeDF = mainDF.select(synonymSelectedColumn.head, synonymSelectedColumn.tail: _*)
      log.info("===> Synonym Function called")

      // Step:7.1. Renaming the columns for tag-value
      val tagValueCol = synonymColumn.map(col => {
        val oldCol = col.split(":")(0).trim()
        val newCol = col.split(":")(1).trim()
        completeDF = completeDF.withColumnRenamed(oldCol, newCol)
        newCol
      })

      completeDF.showOrNoShow(debugFlag)
      log.info("Tag_value called synonym")

      var tagValue: DataFrame = null
      if (!synonymColumnName(0).equalsIgnoreCase("na")) {
        tagValue = CommonUtils.createMeasureNameValue(completeDF, synonymColumnName(0), synonymColumnName(1), tagValueCol)
      } else {
        tagValue = completeDF
      }

      // Step:7.2 Renaming the column for Lookup data
      val xreflookup = synonymColumnLookup.map(cols => {
        val oldCol = cols.split(":")(0)
        val newCol = cols.split(":")(1)
        tagValue = tagValue.withColumnRenamed(oldCol, newCol)
        newCol
      }).toSeq

      var joinedDF = tagValue.join(finalDF, xreflookup, "left_outer")
      joinedDF.showOrNoShow(debugFlag)

      // Step:7.3 Subset cols to take out -
      joinedDF = joinedDF.select(synonymColumnSubset.head, synonymColumnSubset.tail: _*).na.drop

      // Step:7.4 Rename for union
      synonymColumnUnionRename.map(cols => {
        val oldCol = cols.split(":")(0)
        val newCol = cols.split(":")(1)
        joinedDF = joinedDF.withColumnRenamed(oldCol, newCol)

      })

      joinedDF = joinedDF.select(xRefSchema.head, xRefSchema.tail: _*)
      log.info("===> Union called synonym")
      unionDF = finalDF.union(joinedDF)

    } else {

      unionDF = finalDF
    }

    log.info("===> XREF DF =" + xrefName)
    unionDF.showOrNoShow(debugFlag)

    //    unionDF.columns.map(cols => {
    //      unionDF = unionDF.withColumn(cols, hashRemove(col(cols)))//.distinct()
    //
    //    })
    //unionDF=unionDF.select("AI_PARTY_ID","ID_NAME","ID_VALUE").distinct().toDF()

    /*
     * Adding Run timestamp and Inactive Flag in data.
     */
    val runTimeStamp = CommonUtils.getTimeStamp()._1
    unionDF = unionDF.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
    CommonUtils.writeToS3Parquet(unionDF, xRefOutputS3Path, "true", "append")
    finalDF.unpersist()
    log.info("===> XREF Completed : " + xrefName)
  }

  def hashRemove = udf((colName: String) => {
    if ((colName != null) && (colName.contains('#'))) {
      colName.split("#").init.mkString
    } else {
      colName
    }

  })

  /**
   * <b>Generic XREF Logic</b>
   * <p>
   * The Generic XREF logic is used to create the Cross
   * Reference Tables of the Party Model.
   * <p>
   * @return Nothing
   * @author  Deloitte
   * @Developer Vishal Agrawal
   * @version 2.0
   * @since   2018-08-07
   */

  def genericXRef_2(mainDF: DataFrame, xrefName: String, xrefConfigData: Map[String, List[String]]) = {

    log.info("XREF Function called for : " + xrefName)
    for ((k, v) <- xrefConfigData) printf("key: %s, value: %s\n", k, v)

    val bucketName = GlobalVariables.getRootPath
    val srcId = GlobalVariables.getSourceId

    val xRefInputPath = bucketName + xrefConfigData.get(xrefName + ".input.path").get(0).trim()
    val xRefOutputPath = bucketName + xrefConfigData.get(xrefName + ".output.path").get(0).trim()
    val xRefSchema = xrefConfigData.get(xrefName + ".schema").get.toList.map(_.trim().toUpperCase())
    val mainDataSelectedCols = xrefConfigData.get(xrefName + ".main.selected.columns").get.toList.map(_.trim().toUpperCase()) // can be removed
    val tagValueColsList = xrefConfigData.get(xrefName + ".tag.value.column").get.toList.map(_.trim().toUpperCase())
    val tagValueColName = xrefConfigData.get(xrefName + ".tag.value.measure.column.name").get.toList.map(_.trim().toUpperCase())
    val exceptColumn = xrefConfigData.get(xrefName + ".except.column").get.toList.map(_.trim().toUpperCase())
    val autoIncrementColName = xrefConfigData.get(xrefName + ".autoincrement.column").get(0).trim().toUpperCase()

    val synonymColumn = xrefConfigData.getOrElse(xrefName + ".synonym.column", List("NA")).map(_.trim().toUpperCase()) //can be changed to synonymcolumn tag value
    val synonymColumnName = xrefConfigData.getOrElse(xrefName + ".synonym.column.name", List("NA")).map(_.trim().toUpperCase())
    val synonymColumnUnionRename = xrefConfigData.getOrElse(xrefName + ".synonym.union.rename", List("NA")).map(_.trim().toUpperCase())

    val debugFlag = xrefConfigData.getOrElse(xrefName + ".debug.flag", List("false"))(0).trim().toUpperCase()

    var selectedMainDF = mainDF
    selectedMainDF.showOrNoShow(debugFlag)

    var existingXRefDF = sqlContext.emptyDataFrame
    var uniqueValueDF = sqlContext.emptyDataFrame
    var unionDF = sqlContext.emptyDataFrame
    var synonymDF = sqlContext.emptyDataFrame

    log.info("Adding Main. prefix to Main Dataframe")
    // Adding prefix MAIN. to the main dataframe

    val mainPrefix = "MAIN_"
    val mainColumnWithPrefix = selectedMainDF.columns.map(cols => mainDF(cols).as(s"$mainPrefix$cols"))
    selectedMainDF = selectedMainDF.select(mainColumnWithPrefix: _*)
    selectedMainDF.showOrNoShow(debugFlag)

    log.info("Checking pre-existing XREF data, if exists")
    val fileExist = CommonUtils.isS3FileExists(xRefInputPath.replace("*", ""))

    if (fileExist.equalsIgnoreCase("true")) {

      log.info("File exists, Reading pre-existing XREF data")
      existingXRefDF = CommonUtils.readFromS3Parquet(xRefInputPath, "true").limit(20).toDF()

      log.info("Persisting the Filtered existing data") // can be removed
      existingXRefDF.persist(StorageLevel.DISK_ONLY_2) // can be removed

      log.info("Filter XREF w.r.t source, first seven digits are source value")
      var srcIdValue = srcId.substring(0, 7)
      existingXRefDF = existingXRefDF.filter(col("AI_SRC_ID").startsWith(srcIdValue))

      log.info("Adding XREF. prefix to XREF Dataframe")
      val xRefPrefix = "PARTYXREF_"
      val xRefColumnWithPrefix = existingXRefDF.columns.map(cols => existingXRefDF(cols).as(s"$xRefPrefix$cols"))
      existingXRefDF = existingXRefDF.select(xRefColumnWithPrefix: _*)
      existingXRefDF.showOrNoShow(debugFlag)

    } else {
      log.info("File doesnot exists, continuing with Main data to build XREF")
    }

    // Step:1 Renaming Column for tag-value
    var tagValueColumns: List[String] = List()
    if (!tagValueColsList(0).equalsIgnoreCase("NA")) {
      tagValueColumns = tagValueColsList.map(cols => {
        var oldCol = cols.split(":")(0)
        var newCol = cols.split(":")(1)

        selectedMainDF = selectedMainDF.withColumnRenamed(oldCol, newCol)
        newCol
      })
    }
    selectedMainDF.showOrNoShow(debugFlag)
    // Tag Value pair for XREF Creation
    log.info("Tag Value Creation for XREF")
    var tagValueDF = CommonUtils.createMeasureNameValue(selectedMainDF, tagValueColName(0), tagValueColName(1), tagValueColumns)

    // Removing the hash from the column name if any
    log.info("Removing the last # from the MEASURE_NAME column, if being used during tag-value")
    tagValueDF = tagValueDF.withColumn(tagValueColName(0), hashRemove(col(tagValueColName(0))))

    tagValueDF.showOrNoShow(debugFlag)
    tagValueDF = tagValueDF.distinct() /// need to check the requirement of this distinct

    if (fileExist.equalsIgnoreCase("true")) {
      log.info("Left_anti join with pre-existing XREF to get the Unique values")

      val joinXrefExprs = exceptColumn.map(cols => {
        val leftCol = cols.split(":")(0)
        val rightCol = cols.split(":")(1)
        (tagValueDF(leftCol) === existingXRefDF(rightCol))
      }).reduce(_ && _)

      tagValueDF = tagValueDF.join(existingXRefDF, joinXrefExprs, "left_anti")
      tagValueDF.showOrNoShow(debugFlag)
    } else {
      log.info("No Pre-existing DF, taking full values from file to build XREF")
    }

    // Adding autoIncrement column
    log.info("Adding AutoIncrement Column")
    tagValueDF = CommonUtils.addAutoIncremetColumn(tagValueDF, autoIncrementColName)

    log.info("Persist the Dataframe in DISK_ONLY_2 MODE")
    tagValueDF.persist(StorageLevel.DISK_ONLY_2)

    tagValueDF.showOrNoShow(debugFlag)

    //Selecting the data with xref schema
    log.info("Dataframe with selected columns related to XREF Schema")
    var finalDF = tagValueDF.select(xRefSchema.head, xRefSchema.tail: _*) // will fail because of Main.prefix
    finalDF.showOrNoShow(debugFlag)

    // Synonym Column Logic----
    if ((!synonymColumn(0).equalsIgnoreCase("NA")) && (!synonymColumnName(0).equalsIgnoreCase("NA")) && (!synonymColumnUnionRename(0).equalsIgnoreCase("na"))) {

      log.info("Synonym Columns are present on the data, running code to incorporate synonym columns with XREF")
      val synonymTagValueCol = synonymColumn.map(col => {
        val oldCol = col.split(":")(0).trim()
        val newCol = col.split(":")(1).trim()
        tagValueDF = tagValueDF.withColumnRenamed(oldCol, newCol)
        newCol
      })

      // Tag -Value synonym Columns

      log.info("Tag Value Creation for Synonym Columns")
      synonymDF = CommonUtils.createMeasureNameValue(tagValueDF, synonymColumnName(0), synonymColumnName(1), synonymTagValueCol)

      log.info("Removing the last # from the MEASURE_NAME column, if being used during tag-value")
      synonymDF = synonymDF.withColumn(synonymColumnName(0), hashRemove(col(synonymColumnName(0))))

      log.info("Persist the Dataframe in DISK_ONLY_2 MODE")
      synonymDF.persist(StorageLevel.DISK_ONLY_2)
      synonymDF.showOrNoShow(debugFlag)

      val synonymUnionColumn = synonymColumnUnionRename.map(x => x.split(":")(0))
      synonymDF = synonymDF.select(synonymUnionColumn.head, synonymUnionColumn.tail: _*)

      log.info("Renaming Columns for UNION of Data")
      synonymColumnUnionRename.map(cols => {
        val oldCol = cols.split(":")(0)
        val newCol = cols.split(":")(1)
        synonymDF = synonymDF.withColumnRenamed(oldCol, newCol)
      })

      synonymDF.showOrNoShow(debugFlag)

      synonymDF = synonymDF.select(xRefSchema.head, xRefSchema.tail: _*) // might fail due to MAIN. prefix
      unionDF = finalDF.union(synonymDF)
      unionDF.showOrNoShow(debugFlag)

    } else {
      log.info("No Synonym Column in Data")
      unionDF = finalDF
    }

    unionDF.showOrNoShow(debugFlag)

    //    CommonUtils.writeToS3Parquet(unionDF, xRefOutputPath, "true", "append")
    tagValueDF.unpersist()
    synonymDF.unpersist()
    log.info("XREF Completed : " + xrefName)

  }

}