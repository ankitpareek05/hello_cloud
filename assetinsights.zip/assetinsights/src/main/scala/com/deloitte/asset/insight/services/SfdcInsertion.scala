package com.deloitte.asset.insight.services

import scala.collection.Map

trait SfdcInsertion {
  def insertObjectToSfdc(sfdcKeyValuesDF: Map[String, List[String]], layerName: String)
}