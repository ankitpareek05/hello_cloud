package com.deloitte.asset.insight

import org.apache.log4j.Logger
import com.deloitte.asset.insight.service.impl.SfdcExtractionImpl
import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.service.impl.MergeImpl
import scala.collection.immutable.Map

object MergeDriver {
  case class ConfigException(errorMessage: String, errorCode: String) extends Exception(errorMessage)
  private[this] val LOGGER = Logger.getLogger(getClass())

  def main(args: Array[String]) {
    LOGGER.info("MERGE Driver")
    LOGGER.info("Initiating Spark Application")

    val sparkSession = InitiateSparkContext.getSparkSession()

    // Path of parent Config file
    try {
      /*
      val config = "C:/AssetInsightsDocuments/Merge/Corrections/MergeConfig_Oct_07_18.csv"
      val fileName = "CONTACT"
      val sourceName = "TIAA_SALESFORCE"
      val layerName = "STANDARDIZATION".toLowerCase()
      val debugFlag = "true"*/

      
      val debugFlag = args(4).toLowerCase()
      val config = args(0)
      val fileName = args(1).toUpperCase()
      val sourceName = args(2).toUpperCase()
      val layerName = args(3).toLowerCase()
			
      LOGGER.info("***Logging Started for file: " + fileName + "***")
      LOGGER.info("Loading Config file")
      val mergeConfigData = CommonUtils.parseConfigFile(config, fileName, sourceName, layerName)
        .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })

      var merge: MergeImpl = new MergeImpl()
      
      // Calling Merge Functionality
      merge.mergeDataFromSources(mergeConfigData, layerName)
      

    } catch {
      case ex: ConfigException => {
        LOGGER.error(ex.errorCode + " - " + ex.errorMessage)
      }
      case ex: Exception => {
        ex.printStackTrace()
        LOGGER.error(ex.getMessage)
      }
    }
  }
}