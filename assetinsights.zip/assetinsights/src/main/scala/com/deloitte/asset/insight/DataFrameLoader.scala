package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.CommonUtils

object DataFrameLoader {
  def main(args: Array[String]) = {
    var df = CommonUtils.readFromCsvFile(args(0), "true", "false")
    df = CommonUtils.replaceNewLine(df)
    CommonUtils.writeToS3Parquet(df, args(1), "true", "overwrite")
  }
}