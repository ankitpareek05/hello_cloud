package test

import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.geocoding.api.GoogleAPI
import org.json.simple.JSONObject
import org.json.simple.parser.JSONParser
import org.json.simple.JSONArray
import org.apache.spark.sql.Row
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import com.deloitte.asset.insight.utils.CommonUtils
import org.apache.spark.sql.types.IntegerType

case class AddressComponent2(
  ai_address_id:String,
  formatted_address_o:String,
  partial_match:               String,
  formattedAddress:            String,
  status:                      String,
  error_message:               String,
  subpremise : String,
premise : String,
streetNumber : String,
route : String,
neighborhood : String,
locality : String,
sublocality  : String,
administrative_area_level_5 : String,
administrative_area_level_4 : String,
administrative_area_level_3 : String,
administrative_area_level_2 : String,
administrative_area_level_1 : String,
country : String,
postal_code : String,
postal_code_suffix : String,
intersection : String,
political : String,
colloquial_area : String,
natural_feature : String,
airport  : String,
park : String,
point_of_interest : String,
floor : String,
establishment : String,
parking : String,
post_box : String,
postal_town : String,
room : String,
bus_station : String,
train_station : String,
transit_station : String,
street_address:String,
latitude:String,
longitude:String
  )
  extends Product with Serializable {
  def canEqual(that: Any) = that.isInstanceOf[AddressComponent2]

  def productArity = 39

  def productElement(id: Int) = id match {

    case 0  => ai_address_id
    case 1  => formatted_address_o
    case 2  => partial_match
    case 3  => formattedAddress
    case 4  => status
    case 5  => error_message
    case 6  => subpremise
    case 7  => premise
    case 8  => streetNumber
    case 9  => route
    case 10 => neighborhood
    case 11 => locality
    case 12 => sublocality
    case 13 => administrative_area_level_5
    case 14 => administrative_area_level_4
    case 15 => administrative_area_level_3
    case 16 => administrative_area_level_2
    case 17 => administrative_area_level_1
    case 18 => country
    case 19 => postal_code
    case 20 => postal_code_suffix
    case 21 => intersection
    case 22 => political
    case 23 => colloquial_area
    case 24 => natural_feature
    case 25 => airport
    case 26 => park
    case 27 => point_of_interest
    case 28 => floor
    case 29 => establishment
    case 30 => parking
    case 31 => post_box
    case 32 => postal_town
    case 33 => room
    case 34 => bus_station
    case 35 => train_station
    case 36 => transit_station
    case 37 => street_address
    case 38 => latitude
    case 39 => longitude

  }
}

  
  
  
  /*{

  override def toString(): String = {
    val CTRL_A = "\u0001"
    val DELM = CTRL_A

    var addressComponents = partial_match + DELM + formattedAddress + DELM +
      status + DELM +
      error_message + DELM +
      streetNumber + DELM +
      route + DELM +
      locality + DELM +
      administrative_area_level_2 + DELM +
      administrative_area_level_1 + DELM +
      country + DELM +
      postal_code + DELM +
      postal_code_suffix + DELM +
      latitude + DELM +
      longitude + DELM +
      sub_premise + DELM +
      premise

    return addressComponents
  }
}*/

object jsonConversion {
  def main(args: Array[String]) {
    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    val sqlContext = InitiateSparkContext.getSqlContext()
    
     val Schema = StructType(Array(
StructField("ai_address_id",StringType,false),
StructField("formatted_address_o",StringType,false),
StructField("partial_match",StringType,false),
StructField("formattedAddress",StringType,false),
StructField("status",StringType,false),
StructField("error_message",StringType,false),
StructField("subpremise_sn",StringType,false),
StructField("subpremise",StringType,false),
StructField("premise_sn",StringType,false),
StructField("premise",StringType,false),
StructField("streetNumber_sn",StringType,false),
StructField("streetNumber",StringType,false),
StructField("route_sn",StringType,false),
StructField("route",StringType,false),
StructField("neighborhood_sn",StringType,false),
StructField("neighborhood",StringType,false),
StructField("locality_sn",StringType,false),
StructField("locality",StringType,false),
StructField("sublocality_level_1_sn",StringType,false),
StructField("sublocality_level_1",StringType,false),
StructField("sublocality_level_2_sn",StringType,false),
StructField("sublocality_level_2",StringType,false),
StructField("sublocality_level_3_sn",StringType,false),
StructField("sublocality_level_3",StringType,false),
StructField("sublocality_level_4_sn",StringType,false),
StructField("sublocality_level_4",StringType,false),
StructField("sublocality_level_5_sn",StringType,false),
StructField("sublocality_level_5",StringType,false),
StructField("administrative_area_level_5",StringType,false),
StructField("administrative_area_level_5_ln",StringType,false),
StructField("administrative_area_level_4",StringType,false),
StructField("administrative_area_level_4_ln",StringType,false),
StructField("administrative_area_level_3",StringType,false),
StructField("administrative_area_level_3_ln",StringType,false),
StructField("administrative_area_level_2",StringType,false),
StructField("administrative_area_level_2_ln",StringType,false),
StructField("administrative_area_level_1",StringType,false),
StructField("administrative_area_level_1_ln",StringType,false),
StructField("country",StringType,false),
StructField("country_ln",StringType,false),
StructField("postal_code_sn",StringType,false),
StructField("postal_code",StringType,false),
StructField("postal_code_suffix_sn",StringType,false),
StructField("postal_code_suffix",StringType,false),
StructField("intersection_sn",StringType,false),
StructField("intersection",StringType,false),
StructField("political_sn",StringType,false),
StructField("political",StringType,false),
StructField("colloquial_area_sn",StringType,false),
StructField("colloquial_area",StringType,false),
StructField("natural_feature_sn",StringType,false),
StructField("natural_feature",StringType,false),
StructField("airport_sn",StringType,false),
StructField("airport",StringType,false),
StructField("park_sn",StringType,false),
StructField("park",StringType,false),
StructField("point_of_interest_sn",StringType,false),
StructField("point_of_interest",StringType,false),
StructField("floor_sn",StringType,false),
StructField("floor",StringType,false),
StructField("establishment_sn",StringType,false),
StructField("establishment",StringType,false),
StructField("parking_sn",StringType,false),
StructField("parking",StringType,false),
StructField("post_box_sn",StringType,false),
StructField("post_box",StringType,false),
StructField("postal_town_sn",StringType,false),
StructField("postal_town",StringType,false),
StructField("room_sn",StringType,false),
StructField("room",StringType,false),
StructField("bus_station_sn",StringType,false),
StructField("bus_station",StringType,false),
StructField("train_station_sn",StringType,false),
StructField("train_station",StringType,false),
StructField("transit_station_sn",StringType,false),
StructField("transit_station",StringType,false),
StructField("street_address_sn",StringType,false),
StructField("street_address",StringType,false),
StructField("latitude",StringType,false),
StructField("longitude",StringType,false),
StructField("row_id",IntegerType,false)
))
    
    
    val df = sparkContext.textFile("src//main//resources//part-00000_corrupt_records.txt")
    val jsonPared = df.map{
      x =>
        /*var parser = new JSONParser()

      var jsonObj: JSONObject = parser.parse(x).asInstanceOf[JSONObject]
      println(jsonObj)*/
      val test = parseJsonResponse2(x)
      test
    }.flatMap(data => data)
    
    var updatedDF = sparkSession.createDataFrame(jsonPared,Schema)
    
    updatedDF.show(10,false)
    
    //updatedDF.where(updatedDF("row_id")===2).show()
    
     updatedDF.write.parquet("src//main//resources//addparse10//")
    
    
  }
  
  def parseJsonResponse2(jsonResponse: String): List[Row] = {
    var partial_match = "false"
    var ai_address_id = ""
    var formatted_address_o = ""
    
  

    // Status of Google API response & List of suggested addresses
    var status = ""
    var errorMessage = ""
    var addressList = List[Row]()

    try {
      // JSON parser for parsing JSON response, received from Google API
      var parser = new JSONParser()

      var fullObj: JSONObject = parser.parse(jsonResponse).asInstanceOf[JSONObject]

      var row = Row()
      var row_id:Int=0
      
      ai_address_id = fullObj.get("ai_address_id").toString()
      
      formatted_address_o = fullObj.get("formatted_address_o").toString()
      
      val jsonObj = fullObj.get("api_response").asInstanceOf[JSONObject]
      if(!jsonObj.isEmpty()){ 
      status = jsonObj.get("status").toString()
      
//      status = "For making -2 records"

      if (jsonObj.keySet().contains("error_message"))
        errorMessage = jsonObj.get("error_message").toString()

      var suggestedAddressArray = jsonObj.get("results").asInstanceOf[JSONArray]

      var suggestedAddressIterator = suggestedAddressArray.iterator()

      while (suggestedAddressIterator.hasNext()) {
          
         var s_subpremise = ""
    var s_premise = ""
    var s_streetNumber = ""
    var s_route = ""
    var s_neighborhood = ""
    var s_locality = ""
    var s_sublocality_level_1  = ""
    var s_sublocality_level_2  = ""
    var s_sublocality_level_3  = ""
    var s_sublocality_level_4  = ""
    var s_sublocality_level_5  = ""
    var s_administrative_area_level_5 = ""
    var s_administrative_area_level_4 = ""
    var s_administrative_area_level_3 = ""
    var s_administrative_area_level_2 = ""
    var s_administrative_area_level_1 = ""
    var s_country = ""
    var s_postal_code = ""
    var s_postal_code_suffix = ""
    var s_intersection = ""
    var s_political = ""
    var s_colloquial_area = ""
    var s_natural_feature = ""
    var s_airport  = ""
    var s_park = ""
    var s_point_of_interest = ""
    var s_floor = ""
    var s_establishment = ""
    var s_parking = ""
    var s_post_box = ""
    var s_postal_town = ""
    var s_room = ""
    var s_bus_station = ""
    var s_train_station = ""
    var s_transit_station = ""
    var s_street_address = ""

    var l_subpremise = ""
    var l_premise = ""
    var l_streetNumber = ""
    var l_route = ""
    var l_neighborhood = ""
    var l_locality = ""
    var l_sublocality_level_1  = ""
    var l_sublocality_level_2  = ""
    var l_sublocality_level_3  = ""
    var l_sublocality_level_4  = ""
    var l_sublocality_level_5  = ""
    var l_administrative_area_level_5 = ""
    var l_administrative_area_level_4 = ""
    var l_administrative_area_level_3 = ""
    var l_administrative_area_level_2 = ""
    var l_administrative_area_level_1 = ""
    var l_country = ""
    var l_postal_code = ""
    var l_postal_code_suffix = ""
    var l_intersection = ""
    var l_political = ""
    var l_colloquial_area = ""
    var l_natural_feature = ""
    var l_airport  = ""
    var l_park = ""
    var l_point_of_interest = ""
    var l_floor = ""
    var l_establishment = ""
    var l_parking = ""
    var l_post_box = ""
    var l_postal_town = ""
    var l_room = ""
    var l_bus_station = ""
    var l_train_station = ""
    var l_transit_station = ""
    var l_street_address = ""
    
    var formattedAddress = ""
    

    var latitude = ""
    var longitude = "" 
        

        var suggestedAddress = suggestedAddressIterator.next().asInstanceOf[(JSONObject)]

        var addCompArray = suggestedAddress.get("address_components").asInstanceOf[JSONArray]

        var addCompIterator = addCompArray.iterator()
        

        while (addCompIterator.hasNext()) {

          var addressComponent = addCompIterator.next().asInstanceOf[(JSONObject)]
          
          

          var types = ""
//          if(addressComponent.get("types").asInstanceOf[JSONArray].size() > 0){
//          types = addressComponent.get("types").asInstanceOf[JSONArray].get(0).toString()
//          }
          
          if(addressComponent.get("types").asInstanceOf[JSONArray].size() > 0)
          {
            if(addressComponent.get("types").asInstanceOf[JSONArray].size ==1 && addressComponent.get("types").asInstanceOf[JSONArray].contains("political"))
            {
              types = addressComponent.get("types").asInstanceOf[JSONArray].get(0).toString()
            }
            
            else if( addressComponent.get("types").asInstanceOf[JSONArray].contains("political") && addressComponent.get("types").asInstanceOf[JSONArray].size >1)
            {
              if(!addressComponent.get("types").asInstanceOf[JSONArray].get(0).toString().startsWith("poli"))
              {
                types = addressComponent.get("types").asInstanceOf[JSONArray].get(0).toString()
              }
              else
              {
                types = addressComponent.get("types").asInstanceOf[JSONArray].get(addressComponent.get("types").asInstanceOf[JSONArray].size()-1).toString()
              }
            }
            else
            types = addressComponent.get("types").asInstanceOf[JSONArray].get(0).toString()
            
          }
          
          var shortName = addressComponent.get("short_name").toString()
          var longName = addressComponent.get("long_name").toString()
          //log.info("shortName : " + shortName)
          
          //addressComponent.get("types").asInstanceOf[JSONArray].size()

          types match {
            case "subpremise" => {
              s_subpremise = shortName
              l_subpremise = longName
            }
            case "premise" => {
              s_premise = shortName
              l_premise = longName
            }
            case "street_number" => {
              s_streetNumber = shortName
              l_streetNumber = longName
            }
            case "route" => {
              s_route = shortName
              l_route = longName
            }
            case "neighborhood" => {
              s_neighborhood = shortName
              l_neighborhood = longName
            }
            case "locality" => {
              s_locality = shortName
              l_locality = longName
            }
            case "sublocality_level_1" => {
              s_sublocality_level_1 = shortName
              l_sublocality_level_1 = longName
            }
            case "sublocality_level_2" => {
              s_sublocality_level_2 = shortName
              l_sublocality_level_2 = longName
            }
            case "sublocality_level_3" => {
              s_sublocality_level_3 = shortName
              l_sublocality_level_3 = longName
            }
            case "sublocality_level_4" => {
              s_sublocality_level_4 = shortName
              l_sublocality_level_4 = longName
            }
            case "sublocality_level_5" => {
              s_sublocality_level_5 = shortName
              l_sublocality_level_5 = longName
            }
            
            case "administrative_area_level_5" => {
              s_administrative_area_level_5 = shortName
              l_administrative_area_level_5 = longName
            }
            case "administrative_area_level_4" => {
              s_administrative_area_level_4 = shortName
              l_administrative_area_level_4 = longName
            }
            case "administrative_area_level_3" => {
              s_administrative_area_level_3 = shortName
              l_administrative_area_level_3 = longName
            }
            case "administrative_area_level_2" => {
              s_administrative_area_level_2 = shortName
              l_administrative_area_level_2 = longName
            }
            case "administrative_area_level_1" => {
              s_administrative_area_level_1 = shortName
              l_administrative_area_level_1 = longName
            }
            case "country" => {
              s_country = shortName
              l_country = longName
            }
            case "postal_code" => {
              s_postal_code = shortName
              l_postal_code = longName
            }
            case "postal_code_suffix" => {
              s_postal_code_suffix = shortName
              l_postal_code_suffix = longName
            }
            case "political" => {
              s_political = shortName
              l_political = longName
            }
            case "intersection" => {
              s_intersection = shortName
              l_intersection = longName
            }
            case "colloquial_area" => {
              s_colloquial_area = shortName
              l_colloquial_area = longName
            }
            case "natural_feature" => {
              s_natural_feature = shortName
              l_natural_feature = longName
            }
            case "airport" => {
              s_airport = shortName
              l_airport = longName
            }
            case "park" => {
              s_park = shortName
              l_park = longName
            }
            case "point_of_interest" => {
              s_point_of_interest = shortName
              l_point_of_interest = longName
            }
            case "floor" => {
              s_floor = shortName
              l_floor = longName
            }
            case "establishment" => {
              s_establishment = shortName
              l_establishment = longName
            }
            case "parking" => {
              s_parking = shortName
              l_parking = longName
            }
            case "post_box" => {
              s_post_box = shortName
              l_post_box = longName
            }
            case "postal_town" => {
              s_postal_town = shortName
              l_postal_town = longName
            }
            case "room" => {
              s_room = shortName
              l_room = longName
            }
            case "bus_station" => {
              s_bus_station = shortName
              l_bus_station = longName
            }
            case "train_station" => {
              s_train_station = shortName
              l_train_station = longName
            }
            case "transit_station" => {
              s_transit_station = shortName
              l_transit_station = longName
            }
            case "street_address" => {
              s_street_address = shortName
              l_street_address = longName
            }

            case _ => //log.info("No match found for : " + types)
          }
        }

        formattedAddress = suggestedAddress.get("formatted_address").toString()
        if(suggestedAddress.keySet().contains("partial_match")){
        partial_match = suggestedAddress.get("partial_match").toString()

        }
          
        var latLongDetails = suggestedAddress.get("geometry").asInstanceOf[JSONObject].get("location").asInstanceOf[JSONObject]

        latitude = latLongDetails.get("lat").toString()
        longitude = latLongDetails.get("lng").toString()
        row_id=row_id+1
        row =Row(ai_address_id,formatted_address_o,partial_match,formattedAddress,status,errorMessage,s_subpremise,l_subpremise,s_premise,l_premise,s_streetNumber,l_streetNumber,s_route,l_route,s_neighborhood,l_neighborhood,s_locality,l_locality,s_sublocality_level_1,l_sublocality_level_1,s_sublocality_level_2,l_sublocality_level_2,s_sublocality_level_3,l_sublocality_level_3,s_sublocality_level_4,l_sublocality_level_4,s_sublocality_level_5,l_sublocality_level_5,s_administrative_area_level_5,l_administrative_area_level_5,s_administrative_area_level_4,l_administrative_area_level_4,s_administrative_area_level_3,l_administrative_area_level_3,s_administrative_area_level_2,l_administrative_area_level_2,s_administrative_area_level_1,l_administrative_area_level_1,s_country,l_country,s_postal_code,l_postal_code,s_postal_code_suffix,l_postal_code_suffix,s_intersection,l_intersection,s_political,l_political,s_colloquial_area,l_colloquial_area,s_natural_feature,l_natural_feature,s_airport,l_airport,s_park,l_park,s_point_of_interest,l_point_of_interest,s_floor,l_floor,s_establishment,l_establishment,s_parking,l_parking,s_post_box,l_post_box,s_postal_town,l_postal_town,s_room,l_room,s_bus_station,l_bus_station,s_train_station,l_train_station,s_street_address,l_street_address,s_transit_station,l_transit_station,latitude,longitude,row_id) 
        //row = Row(ai_address_id,formatted_address_o,partial_match,formattedAddress,status,errorMessage,l_subpremise,l_premise,l_streetNumber,l_route,l_neighborhood,l_locality,l_sublocality_level_1,l_sublocality_level_2,l_sublocality_level_3,l_sublocality_level_4,l_sublocality_level_5,s_administrative_area_level_5,s_administrative_area_level_4,s_administrative_area_level_3,s_administrative_area_level_2,s_administrative_area_level_1,s_country,l_postal_code,l_postal_code_suffix,l_intersection,l_political,l_colloquial_area,l_natural_feature,l_airport ,l_park,l_point_of_interest,l_floor,l_establishment,l_parking,l_post_box,l_postal_town,l_room,l_bus_station,l_train_station,l_transit_station,l_street_address,latitude,longitude)
        addressList = addressList :+ row
      }}

      
      
//     println(row.get(0))
//     row
      
      
    } catch {
      case ex: Exception => ex.getMessage()
//      return Row()
    }
    println(addressList.length)
    return addressList
  }
}