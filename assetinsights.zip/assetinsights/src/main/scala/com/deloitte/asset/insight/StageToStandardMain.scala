package com.deloitte.asset.insight

import com.deloitte.asset.insight.service.impl.StandardizationImpl
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.services.Standardization
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext

object StageToStandardMain extends Logging {

  def main(args: Array[String]) = {

    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    val sqlContext = InitiateSparkContext.getSqlContext()

    /*    val inputPathConfig = "src\\main\\resources\\MMRELATIONS.csv"
    val layerName = "STANDARDIZATION".toLowerCase()*/
    val fileName: String = "NA"
    val srcName: String = "NA"

    val inputPathConfig = args(0)
    val layerName = args(1)

    if (args.length == 3) {
      GlobalVariables.setDebugFlag(args(2))
    } else {
      log.info("Debug Level is set to FALSE")
      GlobalVariables.setDebugFlag("false")
    }

    try {
      log.info("------- Into Stage to Standardization -------")
      val stageToStandardConfigData = CommonUtils.parseConfigFile(inputPathConfig, fileName, srcName, layerName = layerName)
        .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na.", "."), x._2) })

      val stageToStandard: Standardization = new StandardizationImpl

      stageToStandard.stageToStandardization(stageToStandardConfigData)
    } catch {
      case e: Exception =>
        log.error("Process Failed, see below for error")
        e.printStackTrace()
        System.exit(1)
    }

  }

}