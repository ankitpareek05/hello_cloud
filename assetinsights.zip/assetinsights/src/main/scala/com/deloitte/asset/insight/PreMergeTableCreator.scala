package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.CommonUtils
import org.apache.spark.sql.types.StructType

import org.apache.spark.sql.types.StructField

import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.LongType

object PreMergeTableCreator {
  def main(args: Array[String]) = {
    var df = CommonUtils.readFromCsvFile(args(0), "true", "false")
     
    //df = CommonUtils.replaceNewLine(df)
    
    
    val schema = StructType(Array(
    StructField("AI_MATCH_ID",               DataTypes.StringType,true),
    StructField("AI_MATCH_RULE_ID",          DataTypes.StringType,true),
    StructField("AI_EFFECTIVE_DATE",         DataTypes.StringType,true),
    StructField("AI_SRC_ID",                 DataTypes.StringType,true),
    StructField("AI_PARTY_ID",               DataTypes.StringType,true),
    StructField("AI_EFFECTIVE_DATE_MATCHED", DataTypes.StringType,true),
    StructField("AI_SRC_ID_MATCHED",         DataTypes.StringType,true),
    StructField("AI_PARTY_ID_MATCHED",       DataTypes.StringType,true),
    StructField("AI_MERGE_ACTION",           DataTypes.IntegerType,true)))
    //StructField("AI_RUN_DATETIME",           StringType,true)))
    df.printSchema()
    if(args(2).equals("PRE_MERGE"))
      df = df.withColumn("AI_MERGE_ACTION", df.col("AI_MERGE_ACTION").cast(IntegerType))
    else
      df = df.withColumn("AI_BATCH_ID", df.col("AI_BATCH_ID").cast(LongType)).withColumn("REL_TYPE",df.col("REL_TYPE").cast(IntegerType)).withColumn("INACTIVE_FLAG", df.col("INACTIVE_FLAG").cast(IntegerType))
    CommonUtils.writeToS3Parquet(df, args(1), "true", "overwrite")
  }
}