package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.EndDatingUtility
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import java.text.SimpleDateFormat
import java.util.Date

object EndDatingDriver {
  def main(args: Array[String]) {
    try {
      /*val config = "C:/AssetInsightsDocuments/Merge/Corrections/EndDatingConfig.csv"
      val fileName = "COMPANY"
      val sourceName = "NA"
      val layerName = "STANDARDIZATION".toLowerCase()
      val debugFlag = "true"*/

      
      val debugFlag = args(4).toLowerCase()
      val config = args(0)
      val fileName = args(1).toUpperCase()
      val sourceName = args(2).toUpperCase()
      val layerName = args(3).toLowerCase()
      

      val mergeConfigData = CommonUtils.parseConfigFile(config, fileName, sourceName, layerName)
        .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })
      val endDatingUtility = new EndDatingUtility()
      val sourceIdFilePath = GlobalVariables.getRootPath + mergeConfigData.get(layerName + ".source.id.csv.path").get(0)
      val dimPartyTablePath = GlobalVariables.getRootPath + mergeConfigData.get(layerName + ".dimension.party.input.path").get(0)
      val matchTable = mergeConfigData.get(layerName + ".ai.match.output.match.table").get.map(_.trim())
      val objectNames = mergeConfigData.get(layerName + ".merge.tables.list").get.toList
      val matchTablePath = GlobalVariables.getRootPath + "/" + matchTable(0)
      val updateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
      val folderFormat = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss")
      val inactivationDate = updateFormat.format(new Date())
      val folderDate = folderFormat.format(new Date())
      // Uncomment below 2 lines when SRC PARTY ID is given. Comment the line below these 2 lines
      //val sourcePartyIds = endDatingUtility.getSourcePartyIds(sourceIdFilePath)
      //val partyIdTable = endDatingUtility.getPartyIdsFromSourceIds(sourcePartyIds, dimPartyTablePath)
      
      // Comment the below line when using Party IDs
      val partyIdTable = endDatingUtility.getPartyIdsFromCSV(sourceIdFilePath)
      
      val unMergedRecords = endDatingUtility.getRecordsPostMerge(partyIdTable, matchTablePath)
      
      objectNames.map(objectName => {
          val tableName = objectName.toLowerCase().replace("_", ".")
          val tablePath = GlobalVariables.getRootPath + "/" + mergeConfigData.get(layerName + "." + tableName + ".input.path").get(0)  
          endDatingUtility.inactivateRecords(partyIdTable, tablePath, folderDate, inactivationDate)
        }
      )
      
      
    } catch {
      case e: Exception => e.printStackTrace()
    }
  }
}