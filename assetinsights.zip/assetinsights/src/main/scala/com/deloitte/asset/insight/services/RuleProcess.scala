package com.deloitte.asset.insight.services

import org.apache.spark.sql.DataFrame
import scala.collection.Map
trait RuleProcess {

  def processFinancialRule(mainDF: DataFrame, inputPathConfig: String): DataFrame

 def processKeyValidationRule(mainDF: DataFrame, configFile: Map[String, List[String]]): DataFrame
  
  def processDimFieldStandardization(mainDF: DataFrame,dimLayer:String, inputConfigData: Map[String, List[String]]): DataFrame
  
  def processFactFieldStandardization(mainDF: DataFrame,dimLayer:String, inputConfigData: Map[String, List[String]]): DataFrame

  def processCleanseRule(mainDF: DataFrame, inputPathConfig: String): DataFrame
  
  def processUtilityRule(mainDF:DataFrame,layerName:String, inputConfigData: Map[String, List[String]]):DataFrame

}