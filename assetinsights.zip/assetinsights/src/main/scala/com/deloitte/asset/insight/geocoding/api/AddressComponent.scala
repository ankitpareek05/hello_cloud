package com.deloitte.asset.insight.geocoding.api

case class AddressComponent(
  partial_match:               String,
  formattedAddress:            String,
  status:                      String,
  error_message:               String,
  streetNumber:                String,
  route:                       String,
  locality:                    String,
  administrative_area_level_2: String,
  administrative_area_level_1: String,
  country:                     String,
  postal_code:                 String,
  postal_code_suffix:          String,
  latitude:                    String,
  longitude:                   String,
  sub_premise:                 String,
  premise:                     String
  ) {

  override def toString(): String = {
    val CTRL_A = "\u0001"
    val DELM = CTRL_A

    var addressComponents = partial_match + DELM + formattedAddress + DELM +
      status + DELM +
      error_message + DELM +
      streetNumber + DELM +
      route + DELM +
      locality + DELM +
      administrative_area_level_2 + DELM +
      administrative_area_level_1 + DELM +
      country + DELM +
      postal_code + DELM +
      postal_code_suffix + DELM +
      latitude + DELM +
      longitude + DELM +
      sub_premise + DELM +
      premise

    return addressComponents
  }
}





