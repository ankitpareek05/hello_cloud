package com.deloitte.asset.insight

import org.apache.spark.sql.functions.lit

import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.utils.GlobalVariables
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import com.deloitte.asset.insight.rules.CleanseRule

object MatchApprovalMain extends Logging {

  val sparkSession = InitiateSparkContext.getSparkSession()
  val sparkContext = sparkSession.sparkContext
  val sqlContext = sparkSession.sqlContext
  def main(args: Array[String]) {

    val inputPathConfig = args(0)
    // val inputPathConfig = "src\\main\\resources\\MMRELATIONS.csv"
    val layerName = "STANDARDIZATION".toLowerCase()
    val fileName: String = "NA"
    val srcName: String = "NA"

    val standardizationConfigData = CommonUtils.parseConfigFile(inputPathConfig, fileName, srcName, layerName = layerName)
      .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })

    val bucketName = GlobalVariables.getRootPath
    val matchDimPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.output.path")).head._2(0)
    val matchApprovalPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.approval.path")).head._2(0)

    val matchApprovalRule = standardizationConfigData.getOrElse((layerName + ".rule.filterbasedoncolumnvalue").toLowerCase(), List("NA"))
    log.info("matchApprovalRule ::::::::: " + matchApprovalRule)

    val matchDim = CommonUtils.readFromS3Parquet(bucketName + matchDimPath + "/*", "true")

    //val unMergerdData = matchDim.withColumn("latest_record", row_number().over(Window.partitionBy(col("ai_match_id")).orderBy(col("ai_merge_action").desc))).filter(col("latest_record") === 1 && col("ai_merge_action") === 1)
    val unMergerdData = CleanseRule.rule_filterBasedOnColumnValue(matchDim, matchApprovalRule)

    log.info("unMergerdData count : " + unMergerdData.count())

    val matchFactPath = standardizationConfigData.filter(x => x._1.toLowerCase().contains("match.fact.path")).head._2(0)
    val factPath = bucketName + matchFactPath
    val matchFact = CommonUtils.readFromS3Parquet(factPath, "true")

    var unPivotedFact = matchFact.groupBy(col("ai_match_id")).pivot("ai_output_measure").agg(min("ai_output_value"), min("ai_match_output_value"))

    val unPivotedFactSchema = unPivotedFact.schema

    /**
     *  as the unpivoted fact schema is having column names as administrative_area_level_1_min(ai_output_value),
     *  administrative_area_level_1_min(ai_match_output_value) manipulating them to a standard schema
     */
    var columnMap = Map[String, String]()
    unPivotedFactSchema.map(eachField => {
      if (eachField.name.contains("_min") && eachField.name.contains("_match_")) {
        columnMap += ((eachField.name -> (eachField.name.substring(0, eachField.name.indexOf("_min(ai_match_output_value)")) + "_matched")))
      } else if (eachField.name.contains("_min")) {
        columnMap += ((eachField.name, (eachField.name.substring(0, eachField.name.indexOf("_min(ai_output_value)")))))
      } else {
        columnMap += ((eachField.name -> eachField.name))
      }
    })

    log.info("columnMap : " + columnMap)
    log.info("unPivotedFact schema before changing : " + unPivotedFact.schema)

    // renaming the schema
    for (column <- columnMap.keys) {
      unPivotedFact = unPivotedFact.withColumnRenamed(column, columnMap.get(column).get.toString())
    }
    log.info("unPivotedFact schema before changing : " + unPivotedFact.schema)

    // Joining the unpivoted fact and unmerger records to create a wide dataframe
    val joinColumns = List("ai_match_id").toSeq
    val unMergedWithMatchCols = unMergerdData.join(unPivotedFact.drop("AI_PARTY_ID", "AI_PARTY_ID_MATCHED"), joinColumns, "left_outer")
    log.info("unMergedWithMatchCols schema : " + unMergedWithMatchCols.schema)
    unMergedWithMatchCols.show()
    log.info("unMergedWithMatchCols count : " + unMergedWithMatchCols.count())
    log.info("Writing the match approval data to : " + bucketName + matchApprovalPath)
    
    //CommonUtils.writeToS3(unMergedWithMatchCols.coalesce(1), "s3a://ai-00688001-processing-dev/test/ai_priyanka/approval/test_rule/")

    val finalDf = CommonUtils.replaceNewLine(unMergedWithMatchCols)
    
    finalDf.coalesce(1).write.option("header", "true").option("nullValue", "N/A").option("fileType", "csv").
      option("ignoreLeadingWhiteSpace", "true").option("ignoreTrailingWhiteSpace", "true").option("multiLine", "true").option("quoteAll", true).
      option("quote", "\'").option("nullValue", "").option("nullValue", null).option("nullValue", "NULL").
      mode("overwrite").csv(bucketName + matchApprovalPath)

  }

}