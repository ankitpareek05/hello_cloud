package com.deloitte.asset.insight

import org.apache.spark.sql.functions._
import com.deloitte.asset.insight.service.impl.RuleProcessImpl
import com.deloitte.asset.insight.services.RuleProcess
import com.deloitte.asset.insight.utils.{ CommonUtils, FixedWidthParser, InitiateSparkContext, CommonConstants, DelimiterBasedParser }
import com.deloitte.asset.insight.rules.KeyFieldValidation
import com.deloitte.asset.insight.services.RuleProcess
import org.apache.spark.sql.DataFrame
import scala.collection.Map
import com.deloitte.asset.insight.service.impl.StagingImpl
import org.apache.log4j.{ Level, LogManager, PropertyConfigurator }
import com.deloitte.asset.insight.services.Logging
import org.apache.spark.sql.SparkSession
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.service.impl.PreProcessingImpl
import com.deloitte.asset.insight.utils.DataFrameOperation

/**
 * <b>Preprocess Object</b>
 * <p>
 * Below Reads Source File from S3 location into a Dataframe and then:
 * </p>
 *
 * 1. Parse Config file in MAP
 * 2. Identify Delta Records
 * 3. PerForm Key Validation
 * 4. Perform Cleansing and Standarization task
 * 5. Add four Core keys
 * 6 Write preprocessed DF into S3
 * </p>
 * @see [[com.deloitte.asset.insight.service.impl.StagingImpl]]
 * @author anpareek
 *
 */

object PreProcessingMain extends Logging with Serializable {
  case class ConfigException(smth1: String, code: String) extends Exception(smth1)
  import DataFrameOperation.implicits._

  //val batchStartTime = CommonUtils.getTimeStamp()._1

  def main(args: Array[String]) {

    log.info("Initiating Spark Application")

    val sparkSession = InitiateSparkContext.getSparkSession()

    import DataFrameOperation.implicits._

    if (args.length < 4) {
      log.error("Invalid number of arguments passed")
      log.error("""Arguments Usage:[config-file path][File Name][Source Name][Layer Name][DebugFlag] - <optional> <TRUE|FALSE>""")
      System.exit(1)
    }

    // Path of parent Config file
    try {

      val config = args(0)
      val fileName = args(1).toUpperCase()
      val sourceName = args(2).toUpperCase()
      val layerName = args(3).toLowerCase()

      if (args.length == 5) {
        GlobalVariables.setDebugFlag(args(5))
      } else {
        log.info("Debug Level is set to FALSE")
        GlobalVariables.setDebugFlag("false")
      }

      log.info("Logging Started for file: " + fileName)
      log.info("Loading Config file")
      var preProcessconfigData = CommonUtils.parseConfigFile(config, fileName, sourceName, layerName)
        .filter(key => key._1.toLowerCase().startsWith("preprocessing")).map(x => { (x._1.replace(".na", ""), x._2) })

      // Getting Bucket Name

      val rootPath = GlobalVariables.getRootPath
      val debugFlag = GlobalVariables.getDebugFlag
      log.info("Bucket Name is: " + rootPath)

      var preprocess: PreProcessingImpl = new PreProcessingImpl()

      // Calling Preprocess Functionality
      val preProcessedDF = preprocess.processPreprocessingLayer(preProcessconfigData, layerName)
      preProcessedDF.showOrNoShow(debugFlag)

      val outputPath = rootPath + preProcessconfigData.get(layerName + ".output.path").get(0)
      log.info("Output path of preprocessed file: " + outputPath)
      CommonUtils.writeToS3Parquet(preProcessedDF, outputPath, "true", "overwrite")

    } catch {
      case ex: ConfigException => {
        log.error(ex.code + " - " + ex.smth1)
      }
      case ex: Exception => {
        ex.printStackTrace()
        log.error(ex.getMessage)
        System.exit(1)
      }
    }

  }

}

