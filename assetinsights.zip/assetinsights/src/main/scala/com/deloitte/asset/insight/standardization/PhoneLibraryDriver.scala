package com.deloitte.asset.insight.standardization

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.lit
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions._

import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.geocoding.api._

import com.deloitte.asset.insight.utils._
//import com.deloitte.asset.insight.standardization.PhoneValidation

object PhoneLibraryDriver extends Logging {

  import DataFrameOperation.implicits._
  var sparkSession = InitiateSparkContext.getSparkSession()

  def main(args: Array[String]) = {

  }

  def standardizePhone(inputPhone: DataFrame, target_o: String, target_c: String, callToGoogleAPIActive: Boolean, minQualityThreshold: Int, autoSeqColName: String, phoneDimTablePath: String, phoneStdLoggingPath: String, phone_dim_schema: Array[String], phone_logging_schema: Array[String], phoneFormat: String, code_operationType:String,dim_input_path:String): DataFrame = {

    inputPhone.show(false)
    val inputPhoneDF = inputPhone.select(target_o)
    inputPhoneDF.show()
    var phoneDimdf: DataFrame = CommonUtils.readFromS3Parquet(dim_input_path, "true").select(phone_dim_schema.head, phone_dim_schema.tail: _*)
   // var phoneDimdf: DataFrame = CommonUtils.readFromCsvFile("src\\main\\resources\\PhoneSample.csv", "true", "true")

    //val phoneDimSchema = autoSeqColName +: phone_dim_schema
    val phoneDimWithLoggingSchema = autoSeqColName +: CommonConstants.PHONE_LIB_SCHEMA :+ CommonConstants.API_QUALITY_RATING
    var checkedBefore_c: DataFrame = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    var checkedBefore_o_low_rating: DataFrame = null
    var googleApiDFForRetriedPhone: DataFrame = null
    var pre_checkedBefore_c: DataFrame = null
    var newPhoneDF: DataFrame = null
    var googleAPIDF = CommonUtils.createEmptyDF(CommonConstants.PHONE_LIB_SCHEMA)
    val phone_std_logging_cols = autoSeqColName +: phone_logging_schema
    var loggingDf = CommonUtils.createEmptyDF(phone_std_logging_cols)
    val country = CommonConstants.API_COUNTRY
    val googleAPIQualityRating = GlobalVariables.getGoogleAPIQualityRating
    var checkedBefore_o_low_rating_matching_c: DataFrame = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
   
    var unionDf: DataFrame = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    var googleApiRetriedOkDF: DataFrame = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    var googleApiRetriedNotOkDF: DataFrame = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    var finalPhoneNotMeetingStdCriteria: DataFrame = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    var googleApiRetriedZeroRecordsDF = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    val phoneDimSchema =  phone_dim_schema
    val debugFlag = GlobalVariables.getDebugFlag
    var dimensionDf = CommonUtils.createEmptyDF(phoneDimWithLoggingSchema)
    var phoneDimWithNoCountry: DataFrame = phoneDimdf.filter(trim(col(country)) === null || trim(col(country)).isNull || length(col(country)) === 1)
  
    var exceptCountryDF: DataFrame = phoneDimdf.except(phoneDimWithNoCountry)

    phoneDimWithNoCountry = phoneDimWithNoCountry.withColumn(country, lit("US")).select(phone_dim_schema.head, phone_dim_schema.tail: _*)
    
    
    phoneDimdf = exceptCountryDF.union(phoneDimWithNoCountry)
    var validCountryCode = phoneDimdf.filter(length(col(country)) === 2).select(phone_dim_schema.head, phone_dim_schema.tail: _*)
    val invalidCountryCode = phoneDimdf.filter(length(col(country)) > 2)
    //phoneDimdf=validCountryCode
    if (!invalidCountryCode.head(1).isEmpty) 
    {
      val countrycode = invalidCountryCode.select(country).withColumnRenamed(country, "From_Value").distinct()
    
      val brodcstedNewCountryCode = sparkContext.broadcast(CommonUtils.CodecodeValueLookUp(code_operationType, "TIAA", "SFDC", countrycode))
      val newCountryCode = brodcstedNewCountryCode.value
     newCountryCode.showOrNoShow(debugFlag) 
     newCountryCode.persist()
      var newJoinDf = phoneDimdf.join(newCountryCode, phoneDimdf(country) === newCountryCode("From_Value"))
     newJoinDf.showOrNoShow(debugFlag)
      val test = newJoinDf.drop(phoneDimdf(country)).drop(newCountryCode("From_Value")).drop("Status")
      
      val test2 = test.withColumnRenamed("To_Value", country)
     
      newJoinDf = test2.select(phone_dim_schema.head, phone_dim_schema.tail: _*)
      
     validCountryCode = validCountryCode.select(phone_dim_schema.head, phone_dim_schema.tail: _*)
      phoneDimdf = newJoinDf.union(validCountryCode)
      phoneDimdf.persist()
      phoneDimdf.showOrNoShow(debugFlag)
    }

   

    //Checking if input phone is already existing in phone_o column of Phone Dimension

    var checkedBefore_o = AddressValidation.validateAddressInAI(inputPhoneDF, phoneDimdf, target_o, target_o, autoSeqColName, phone_dim_schema).distinct
    println("check before o")
    checkedBefore_o.show()
    
    if (callToGoogleAPIActive) 
    {
      log.info("Google Phone Library Flag is active")

      if (!checkedBefore_o.head(1).isEmpty) {
        log.info("Retrying Matched Phone with _o........")
        // Filtering the phone which needs to be reformatted with Google API as they have quality_rating < threshold
        checkedBefore_o_low_rating = checkedBefore_o.filter(col(CommonConstants.API_QUALITY_RATING) < minQualityThreshold)
        checkedBefore_o_low_rating = checkedBefore_o_low_rating.join(inputPhone, inputPhone(target_o) === checkedBefore_o_low_rating(target_o)).drop(inputPhone(target_o)).distinct()
        val checkedBefore_o_low_rating_selected = checkedBefore_o_low_rating.select(autoSeqColName, target_o)
        checkedBefore_o_low_rating_matching_c = AddressValidation.validateAddressInAI(checkedBefore_o_low_rating_selected, phoneDimdf.drop(autoSeqColName), target_o, target_c, autoSeqColName, phone_dim_schema).distinct.filter(col(CommonConstants.API_QUALITY_RATING) >= minQualityThreshold)
            .select(phoneDimSchema.head, phoneDimSchema.tail: _*)
            
        checkedBefore_o_low_rating = checkedBefore_o_low_rating.join(checkedBefore_o_low_rating_matching_c, Seq(autoSeqColName), "left_anti")
        println("********")
        checkedBefore_o_low_rating.show()
        checkedBefore_o_low_rating_matching_c.show()
        checkedBefore_o_low_rating_matching_c = checkedBefore_o_low_rating_matching_c
            .withColumn(CommonConstants.PHONE_API_VALIDITY, lit("true"))
            .withColumn(CommonConstants.API_ERROR_MESSAGE, lit("AI_INSERT"))
            .select(phoneDimWithLoggingSchema.head, phoneDimWithLoggingSchema.tail: _*)
        
        /*var retriedPhoneNotMeetingStdCriteria = checkedBefore_o_low_rating//.filter(col(target_o).contains("/") || col(target_o).contains("&") || trim(col(target_o)).isNull || col(target_o).contains("E"))
        log.info("Phone not meeting standardization requirements")
        retriedPhoneNotMeetingStdCriteria.showOrNoShow(debugFlag)
        val retriedPhoneMeetingStdCriteria = checkedBefore_o_low_rating//.join(retriedPhoneNotMeetingStdCriteria, Seq(target_o, autoSeqColName, country), "left_anti")
        
        log.info("Phone meeting standardization requirements")
        retriedPhoneMeetingStdCriteria.showOrNoShow(debugFlag)*/
        if (!checkedBefore_o_low_rating.head(1).isEmpty) {
          // Calling Google API for existing phone having quality_rating < threshold
         
          googleApiDFForRetriedPhone = PhoneValidation.validatePhoneWithGoogleLibrary(checkedBefore_o_low_rating, target_c, phone_dim_schema, country, phoneFormat)
          googleApiDFForRetriedPhone.persist(StorageLevel.MEMORY_AND_DISK_SER)
          googleApiDFForRetriedPhone.showOrNoShow(debugFlag)
          //Filtering standardized phone with OK status
          googleApiRetriedOkDF = googleApiDFForRetriedPhone.filter(googleApiDFForRetriedPhone(CommonConstants.PHONE_API_VALIDITY) === "true")

          // Adding quality rating as 2 for standardized phone
          googleApiRetriedOkDF = googleApiRetriedOkDF.withColumn(CommonConstants.API_QUALITY_RATING, lit(googleAPIQualityRating))
            .select(phoneDimWithLoggingSchema.head, phoneDimWithLoggingSchema.tail: _*)

          googleApiRetriedZeroRecordsDF = googleApiDFForRetriedPhone
            .filter(googleApiDFForRetriedPhone(CommonConstants.PHONE_API_VALIDITY) === "false")

          googleApiRetriedZeroRecordsDF = googleApiRetriedZeroRecordsDF.withColumn(CommonConstants.API_QUALITY_RATING, lit("1"))
            .select(phoneDimWithLoggingSchema.head, phoneDimWithLoggingSchema.tail: _*)

          /* googleApiRetriedOkDF.show()
          googleApiRetriedZeroRecordsDF.show()*/
        }

      }

     

       /* googleApiRetriedOkDF.show()
        googleApiRetriedZeroRecordsDF.show()
      //  googleApiNewOkDF.show()
        //checkedBefore_c.show()
        //finalPhoneNotMeetingStdCriteria.show()
*/      unionDf = googleApiRetriedOkDF./*union(googleApiNewOkDF).*/union(checkedBefore_c).union(googleApiRetriedZeroRecordsDF).union(checkedBefore_o_low_rating_matching_c).distinct
      //unionDf.show()

    } else {
      log.info("Google API Flag is not active")

      var alreadyExistingPhoneDF = checkedBefore_o.union(checkedBefore_c).select(target_o).distinct()
      //alreadyExistingPhoneDF.show()

      alreadyExistingPhoneDF.showOrNoShow(debugFlag)

      //inputPhoneDF.show()
      newPhoneDF = inputPhoneDF.except(alreadyExistingPhoneDF).distinct()
      //newPhoneDF.show()

      // Adding phone same as phone_o
      newPhoneDF = newPhoneDF.withColumn(target_c, col(target_o))
      //newPhoneDF.show()
      // Adding the status for logging purpose
      newPhoneDF = newPhoneDF.withColumn(CommonConstants.PHONE_API_VALIDITY, lit(""))
      //newPhoneDF.show()
      // Adding the error message for logging purpose
      newPhoneDF = newPhoneDF.withColumn(CommonConstants.API_ERROR_MESSAGE, concat_ws(" ", lit("<"), col(target_o), lit("> is not standardized.")))
      //newPhoneDF.show()

      newPhoneDF.persist(StorageLevel.MEMORY_AND_DISK_SER)

      var blankCols = CommonConstants.PHONE_LIB_SCHEMA diff newPhoneDF.columns

      for (blankCol <- blankCols) {
        // Adding blank values to other address components of Address Dimesion
        newPhoneDF = newPhoneDF.withColumn(blankCol, lit(" "))
      }

      // Adding quality rating as 0 for not standardized phone
      unionDf = newPhoneDF.withColumn(CommonConstants.API_QUALITY_RATING, lit("0"))
      //unionDf.show()
    }

    unionDf.persist(StorageLevel.MEMORY_AND_DISK_SER)

    if (!unionDf.head(1).isEmpty) {

      dimensionDf = unionDf.select(phoneDimSchema.head, phoneDimSchema.tail: _*)
      val runTimeStamp = CommonUtils.getTimeStamp()._1
      dimensionDf = dimensionDf.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
      dimensionDf.printSchema()
      dimensionDf.show()
      log.info("=================== Newly added schema and records =================== " /*+ dimensionDf.count*/ )
      dimensionDf.showOrNoShow(debugFlag)

      log.info("Writing Phone dimension data")
      dimensionDf.show()
      CommonUtils.writeToS3Parquet(dimensionDf, phoneDimTablePath, "true", "append")
    } else {
      log.info("No record added in phone dimension table")
    }

    // Selected specific column for logging purpose
    loggingDf = unionDf.select(phone_std_logging_cols.head, phone_std_logging_cols.tail: _*)
    val runTimeStamp = CommonUtils.getTimeStamp()._1
    loggingDf = loggingDf.withColumn(CommonConstants.SRC_TIMESTAMP, lit(runTimeStamp)).withColumn(CommonConstants.INACTIVE_FLAG, lit(0))
    if (!loggingDf.head(1).isEmpty) {

      log.info("==================== Logging Dataframe =================================")
      loggingDf.showOrNoShow(debugFlag)

      log.info("Writing Phone standardization logging at " + phoneStdLoggingPath)
      loggingDf.show()
      CommonUtils.writeToS3Parquet(loggingDf, phoneStdLoggingPath, "true", "append")

    } else {
      log.info("No record added in Logging table")
    }
    //unionDf.unpersist()
    /*if (phoneDimdf != null)
          phoneDimdf.unpersist()

        googleAPIDF.unpersist()

        if (googleApiDFForRetriedPhone != null)
          googleApiDFForRetriedPhone.unpersist()

        inputPhone.unpersist()
        newPhoneDF.unpersist()
        finalPhoneNotMeetingStdCriteria.unpersist()*/

    return loggingDf

  }

}