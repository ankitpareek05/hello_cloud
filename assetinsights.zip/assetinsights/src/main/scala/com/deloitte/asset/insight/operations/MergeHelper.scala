package com.deloitte.asset.insight.operations

import org.apache.spark.sql.Dataset
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.substring
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.row_number

import com.deloitte.asset.insight.bean.MatchApprovalBean
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.Row
import com.deloitte.asset.insight.bean.GenericMatchApprovalBean
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.storage.StorageLevel

class MergeHelper(joinColsForRel: Seq[String], genericCols: Seq[String], sparkSess: SparkSession) extends Logging with Serializable {
  val sparkSession = sparkSess
  val joinColumnsForRel = joinColsForRel
  val genericColumns = genericCols

  import sparkSession.implicits._

  def getMatchTableData(matchTablePath: String, isSameSource: Boolean): Dataset[MatchApprovalBean] = {
    try {
      var matchDataDF = CommonUtils.readFromS3Parquet(matchTablePath, "true")
        //      matchDataDF.printSchema()
        //sparkSession.read.option("header", "true").option("inferSchema", "true").csv(matchTablePath)
        .

        //        CommonUtils.readFromCsvFile(matchTablePath,"true","true").
        withColumnRenamed("AI_SRC_ID", "AI_ORIGINAL_SRC_ID").
        withColumnRenamed("AI_PARTY_ID", "AI_ORIGINAL_PARTY_ID").
        //filter("AI_PARTY_ID = '15397862066520593704374636566'").
        //filter("AI_ORIGINAL_PARTY_ID = AI_PARTY_ID_MATCHED").
        //        //withColumnRenamed("ai_effective_date", "ai_effective_date").
        as[MatchApprovalBean]
       
      /*if(isSameSource){
        matchDataDF = matchDataDF.filter(col("AI_ORIGINAL_SRC_ID").equalTo(col("AI_SRC_ID_MATCHED")))
      } else {
        matchDataDF = matchDataDF.filter(col("AI_ORIGINAL_SRC_ID").notEqual(col("AI_SRC_ID_MATCHED")))
      }*/
      matchDataDF.createOrReplaceTempView("match_output_dim")
      //val query = "select AI_ORIGINAL_PARTY_ID, AI_PARTY_ID_MATCHED from match_output_dim where AI_MERGE_ACTION = 2 group by AI_ORIGINAL_PARTY_ID, AI_PARTY_ID_MATCHED having max(AI_MERGE_ACTION) = 2"
      val query = "select AI_ORIGINAL_PARTY_ID, AI_PARTY_ID_MATCHED from match_output_dim where AI_MERGE_ACTION = 2 except select AI_ORIGINAL_PARTY_ID, AI_PARTY_ID_MATCHED from match_output_dim where AI_MERGE_ACTION = 3"
      //matchDataDF = matchDataDF.withColumn("latest_record", row_number().over(Window.partitionBy(col("AI_MATCH_ID")).orderBy(col("AI_MATCH_RULE_ID").desc))).filter(col("latest_record") === 1 && col("AI_MERGE_ACTION") === 2)
      //  .drop("latest_record").as[MatchApprovalBean]
      var consideredData = sparkSession.sql(query)
      matchDataDF = matchDataDF.join(consideredData, Seq("AI_ORIGINAL_PARTY_ID","AI_PARTY_ID_MATCHED"), "inner").dropDuplicates().as[MatchApprovalBean]

      //matchDataDF = matchDataDF.filter("AI_ORIGINAL_PARTY_ID = '15383920474320070764504178721' OR AI_ORIGINAL_PARTY_ID = '153839204973200701348619730973' OR AI_ORIGINAL_PARTY_ID = '153839204899200701030792151074'")
      //matchDataDF = matchDataDF.filter("AI_ORIGINAL_PARTY_ID='153925447164304541039382085739' OR AI_ORIGINAL_PARTY_ID = '15392652252340489798863917108' OR AI_ORIGINAL_PARTY_ID = '153927280939600141228360647000'")
      //matchDataDF = matchDataDF.filter("AI_ORIGINAL_PARTY_ID='15392652252340489798863917108'")
      println("-------------- Number of Records in Match Data DF: " + matchDataDF.count())
      matchDataDF.printSchema()
      return matchDataDF //null

    } catch {
      case exception: Exception => {
        exception.printStackTrace(); log.error("Unable to load the Dataset...")
      }
    }
    return null
  }

  def mergeRelPartyPartyRecords(matchApprovalDataset: Dataset[Row], latestDataset: Dataset[Row], projectCols: Seq[String], sameSource: Boolean): Dataset[Row] = {
    var joinedTable = latestDataset.join(matchApprovalDataset, substring(col("AI_SRC_ID_MATCHED"),1,7).equalTo(substring(col("AI_SRC_ID"),1,7))
      .and(col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID"))))
      
    if(!sameSource){
      joinedTable = latestDataset.join(matchApprovalDataset, col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID")))
    }

    println("---------- JOINED TABLE SCHEMA -----------")
    joinedTable.printSchema()
    
    var sameSourceMergeCols = projectCols
    var selectionCols = sameSourceMergeCols.map(name => col(name))
    var updatedRecords = joinedTable.select(genericCols.head, genericCols.tail: _*).as[GenericMatchApprovalBean]
    updatedRecords = updatedRecords.dropDuplicates()
    
    var preFinalSet = latestDataset.join(updatedRecords, joinColumnsForRel, "inner").persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    
    val oldSourceSet = preFinalSet.select(selectionCols: _*).withColumn("INACTIVE_FLAG", lit(0)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    
    var distinctSourceMergeCols = projectCols
    var distinctMergeCols = distinctSourceMergeCols.map(name => col(name))
    preFinalSet = preFinalSet.drop("AI_PARTY_ID").withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID")
    val matchedSet = preFinalSet.select(distinctMergeCols: _*).withColumn("INACTIVE_FLAG", lit(0))
    
    println("---------- MATCHED SET SCHEMA -------------")
    matchedSet.printSchema()
    
    println("---------- OLD SOURCE SET SCHEMA -----------")
    oldSourceSet.printSchema()
    var finalDataset = matchedSet.union(oldSourceSet).filter("AI_PARTY_ID != AI_REL_PARTY_ID")
    
    return finalDataset.dropDuplicates()
  }

  def mergeRecords(matchApprovalDataset: Dataset[Row], latestDataset: Dataset[Row], projectCols: Seq[String], sameSource: Boolean): Dataset[Row] = {
    latestDataset.printSchema()
    var joinedTable = latestDataset.join(matchApprovalDataset, substring(col("AI_SRC_ID_MATCHED"),1,7).equalTo(substring(col("AI_SRC_ID"),1,7))
      .and(col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID"))))
      
    if(!sameSource){
      joinedTable = latestDataset.join(matchApprovalDataset, col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID")))
    }
    
    //println("--------------------- JOINED TABLE DATA ----------------------------------")
    //joinedTable.show(10000, false)
    
    //println("--------------------- Count of Records after join :" + joinedTable.count())
    var updatedRecords = joinedTable.select(genericCols.head, genericCols.tail: _*).as[GenericMatchApprovalBean]
    updatedRecords = updatedRecords.dropDuplicates()


    var preFinalSet = latestDataset.join(updatedRecords, joinColumnsForRel, "inner")

    val oldSourceSet = preFinalSet.select(projectCols.head, projectCols.tail: _*).withColumn("INACTIVE_FLAG", lit(1))
    //println("---------------------- DISPLAYING OLD SOURCE SET -------------------------------")
    //oldSourceSet.show(10000, false)
    preFinalSet = preFinalSet.drop("AI_PARTY_ID").withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID")
    val matchedSet = preFinalSet.select(projectCols.head, projectCols.tail: _*).withColumn("INACTIVE_FLAG", lit(0))
    var finalDataset = matchedSet.union(oldSourceSet)
    //println("---------------------- DISPLAYING FINAL SET -------------------------")
    //finalDataset.show(10000, false)
    return finalDataset.dropDuplicates()
    
  }

  def mergePartyRecords(matchApprovalDataset: Dataset[Row], latestDataset: Dataset[Row], projectCols: Seq[String], sameSource: Boolean): Dataset[Row] = {
    latestDataset.printSchema()
    var joinedTable = latestDataset.join(matchApprovalDataset, substring(col("AI_SRC_ID_MATCHED"),1,7).equalTo(substring(col("AI_SRC_ID"),1,7))
      .and(col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID"))))
      
    if(!sameSource){
      joinedTable = latestDataset.join(matchApprovalDataset, col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID")))
    }
    
    var updatedRecords = joinedTable.select(genericCols.head, genericCols.tail: _*).as[GenericMatchApprovalBean]
    updatedRecords = updatedRecords.dropDuplicates()

    var preFinalSet = latestDataset.join(updatedRecords, joinColumnsForRel, "inner")

    val oldSourceSet = preFinalSet.select(projectCols.head, projectCols.tail: _*).withColumn("INACTIVE_FLAG", lit(1))
    
    if(sameSource){
      return oldSourceSet
    }

    preFinalSet = preFinalSet.drop("AI_PARTY_ID").withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID")
    val matchedSet = preFinalSet.select(projectCols.head, projectCols.tail: _*).withColumn("INACTIVE_FLAG", lit(0))
    var finalDataset = matchedSet.union(oldSourceSet)
    return finalDataset.dropDuplicates()
    
  }
  
  def mergeXrefRecords(matchApprovalDataset: Dataset[Row], latestDataset: Dataset[Row], projectCols: Seq[String], sameSource: Boolean): Dataset[Row] = {
    var joinedTable = latestDataset.join(matchApprovalDataset, substring(col("AI_SRC_ID_MATCHED"),1,7).equalTo(substring(col("AI_SRC_ID"),1,7))
      .and(col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID")))).dropDuplicates()
    if(!sameSource){
      joinedTable = latestDataset.join(matchApprovalDataset, col("AI_PARTY_ID_MATCHED").equalTo(col("AI_PARTY_ID"))).dropDuplicates()
    }
    // Joined Table consists of the winning party Id and the losing party id as well
    // AI_ORIGINAL_PARTY_ID : Winning Party ID
    // AI_PARTY_ID: Losing Party ID
    var losingProjectionColumns = projectCols
    var losingPartyRecords = joinedTable.select(losingProjectionColumns.head, losingProjectionColumns.tail:_*).withColumn("INACTIVE_FLAG", lit(1)).dropDuplicates()
    
    // The winning party records are needed in case there is a cross source merge
    var winningProjectionColumns = "AI_ORIGINAL_PARTY_ID" +: projectCols
    var winningPartyRecords = joinedTable.select(winningProjectionColumns.head, winningProjectionColumns.tail:_*).withColumn("INACTIVE_FLAG",lit(0)).drop("AI_PARTY_ID").dropDuplicates()
    
    // Now get the id name and value pairs which are not in the winning party records but are present in losing party records
    winningPartyRecords.createOrReplaceTempView("WinningRecords")
    losingPartyRecords.createOrReplaceTempView("LosingRecords")
    
    var relatedRecords = sparkSession.sql("SELECT W.AI_ORIGINAL_PARTY_ID, L.* FROM WinningRecords W, LosingRecords L WHERE W.AI_PARTY_ID_MATCHED = L.AI_PARTY_ID")
    relatedRecords = relatedRecords.select(winningProjectionColumns.head, winningProjectionColumns.tail:_*).withColumn("INACTIVE_FLAG", lit(0))
                                    .drop("AI_PARTY_ID")
                                    .withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID")
                                    .dropDuplicates()
    winningPartyRecords = winningPartyRecords.withColumnRenamed("AI_ORIGINAL_PARTY_ID", "AI_PARTY_ID").select(projectCols.head, projectCols.tail:_*).dropDuplicates()
    relatedRecords = relatedRecords.select(projectCols.head, projectCols.tail:_*).dropDuplicates()
    losingPartyRecords = losingPartyRecords.select(projectCols.head, projectCols.tail:_*).dropDuplicates()
    
    if(sameSource){
      return losingPartyRecords.union(relatedRecords).dropDuplicates()
    }
    
    return losingPartyRecords.union(winningPartyRecords).union(relatedRecords).dropDuplicates()
  }
}