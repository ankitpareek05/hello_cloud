package com.deloitte.asset.insight

import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.utils.Facts
import com.deloitte.asset.insight.service.impl.StagingImpl
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.CommonConstants

/* Below Reads Preprocessed File from S3 location into a Dataframe and then:
    * 1. Convert it to Standardized Data by calling method stageStandardizedValidate.show()
    * 2.Save  it on S3
 */

object SchemaStandardization {

  def main(args: Array[String]) {

    //    val sqlContext = InitiateSparkContext.getSqlContext()
    //    var inputPathConfig = "src\\main\\resources\\pimco\\Contacts_MainConfig.conf"
    //    val inputPath = CommonUtils.getConfigData(inputPathConfig).get(CommonConstants.S3_INPUT_PATH_SCHEMA_STANDARDIZATION).get(0)
    //
    //    import sqlContext.implicits._
    //    var preProcessedDF = CommonUtils.readFromS3Parquet(inputPath, "true")
    //   preProcessedDF.show()
    //
    //    var stageProcess: StagingImpl = new StagingImpl()
    //    //val stageStandardizedValidate = stageProcess.processStandarization(preProcessedDF, inputPathConfig)
    //    //stageStandardizedValidate.show()

  }
}