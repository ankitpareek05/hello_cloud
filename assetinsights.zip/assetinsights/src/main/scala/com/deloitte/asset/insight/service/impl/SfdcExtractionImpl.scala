package com.deloitte.asset.insight.service.impl

import com.deloitte.asset.insight.operations.SfdcObjectExtraction
import com.deloitte.asset.insight.services.SfdcExtraction
import scala.collection.Map

class SfdcExtractionImpl extends SfdcExtraction {
  
  override def extractObjectFromSfdc(sfdcKeyValues: Map[String, List[String]], layerName:String) = {
    val sfdcTables = sfdcKeyValues.get(layerName + ".sfdc.extraction.tables.list").get.map(_.trim().toLowerCase().replaceAll("_", "."))

    if (!sfdcTables(0).equalsIgnoreCase("na")) {
      sfdcTables.map(objectName => {
        val sfdcObjectName = layerName + "." + objectName
        val sfdcConfigData = sfdcKeyValues.filter(x => x._1.toLowerCase().startsWith(sfdcObjectName))
        println("===> Running Sfdc Object Extraction for : " + sfdcObjectName)
        
        SfdcObjectExtraction.processSfdcExtraction(sfdcConfigData, sfdcObjectName)
        
      })
    } else {
      println("===> No SFDC Extraction List Available ")
    }
  }
}