package com.deloitte.asset.insight.rules

import org.apache.spark.sql.Row
import org.webtool.rules.FinanceRulesImpl
import com.deloitte.asset.insight.utils.RulesConstants
import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.services.Logging

/*
 * Error table stores error record
 */
case class ErrorTable( SOURCE : String, AI_SRC_ID : String, FILE_NAME : String, ERROR_CODE : String,ERROR_CATEGOERY : String,ERROR_COLUMN :String, ERROR_DESCRIPTION : String, ERROR_RECORDS : String )
/*
 * Defines all Financial Rule
 * Developer: Neeraj Kumar & Sunny Rajpal
 */
object FinancialRules extends Serializable with Logging {

	val sparkContext = InitiateSparkContext.getSparkContext()

	var source = sparkContext.getConf.get( "spark.source.name" )
	var firmName = sparkContext.getConf.get( "spark.firm.name" )
	var entity = sparkContext.getConf.get( "spark.entity.name" )
	var errorCode = sparkContext.getConf.get( "spark.error.code" )
	var errorType = sparkContext.getConf.get( "spark.error.type" )
	var errorCategoery = sparkContext.getConf.get( "spark.error.categoery" )
	var errorDescription = sparkContext.getConf.get( "spark.error.description" )
	var errorRecords = sparkContext.getConf.get( "spark.error.records" )

	val financeRules = new FinanceRulesImpl
	//by:Sunny
	def creditCardExpiryCheck( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Credit_Card_Expiry_Check
		errorRecords = row.mkString( "|" )

		try {
			val colValue = row.getAs[ String ]( colName( 0 ) )
			val creditCheckOutput = financeRules.rule_Credit_Card_Expiry_Check( colValue )

			if ( creditCheckOutput.get( "Status" ).equalsIgnoreCase( "Invalid" ) || creditCheckOutput.get( "Status" ).equalsIgnoreCase( "Expired" ) ) {

				errorDescription = creditCheckOutput.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else { null }
		} catch {
			case e : Exception => {
				//log.info("Exception: =>  " + e.getMessage)
				errorDescription = "Exception: =>  " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )

			}
		}
	}

	def annualRevenueValidationCheck( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Annual_Revenue_Validation
		errorRecords = row.mkString( "|" )
		try {
			val colValue = row.getAs[ String ]( colName( 0 ) )
			val annualRevenueCheckOutput = financeRules.rule_Annual_Revenue_Validation( colValue )

			if ( annualRevenueCheckOutput.get( "isValid" ).equalsIgnoreCase( "false" ) ) {

				errorDescription = annualRevenueCheckOutput.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )

			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: =>  " + e.getMessage)
				errorDescription = "Exception: =>  " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def gammaValidationCheck( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Gamma_Validation
		errorRecords = row.mkString( "|" )
		try {
			val colValue = row.getAs[ String ]( colName( 0 ) )
			val gammaValidationCheckOutput = financeRules.rule_Gamma_Validation( colValue )

			if ( gammaValidationCheckOutput.get( "StatusNote" ).equalsIgnoreCase( "NonNumber" ) ) {

				errorDescription = gammaValidationCheckOutput.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }
		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)

				errorDescription = "Exception: =>  " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )

			}
		}

	}
	def positiveClosePriceValueValidationCheck( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Positive_Close_Price_Value_Validation
		errorRecords = row.mkString( "|" )
		try {
			val colValue = row.getAs[ String ]( colName( 0 ) )
			val positiveValueCheck = financeRules.rule_Positive( colValue )

			if ( positiveValueCheck.get( "isValid" ).equalsIgnoreCase( "false" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }
		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal

	def accuralPeriodValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Accrual_Period_Validation
		errorRecords = row.mkString( "|" )
		try {
			val startDate = row.getAs[ String ]( colName( 0 ) )
			val endDate = row.getAs[ String ]( colName( 1 ) )
			val accuralPeriodValidationCheck = financeRules.rule_Accrual_Period_Validation( startDate, endDate )

			if ( accuralPeriodValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = accuralPeriodValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }
		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def annualRevenueValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Annual_Revenue_Validation
		errorRecords = row.mkString( "|" )
		try {
			val annualRevenue = row.getAs[ String ]( colName( 0 ) )
			val annualValidationCheck = financeRules.rule_Annual_Revenue_Validation( annualRevenue )
			if ( annualValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = annualValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def betaCoefficientValidation( colName : Array[ String ], row : Row ) = {
		//errorCode = RulesConstants.rule_Beta_Coefficient_Validation
		errorRecords = row.mkString( "|" )
		try {
			val betaCoefficient = row.getAs[ String ]( colName( 0 ) )
			val betaCoefficientValidationCheck = financeRules.rule_Beta_Coefficient_Validation( betaCoefficient )
			if ( betaCoefficientValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = betaCoefficientValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def currencyCodeValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Currency_Code_Validation
		errorRecords = row.mkString( "|" )
		try {
			val ISOCurrencyCode = row.getAs[ String ]( colName( 0 ) )
			val currencyCodeValidationCheck = financeRules.rule_Currency_Code_Validation( ISOCurrencyCode )
			if ( currencyCodeValidationCheck.get( "Out_Currency_Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = currencyCodeValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def cUSIPValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_CUSIP_Validation
		errorRecords = row.mkString( "|" )
		try {
			val in_CUSIP = row.getAs[ String ]( colName( 0 ) )
			val cUSIPValidationCheck = financeRules.rule_CUSIP_Validation( in_CUSIP )
			if ( cUSIPValidationCheck.get( "Out_IsValid" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = cUSIPValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def dividendYieldValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Dividend_Yield_Validation
		errorRecords = row.mkString( "|" )
		try {
			val dividendYield = row.getAs[ String ]( colName( 0 ) )
			val dividendYieldValidationCheck = financeRules.rule_Dividend_Yield_Validation( dividendYield )
			if ( dividendYieldValidationCheck.get( "StatusNote" ).equalsIgnoreCase( "NonNumber" ) ) {

				errorDescription = dividendYieldValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def eADDrawnBalanceValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_EAD_Drawn_Balance_Validation
		errorRecords = row.mkString( "|" )
		try {
			val eAD = row.getAs[ String ]( colName( 0 ) )
			val drawnBalance = row.getAs[ String ]( colName( 1 ) )
			val eADDrawnBalanceValidationCheck = financeRules.rule_EAD_Drawn_Balance_Validation( eAD, drawnBalance )
			if ( eADDrawnBalanceValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = eADDrawnBalanceValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def eADValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_EAD_Validation
		errorRecords = row.mkString( "|" )
		try {
			val eAD = row.getAs[ String ]( colName( 0 ) )
			val eADValidationCheck = financeRules.rule_EAD_Validation( eAD )
			if ( eADValidationCheck.get( "StatusNote" ).equalsIgnoreCase( "NonNumber" ) ) {

				errorDescription = eADValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal :Require Modification as nothing is mentioned in rules.
	def ePSValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_EPS_Validation
		errorRecords = row.mkString( "|" )
		try {
			val ePS = row.getAs[ String ]( colName( 0 ) )
			val ePSValidationCheck = financeRules.rule_EPS_Validation( ePS )
			if ( ePSValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = ePSValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}
	//by:SunnyRajpal
	def gBRBankSortCodeParse( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_GBR_Bank_Sort_Code_Parse
		errorRecords = row.mkString( "|" )
		try {
			val sortCode = row.getAs[ String ]( colName( 0 ) )
			val gBRBankSortCodeParseCheck = financeRules.rule_GBR_Bank_Sort_Code_Parse( sortCode )
			if ( gBRBankSortCodeParseCheck.get( "Out_Bank_Sort_Code" ).equalsIgnoreCase( "Invalid Sort Code" ) ) {

				errorDescription = gBRBankSortCodeParseCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def gBRBankSortCodeStandardize( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_GBR_Bank_Sort_Code_Standardize
		errorRecords = row.mkString( "|" )
		try {
			val sortCode = row.getAs[ String ]( colName( 0 ) )
			val gBRBankSortCodeStandardizeCheck = financeRules.rule_GBR_Bank_Sort_Code_Standardize( sortCode )
			if ( gBRBankSortCodeStandardizeCheck.get( "Out_Standardised_Bank_Sort_Code" ).equalsIgnoreCase( "Invalid input. Must be 6 digit." ) ) {

				errorDescription = gBRBankSortCodeStandardizeCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def gBRBankSortCodeValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_GBR_Bank_Sort_Code_Validation
		errorRecords = row.mkString( "|" )
		try {
			val sortCode = row.getAs[ String ]( colName( 0 ) )
			val gBRBankSortCodeValidationCheck = financeRules.rule_GBR_Bank_Sort_Code_Validation( sortCode )
			if ( gBRBankSortCodeValidationCheck.get( "Out_Validation_Note" ).equalsIgnoreCase( "Invalid Sort Code" ) ) {

				errorDescription = gBRBankSortCodeValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}
	//by:SunnyRajpal
	def iBANValidition( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_IBAN_Validition
		errorRecords = row.mkString( "|" )
		try {
			val inIBAN = row.getAs[ String ]( colName( 0 ) )
			val iBANValiditionCheck = financeRules.rule_IBAN_Validition( inIBAN )
			if ( iBANValiditionCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = iBANValiditionCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def interestRateWithinRange( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Interest_Rate_Within_Range
		errorRecords = row.mkString( "|" )
		try {
			val interestRate = row.getAs[ String ]( colName( 0 ) )
			val interestRateWithinRangeCheck = financeRules.rule_Interest_Rate_Within_Range( interestRate )
			if ( interestRateWithinRangeCheck.get( "Out_Within_Range" ).equalsIgnoreCase( "False" ) ) {

				errorDescription = interestRateWithinRangeCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def iSINCodeValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_ISIN_Code_Validation
		errorRecords = row.mkString( "|" )
		try {
			val iSIN = row.getAs[ String ]( colName( 0 ) )
			val iSINCodeValidationCheck = financeRules.rule_ISIN_Code_Validation( iSIN )
			if ( iSINCodeValidationCheck.get( "Out_IsValid" ).equalsIgnoreCase( "False" ) ) {

				errorDescription = iSINCodeValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def loanToValueRatio( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Loan_to_Value_Ratio
		errorRecords = row.mkString( "|" )
		try {
			val in_Loan_Amount = row.getAs[ String ]( colName( 0 ) )
			val in_Property_Value = row.getAs[ String ]( colName( 1 ) )
			val loanToValueRatioCheck = financeRules.rule_Loan_to_Value_Ratio( in_Loan_Amount, in_Property_Value )
			if ( loanToValueRatioCheck.get( "Out_LTV_Ratio" ).equalsIgnoreCase( "Invalid input" ) ) {

				errorDescription = loanToValueRatioCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}
	//by:SunnyRajpal
	def lossGivenDefaultValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Loss_Given_Default_Validation
		errorRecords = row.mkString( "|" )
		try {
			val lossGivenDefaultValue = row.getAs[ String ]( colName( 0 ) )
			val lossGivenDefaultValidationCheck = financeRules.rule_Loss_Given_Default_Validation( lossGivenDefaultValue )
			if ( lossGivenDefaultValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = lossGivenDefaultValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def marketCapValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Market_Cap_Validation
		errorRecords = row.mkString( "|" )
		try {
			val marketCapValue = row.getAs[ String ]( colName( 0 ) )
			val marketCapValidationCheck = financeRules.rule_Market_Cap_Validation( marketCapValue )
			if ( marketCapValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = marketCapValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def maturityDateValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Maturity_Date_Validation
		errorRecords = row.mkString( "|" )
		try {
			val dateStringAsDDMMYYYY = row.getAs[ String ]( colName( 0 ) )
			val maturityDateValidationCheck = financeRules.rule_Maturity_Date_Validation( dateStringAsDDMMYYYY )
			if ( maturityDateValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = maturityDateValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def positiveClosePriceValueValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Positive_Close_Price_Value_Validation
		errorRecords = row.mkString( "|" )
		try {
			val closePriceValue = row.getAs[ String ]( colName( 0 ) )
			val positiveClosePriceValueValidationCheck = financeRules.rule_Positive_Close_Price_Value_Validation( closePriceValue )
			if ( positiveClosePriceValueValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveClosePriceValueValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def positiveCouponPercentValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Positive_Coupon_Percent_Validation
		errorRecords = row.mkString( "|" )
		try {
			val couponPercent = row.getAs[ String ]( colName( 0 ) )
			val positiveCouponPercentValidationCheck = financeRules.rule_Positive_Coupon_Percent_Validation( couponPercent )
			if ( positiveCouponPercentValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveCouponPercentValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def positiveLastPriceValueValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Positive_Last_Price_Value_Validation
		errorRecords = row.mkString( "|" )
		try {
			val lastPriceValue = row.getAs[ String ]( colName( 0 ) )
			val positiveLastPriceValueValidationCheck = financeRules.rule_Positive_Last_Price_Value_Validation( lastPriceValue )
			if ( positiveLastPriceValueValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveLastPriceValueValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def positiveOpenPriceValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Positive_Open_Price_Validation
		errorRecords = row.mkString( "|" )
		try {
			val openPrice = row.getAs[ String ]( colName( 0 ) )
			val positiveOpenPriceValidationCheck = financeRules.rule_Positive_Open_Price_Validation( openPrice )
			if ( positiveOpenPriceValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveOpenPriceValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	//by:SunnyRajpal
	def positiveVolumeValidation( colName : Array[ String ], row : Row ) = {
		errorCode = RulesConstants.rule_Positive_Volume_Validation
		errorRecords = row.mkString( "|" )
		try {
			val volume = row.getAs[ String ]( colName( 0 ) )
			val positiveVolumeValidationCheck = financeRules.rule_Positive_Volume_Validation( volume )
			if ( positiveVolumeValidationCheck.get( "Status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveVolumeValidationCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
				//errorTable
			} else { null }

		} catch {
			case e : Exception => {
				//log.info("Exception: => " + e.getMessage)
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}
	//by:neeraj
	def priceEarningsRatioValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Price_Earnings_Ratio_Validation
		errorRecords = row.mkString( "|" )
		try {

			val peRatio = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Price_Earnings_Ratio_Validation( peRatio )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def probabilityOfDefaultValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Probability_of_Default_Validation
		errorRecords = row.mkString( "|" )
		try {

			val probability = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Probability_of_Default_Validation( probability )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def ratingCodeValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Rating_Code_Validation
		errorRecords = row.mkString( "|" )
		try {

			val rating = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Rating_Code_Validation( rating )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def ratingDateValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Rating_Date_Validation
		errorRecords = row.mkString( "|" )
		try {

			val date = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Rating_Date_Validation( date )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def riskWeightedAssetValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Risk_Weighted_Asset_Validation
		errorRecords = row.mkString( "|" )
		try {

			val riskWeighted = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Risk_Weighted_Asset_Validation( riskWeighted )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def sedolValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_SEDOL_Validation
		errorRecords = row.mkString( "|" )
		try {

			val stockExchange = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_SEDOL_Validation( stockExchange )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def stockExchangeValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Stock_Exchange_Validation
		errorRecords = row.mkString( "|" )
		try {

			val stockExchange = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Stock_Exchange_Validation( stockExchange )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def usaRoutingNumberValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_USA_Routing_Number_Validation
		errorRecords = row.mkString( "|" )
		try {

			val inputNum = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_USA_Routing_Number_Validation( inputNum )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def volatilityValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Volatility_Validation
		errorRecords = row.mkString( "|" )
		try {

			val volatility = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Volatility_Validation( volatility )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def isPositive( colName : Array[ String ], row : Row ) = {

		// Need to change rule_Positive is not available
		errorCode = RulesConstants.rule_GBR_Bank_Account_Validation
		errorRecords = row.mkString( "|" )
		try {

			val colValue = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Positive( colValue )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "Invalid" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def gbrBankAccountValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_GBR_Bank_Account_Validation
		errorRecords = row.mkString( "|" )
		try {

			val bankAcctNum = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_GBR_Bank_Account_Validation( bankAcctNum )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def ageForAccountValidation( colName : Array[ String ], row : Row ) = {

		// Need to change rule_Age_For_Account_Validation is not available
		errorCode = RulesConstants.rule_Delta_Validation
		errorRecords = row.mkString( "|" )
		try {

			val age = row.getAs[ String ]( colName( 0 ) )
			val accountType = row.getAs[ String ]( colName( 1 ) )

			val positiveValueCheck = financeRules.rule_Age_For_Account_Validation( age, accountType )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def deltaValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Delta_Validation
		errorRecords = row.mkString( "|" )
		try {

			val delta = row.getAs[ String ]( colName( 0 ) )

			val positiveValueCheck = financeRules.rule_Delta_Validation( delta )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def exDividendDateValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Ex_Dividend_Date_Validation
		errorRecords = row.mkString( "|" )
		try {

			val exDividendDate = row.getAs[ String ]( colName( 0 ) )
			val recordDate = row.getAs[ String ]( colName( 1 ) )

			val positiveValueCheck = financeRules.rule_Ex_Dividend_Date_Validation( exDividendDate, recordDate )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def currencyodeCountryValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Currency_Code_Country_Validation
		errorRecords = row.mkString( "|" )
		try {

			val ISOCurrencyCode = row.getAs[ String ]( colName( 0 ) )
			val ISO3CharCountryCode = row.getAs[ String ]( colName( 1 ) )

			val positiveValueCheck = financeRules.rule_Currency_Code_Country_Validation( ISOCurrencyCode, ISO3CharCountryCode )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def canTransitNumberValidation( colName : Array[ String ], row : Row ) = {

		// Need to change rule_CAN_Transit_Number_Validation is not available
		errorCode = RulesConstants.rule_Credit_Card_Expiry_Check
		errorRecords = row.mkString( "|" )
		try {

			val transitNumber = row.getAs[ String ]( colName( 0 ) )
			val positiveValueCheck = financeRules.rule_CAN_Transit_Number_Validation( transitNumber )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def bicSwiftCodeValidation( colName : Array[ String ], row : Row ) = {

		// Need to change rule_BIC_SWIFT_Code_Validation is not available
		errorCode = RulesConstants.rule_Credit_Card_Expiry_Check
		errorRecords = row.mkString( "|" )
		try {

			val BICSWIFTCode = row.getAs[ String ]( colName( 0 ) )
			val positiveValueCheck = financeRules.rule_BIC_SWIFT_Code_Validation( BICSWIFTCode )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def creditCardSecurityCodeValidation( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_Credit_Card_Security_Code_Validation
		errorRecords = row.mkString( "|" )
		try {

			val cCSecurityCode = row.getAs[ String ]( colName( 0 ) )
			val positiveValueCheck = financeRules.rule_Credit_Card_Security_Code_Validation( cCSecurityCode )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

	def gbrBankAccountParse( colName : Array[ String ], row : Row ) = {

		errorCode = RulesConstants.rule_GBR_Bank_Account_Parse
		errorRecords = row.mkString( "|" )
		try {

			val bankAcctNum = row.getAs[ String ]( colName( 0 ) )
			val positiveValueCheck = financeRules.rule_GBR_Bank_Account_Parse( bankAcctNum )

			if ( positiveValueCheck.get( "status" ).equalsIgnoreCase( "N" ) ) {

				errorDescription = positiveValueCheck.toString()
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			} else {
				null
			}
		} catch {
			case e : Exception => {
				errorDescription = "Exception: => " + e.getMessage
				ErrorTable( source, firmName, entity, errorCode, errorType, errorCategoery, errorDescription, errorRecords )
			}
		}
	}

}

