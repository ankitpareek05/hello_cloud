package com.deloitte.asset.insight.utils

import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.hive.HiveContext

import com.deloitte.asset.insight.services.Logging
import org.apache.spark.serializer.KryoSerializer

object InitiateSparkContext extends Logging {

  val properties = System.getProperties()
  properties.setProperty("hadoop.home.dir", "C:\\winutils\\")

  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("org").setLevel(Level.ERROR)

  log.info("Initiating SparkSession")

  private val sparkSession = SparkSession.builder().appName("AssetInsight")
        .master("local[1]")
    //    .enableHiveSupport()
    .config("spark.sql.broadcastTimeout", "36000")
    .config("spark.serializer", classOf[KryoSerializer].getName)
    .config("spark.sql.tungsten.enabled", "true")
    .config("spark.sql.crossJoin.enabled","true")
    // .config("spark.eventLog.enabled", "true")
    .config("spark.io.compression.codec", "snappy")
    .config("spark.rdd.compress", "true")
    .getOrCreate()

  log.info("SparkSession created")

  private val sparkContext = sparkSession.sparkContext
  private val sqlContext = sparkSession.sqlContext

    sparkContext.hadoopConfiguration.set("fs.s3a.access.key", CommonConstants.S3_ACCESS_KEY)
  sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", CommonConstants.S3_SECRET_ACCESS_KEY)
  sparkContext.hadoopConfiguration.set("fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
  sparkContext.hadoopConfiguration.set("fs.s3a.connection.timeout", "200000")

  def getSparkSession(): SparkSession = {
    log.info("Getting Spark Session")
    this.sparkSession
  }

  def getSparkContext(): SparkContext = {
    log.info("Getting Spark Context")
    this.sparkContext
  }

  def getSqlContext(): SQLContext = {
    log.info("Getting SQL Context")
    this.sqlContext
  }

}