package com.deloitte.asset.insight

import org.apache.log4j.Logger

import com.deloitte.asset.insight.service.impl.SfdcInsertionImpl
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext

/**
 * <b>Collections Reference</b>
 * <p>
 * Below Reads Source File from S3 location into a Dataframe and then:
 * </p>
 *
 * 1. Parse Config file in MAP
 * 2. Identify Sfdc Objects
 * 3. Select needed columns from the Sfdc Object
 * 4. Pull the Sfdc Object from Sfdc into Spark Dataset
 * 5. Save the dataset as csv on
 * 6 Write preprocessed DF into S3
 * </p>
 * @see [[com.deloitte.asset.insight.service.impl.StagingImpl]]
 * @author nemannur
 *
 */

object SfdcInsertionMain extends Logging with Serializable {
  case class ConfigException(smth1: String, code: String) extends Exception(smth1)
  private[this] val LOGGER = Logger.getLogger(getClass())

  def main(args: Array[String]) {

    log.info("Initiating Spark Application")

    val sparkSession = InitiateSparkContext.getSparkSession()

    // Path of parent Config file
    try {

//          val config = "C:/AssetInsightsDocuments/SFDC/MSD/SFDC_FINAL_STEP_CONFIG.csv"
//            val fileName = "SFDC_LOADS"
//            val sourceName = "DYNAMICS"
//            val layerName = "SFDCWRITE".toLowerCase()
//      val debugFlag = "true"

      val config = args(0)
      val fileName = args(1).toUpperCase()
      val sourceName = args(2).toUpperCase()
      val layerName = args(3).toLowerCase()

      //      if (args.length == 5) {
      //        GlobalVariables.setDebugFlag(args(5))
      //      } else {
      //        log.info("Debug Level is set to FALSE")
      //        GlobalVariables.setDebugFlag("false")
      //      }

      log.info("Logging Started for file: " + fileName)
      log.info("Loading Config file")
      var sfdcConfigData = CommonUtils.parseConfigFile(config, fileName, sourceName, layerName)
        .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na", ""), x._2) })

      // Getting Bucket Name
      val rootPath = GlobalVariables.getRootPath
      log.info("Bucket Name is: " + rootPath)

      var sfdcInsert: SfdcInsertionImpl = new SfdcInsertionImpl()

      // Calling Insertion Functionality
      sfdcInsert.insertObjectToSfdc(sfdcConfigData, layerName)

    } catch {
      case ex: ConfigException => {
        log.error(ex.code + " - " + ex.smth1)
      }
      case ex: Exception => {
        ex.printStackTrace()
        log.error(ex.getMessage)
      }
    }

  }

}