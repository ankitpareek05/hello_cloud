package com.deloitte.asset.insight

import com.deloitte.asset.insight.operations.MasterRecordBuilder
import com.deloitte.asset.insight.operations.MasterRecordBuilder
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import scala.collection.Map
import com.deloitte.asset.insight.services.Logging
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window

object MasterRecordDriver extends Logging with Serializable {

  def main(args: Array[String]) {

    val masterRecordCreation = new MasterRecordBuilder()

    val configPath = args(0)
    val filename = args(1)
    val sourceName = args(2)
    val layerName = args(3).toLowerCase

    var masterConfigData = CommonUtils.parseConfigFile(configPath, filename, sourceName, layerName)
      .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na.", "."), x._2) })

    val bucketName = GlobalVariables.getRootPath
    log.info("Root path set to: " + bucketName)

    val layerNm = GlobalVariables.getLayerName
    log.info("Layer Name set to: " + layerNm)

    val sourceId = GlobalVariables.getSourceId
    log.info("Master ID Set to: " + layerNm)

    val trustTablePath = bucketName + masterConfigData.getOrElse(layerNm + ".trust.table.path", List("NA")).mkString
    log.info("Path of Object Level Trust table: " + trustTablePath)

    val measureTrustTablePath = bucketName + masterConfigData.getOrElse(layerNm + ".measure.trust.table.path", List("NA")).mkString
    log.info("Path of Measure Level Trust table: " + trustTablePath)

    var measureTable: DataFrame = null
    var trustTable: DataFrame = null

    if (!trustTablePath.equalsIgnoreCase("NA")) {
      log.info("Reading Object Level Trust table from path: " + trustTablePath)
      trustTable = CommonUtils.readFromCsvFile(trustTablePath, "true", "false")
      trustTable = trustTable.select(trustTable.columns.map(x => col(x).as(x.toUpperCase())): _*)

    } else {

      trustTable = CommonUtils.readFromCsvFile("src//main//resources//trustTable.csv", "true", "false")
      trustTable = trustTable.select(trustTable.columns.map(x => col(x).as(x.toUpperCase())): _*)
    }

    if (!measureTrustTablePath.equalsIgnoreCase("NA")) {
      log.info("Reading Measure Level Trust table from path: " + measureTrustTablePath)
      measureTable = CommonUtils.readFromCsvFile(measureTrustTablePath, "true", "false")
      measureTable = measureTable.select(measureTable.columns.map(x => col(x).as(x.toUpperCase())): _*)
    } else {
      measureTable = CommonUtils.readFromCsvFile("src//main//resources//measure_trustTable.csv", "true", "false")
    }

    val objectList = masterConfigData.get(layerNm + ".object.name.list").get.map(_.trim().toLowerCase().replaceAll("_", "."))
    log.info("Calling objects: " + objectList)

    objectList.map { objName =>
      val objLayer = layerNm + "." + objName

      objName match {
        case "xref.party"             => masterRecordCreation.getXrefMasterData(objLayer, trustTable, masterConfigData)
        case "dimension.party"        => masterRecordCreation.getPartyAndRelMasterData(objLayer, trustTable, masterConfigData, "ai_party")
        case "contact.fact"           => masterRecordCreation.generateFactMasterData(objLayer, trustTable, measureTable, masterConfigData, "ai_contact_fct")
        case "company.fact"           => masterRecordCreation.generateFactMasterData(objLayer, trustTable, measureTable, masterConfigData, "ai_company_fct")
        case "relation.party.address" => masterRecordCreation.getRelationMasterData(objLayer, trustTable, masterConfigData, "ai_rel_party_address")
        case "relation.party.party"   => masterRecordCreation.getRelationMasterData(objLayer, trustTable, masterConfigData, "ai_rel_party_party")
        case "relation.party.phone"   => masterRecordCreation.getRelationMasterData(objLayer, trustTable, masterConfigData, "ai_rel_party_phone")
        case "relation.party.email"   => masterRecordCreation.getRelationMasterData(objLayer, trustTable, masterConfigData, "ai_rel_party_email")
        case "relation.party.url"     => masterRecordCreation.getRelationMasterData(objLayer, trustTable, masterConfigData, "ai_rel_party_url")
        case _                        => log.info(" No Match Found for =>" + objName)
      }

    }
    log.info("Master build completed")

    System.exit(0)

  }

}