package com.deloitte.asset.insight.operations

import org.apache.log4j.{ Logger }
import java.util.Calendar
import java.io.IOException
import java.text.SimpleDateFormat
import java.io.FileNotFoundException
import java.io.IOException
import scala.collection.Map
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.utils.CommonUtils

object SfdcObjectExtraction {
  val sparkSession = InitiateSparkContext.getSparkSession()
  private[this] val LOGGER = Logger.getLogger(getClass())
  def processSfdcExtraction(configData: Map[String, List[String]], objectName: String) = {
    
    val userName = configData.get(objectName + ".sfdc.username").get(0).split(":")(1)
    LOGGER.info("Username : " + userName)

    val password = configData.get(objectName + ".sfdc.password").get(0).split(":")(1)

    var securityToken = configData.get(objectName + ".sfdc.sec.token").get(0).split(":")(1)
    val sandbox = configData.get(objectName + ".sfdc.sandbox").get(0).split(":")(1)
    val instanceValue = configData.get(objectName + ".sfdc.instance").get(0)
    val sfdcApiVersion = configData.get(objectName + ".sfdc.api.version").get(0).split(":")(1)
    val sfdcObjectName = configData.get(objectName + ".sfdc.objectname").get(0).split(":")(1)
    val instance = instanceValue.split(":")(1) + ":" + instanceValue.split(":")(2) 
    
    if (securityToken.toUpperCase().equals("N")) {
      securityToken = ""
    }

    val date = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(Calendar.getInstance().getTime())

    
    val query = configData.get(objectName + ".sfdc.extraction.query").get(0).split(":")(1)
    var path = configData.get(objectName + ".sfdc.extraction.result.path").get(0).split(":")(1)
  
    val soql = query.toString()

    LOGGER.info("Reading object '" + sfdcObjectName + "' from Salesforce...")
 
    try {
//      val data = sparkSession.read.format("com.springml.spark.salesforce").
//        option("login", instance).
//        option("username", userName).
//        option("password", password + securityToken).
//        option("soql", soql).
//        option("version", sfdcApiVersion).
//        option("sfObject", actualObjectName).
//        
//        load()
      val data = CommonUtils.getSFDCObjects(instance, userName, password + securityToken, soql, sfdcApiVersion, sfdcObjectName)
      val sfdcData = CommonUtils.replaceNewLine(data)
      
      LOGGER.info("Successfully loaded data object '" + sfdcObjectName + "' from Salesforce...")
      path = GlobalVariables.getRootPath + "/" + path

      CommonUtils.writeToS3(sfdcData, path + "/" + sfdcObjectName + "/")
      
      LOGGER.info("Write Successful to File System for " + sfdcObjectName + " at location '" + path + "/" + sfdcObjectName + "/")
      
    } catch {
      case ioException: IOException =>
        LOGGER.info("Write Operation denied");
        ioException.printStackTrace()
      case generalException: Exception =>
        LOGGER.info("Encountered a Generic Exception...");
        generalException.printStackTrace();
        
        LOGGER.error("Encountered Exception while processing '" + objectName + "' from SFDC...");
    }
  }
}
