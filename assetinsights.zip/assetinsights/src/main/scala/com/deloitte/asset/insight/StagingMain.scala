package com.deloitte.asset.insight

import com.deloitte.asset.insight.service.impl.StagingImpl
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.deloitte.asset.insight.utils.DataFrameOperation
import com.deloitte.asset.insight.service.impl.RuleProcessImpl
import org.apache.spark.storage.StorageLevel

/**
 * <b>Staging Object</b>
 * <p>
 * Below Reads Pre-Processed File from S3 location into a Dataframe and then:
 * </p>
 *
 * 1. Create Dataframe stagingDF of Pre-Processed Data saved on s3 by calling method readFromCsvFile.
 *
 * 2. Create the XREF Table by using the Pre-Processed data created in step 1 by calling the method enrichXrefGeneric() and then write to S3.
 *
 * 3. Create the Dimensions Table by using the Pre-Processed data created in step 1 by calling the method enrichDimensionsGeneric() and then write to S3.
 *
 * 4. Create the Fact Table by using the Pre-Processed data created in step 1 by calling the method enrichFactsGeneric() and then write to S3.
 *
 * 5. Create the Fact Table by using the Pre-Processed data created in step 1 by calling the methodenrichRelationsGeneric and then write to S3.
 * </p>
 * @see [[com.deloitte.asset.insight.service.impl.StagingImpl]]
 */

/*
 * @Developer: kanikasharma6
 *
 */
object Staging extends Logging with Serializable {

  def main(args: Array[String]) {

    val sparkSession = InitiateSparkContext.getSparkSession()
    val sparkContext = InitiateSparkContext.getSparkContext()
    val sqlContext = InitiateSparkContext.getSqlContext()
    import DataFrameOperation.implicits._
/*
    if (args.length < 5) {
      log.error("Invalid number of arguments passed")
      log.error("""Arguments Usage:
            [config-file path]
            [File Name]
            [Source Name]
            [Layer Name]
            [ModuleName] - <ALL|XREF|REL|DIM|FACT>
            [DebugFlag] - <optional> <TRUE|FALSE>
            """)
      System.exit(1)
    }

    val inputPathConfig = args(0)
    val fileName = args(1).toUpperCase()
    val sourceName = args(2).toUpperCase()
    val layerName = args(3).toLowerCase()
    val module = args(4)*/

    
    val inputPathConfig = "src//main//resources//SFDC_CONFIG_PROD1.csv"
    val fileName = "CONTACT"
    val sourceName = "TIAA_SALESFORCE"
    val layerName = "staging"
    val module = "FACT"
/*    if (args.length == 6) {
      GlobalVariables.setDebugFlag(args(5))
    } else {
      log.info("Debug Level is set to FALSE")
      GlobalVariables.setDebugFlag("false")
    }*/
    
     /* val inputPathConfig = "src//main//resources//MMD_CONFIG.csv"
    val fileName = "MMCOMP"
    val sourceName = "MMD"
    val layerName = "staging"
    val module = "DIM"*/

    var stagingConfigData = CommonUtils.parseConfigFile(inputPathConfig, fileName, sourceName, layerName)
      .filter(key => key._1.toLowerCase().startsWith(layerName)).map(x => { (x._1.replace(".na.", "."), x._2) })
    //stagingConfigData.map(x=> println(x._1 +"++++++++"+x._2))
    //println("HElo")
    val bucketName = GlobalVariables.getRootPath
    val layerNm = GlobalVariables.getLayerName
    //val debugFlag = GlobalVariables.getDebugFlag
    val debugFlag = "false"

    var stageProcess: StagingImpl = new StagingImpl()

    if (!module.equalsIgnoreCase("HIERARCHY")) {
      
      val inputPath = bucketName + stagingConfigData.get(layerNm + ".input.path").get(0)
      val subsetcols=stagingConfigData.getOrElse(layerNm + ".map.subset.column", List("NA"))
      // Reading Pre-Processed DataFrame
      var stagingDF = CommonUtils.readFromS3Parquet(inputPath, "true").toDF()
      if(!subsetcols(0).equalsIgnoreCase("NA")){
       stagingDF=CommonUtils.getDFWithSubsetCol(subsetcols, stagingDF)
       stagingDF.persist(StorageLevel.MEMORY_AND_DISK_SER) 
      }

      
     
      val ruleCall = new RuleProcessImpl
      stagingDF = ruleCall.processUtilityRule(stagingDF, layerName, stagingConfigData)
      stagingDF.showOrNoShow(debugFlag)

      //Create XREF Table
      if (module.equalsIgnoreCase("ALL")) {
        log.info("XREF Method called")
        val xrefDf = stageProcess.enrichXrefGeneric(stagingDF, stagingConfigData)

        log.info("DIM Method called")
        var stageDimensionValidate = stageProcess.enrichDimensionsGeneric(stagingDF, stagingConfigData)

        log.info("FACT Method called")
        var stageFactsValidate = stageProcess.enrichFactsGeneric(stagingDF, stagingConfigData)

        log.info("REL Method called")
        var stageRelValidate = stageProcess.enrichRelationsGeneric(stagingDF, stagingConfigData)
      } else if (module.equalsIgnoreCase("XREF")) {
        log.info("XREF Method called")
        val xrefDf = stageProcess.enrichXrefGeneric(stagingDF, stagingConfigData)
      } else if (module.equalsIgnoreCase("DIM")) {

        log.info("DIM Method called")
        var stageDimensionValidate = stageProcess.enrichDimensionsGeneric(stagingDF, stagingConfigData)
      } else if (module.equalsIgnoreCase("FACT")) {
        log.info("FACT Method called")
        var stageFactsValidate = stageProcess.enrichFactsGeneric(stagingDF, stagingConfigData)

      } else if (module.equalsIgnoreCase("REL")) {
        log.info("REL Method called")
        var stageRelValidate = stageProcess.enrichRelationsGeneric(stagingDF, stagingConfigData)
      } else {
        log.info("Correct Module has not been defined in Argument four. Expected: <ALL|XREF|REL|DIM|FACT>")
      }
    } else if (module.equalsIgnoreCase("HIERARCHY")) {
      log.info("HIERARCHY Method called")
      var stageRelValidate = stageProcess.enrichHierarchy(stagingConfigData)

    } else {
      log.info("Correct Module has not been defined in Argument four. Expected: <ALL|XREF|REL|DIM|FACT|HIERARCHY>")
    }

  }

}