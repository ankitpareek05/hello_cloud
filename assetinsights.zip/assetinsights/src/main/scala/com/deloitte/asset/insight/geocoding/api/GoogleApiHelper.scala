package com.deloitte.asset.insight.geocoding.api

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

import scala.collection.mutable.StringBuilder
import scala.reflect.api.materializeTypeTag

import org.apache.spark.sql.functions.udf
import org.json.simple.JSONArray
import org.json.simple.JSONObject
import org.json.simple.parser.JSONParser
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.GlobalVariables

object GoogleAPI extends Serializable with Logging {

  val getAddressFromGoogleApiUdf = udf((address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int,invalidChars: Array[String]) => {
    val formattedAddressList = GoogleAPI.getSuggestedAddresses(address, gooleApiURI, googleApiKey, googleApiDelay, invalidChars)
    var output = ""

    if (formattedAddressList == null) {
      log.info("formattedAddress is NULL")
    } else {

      if (formattedAddressList.size > 0) {
        output = formattedAddressList(0).toString()
      }
    }
    output
  })
  
  def getAddressFromGoogleApi(address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]) : String = {
    val formattedAddressList = getSuggestedAddresses(address, gooleApiURI, googleApiKey, googleApiDelay, invalid_chars)
    var output = ""

    if (formattedAddressList == null) {
      log.info("formattedAddress is NULL")
    } else {

      if (formattedAddressList.size > 0) {
        output = formattedAddressList(0).toString()
      }
    }
    output
  }

  def getSuggestedAddresses(_address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]): List[AddressComponent] = {
    var address = _address
    if (address == null)
      address = ""

    var formattedAddress = GoogleAPI.convertAddressForURL(address, invalid_chars)
    var jsonResponse = new StringBuilder()

    try {
      var url = new URL(gooleApiURI + formattedAddress + "&key=" + googleApiKey)
      log.info("url : " + url)

      Thread.sleep(googleApiDelay)
      
      log.info("Calling Google API for " + address)
      val conn = url.openConnection().asInstanceOf[HttpURLConnection]

      conn.setRequestMethod("GET")
      conn.setRequestProperty("Accept", "application/json")
      
      log.info("============== request =====================")
      log.info(conn)

      //Hit Google Geocoding API and get formatted address
      var br = new BufferedReader(new InputStreamReader(conn.getInputStream()))

      var str = br.readLine()
      while (str != null) {
        jsonResponse.append(str)
        str = br.readLine()
      }

      log.info("JSON response from Google API : " + jsonResponse)

      br.close()
    } catch {
      case ex: IOException => {
        log.info("Exception occured : " + ex.getMessage)
        log.info("Affected address : " + address)
      }
    }

    var suggestedAddressList = GoogleAPI.parseJsonResponse(jsonResponse.toString())

    return suggestedAddressList
  }

  /**
   * This method takes JSON response, received from Google API & extract the address components from it.
   * @param jsonResponse
   * @return : Formatted address
   */
  def parseJsonResponse(jsonResponse: String): List[AddressComponent] = {
    var partial_match = "false"
    var s_subpremise = ""
    var s_premise = ""
    var s_streetNumber = ""
    var s_route = ""
    var s_neighborhood = ""
    var s_locality = ""
    var s_administrative_area_level_2 = ""
    var s_administrative_area_level_1 = ""
    var s_country = ""
    var s_postal_code = ""
    var s_postal_code_suffix = ""

    var l_subpremise = ""
    var l_premise = ""
    var l_streetNumber = ""
    var l_route = ""
    var l_neighborhood = ""
    var l_locality = ""
    var l_administrative_area_level_2 = ""
    var l_administrative_area_level_1 = ""
    var l_country = ""
    var l_postal_code = ""
    var l_postal_code_suffix = ""
    var formattedAddress = ""

    var latitude = ""
    var longitude = ""

    // Status of Google API response & List of suggested addresses
    var status = ""
    var errorMessage = ""
    var addressList = List[AddressComponent]()

    try {
      // JSON parser for parsing JSON response, received from Google API
      var parser = new JSONParser()

      var jsonObj: JSONObject = parser.parse(jsonResponse).asInstanceOf[JSONObject]

      status = jsonObj.get("status").toString()
      
//      status = "For making -2 records"

      if (jsonObj.keySet().contains("error_message"))
        errorMessage = jsonObj.get("error_message").toString()

      var suggestedAddressArray = jsonObj.get("results").asInstanceOf[JSONArray]

      var suggestedAddressIterator = suggestedAddressArray.iterator()

      while (suggestedAddressIterator.hasNext()) {

        var suggestedAddress = suggestedAddressIterator.next().asInstanceOf[(JSONObject)]

        var addCompArray = suggestedAddress.get("address_components").asInstanceOf[JSONArray]

        var addCompIterator = addCompArray.iterator()

        while (addCompIterator.hasNext()) {

          var addressComponent = addCompIterator.next().asInstanceOf[(JSONObject)]

          var types = addressComponent.get("types").asInstanceOf[JSONArray].get(0)
          var shortName = addressComponent.get("short_name").toString()
          var longName = addressComponent.get("long_name").toString()
          //log.info("shortName : " + shortName)

          types match {
            case "subpremise" => {
              s_subpremise = shortName
              l_subpremise = longName
            }
            case "premise" => {
              s_premise = shortName
              l_premise = longName
            }
            case "street_number" => {
              s_streetNumber = shortName
              l_streetNumber = longName
            }
            case "route" => {
              s_route = shortName
              l_route = longName
            }
            case "neighborhood" => {
              s_neighborhood = shortName
              l_neighborhood = longName
            }
            case "locality" => {
              s_locality = shortName
              l_locality = longName
            }
            case "administrative_area_level_2" => {
              s_administrative_area_level_2 = shortName
              l_administrative_area_level_2 = longName
            }
            case "administrative_area_level_1" => {
              s_administrative_area_level_1 = shortName
              l_administrative_area_level_1 = longName
            }
            case "country" => {
              s_country = shortName
              l_country = longName
            }
            case "postal_code" => {
              s_postal_code = shortName
              l_postal_code = longName
            }
            case "postal_code_suffix" => {
              s_postal_code_suffix = shortName
              l_postal_code_suffix = longName
            }

            case _ => //log.info("No match found for : " + types)
          }
        }

        formattedAddress = suggestedAddress.get("formatted_address").toString()
        if(suggestedAddress.keySet().contains("partial_match")){
        partial_match = suggestedAddress.get("partial_match").toString()

        }
          
        var latLongDetails = suggestedAddress.get("geometry").asInstanceOf[JSONObject].get("location").asInstanceOf[JSONObject]

        latitude = latLongDetails.get("lat").toString()
        longitude = latLongDetails.get("lng").toString()
      }

      var addressObj = new AddressComponent(partial_match,formattedAddress, status, errorMessage, l_streetNumber, l_route, l_locality, s_administrative_area_level_2, s_administrative_area_level_1, s_country, l_postal_code, l_postal_code_suffix, latitude, longitude,l_subpremise,l_premise)

      addressList = addressList :+ addressObj
    } catch {
      case ex: Exception => ex.getMessage()
    }

    return addressList
  }

  def convertAddressForURL(str: String, invalidChars: Array[String]): String = {

    var address = str
//    val invalidChars = Array("\n", "#", "$", "&")

    for (invalidChar <- invalidChars) {

      if (address.contains(invalidChar)) {
        address = address.replaceAllLiterally(invalidChar, " ")
      }
    } 
    
//    address = address.replace("South", "Sou")
    
    var addressParts = address.trim().split(",")
    var sb = new StringBuilder()

    for (i <- 0 until addressParts.size) {

      var childAddress = addressParts(i).trim().split(" ")

      if (childAddress.length > 1) {

        for (j <- 0 until childAddress.size) {
          //replace " "with "+"
          sb.append(childAddress(j).trim()).append("+")
        }
        // Delete training "+"
        sb.deleteCharAt(sb.length() - 1)
      } else {
        sb.append(addressParts(i).trim())
      }
      if (!addressParts(i).trim().equals(""))
        //replace "," with ",+"
        sb.append(",+")
    }

    if (sb.length() > 2) {
      // Delete training ",+"
      sb.deleteCharAt(sb.length() - 1)
      sb.deleteCharAt(sb.length() - 1)
    }

    return (sb.toString())
  }
}