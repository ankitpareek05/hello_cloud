package com.deloitte.asset.insight.geocoding.api

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

import scala.collection.mutable.StringBuilder
import scala.reflect.api.materializeTypeTag

import org.apache.spark.sql.functions.udf
import org.json.simple.JSONArray
import org.json.simple.JSONObject
import org.json.simple.parser.JSONParser
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.GlobalVariables
//import play.api.libs.json.Json

case class APIResponse(
  ai_address_id:               String,
  formatted_address_o:            String,
  api_response:                      String
  )

object GoogleAPI2 extends Serializable with Logging {

  /*val getAddressFromGoogleApiUdf = udf((address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int,invalidChars: Array[String]) => {
    val formattedAddressList = GoogleAPI.getSuggestedAddresses(address, gooleApiURI, googleApiKey, googleApiDelay, invalidChars)
    var output = ""

    if (formattedAddressList == null) {
      log.info("formattedAddress is NULL")
    } else {

      if (formattedAddressList.size > 0) {
        output = formattedAddressList(0).toString()
      }
    }
    output
  })*/
  
  def getAddressFromGoogleApi(id:String,address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]) : String = {
    val formattedAddressJson = getSuggestedAddresses(id,address, gooleApiURI, googleApiKey, googleApiDelay, invalid_chars)

    if (formattedAddressJson == null) {
      log.info("formattedAddress is NULL")
      return ""
    } else {
            formattedAddressJson
    }
  }

  def getSuggestedAddresses(id:String,_address: String, gooleApiURI: String, googleApiKey: String, googleApiDelay: Int, invalid_chars: Array[String]): String = {
    var address = _address
    if (address == null)
      address = ""

    var formattedAddress = GoogleAPI.convertAddressForURL(address, invalid_chars)
    var jsonResponse = new StringBuilder()

    try {
      var url = new URL(gooleApiURI + "key=" + googleApiKey + "&language=en&address=" + formattedAddress)
      println("url : " + url)

      Thread.sleep(googleApiDelay)
      
      println("Calling Google API for " + address)
      val conn = url.openConnection().asInstanceOf[HttpURLConnection]

      conn.setRequestMethod("GET")
      conn.setRequestProperty("Accept", "application/json")
      
      log.info("============== request =====================")
      log.info(conn)

      //Hit Google Geocoding API and get formatted address
      var br = new BufferedReader(new InputStreamReader(conn.getInputStream()))

      var str = br.readLine()
      while (str != null) {
        jsonResponse.append(str)
        str = br.readLine()
      }

      log.info("JSON response from Google API : " + jsonResponse)

      br.close()
    } catch {
      case ex: IOException => {
        log.info("Exception occured : " + ex.getMessage)
        log.info("Affected address : " + address)
      }
    }

    
//    var addressObj = new APIResponse(id,address,jsonResponse.toString())
    val jsonString = """{"ai_address_id":""""+id+"""","formatted_address_o":""""+address+"""","api_response":"""+jsonResponse.toString()+"""}"""
    /*var parser = new JSONParser()

    var jsonObj: JSONObject = parser.parse(jsonString).asInstanceOf[JSONObject]
    println("JsonObj:::: "+jsonObj)
    return jsonObj*/
    return jsonString//.toString().stripMargin
  }
}