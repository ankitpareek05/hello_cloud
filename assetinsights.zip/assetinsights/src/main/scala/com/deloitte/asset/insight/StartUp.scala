package com.deloitte.asset.insight

import com.typesafe.config.ConfigFactory
import com.deloitte.asset.insight.services.Logging

object StartUp extends Logging {
  def main(args: Array[String]) {

    val conf = ConfigFactory.load()
    log.info("HELLO!!  " + conf.getString("appName"))

    var result_str = "";
    for (row <- 0 to 7) {
      for (column <- 0 to 7) {
        if (((column == 1 || column == 5) && row != 0) || ((row == 0 || row == 3) && (column > 1 && column < 5))) {
          result_str = result_str + "*"
        } else result_str = result_str + " "
      }
      result_str = result_str + "\n"
    }
    print(result_str)

    var result_str1 = "";
    for (row <- 0 to 7) {

      if (row == 0 || row == 7) {
        result_str1 = result_str1 + "********"
      }
      if ((row != 0 || row != 7) && (row > 1 || row < 7)) {
        result_str1 = result_str1 + "   **  "
      }

      result_str1 = result_str1 + "\n"
    }
    print(result_str1)
  }
}