package com.deloitte.asset.insight.utils

object GlobalVariables {
  private var rootPath = ""
  private var fileName = ""
  private var sourceId = ""
  private var sourceName = ""
  private var layerName = ""
  private var moduleName = ""
  private var googleAPIQualityRating = ""
  private var lookupFilePath = ""
  private var debugFlag = ""
  private var coreKeyAsOfDate = ""
  private var coreKeyAsOnDate = ""
  private var coreKeyBatchId = ""
  private var coreKeySrcId = ""

  //Getter
  def getRootPath = rootPath

  //Setter
  def setRootPath(value: String): Unit = rootPath = value

  //Getter
  def getFileName = fileName

  //Setter
  def setFileName(value: String): Unit = fileName = value

  //Getter
  def getSourceId = sourceId

  //Setter
  def setSourceId(value: String): Unit = sourceId = value

  //Getter
  def getSourceName = sourceName

  //Setter
  def setSourceName(value: String): Unit = sourceName = value

  //Getter
  def getLayerName = layerName

  //setter
  def setLayerName(value: String): Unit = layerName = value

  //Getter
  def getModuleName = moduleName

  //setter
  def setModuleName(value: String): Unit = moduleName = value

  //Getter
  def getGoogleAPIQualityRating = googleAPIQualityRating
  
  //setter
  def setGoogleAPIQualityRating(value: String): Unit = googleAPIQualityRating = value
  
  def getLookUpFilePath = lookupFilePath
  
  def setLookUpFilePath(value: String): Unit = lookupFilePath = value

  //Getter
  def getDebugFlag = debugFlag

  //Setter
  def setDebugFlag(value: String): Unit = debugFlag = value

  def getCoreKeyAsOfDateColName = coreKeyAsOfDate

  def setCoreKeyAsOfDateColName(value: String): Unit = coreKeyAsOfDate = value

  def getCoreKeyAsOnDateColName = coreKeyAsOnDate

  def setCoreKeyAsOnDateColName(value: String): Unit = coreKeyAsOnDate = value

  def getCoreKeyBatchIdColName = coreKeyBatchId
  
  def setCoreKeyBatchIdColName(value: String): Unit = coreKeyBatchId = value

  def getCoreKeySourceIdColName = coreKeySrcId
  
  def setCoreKeySourceIdColName(value: String): Unit = coreKeySrcId = value
}