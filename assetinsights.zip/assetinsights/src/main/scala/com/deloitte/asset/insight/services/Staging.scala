package com.deloitte.asset.insight.services

import org.apache.spark.sql.DataFrame
import scala.collection.Map

trait Staging {
  def processSchemaStandarization(mainDF: DataFrame, configData: Map[String, List[String]], layerNAme: String): DataFrame

  def enrichXrefGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]])
  def enrichDimensionsGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]])
  def enrichFactsGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]])
  def enrichRelationsGeneric(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]])
  def enrichRelationsGeneric2(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]])
  def enrichRelationsGeneric3(preProcessedDF: DataFrame, inputConfigData: Map[String, List[String]])
  def enrichHierarchy(inputConfigData: Map[String, List[String]])
}