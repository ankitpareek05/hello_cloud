package com.deloitte.asset.insight.operations

import java.io.FileNotFoundException
import java.io.IOException
import scala.collection.Map

import org.apache.spark.sql.functions.col
import com.deloitte.asset.insight.service.impl.StagingImpl
import com.deloitte.asset.insight.services.Logging
import com.deloitte.asset.insight.utils.CommonConstants
import com.deloitte.asset.insight.utils.CommonUtils
import com.deloitte.asset.insight.utils.GlobalVariables
import com.deloitte.asset.insight.utils.InitiateSparkContext
import org.apache.spark.sql.Row
import org.apache.spark.sql.Dataset

object SfdcObjectInsertion extends Logging {

  val sparkSession = InitiateSparkContext.getSparkSession()
  import sparkSession.implicits._
  def processSfdcInsertion(configData: Map[String, List[String]], objectName: String) = {
    // retrieving the required data from the config object
    val layerName = objectName.split("\\.")(0)
    val bucketName = GlobalVariables.getRootPath
    val inputFilePath = bucketName + configData.get(objectName + ".input.path").get(0).trim()
    val userName = configData.get(layerName + ".sfdc.username").get(0).split(":")(1)
    val password = configData.get(layerName + ".sfdc.password").get(0).split(":")(1)
    val securityToken = configData.get(layerName + ".sfdc.sec.token").get(0).split(":")(1)
    val instance = configData.get(layerName + ".sfdc.instance").get(0)
    val batchSize = Integer.parseInt(configData.get(layerName + ".sfdc.batchsize").get(0).split(":")(1))

    val sfdcObjectName = configData.get(layerName + ".sfdc.objectname").get(0).split(":")(1)
    val instanceName = instance.splitAt(instance.indexOf("http"))._2
    // Creating the dataframe with schema aligned with salesforce
    var i = 0
    val standarizationSchema = configData.get(objectName + "." + CommonConstants.STANDARD_SCHEMA).get
    var oldColArray: Array[String] = new Array[String](standarizationSchema.size)
    standarizationSchema.map(elem =>
      {
        oldColArray(i) = elem.split(":")(0)
        i = i + 1
      })
    val oldColNames = oldColArray.map(name => col(name))

    var inputDf = CommonUtils.readFromCsvFile(inputFilePath, "true", "false")
    inputDf = CommonUtils.replaceNewLine(inputDf)
    val resultantDF = inputDf.select(oldColNames: _*)
    var stageProcess: StagingImpl = new StagingImpl()

    // Renaming the columns to be aligned with salesforce
    var renamedDf = stageProcess.processSchemaStandarization(resultantDF, configData, objectName)
    renamedDf = CommonUtils.replaceNewLine(renamedDf)
    val rowSchema = renamedDf.schema
    val finalWriteData = renamedDf.collectAsList()
    val dataSize = finalWriteData.size()
    var writeDf: Dataset[Row] = null
    var recordCount = 0
    try {

      var dataList = new java.util.ArrayList[Row]()
      for (i <- 0 until dataSize) {
        dataList.add(finalWriteData.get(i))
        recordCount = recordCount + 1
        if (math.abs(i % batchSize) == 0) {
          writeDf = sparkSession.createDataFrame(dataList, rowSchema)
          try {
            CommonUtils.writeSFDCObjects(writeDf, instanceName, userName, password + securityToken, sfdcObjectName)
          } catch {
            case e: Exception => {
              e.printStackTrace()
              log.info("================= Proceeding with next batch ==================")
            }
          }
          dataList = new java.util.ArrayList[Row]()
          println("Completed Batch. Loaded '" + recordCount + "' so far...")
        }
      }
      println("=================== Proceeding with leftover records ==================")
      writeDf = sparkSession.createDataFrame(dataList, rowSchema)
      CommonUtils.writeSFDCObjects(writeDf, instanceName, userName, password + securityToken, sfdcObjectName)
      println("Completed Batch. Loaded '" + recordCount + "' so far...")
    } catch {

      case ioException: IOException =>
        log.info("Write Operation denied")
        ioException.printStackTrace()
      case generalException: Exception =>

      case e: Exception => {
        log.info("Encountered a Generic Exception...")
        e.printStackTrace()
        log.error("Encountered Exception while processing '" + objectName + "' to SFDC...");
      }
    }
  }
}