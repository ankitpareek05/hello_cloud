package com.deloitte.asset.insight.rules

import java.text.SimpleDateFormat

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf

import com.deloitte.asset.insight.utils.InitiateSparkContext
import com.pratik.General.GenricRules
import com.deloitte.asset.insight.utils.CommonUtils
import org.apache.spark.storage.StorageLevel
import scala.collection.Map
import com.deloitte.asset.insight.services.Logging

object CleanseRule extends Serializable with Logging {

  //val suffixes = List("I", "II", "III", "IV", "V", "SENIOR", "JUNIOR", "JR", "SR", "PHD", "APR", "RPH", "PE", "MD", "MA", "DMD", "CME", "ESQ", "ESQUIRE", "i", "ii", "iii", "iv", "v", "JR.", "SR.", "PHD.", "LTD.", "APR.", "RPH.", "PE.", "MD.", "MA.", "DMD.", "CME.", "ESQ.", "ESQUIRE.", "INC.", "J.D.", "TECH.", "PUB.", "ORG.", "PVT.", "CO.", "2ND", "3RD")

  val sparkContext = InitiateSparkContext.getSparkContext()
  val sqlContext = InitiateSparkContext.getSqlContext()

  val genricRules = new GenricRules()

  def rule_Replace_Non_Alphabetic_with_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF

    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Replace_Non_Alphabetic_with_Space(col(colName2)))

    standardData
  }

  def udfrule_Replace_Non_Alphabetic_with_Space = udf((colName: String) => {
    genricRules.rule_Replace_Non_Alphabetic_with_Space(colName)

  })

  def rule_Remove_All_Leading_Zeros(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Remove_All_Leading_Zeros(col(colName2)))

    standardData
  }

  def udfrule_Remove_All_Leading_Zeros = udf((colName: String) => {
    genricRules.rule_Remove_All_Leading_Zeros(colName)

  })

  def rule_Replace_Hyphen_Underscore_with_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Replace_Hyphen_Underscore_with_Space(col(colName2)))

    standardData
  }

  def udfrule_Replace_Hyphen_Underscore_with_Space = udf((colName: String) => {
    genricRules.rule_Replace_Hyphen_Underscore_with_Space(colName)

  })

  def rule_Remove_Non_Numbers(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Remove_Non_Numbers(col(colName2)))

    standardData
  }

  def udfrule_Remove_Non_Numbers = udf((colName: String) => {
    GenricRules.rule_Remove_Non_Numbers(colName)
    //genricRules.rule_ rule_Remove_Non_Numbers(colName)

  })

  def rule_All_Trim(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_All_Trim(col(colName2)))

    standardData
  }

  def udfrule_All_Trim = udf((colName: String) => {
    genricRules.rule_All_Trim(colName)
    //genricRules.rule_ rule_Remove_Non_Numbers(colName)

  })

  def rule_Translate_Diacritic_Characters(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Translate_Diacritic_Characters(col(colName2)))

    standardData
  }

  def udfrule_Translate_Diacritic_Characters = udf((colName: String) => {
    genricRules.rule_Translate_Diacritic_Characters(colName)
    //genricRules.rule_ rule_Remove_Non_Numbers(colName)

  })

  def rule_Replace_Punctuation_with_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Replace_Punctuation_with_Space(col(colName2)))

    standardData
  }

  def udfrule_Replace_Punctuation_with_Space = udf((colName: String) => {
    genricRules.rule_Replace_Punctuation_with_Space(colName)
    //genricRules.rule_ rule_Remove_Non_Numbers(colName)

  })

  def rule_Replace_Period_With_Space(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfrule_Replace_Period_With_Space(col(colName2)))

    standardData
  }

  def udfrule_Replace_Period_With_Space = udf((colName: String) => {
    genricRules.rule_Replace_Period_With_Space(colName)

  })

  def rule_replaceSlashesWithSpace(mainDF: DataFrame, colName1: String, colName2: String, colName3: String): DataFrame = {

    var standardData = mainDF
    standardData = standardData.withColumnRenamed(colName1, colName2)
    standardData = standardData.withColumn(colName3, udfreplaceSlashesWithSpace(col(colName2)))

    standardData
  }

  def udfreplaceSlashesWithSpace = udf((colName: String) => {
    genricRules.replaceSlashesWithSpace(colName)

  })

  def rule_concatColumnsWithPipe(mainDF: DataFrame, ruleValue: String, Delimiter: String): DataFrame = {
    var standardData = mainDF
    val colSplit = ruleValue.split(":")
    var srcColummns = colSplit(0).split('|')
    val keyColumns = CommonUtils.getColumnsArray(srcColummns)
    standardData = standardData.withColumn(colSplit(1), concat_ws(Delimiter, keyColumns: _*))

    standardData
  }

  def rule_concatColumnsWithSpace(mainDF: DataFrame, ruleValue: String, Delimiter: String): DataFrame = {

    var standardData = mainDF
    val colSplit = ruleValue.split(":")
    var srcColummns = colSplit(0).split('|')
    val keyColumns = CommonUtils.getColumnsArray(srcColummns)

    standardData = standardData.withColumn(colSplit(1), concat_ws(Delimiter, keyColumns: _*))

    standardData
  }

  def rule_concatColumnsWithComma(mainDF: DataFrame, ruleValue: String, Delimiter: String): DataFrame = {
    var standardData = mainDF
    val colSplit = ruleValue.split(":")
    var srcColummns = colSplit(0).split('|')
    val keyColumns = CommonUtils.getColumnsArray(srcColummns)
    standardData = standardData.withColumn(colSplit(1), concat_ws(Delimiter, keyColumns: _*))

    standardData
  }

  def rule_concatColumnsWithHyphen(mainDF: DataFrame, ruleValue: String, Delimiter: String): DataFrame = {
    var standardData = mainDF
    val colSplit = ruleValue.split(":")
    var srcColummns = colSplit(0).split('|')
    val keyColumns = CommonUtils.getColumnsArray(srcColummns)
    standardData = standardData.withColumn(colSplit(1), concat_ws(Delimiter, keyColumns: _*))

    standardData
  }

  def rule_concatColumnWithOneNullAlways(mainDF: DataFrame, ruleValue: String): DataFrame = {
    var standardData = mainDF
    var cancatenateDF: DataFrame = null
    val colSplit = ruleValue.split(":")
    var srcColummns = colSplit(0).split("|")
    val keyColumns = CommonUtils.getColumnsArray(srcColummns)
    cancatenateDF = mainDF.withColumn(colSplit(1), when(keyColumns(0).isNull or keyColumns(0).isin(""), keyColumns(1)).otherwise(keyColumns(0)))
    cancatenateDF
  }

  def rule_filterBasedOnColumnValue(mainDf: DataFrame, ruleValue: List[String]): DataFrame = {

    var filterDF = mainDf
    log.info("filterDF schema ::::::" + filterDF.schema)
    val filterExpression = ruleValue.map({ col =>
      val colSplit = col.split(":")
      val filterColName = colSplit(0)
      val filterColValue = colSplit(2)
      var filterOperator = colSplit(1).trim().toUpperCase()
      log.info("filterColName ::::::::::: " + filterColName)
      log.info(" filterOperator ::::::::::: " + filterOperator)
      log.info(" filterColValue::::::::::: " + filterColValue)
      filterOperator match {
        case "NOTEQUAL"             => (filterDF(filterColName) =!= filterColValue)
        case "EQUAL"                => (filterDF(filterColName) === filterColValue)
        case "GREATERTHAN"          => (filterDF(filterColName) > filterColValue)
        case "GREATERTHAN OR EQUAL" => (filterDF(filterColName) >= filterColValue)
        case "LESSTHAN"             => (filterDF(filterColName) < filterColValue)
        case "LESSTHAN OR EQUAL"    => (filterDF(filterColName) <= filterColValue)
      }

    }).reduce(_ && _).toString()
    log.info("filterExpression + " + filterExpression)

    filterDF = filterDF.filter(filterExpression)
    filterDF
  }

  def rule_derivedcolbasedoncolvalue(mainDf: DataFrame, lookupcolumns: String, lookupValues: String): DataFrame = {
    //val lookupValues=inputConfigData.getOrElse("derived.col.lookup.basedon.colvalue", List("NA")).mkString(",")
    var derivedDf = mainDf
    log.info(lookupValues)

    val colSplit = lookupcolumns.split(":")
    if (!lookupValues.equalsIgnoreCase("na")) {
      log.info("lookupvalues" + lookupValues)
      log.info(colSplit(1) + "----" + colSplit(0))
      derivedDf = derivedDf.withColumn(colSplit(1), CommonUtils.addColumnBasedNewValue(derivedDf(colSplit(0)), lit(lookupValues)))
      derivedDf.persist(StorageLevel.MEMORY_AND_DISK_SER)
    }

    derivedDf

  }

  def rule_filterOnColumnIfMultipleKeys(mainDF: DataFrame, col: String): DataFrame = {

    var filterDF = mainDF
    val filterDFSchema = filterDF.schema

    val colName = col.split(":")
    // creating pair rdd with key and entire row in order to reduce bt key
    val keyWithRowRDD = filterDF.rdd.map(eachRecord => (eachRecord.getAs(colName(0)).toString(), eachRecord))

    // reduce by key and if the type = 'C' then ignore that record. This will hold good for key with 2 values only
    val filteredRDD = keyWithRowRDD.reduceByKey((rows, currentRow) => {
      if (rows.getAs(colName(0)).toString() == currentRow.getAs(colName(0)).toString()) {
        if (rows.getAs(colName(1)).toString() == colName(2)) {
          currentRow
        } else {
          rows
        }
      } else {
        currentRow
      }
    }).map(rec => rec._2)

    filterDF = sqlContext.createDataFrame(filteredRDD, filterDFSchema)

    filterDF
  }

  /*def rule_seperatePhoneNumber(mainDF: DataFrame, ruleAction: String): DataFrame = {
    var derivedDf = mainDF
    var finaldf: DataFrame = null
    //columns.map{x=>


      val colSplit = ruleAction.split(":")
      val inputCol = colSplit(0)
      val outputCol1 = colSplit(1)
      val outputCol2 = colSplit(2)
      var df = derivedDf.filter(length(col(inputCol)) > 6 && (col(inputCol).contains("/") || col(inputCol).contains("&")))
      var df1 = derivedDf.filter(length(col(inputCol)) <= 14 && length(col(inputCol)) >= 6 && (!col(inputCol).contains("/") || col(inputCol).contains("&")))
      var filterdf = df.union(df1)
      var noPhonedf = derivedDf.except(filterdf)

      df = df.withColumn(outputCol1, when(size(split(trim(col(inputCol)), "[/&]")) === 2 && length(split(trim(col(inputCol)), "[/&]").getItem(0)) >= 6, trim(split(trim(col(inputCol)), "[/&]").getItem(0))).otherwise(trim(col(inputCol)))).withColumn(outputCol2, when(size(split(trim(col(inputCol)), "[/&]")) === 2 && length(split(trim(col(inputCol)), "[/&]").getItem(1)) >= 6, trim(split(trim(col(inputCol)), "[/&]").getItem(1))).otherwise(lit("")))
      df1 = df1.withColumn(outputCol1, col(inputCol)).withColumn(outputCol2, lit(""))
      noPhonedf = noPhonedf.withColumn(outputCol1, col(inputCol)).withColumn(outputCol2, lit(""))
      finaldf = df.union(df1).union(noPhonedf)


    finaldf
  }*/

  def rule_removeCountryCode(mainDF: DataFrame, columns: String): DataFrame = {
    var derivedDf = mainDF
    var finaldf: DataFrame = null
    val colSplit = columns.split(":")
    val inputCol = colSplit(0)
    val outputCol1 = colSplit(1)
    val outputCol2 = colSplit(2)

    derivedDf = derivedDf.withColumnRenamed(inputCol, outputCol1)

    var df3 = derivedDf.withColumn(outputCol2, when(col(outputCol1).startsWith("(001)"), trim(col(outputCol1).substr(6, 40))).when(col(outputCol1).startsWith("011-"), trim(col(outputCol1).substr(5, 40))).when(col(outputCol1).startsWith("011"), trim(col(outputCol1).substr(4, 40))).when(col(outputCol1).startsWith("001"), trim(col(outputCol1).substr(4, 40))).otherwise(col(outputCol1)))
    finaldf = df3

    finaldf
  }

  def udfReplace = udf((colName: String) => {

    colName.replaceAll("(^011|^001|^(001)|^011-)", "")

  })

  def rule_seperatePhoneNumber(mainDF: DataFrame, ruleAction: String): DataFrame = {
    var derivedDf = mainDF
    var finaldf: DataFrame = null
    val colSplit = ruleAction.split(":")
    val inputCol = colSplit(0)
    val outputCol1 = colSplit(1)
    val outputCol2 = colSplit(2)
    print(inputCol + " " + outputCol1 + " " + outputCol2)
    finaldf = derivedDf.withColumn(outputCol1, trim(udfSeperator(col(inputCol))(0))).withColumn(outputCol2, trim(udfSeperator(col(inputCol))(1)))
    //finaldf.show()
    finaldf
  }

  def udfSeperator = udf((colValue: String) => {
    if (colValue != null && colValue != "" && colValue.length() >= 6 && (colValue.contains("/") || colValue.contains("&"))) {
      val a = colValue.split("[/&]")
      if ((a.size == 2 && (a(0).length() >= 6)) && (a.size == 2 && (a(1).length() >= 6 || a(1).length() <= 14))) {
        Seq(colValue.split("[/&]")(0), colValue.split("[/&]")(1))
      } else
        Seq(colValue, " ")
    } else
      Seq(colValue, " ")

  })

  def rule_createDuplicateColumn(mainDF: DataFrame, columns: String): DataFrame = {
    var standardData = mainDF
    val colSplit = columns.split(":")
    val inputCol = colSplit(0)
    val outputCol1 = colSplit(1)
    val outputCol2 = colSplit(2)

    standardData = standardData.withColumnRenamed(inputCol, outputCol1)
    standardData = standardData.withColumn(outputCol2, standardData(outputCol1))
    standardData
  }

  def rule_splitname(mainDF: DataFrame, column: String): DataFrame = {

    val sparkSession = InitiateSparkContext.getSparkSession()
    sparkSession.udf.register("udfrule_splitname", udfrule_splitname)
    var inputDf = mainDF
    inputDf.persist(StorageLevel.MEMORY_AND_DISK_2)
    //    inputDf = inputDf.withColumn("FIRST_NAME", CleanseRule.udfrule_splitname(inputDf(column), lit("F")))
    //      .withColumn("MIDDLE_NAME", CleanseRule.udfrule_splitname(inputDf(column), lit("M")))
    //      .withColumn("LAST_NAME", CleanseRule.udfrule_splitname(inputDf(column), lit("L")))
    //      .withColumn("SUFFIX", CleanseRule.udfrule_splitname(inputDf(column), lit("S")))

    //inputDf = inputDf.withColumn("SPLITNAME", callUDF("udfrule_splitname",inputDf(column)))

    inputDf = inputDf.withColumn("SPLITNAME", udfrule_splitname(inputDf(column)))
    inputDf = inputDf.withColumn("FIRST_NAME", split(inputDf("SPLITNAME"), "\\|").getItem(0))
      .withColumn("MIDDLE_NAME", split(inputDf("SPLITNAME"), "\\|") getItem (1))
      .withColumn("LAST_NAME", split(inputDf("SPLITNAME"), "\\|").getItem(2))
      .withColumn("SUFFIX", split(inputDf("SPLITNAME"), "\\|").getItem(3))
      .drop(inputDf("SPLITNAME"))
    inputDf
  }

  //  def udfrule_splitname = udf((colName: String) => {
  //
  //    val name: String = nameParser(colName)
  //    name
  //
  //  })

  def udfrule_splitname = udf[String, String]((name: String) => {
    val suffixes = List("I", "II", "III", "IV", "V", "SENIOR", "JUNIOR", "JR", "SR", "PHD", "APR", "RPH", "PE", "MD", "DMD", "CME", "ESQ", "ESQUIRE", "i", "ii", "iii", "iv", "v", "JR.", "SR.", "PHD.", "LTD.", "APR.", "RPH.", "PE.", "MD.", "DMD.", "CME.", "ESQ.", "ESQUIRE.", "INC.", "J.D.", "TECH.", "PUB.", "ORG.", "PVT.", "CO.", "2ND", "3RD")

    val nameArr = name.trim().split(" ").map(x => x.trim())

    var fName = ""
    var mName = ""
    var lName = ""
    var suff = ""

    var returnName = fName + "|" + mName + "|" + lName + "|" + suff

    val index = nameArr.length

    if (name != null && !name.trim().isEmpty()) {

      var nameArry: Array[String] = nameArr

      if ((suffixes.contains(nameArr(index - 1).toUpperCase()))) {

        suff = nameArr(index - 1)
        var trimName = name.dropRight(suff.length)
        // println(name2)

        nameArry = trimName.split(" ", 3)

        //     if (nameArry(2).length == 0){
        //       nameArry = nameArry.slice(0,2)
        //     }
        //nameArry.foreach(println)

        if ((nameArry.length) > 2) {

          fName = nameArry(0)
          mName = nameArry(1)
          lName = nameArry(2)
          val fullname = Array(fName, mName, lName, suff)
          returnName = fName + "|" + mName + "|" + lName + "|" + suff
          returnName
          //return returnName
        }
        else if ((nameArry.length) > 1) {

          fName = nameArry(0)
          lName = nameArry(1)
          val fullname = Array(fName, mName, lName, suff)
          returnName = fName + "|" + mName + "|" + lName + "|" + suff
          returnName
          //return returnName
        } else {

          fName = nameArry(0)
          val fullname = Array(fName, mName, lName, suff)
          returnName = fName + "|" + mName + "|" + lName + "|" + suff
          returnName
          //return returnName
        }

      } else {

        val nameArr = name.split(" ", 3).map(x => x.trim())

        if ((nameArr.length) > 2) {

          fName = nameArr(0)
          mName = nameArr(1)
          lName = nameArr(2)
          val fullname = Array(fName, mName, lName, suff)
          returnName = fName + "|" + mName + "|" + lName + "|" + suff
          returnName
          //return returnName
        }
        else if ((nameArr.length) > 1) {

          fName = nameArr(0)
          lName = nameArr(1)
          val fullname = Array(fName, mName, lName, suff)
          returnName = fName + "|" + mName + "|" + lName + "|" + suff
          returnName
          // return returnName
        } else {

          fName = nameArr(0)
          val fullname = Array(fName, mName, lName, suff)
          returnName = fName + "|" + mName + "|" + lName + "|" + suff
          returnName
          //return returnName
        }

      }

    } else {
      returnName
      //return returnName
    }

  })

}