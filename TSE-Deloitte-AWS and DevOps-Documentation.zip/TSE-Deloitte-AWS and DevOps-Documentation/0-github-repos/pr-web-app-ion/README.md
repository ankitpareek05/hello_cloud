# packer
Repo to hold packer templates to build customized AMIs for DevOps project
