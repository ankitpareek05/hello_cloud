#!bin/bash
sudo su
cd
sudo apt-get update -y
