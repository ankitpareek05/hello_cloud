package com.zurich.dl.generic.utils

object Constants{
     
    /** Audit temp table Name */
    val AUDIT_TBL_TMP="AUD_TBL_BATCH_RUN_LOG_TMP"
    
    /** Audit table name */
    val AUDIT_TBL="AUD_TBL_BATCH_RUN_LOG"
    
    val AUDIT_FILE_STATUS_TBL="AUDIT_SOURCE_FILE_LOAD_MASTER"
    
    /** List of Attunity Columns */
    val ATTUNITYCOLUMNS  = List("header_change_seq","header_change_mask","header_stream_position","header_operation","header_transaction_id","header_change_oper","header_timestamp")
    
    /** Audit columns */
    val AUDITCOLUMNS = List("eudlmd5value","eudleffectivestartdate","eudleffectiveenddate","eudlchangeflag","eudlloaddate","eudlloadedby","eudlbatchid","eudlcurrentind","sourcefilename","eudlsource")
    
    /** Columns specific to audit table */
    val AUDITTBLCOLUMNS=List("aud_job_id","aud_job_run_status","aud_job_run_status")
    val SRC_SSG ="SSG"
    val SRC_PIPELINE = "SSGPIPELINE" 
    val APPLICATION = "Application"
}
