package com.zurich.dl.generic.utils
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.joda.time.DateTime
import grizzled.slf4j.Logger
import org.apache.spark.sql.{ DataFrame }
import org.apache.spark.sql.SaveMode
import java.util.HashMap
import org.apache.spark.sql.functions._ //{ udf, lit, col, broadcast }
import com.zurich.dl.generic.utils.Constants._
import scala.collection.mutable.Map
import org.joda.time.format.DateTimeFormatter
import scala.reflect.runtime.universe
import org.apache.spark.sql.SparkSession
object Utilities {

  val logger = Logger("CustomLogger")
  
  val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

  /**
   * validateNotNull function checks whether the primary key column has
   *  Null values and if any, loads them to the error table
   *
   * @param SQLContext
   * @param DataFrame which contains the input table data
   * @param List which contains the primary key columns read from the yaml file
   * @return DataFrame of valid and invalid records
   */

  def validateNotNull(sqlContext: SparkSession, df: DataFrame, primary_key_col_list: List[String]): List[DataFrame] = {

    var primaryCheckCorrect = ""
    var primary_check_incorrect = ""

    for (z <- primary_key_col_list) {
      primaryCheckCorrect = primaryCheckCorrect + "and length(trim(" + z + "))>0 "
      primary_check_incorrect = primary_check_incorrect + "OR " + z + " is null OR length(trim(" + z + "))=0 "
    }
    df.registerTempTable("incoming_data")
    val valid_records_query = "select * from incoming_data where " + (primaryCheckCorrect.drop(3))
    val invalid_records_query = "select * from incoming_data where " + (primary_check_incorrect.drop(2))

    logger.info(this.getClass.getName() + ": ***valid_records_query:- " + valid_records_query + "***")
    logger.info(this.getClass.getName() + ": ***invalid_records_query:- " + invalid_records_query + "***")

    val valid_records = sqlContext.sql(valid_records_query)
    val invalid_records = sqlContext.sql(invalid_records_query)

    List(valid_records, invalid_records)

  }

  /**
   * ValidateReferentialIntegrity function checks if all the
   *  referential integrity constrains are satisfied and if not,
   *  loads those records to the error table
   *
   * @param SQLContext
   * @param HashMap
   * @param DataFrame
   *        contains the input table data
   * @param List
   *        contains the columns to be checked for referential integrity, read from the yaml file
   * @return DataFrame
   *        records which satisfy and don't satisfy the constraint
   */

  def validateReferentialIntegrity(sqlContext: SparkSession, m: HashMap[String, String], dfInput: DataFrame, colNames: List[String]): List[DataFrame] = {
    val colList = m.keySet().toArray().toList
    var trueList = dfInput
    var falseList = dfInput.limit(0)
    for (list <- colList) {
      val stringToSplit = m.get(list).toUpperCase()

      val finalArray = stringToSplit.split(",")
      val inListInter: (String => String) = (arg: String) => { if (finalArray.contains(arg.toUpperCase())) "true" else "false" }
      val sqlfunc = udf(inListInter)

      val interDF = dfInput.withColumn("Result", sqlfunc(col(list.toString())))
      interDF.registerTempTable("interDF_tbl")

      val resdf = sqlContext.sql("""select * from interDF_tbl where Result = "false"""")
      val falseListInter = resdf.drop("Result")
      falseList = falseList.unionAll(falseListInter)

    }
    if (!(colNames.isEmpty)) {
      falseList = falseList.dropDuplicates(colNames)
    }
    List(trueList, falseList)
  }

  /**
   *  ValidateDateFormat function checks if the date fields
   *  in the data frame are in the format expected in yaml file
   *  and if not, load those records to the error table
   *
   * @param SparkContext
   * @param SQLContext
   * @param DataFrame
   *        contains the records which passed the referential integrity check
   * @param HashMap
   * @return DataFrame
   *         data set of all and error records
   */

  def validateDateFormat(sc1: SparkSession, sqlContext: SparkSession, df: DataFrame, date_map: Map[String, String]): List[DataFrame] = {
    /**
     * take a dataframe as input, get the date fields and its corresponding expected formats from YAML file.
     *   If date is not in expected format, error it out or else convert to ISO
     * */

    val incoming_data = "incoming_data"
    val transformed_data = "transformed_data"
    val col_test = df.columns
    val cn = col_test.length

    var date_sql_null_check: String = ""
    var date_sql_part = ""
    var sql_temp: String = ""

    df.registerTempTable(incoming_data)
    sqlContext.udf.register("ConvertDateTime", convertDateTime _)
    sc1.sparkContext.broadcast(convertDateTime _)

    for (i <- 0 to cn - 1) {
      var flag: String = col_test(i)
      date_map.foreach(x => {
        if (col_test(i).equalsIgnoreCase(x._1.toString())) {

          var edited_col_name = x._1 + "_changed "
          date_sql_part = date_sql_part + ",ConvertDateTime(trim(" + x._1 + """),"""" + x._2 + """") """ + edited_col_name
          flag = "nvl(" + x._1 + """_changed,""" + x._1 + """) as """ + x._1
          date_sql_null_check = date_sql_null_check + x._1 + "_changed is null or "
        }
      })
      sql_temp = sql_temp + "," + flag
    }

    val sql_final = "select " + sql_temp.drop(1) + " from " + transformed_data
    val date_sql_null_check_final = date_sql_null_check.dropRight(4)
    val sql_initial = "select incoming_data.* " + date_sql_part + " from incoming_data"

    logger.info(this.getClass.getName() + ": ***selecting the incoming data with changed date:- " + sql_initial + "***")
    logger.info(this.getClass.getName() + ": ***where clause for not null check :- " + date_sql_null_check_final + "***")
    logger.info(this.getClass.getName() + ": ***selecting the final correct data:- " + sql_final + "***")

    val df_full = sqlContext.sql(sql_initial)
    df_full.registerTempTable(transformed_data)

    val df_total_dataset = sqlContext.sql(sql_final)
    val df_incorrect_dataset = (df_full.filter(date_sql_null_check_final)).select(col_test.head, col_test.tail: _*)
    List(df_total_dataset, df_incorrect_dataset)

  }

  /**
   *  ConvertDateTime function converts the date format of the
   *  incoming date field to ISO format and catches the
   *  IllegalArgumentException and NullPointerException
   *
   * @param String
   *        contains the input date value
   * @param String
   *        contains the date format
   * @return DataFrame of valid and invalid records
   */

  def convertDateTime(dt: String, fmt: String): String = {
    try {
      val dateFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern(fmt)
      val jodatime: DateTime = dateFormatGeneration.parseDateTime(dt);
      val str: String = ISOFormatGeneration.print(jodatime);
      str
    } catch {
      case xe: IllegalArgumentException => return null
      case xe: NullPointerException     => return null
    }
  }

  /** getCurrentTimestamp function returns the current timestamp in ISO format */
  def getCurrentTimestamp(): String = {
    val now: DateTime = new org.joda.time.DateTime()
    ISOFormatGeneration.print(now)
  }

  /**
   * getBatchId function generates a batch ID for each run
   */
  def getBatchId(): String = {
    val now: DateTime = new org.joda.time.DateTime()
    val BatchIdFormatGeneration = DateTimeFormat.forPattern("yyyyMMddHHmmss")
    BatchIdFormatGeneration.print(now)
  }

  /**
   *  PerformCDC function takes the incremental data from DateFormat method
   *  output, inserts it into History snapshot and updates the current flag
   *  in history snapshot
   *
   *  @param SQLContext
   *  @param BatchId
   *  @param DataFrame
   *         history data frame
   *  @param DataFrame
   *         incremental data frame
   *  @param List
   *         primary key column list
   *  @return List(DataFrame)
   */

  def performCDC(sqlContext: SparkSession, batchId: String, history_df: DataFrame, incremental_df: DataFrame, primary_key_col_list: List[String]): List[DataFrame] = {
    import sqlContext.implicits._
    /** Attunity Columns& Audit Columns List */

    val attunityChangeOper = ATTUNITYCOLUMNS(5)
    val attunityTimestamp = ATTUNITYCOLUMNS(6)
    val auditMd5Value = AUDITCOLUMNS(0)
    val auditEffStartDt = AUDITCOLUMNS(1)
    val auditEffEndDt = AUDITCOLUMNS(2)
    val auditChangeFlag = AUDITCOLUMNS(3)
    val auditBatchId = AUDITCOLUMNS(6)
    val auditCurrentInd = AUDITCOLUMNS(7)

    /** Get Target Table Schema */
    val dataSchema = history_df.columns

    /** Get the records from target table which have matching keys in Incremental dataset */
   
    val changedDf = history_df.as("d1").join(broadcast(incremental_df), primary_key_col_list)
      .select($"d1.*").distinct().select(dataSchema.head, dataSchema.tail: _*)
    
    logger.info(this.getClass.getName() + ": ***Getting the records from target table which have matching keys in Incremental dataset***")

    /** Get the unchanged records from target table */
    val unchangedDf = history_df.except(changedDf).select(dataSchema.head, dataSchema.tail: _*)
    
    logger.info(this.getClass.getName() + ": ***Getting the unchanged records from target table***")
    
    /** Create a dataframe with deleted records from Incremental set using the Change Flag */
    val deletedDf = incremental_df.filter($"$attunityChangeOper" === "D").as("T1").join(broadcast(changedDf.as("T2")), primary_key_col_list).select($"T1.*", $"T2.$auditEffStartDt")
      .drop(f"$auditBatchId").withColumn(f"$auditCurrentInd", lit("N")).withColumn(f"$auditEffEndDt", unix_timestamp($"$attunityTimestamp", "yyyy-MM-dd HH:mm:ss").cast("timestamp"))
      .withColumn(f"$auditChangeFlag", lit("D")).withColumn(f"$auditBatchId", lit(batchId)).select(dataSchema.head, dataSchema.tail: _*)
     
    logger.info(this.getClass.getName() + ": ***Created a dataframe with deleted records from Incremental set using the Change Flag***")
     
    /** Create a dataframe with updated records(Expired Records) from Target table with Proper History Stich (EndDt=New Record Start date - 1 Second) */
    val updateDeleteDf = history_df.as("T1").join(broadcast(incremental_df.filter($"$attunityChangeOper" === "U").as("T2")), primary_key_col_list).select($"T1.*", $"T2.$attunityTimestamp")
      .drop(f"$auditCurrentInd", f"$auditEffEndDt", f"$auditChangeFlag", f"$auditBatchId").withColumn(f"$auditEffEndDt", unix_timestamp($"$attunityTimestamp", "yyyy-MM-dd HH:mm:ss").minus(1).cast("timestamp"))
      .withColumn(f"$auditChangeFlag", lit("UD")).withColumn(f"$auditCurrentInd", lit("N")).withColumn(f"$auditBatchId", lit(batchId)).select(dataSchema.head, dataSchema.tail: _*)
     
    logger.info(this.getClass.getName() + ": ***Created a dataframe with updated records(Expired Records) from Target table with Proper History Stich (EndDt=New Record Start date - 1 Second)***")
     
    /** Create a dataframe with Updated records from Incremental set using the Change Flag */
    val updateInsertDf = incremental_df.filter($"$attunityChangeOper" === "U").withColumn(f"$auditCurrentInd", lit("Y")).withColumn(f"$auditChangeFlag", lit("UI"))
      .withColumn(f"$auditEffStartDt", unix_timestamp($"$attunityTimestamp", "yyyy-MM-dd HH:mm:ss").cast("timestamp"))
      .withColumn(f"$auditEffEndDt", lit("9999-12-31").cast("timestamp")).select(dataSchema.head, dataSchema.tail: _*)

    logger.info(this.getClass.getName() + ": ***Created a dataframe with Updated records from Incremental set using the Change Flag***")  
      
    /** Create a dataframe with New records from Incremental set using the Change Flag */
    val insertDf = incremental_df.filter($"$attunityChangeOper" === "I").withColumn(f"$auditCurrentInd", lit("Y")).withColumn(f"$auditChangeFlag", lit("I"))
      .withColumn(f"$auditEffStartDt", unix_timestamp($"$attunityTimestamp", "yyyy-MM-dd HH:mm:ss").cast("timestamp"))
      .withColumn(f"$auditEffEndDt", lit("9999-12-31").cast("timestamp")).select(dataSchema.head, dataSchema.tail: _*)

    logger.info(this.getClass.getName() + ": ***Created a dataframe with New records from Incremental set using the Change Flag***")
   
    /** Union all active records (Current Indicator =Y) */
    val activeDf = unchangedDf.union(updateInsertDf).union(insertDf)
    
    logger.info(this.getClass.getName() + ": ***Union all active records with CurrentInd = 'Y'***")

    /** Union all active records (Current Indicator =N) */
    val inactiveDf = deletedDf.union(updateDeleteDf)
    
    logger.info(this.getClass.getName() + ": ***Union all active records with CurrentInd = 'N'***")

    /** Returns active,Inactive datasets */
    List(activeDf, inactiveDf)
  }

  /** Insert Audit Record For Incremental/Full Load */

  def insertInAudit(sqlContext: SparkSession, databaseName: String, srcTable: String, tgtTable: String, primaryKeyList: List[String], aud_job_id: String, aud_sub_job_id: String, aud_job_id_raw: String, aud_sub_job_start_timestamp: String, aud_job_start_timestamp: String, aud_sub_job_end_timestamp: String, aud_updatedby: String, load_Type: String,aud_cob_date: String, auditBatchId: String) = {

    sqlContext.sql(f"""use $databaseName""")

    val auditTableTemp = AUDIT_TBL_TMP
    val auditJobIdCol = AUDITTBLCOLUMNS(0)
    val auditSubJobStatusCol = AUDITTBLCOLUMNS(2)
    val auditBatchIdCol = AUDITCOLUMNS(6)
    val auditChangeFlagCol = AUDITCOLUMNS(3)
    val attunityChangeOperCol = ATTUNITYCOLUMNS(5)
    val attunityChangeIndCol = AUDITCOLUMNS(7)
    val auditJobId = aud_job_id
    val auditJobIdRaw = aud_job_id_raw
    val auditJobRunStatus = null
    val auditJobEndTs = null
    var auditSubJobRunStatus = ""
    val auditCOBDate = aud_cob_date
    val auditUpdateTmp = DateTime.now()
    val auditUpdateDt = DateTimeFormat.forPattern("yyyy-MM-dd").print(auditUpdateTmp)
    val primary_key_list = primaryKeyList.mkString(",")
    var auditSubJobSrcRowCount = -1
    var auditSubJobTgtRowCount = -2

    if (load_Type.toUpperCase() == "INCREMENTAL") {

      auditSubJobSrcRowCount = sqlContext.sql(f"""select cast(count(distinct $primary_key_list) as Int) from $srcTable where $attunityChangeOperCol IN ('I','U','D')""").head.getInt(0)
      auditSubJobTgtRowCount = sqlContext.sql(f"""select cast(count(*) as Int) from $tgtTable where $auditBatchIdCol=$auditBatchId and $auditChangeFlagCol IN ('I','UI','D')""").head.getInt(0)
    }

    if (load_Type.toUpperCase() == "FULL") {

      auditSubJobSrcRowCount = sqlContext.sql(f"""select cast(count(*) as Int) from $srcTable""").head.getInt(0)
      auditSubJobTgtRowCount = sqlContext.sql(f"""select cast(count(*) as Int) from $tgtTable""").head.getInt(0)
    }

    if (load_Type.toUpperCase() == "APPLICATIONDATA") {
      
      auditSubJobSrcRowCount = sqlContext.sql(f"""select cast(count(*) as Int) from $srcTable""").head.getInt(0)
     
      var condition = ""
      if (tgtTable.toLowerCase().contains("apply")) {
        condition = " and " + auditBatchIdCol + "=" + auditBatchId
      } 
      auditSubJobTgtRowCount = sqlContext.sql(f"""select cast(count(*) as Int) from $tgtTable where $attunityChangeIndCol='Y'""" + condition).head.getInt(0)
    }

    if (auditSubJobSrcRowCount == auditSubJobTgtRowCount) {
      auditSubJobRunStatus = "SUCCESS"
    } else {
      auditSubJobRunStatus = "FAIL"
    }

    val auditDf = sqlContext.sql(f"""select "$auditBatchId" as aud_batch_id ,"$auditCOBDate" as aud_cob_date,"$auditJobId" as aud_job_id,$auditJobRunStatus as aud_job_run_status,"$aud_job_start_timestamp" as aud_job_start_timestamp,$auditJobEndTs as aud_job_end_timestamp,"$aud_sub_job_id" as aud_sub_job_id,"" as aud_sub_job_log_path,"$aud_sub_job_start_timestamp" as aud_sub_job_start_timestamp,"$aud_sub_job_end_timestamp" as aud_sub_job_end_timestamp,"$auditSubJobRunStatus" as aud_sub_job_run_status,"$auditSubJobSrcRowCount" as aud_sub_job_source_rowcount,"$auditSubJobTgtRowCount" as aud_sub_job_target_rowcount,"$aud_updatedby" as aud_updatedby,"$auditUpdateDt" as aud_update_date""")

    logger.info(this.getClass.getName() + ": ***Loading into audit temp table " + auditTableTemp + "***")
    auditDf.write.mode(SaveMode.Append).insertInto(auditTableTemp)
  }

  /**
   * Perform CDC for Full loads with the help of primary keys and checksum and identify the inserts, updates and deletes for the current load
   */
  def performCDCForFullLoads(sqlContext: SparkSession, batchId: String, history_df: DataFrame, incremental_df: DataFrame, primary_key_col_list: List[String], currentTimeStamp: String): List[DataFrame] = {

    import sqlContext.implicits._
    /** Audit Columns List */
    val auditMd5Value = AUDITCOLUMNS(0)
    val auditEffEndDt = AUDITCOLUMNS(2)
    val auditChangeFlag = AUDITCOLUMNS(3)
    val auditCurrentInd = AUDITCOLUMNS(7)

    val dataSchema = history_df.columns

    val primary_key_with_checksum = primary_key_col_list :+ auditMd5Value
    var flag: Boolean = true
    var primaryNullCheck = ""
    for (z <- primary_key_col_list) {
      if (flag) {
        primaryNullCheck = primaryNullCheck + " d2." + z + " is null "
        flag = false
      } else {
        primaryNullCheck = primaryNullCheck + " AND d2." + z + " is null "
      }
    }

    /** identify unchanged data when compared to historic data using primary keys and checksum */
    val unchangeddData = history_df.as("d1").join(incremental_df, primary_key_with_checksum)
      .select($"d1.*").distinct().select(dataSchema.head, dataSchema.tail: _*)
      
    logger.info(this.getClass.getName() + ": ***unchanged data when compared to historic data using primary keys and checksum***")

    /** identify the updates and inserts from the current batch by removing the unchanged data */
    val incrementallatestData = incremental_df.as("d1").join(unchangeddData.as("d2"), primary_key_with_checksum, "left_outer")
      .where(primaryNullCheck)
      .select($"d1.*").distinct().select(dataSchema.head, dataSchema.tail: _*)

    logger.info(this.getClass.getName() + ": ***updates and inserts from the current batch by removing the unchanged data***")
      
    /** unchanged, inserts and updates will be active data which will go under 'Y' partition */
    val activeData = unchangeddData.union(incrementallatestData)

    logger.info(this.getClass.getName() + ": ***unchanged, inserts and updates will be active data which will go under 'Y' partition***")
    
    /** identify the expired and updated data which will go under 'N' partition */
    val updatedAndExpiredData = history_df.except(unchangeddData)

    logger.info(this.getClass.getName() + ": ***expired and updated data which will go under 'N' partition***")
    
    /** need to update the eff end date, change flag and change indicator before writing into 'N' partition */
    val inActiveData = updatedAndExpiredData.drop(f"$auditCurrentInd", f"$auditEffEndDt", f"$auditChangeFlag")
      .withColumn(f"$auditEffEndDt", lit(currentTimeStamp).cast("timestamp"))
      .withColumn(f"$auditCurrentInd", lit("N"))
      .withColumn(f"$auditChangeFlag", lit("N"))
      .select(dataSchema.head, dataSchema.tail: _*)

    List(activeData, inActiveData)

  }

}
