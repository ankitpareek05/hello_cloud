package com.zurich.dl.generic.utils

// import scala.reflect.BeanProperty
import scala.beans.BeanProperty

class Config {

  @BeanProperty var source_name = new java.util.HashMap[String, L1Info]

}
class L1Info {
  @BeanProperty var primary_key = new java.util.ArrayList[String]
  @BeanProperty var null_check_fields = new java.util.ArrayList[String]
  @BeanProperty var date_fields = new java.util.HashMap[String, String]
  @BeanProperty var reference_check = new java.util.HashMap[String, String]
  @BeanProperty var raw_layer_tbl = new String
  @BeanProperty var raw_layer_cdc_tbl = new String
  @BeanProperty var l1_tbl = new String
  @BeanProperty var l1_err_tbl = new String
}

class RawAvroConfig {
@BeanProperty var rawSource = new java.util.HashMap[String, RawAvroInfo]
}

class RawAvroInfo {
@BeanProperty var staginDir = new String
@BeanProperty var rawLayerTbl = new String
@BeanProperty var fileDelimiter = new String
}
