package com.zurich.dl.ssg.consumption

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import com.zurich.dl.generic.utils.Utilities
import grizzled.slf4j.Logger
import org.apache.spark.SparkException
import com.zurich.dl.generic.utils.Constants._
import com.zurich.dl.generic.utils.RawAvroConfig
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }

/**
 * The Class SSGCustomerDetails.
 */
object SSGCustomerDetails {

  def main(args: Array[String]) {
    
    val logger = Logger("CustomLogger")
     
      if (args.length != 5) {
      logger.error("Invalid number of arguments passed.")
      logger.error("<Database Name> <Target view name> <Property File Path> <BatchId> <Loadedby>")
      System.exit(1)
    }
     
    logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
    val startTime = Utilities.getCurrentTimestamp()
     
    logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")
     
    val sqlContext = SparkSession.builder()
                                 .appName("SSGCustomerDetails")
                                 .enableHiveSupport()
                                 .getOrCreate()
    
    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    import sqlContext.implicits._
    sqlContext.conf.set("hive.exec.dynamic.partition", "true");
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
    sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");
    
    /** Load Property File */
    logger.info(this.getClass.getName() + ": ***Reading Property file***")
    
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val propertyFilePath = fs.open(new Path(args(2)))   
    val propConfReader = new InputStreamReader(propertyFilePath)
    val propConf = ConfigFactory.parseReader(propConfReader)
    
    val consumptionViewDb = args(1).split('.')
    
    /** Read the queries from the property file */
    val query1 =  propConf.getString("query_1").replaceAll("\\bCONSUMPTION_VIEW_DB", consumptionViewDb(0))
    val query2 =  propConf.getString("query_2")
    val query3 =  propConf.getString("query_3")
    val query4 =  propConf.getString("query_4")
    val query5 =  propConf.getString("query_5")
    val query6 =  propConf.getString("query_6")
    val query7 =  propConf.getString("query_7")
    val query8 =  propConf.getString("query_8")
    val query9 =  propConf.getString("query_9")
    val query10 =  propConf.getString("query_10")
    val query11 =  propConf.getString("query_11")
    val query12 =  propConf.getString("query_12")
    val query13 =  propConf.getString("query_13")
    val query14 =  propConf.getString("query_14")
    
    val joinkeys=propConf.getString("join_key_list")
    val joinkeyList=joinkeys.split(",").toList
    
    /** Audit Column Names */
    val auditBatchIdCol = AUDITCOLUMNS(6)
    val auditLoadDateCol = AUDITCOLUMNS(4)
    val auditLoadedByCol = AUDITCOLUMNS(5)
    val auditSourceCol = AUDITCOLUMNS(9)
   
    /** Audit Column Data */ 
    val batchId =args(3)
    val loadedBy=args(4)
    val sourceName=SRC_SSG
    val loadDate = Utilities.getCurrentTimestamp()
   
    val tgtTbl=args(1)
    
	  /** Use the database */
    sqlContext.sql("use "+args(0)) 
    
    /** Get the Consumption View Temp table Schema */ 	
    val trgtTblSc = sqlContext.table(tgtTbl).columns
    
    logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")
    val DfCustomerPolicyDetails=sqlContext.sql(query1)
    val DfPartyType=sqlContext.sql(query2)
    val DfPersonDetails=sqlContext.sql(query3)
    val DfLastName=sqlContext.sql(query4)
    val DfGoneAway=sqlContext.sql(query5)
    val DfEmailAddress=sqlContext.sql(query6)
    val DfDayTimePhoneNumber=sqlContext.sql(query7)
    val DfEveningPhoneNumber=sqlContext.sql(query8)
    val DfHomePhoneNumber=sqlContext.sql(query9)
    val DfOfficePhoneNumber=sqlContext.sql(query10)
    val DfMobilePhoneNumber=sqlContext.sql(query11)
    val DfAddressDetails=sqlContext.sql(query12)
    val DfMarketingPreference=sqlContext.sql(query13)
    val DfCorrespondencePreference=sqlContext.sql(query14)
    
    val cliClientPublicRef=List(joinkeyList(0))
    val policyNumber=List(joinkeyList(1))
    
    logger.info(this.getClass.getName() + ": ***Creating Final Dataframe**") 
    val finalDf = DfCustomerPolicyDetails.join(broadcast(DfPartyType),cliClientPublicRef,"left").drop(DfPartyType(joinkeyList(0)))
                .join(broadcast(DfPersonDetails),cliClientPublicRef,"left").drop(DfPersonDetails(joinkeyList(0)))
                .join(broadcast(DfLastName),cliClientPublicRef,"left").drop(DfLastName(joinkeyList(0)))
                .join(broadcast(DfGoneAway),cliClientPublicRef,"left").drop(DfGoneAway(joinkeyList(0)))
                .join(broadcast(DfEmailAddress),cliClientPublicRef,"left").drop(DfEmailAddress(joinkeyList(0)))
                .join(broadcast(DfDayTimePhoneNumber),cliClientPublicRef,"left").drop(DfDayTimePhoneNumber(joinkeyList(0)))
                .join(broadcast(DfEveningPhoneNumber),cliClientPublicRef,"left").drop(DfEveningPhoneNumber(joinkeyList(0)))
                .join(broadcast(DfHomePhoneNumber),cliClientPublicRef,"left").drop(DfHomePhoneNumber(joinkeyList(0)))
                .join(broadcast(DfOfficePhoneNumber),cliClientPublicRef,"left").drop(DfOfficePhoneNumber(joinkeyList(0)))
                .join(broadcast(DfMobilePhoneNumber),cliClientPublicRef,"left").drop(DfMobilePhoneNumber(joinkeyList(0)))
                .join(broadcast(DfAddressDetails),cliClientPublicRef,"left").drop(DfAddressDetails(joinkeyList(0)))
                .join(broadcast(DfMarketingPreference),cliClientPublicRef,"left").drop(DfMarketingPreference(joinkeyList(0)))
                .join(broadcast(DfCorrespondencePreference),joinkeyList,"left").drop(DfCorrespondencePreference(joinkeyList(0))).drop(DfCorrespondencePreference(joinkeyList(1)))
                .drop(DfCustomerPolicyDetails(joinkeyList(0)))
                .withColumn(auditBatchIdCol,lit(batchId))
                .withColumn(auditLoadDateCol,lit(loadDate))
                .withColumn(auditLoadedByCol,lit(loadedBy))
                .withColumn(auditSourceCol,lit(sourceName))
                .select(trgtTblSc.head, trgtTblSc.tail: _*)
   
    logger.info(this.getClass.getName() + ": ***Loading the target table***")            
    finalDf.withColumn("goneaway", coalesce($"goneaway", lit("N"))).write.mode(SaveMode.Overwrite).insertInto(tgtTbl)

    val endTime = Utilities.getCurrentTimestamp()

    logger.info(this.getClass.getName() + ": ***Consumption View for SSG CustomerDetails is Completed at : " + endTime + "***")
    sqlContext.stop()
  }
}