package com.zurich.dl.ssg.consumption

import org.apache.spark.sql.SparkSession
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
import grizzled.slf4j.Logger
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader
import com.zurich.dl.generic.utils.Utilities
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.types.StringType

/**
 * The Class SSGPolicyIDV.
 */
object SSGPolicyIDV {

  def main(args: Array[String]) {

    val logger = Logger("CustomLogger")

    if (args.length != 5) {
      logger.error("invalid number of arguments passed.")
      logger.error("<Database Name> <Target view name> <Property File Path> <BatchId> <Loadedby>")
      System.exit(1)
    }

    logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
    val startTime = Utilities.getCurrentTimestamp()
     
    logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")

    val sqlContext = SparkSession.builder()
      .appName("SSGPolicyIDV")
      .enableHiveSupport()
      .getOrCreate()

    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    val tgtTbl = args(1)
    val consumptionViewDb = args(1).split('.')

    val batchId = args(3)
    val loadedBy = args(4)
    val loadDate = Utilities.getCurrentTimestamp()
    val sourceName = SRC_SSG

    /** Audit columns. */
    val auditLoadDate = AUDITCOLUMNS(4)
    val auditLoadedBy = AUDITCOLUMNS(5)
    val auditBatchId = AUDITCOLUMNS(6)
    val auditSourceCol = AUDITCOLUMNS(9)

    /** Reading the property file having queries. */
    logger.info(this.getClass.getName() + ": ***Reading Property file***")
    
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val propertyFilePath = fs.open(new Path(args(2)))
    val propConfReader = new InputStreamReader(propertyFilePath)
    val propConf = ConfigFactory.parseReader(propConfReader)
    val query1 = propConf.getString("query_1").replaceAll("\\bCONSUMPTION_VIEW_DB", consumptionViewDb(0))

    val notNullColumns = propConf.getString("not_null_columns_list")
    val notNullColumnsList = notNullColumns.split(",").toList

    var flag: Boolean = true
    var nullCheck = ""
    for (z <- notNullColumnsList) {
      if (flag) {
        nullCheck = nullCheck + z + " is not null "
        flag = false
      } else {
        nullCheck = nullCheck + " OR " + z + " is not null "
      }
    }

    /** Use the database. */
    sqlContext.sql("use " + args(0))
    val trgtTblSc = sqlContext.table(tgtTbl).columns
    
    logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")
    val policyIdVDf = sqlContext.sql(f"""$query1""")
    policyIdVDf.createOrReplaceTempView("policyIdVDf")

    /**
     *  Added the not null checks to eliminate records with all null values
     *  except for policy number and adding the audit columns.
     */
    logger.info(this.getClass.getName() + ": ***Creating Final Dataframe**")
    val finalDf = policyIdVDf.where(nullCheck)
      .withColumn(f"$auditBatchId", lit(batchId))
      .withColumn(f"$auditLoadDate", lit(loadDate).cast("timestamp"))
      .withColumn(f"$auditSourceCol", lit(sourceName))
      .withColumn(f"$auditLoadedBy", lit(loadedBy))
      .select(trgtTblSc.head, trgtTblSc.tail: _*)

    /** Inserting the data into the table. */
    logger.info(this.getClass.getName() + ": ***Loading the target table***")  
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tgtTbl)

    val endTime = Utilities.getCurrentTimestamp()

    logger.info(this.getClass.getName() + ": ***Consumption View for SSG-PolicyIDV is Completed at : " + endTime + "***")
    sqlContext.stop()

  }

}
    