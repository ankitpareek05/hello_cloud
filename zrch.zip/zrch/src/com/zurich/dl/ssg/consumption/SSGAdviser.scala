package com.zurich.dl.ssg.consumption

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import grizzled.slf4j.Logger
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import com.zurich.dl.generic.utils.Utilities
import java.io.InputStreamReader
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.{lit,broadcast}
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.serializer.KryoSerializer

/**
 * The Class SSGAdviser.
 */
object SSGAdviser {

  def main(args: Array[String]) {
    
     val logger = Logger("CustomLogger")

      if (args.length != 5) {
     logger.error("invalid number of arguments passed.")
     logger.error("Arguments Usage: <Database Name><Target Table><property file path><Batch_ID><LoadedBy>")
     System.exit(1)
    }

     logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
     val startTime = Utilities.getCurrentTimestamp()
     
     logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")
     
     val sqlContext = SparkSession.builder()
                                  .appName("SSGAdviser")
                                  .enableHiveSupport()
                                  .getOrCreate()
    
     sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
     sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
     sqlContext.conf.set("spark.eventLog.enabled", "true")
     sqlContext.conf.set("spark.app.id", "Logs")
     sqlContext.conf.set("spark.io.compression.codec", "snappy")
     sqlContext.conf.set("spark.rdd.compress", "true")

     import sqlContext.implicits._
     sqlContext.conf.set("hive.exec.dynamic.partition", "true");
     sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
     sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");

     /** Load Property File */
     logger.info(this.getClass.getName() + ": ***Reading Property file***")
     
     val conf = new Configuration()
     val fs = FileSystem.get(conf);
     val propertyFilePath = fs.open(new Path(args(2)))   
     val propConfReader = new InputStreamReader(propertyFilePath)
     val propConf = ConfigFactory.parseReader(propConfReader)
     val queryHierarchy =  propConf.getString("query_hierarchy")
     val queryAdviser =  propConf.getString("query_adviser")
     val queryAdviserAdd =  propConf.getString("query_adviseradd")
     
     val joinkeys=propConf.getString("join_key_list")
     val joinkeyList=joinkeys.split(",").toList
    
     /** Audit Column Names */
     val auditBatchIdCol = AUDITCOLUMNS(6)
     val auditLoadDateCol = AUDITCOLUMNS(4)
     val auditLoadedByCol = AUDITCOLUMNS(5)
     val auditSourceCol = AUDITCOLUMNS(9)
   
     /** Audit Column Data */ 
     val batchId =args(3)
     val loadedBy=args(4)
     val sourceName=SRC_SSG
     val loadDate = Utilities.getCurrentTimestamp()
   
     val tgtTbl=args(1)
    
     /** Use the database */
     sqlContext.sql("use "+args(0)) 
     
     /** Get the Consumption View Temp table Schema */
     val trgtTblSc = sqlContext.table(tgtTbl).columns
    
     val adviserCode=joinkeyList(0)
     
     logger.info(this.getClass.getName() + ": ***Creating data frame with Hierarchy query ***")
     val adviserHierarchyDf=sqlContext.sql(queryHierarchy)
     adviserHierarchyDf.createOrReplaceTempView("query_hierarchy")
     
     logger.info(this.getClass.getName() + ": ***Creating data frame with adviser query ***")
     
     val adviserDf=sqlContext.sql(queryAdviser)
       
     
     logger.info(this.getClass.getName() + ": ***Creating data frame with adviserAdd query ***")
     val adviserAddDf=sqlContext.sql(queryAdviserAdd)
    
     logger.info(this.getClass.getName() + ": ***Creating final data frame ****")
     val finalDf=adviserDf.join(broadcast(adviserAddDf),joinkeyList,"left").drop(adviserAddDf(adviserCode))
                          .withColumn(auditBatchIdCol,lit(batchId))
                          .withColumn(auditLoadDateCol,lit(loadDate))
                          .withColumn(auditLoadedByCol,lit(loadedBy))
                          .withColumn(auditSourceCol,lit(sourceName))
                          .select(trgtTblSc.head, trgtTblSc.tail: _*)
   
     logger.info(this.getClass.getName() + ": ***Loading the target table***")
     finalDf.write.mode(SaveMode.Overwrite).insertInto(tgtTbl)

     val endTime = Utilities.getCurrentTimestamp()

     logger.info(this.getClass.getName() + ": ***Consumption View for Application-Requirements is Completed at : " + endTime + "***")
     sqlContext.stop()
  }
}