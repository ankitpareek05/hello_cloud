package com.zurich.dl.ssg.consumption

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import grizzled.slf4j.Logger
import org.apache.spark.SparkException
import com.zurich.dl.generic.utils.Constants._
import com.zurich.dl.generic.utils.RawAvroConfig
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import com.zurich.dl.generic.utils.Utilities
import java.io.InputStreamReader
import org.apache.spark.sql.SaveMode
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }

/**
 * The Class SSGPolicyList.
 */
object SSGPolicyList {

 def main(args: Array[String]) {

  val logger = Logger("CustomLogger")

    if (args.length != 5) {
     logger.error("invalid number of arguments passed.")
     logger.error("Arguments Usage: <Database Name><Target Table><property file path><Batch_ID><LoadedBy>")
     System.exit(1)
    }

  logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
    val startTime = Utilities.getCurrentTimestamp()
     
    logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")

  val sqlContext = SparkSession.builder()
                               .appName("SSGPolicyList")  
                               .enableHiveSupport()  
                               .getOrCreate()

  sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
  sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
  sqlContext.conf.set("spark.eventLog.enabled", "true")
  sqlContext.conf.set("spark.app.id", "Logs")
  sqlContext.conf.set("spark.io.compression.codec", "snappy")
  sqlContext.conf.set("spark.rdd.compress", "true")

  import sqlContext.implicits._
  sqlContext.conf.set("hive.exec.dynamic.partition", "true");
  sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
  sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");

  /** Load Property File */
  logger.info(this.getClass.getName() + ": ***Reading Property file***")
  
  val conf = new Configuration()
  val fs = FileSystem.get(conf);
  val propertyFilePath = fs.open(new Path(args(2)))   
   val propConfReader = new InputStreamReader(propertyFilePath)
  val propConf = ConfigFactory.parseReader(propConfReader)
  val consumptionViewDb = args(1).split('.')
    
  /** Read the queries from the property file */
  val query1 =  propConf.getString("query_1")
   val query2 =  propConf.getString("query_2") 
  val query3 =  propConf.getString("query_3")
  val query4 =  propConf.getString("query_4")
  val query5 =  propConf.getString("query_5")
  val query6 =  propConf.getString("query_6").replaceAll("\\bCONSUMPTION_VIEW_DB", consumptionViewDb(0))
        val query7 =  propConf.getString("query_7")
  val joinkeys=propConf.getString("join_key_list")
  val joinkeyList=joinkeys.split(",").toList
  
  /** Audit Column Names */
  val auditBatchIdCol = AUDITCOLUMNS(6)
  val auditLoadDateCol = AUDITCOLUMNS(4)
  val auditLoadedByCol = AUDITCOLUMNS(5)
  val auditSourceCol = AUDITCOLUMNS(9)

  /** Audit Column Data */ 
  val batchId =args(3)
  val loadedBy=args(4)
  val sourceName=SRC_SSG
  val loadDate = Utilities.getCurrentTimestamp()
    
  val tgtTbl=args(1)
    
  /** Use the database */
  sqlContext.sql("use "+args(0)) 
    
  /** Get the Consumption View Temp table Schema */ 
  val trgtTblSc = sqlContext.table(tgtTbl).columns
    
  /** Create the Load ready set for loading the Consumption View Temp table */
  logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")
        val mainDf=sqlContext.sql(query1)
        val policyStatusDf=sqlContext.sql(query2)
        val applicationDf=sqlContext.sql(query3)
        val sellingAgentcodeDf=sqlContext.sql(query4) 
        val premiumbandDf=sqlContext.sql(query5)
        val custmrmatchDf=sqlContext.sql(query6)
        val policyinceptDf=sqlContext.sql(query7)
  val policyNumber=joinkeyList(0) 

    logger.info(this.getClass.getName() + ": ***Creating Final Dataframe**")
  val finalDf=mainDf.join(broadcast(policyStatusDf),joinkeyList,"left").drop(policyStatusDf(policyNumber))
                    .join(broadcast(applicationDf),joinkeyList,"left").drop(policyStatusDf(policyNumber))
                    .join(broadcast(sellingAgentcodeDf),joinkeyList,"left").drop(sellingAgentcodeDf(policyNumber))                   
                    .join(broadcast(premiumbandDf),joinkeyList,"left").drop(premiumbandDf(policyNumber))
                    .join(broadcast(custmrmatchDf),joinkeyList,"left").drop(custmrmatchDf(policyNumber))
                          .join(broadcast(policyinceptDf),joinkeyList,"left").drop(custmrmatchDf(policyNumber))
                      .withColumn(auditBatchIdCol,lit(batchId))
                    .withColumn(auditLoadDateCol,lit(loadDate))
                      .withColumn(auditLoadedByCol,lit(loadedBy))
                      .withColumn(auditSourceCol,lit(sourceName))
                      .select(trgtTblSc.head, trgtTblSc.tail: _*)
         
  logger.info(this.getClass.getName() + ": ***Loading the target table***")
  
  /******Overwrite(Truncate and Load) the Load ready set into the Consumption View Temp table *****/ 
  finalDf.write.mode(SaveMode.Overwrite).insertInto(tgtTbl)
  
  val endTime = Utilities.getCurrentTimestamp()

    logger.info(this.getClass.getName() + ": ***Consumption View for SSG-PolicyList is Completed at : " + endTime + "***")
    sqlContext.stop()

 }
}