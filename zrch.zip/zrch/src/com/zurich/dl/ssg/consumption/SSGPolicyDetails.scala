package com.zurich.dl.ssg.consumption

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import grizzled.slf4j.Logger
import org.apache.spark.SparkException
import com.zurich.dl.generic.utils.Constants._
import com.zurich.dl.generic.utils.RawAvroConfig
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader
import org.apache.spark.sql.SaveMode
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }
import com.zurich.dl.generic.utils.Utilities

/**
 * The Class SSGPolicyDetails.
 */
object SSGPolicyDetails {

  def main(args: Array[String]) {
    
    val logger = Logger("CustomLogger")
    
    if (args.length != 5) {
      logger.error("invalid number of arguments passed.")
      logger.error("<Database Name> <Target view name> <Property File Path> <BatchId> <Loadedby>")
      System.exit(1)
    }

    logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
    val startTime = Utilities.getCurrentTimestamp()
     
    logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")

     
    val sqlContext = SparkSession.builder()
                                 .appName("SSGPolicyDetails")
                                 .enableHiveSupport()
                                 .getOrCreate()
    
    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    import sqlContext.implicits._
    sqlContext.conf.set("hive.exec.dynamic.partition", "true");
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
    sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");
    
    sqlContext.sql("CREATE TEMPORARY FUNCTION collect AS 'com.zurich.dl.generic.udf.CollectUDAF'")
    
    /** Load Property File */
    logger.info(this.getClass.getName() + ": ***Reading Property file***")
    
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val propertyFilePath = fs.open(new Path(args(2)))   
    val propConfReader = new InputStreamReader(propertyFilePath)
    val propConf = ConfigFactory.parseReader(propConfReader)
    
    /** Read queries from property file */
    val policyInceptionDate = propConf.getString("policyInceptionDate")
    val financialMovement =  propConf.getString("financialMovement")
    val claRole =  propConf.getString("claRole")
    val grossprm =  propConf.getString("grossprm")
    val repamt =  propConf.getString("repamt")
    val sumAssured =  propConf.getString("sumAssured")
    val finMovType =  propConf.getString("finMovType")
    
    val appDate =  propConf.getString("appDate")
    val lasmoker =  propConf.getString("lasmoker")
    val policyProduct =  propConf.getString("policyProduct")
    val accountType =  propConf.getString("accountType")
    val dates =  propConf.getString("dates")
    val freq =  propConf.getString("freq")
    val trusttype =  propConf.getString("trusttype")
    
    val collectionDay =  propConf.getString("collectionDay")
    val note =  propConf.getString("note")
    val deferredperiod =  propConf.getString("deferredperiod")
    val wopdeferredperiod =  propConf.getString("wopdeferredperiod")
    val decIntRate =  propConf.getString("decIntRate")
    val index =  propConf.getString("index")
    val policyBasis =  propConf.getString("policyBasis")

    val tgtTbl=args(1)
    val currentDate = Utilities.getCurrentTimestamp()
    val batchId = args(3)
    val loadedBy = args(4)
    val sourceName=SRC_SSG
    
    /** Use the database */
    sqlContext.sql("use "+ args(0))
    
    logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")
    val policyInceptionDateDf = sqlContext.sql(policyInceptionDate)
    val financialMovementDf =sqlContext.sql(financialMovement)
    val claRoleDf =sqlContext.sql(claRole)
    val grossprmDf =sqlContext.sql(grossprm)
    val repamtDf =sqlContext.sql(repamt)
    val sumAssuredDf =sqlContext.sql(sumAssured)
    val finMovTypeDf =sqlContext.sql(finMovType)

    policyInceptionDateDf.createOrReplaceTempView("policyInceptionDateDF")
    financialMovementDf.createOrReplaceTempView("financialMovementDf")
    claRoleDf.createOrReplaceTempView("claRoleDf")
    grossprmDf.createOrReplaceTempView("grossprmDf")
    repamtDf.createOrReplaceTempView("repamtDf")
    sumAssuredDf.createOrReplaceTempView("sumAssuredDf")
    finMovTypeDf.createOrReplaceTempView("finMovTypeDf")

    val appDateDf =sqlContext.sql(appDate)
    val lasmokerDf =sqlContext.sql(lasmoker)
    val policyProductDf =sqlContext.sql(policyProduct)
    val accountTypeDf =sqlContext.sql(accountType)
    val datesDf =sqlContext.sql(dates)
    val freqDf =sqlContext.sql(freq)
    val trusttypeDf =sqlContext.sql(trusttype)

    appDateDf.createOrReplaceTempView("appDateDf")
    lasmokerDf.createOrReplaceTempView("lasmokerDf")
    policyProductDf.createOrReplaceTempView("policyProductDf")
    accountTypeDf.createOrReplaceTempView("accountTypeDf")
    datesDf.createOrReplaceTempView("datesDf")
    freqDf.createOrReplaceTempView("freqDf")
    trusttypeDf.createOrReplaceTempView("trusttypeDf")

    val collectionDayDf =sqlContext.sql(collectionDay)
    val noteDf =sqlContext.sql(note)
    val deferredperiodDf =sqlContext.sql(deferredperiod)
    val wopdeferredperiodDf =sqlContext.sql(wopdeferredperiod)
    val decIntRateDf =sqlContext.sql(decIntRate)
    val indexDf =sqlContext.sql(index)
    val policyBasisDf =sqlContext.sql(policyBasis)
    
    collectionDayDf.createOrReplaceTempView("collectionDayDf")
    noteDf.createOrReplaceTempView("noteDf")
    deferredperiodDf.createOrReplaceTempView("deferredperiodDf")
    wopdeferredperiodDf.createOrReplaceTempView("wopdeferredperiodDf")
    decIntRateDf.createOrReplaceTempView("decIntRateDf")
    indexDf.createOrReplaceTempView("indexDf")
    policyBasisDf.createOrReplaceTempView("policyBasisDf")

    val aggregateDf = sqlContext.sql("""SELECT cc.Ctrt_ContractPublicRef AS policynumber,
	NULL as subaccountnumber,
	NULL as portfolioid,
	NULL as lastname,
	NULL as firstname,
	NULL as birthdate,
	NULL as livingstatus,
	cc.CommencementDate AS policytermstartdate,
	pid.BusinessStartDate AS policyinceptiondate,
	NULL as totalcurrentpensionvalue,
	NULL as totalvalueofpensioncontributions,
	NULL as currentproductvalue,
	NULL as mostrecentregularemployercontribution,
	NULL as mostrecentregularemployeecontribution,
	fm.mostrecentregulardirectcontribution,
	cr.mostrecentregularcontributiondatereceived,
	NULL as totalreginddue,
	NULL as totalregindrecdgross,
	NULL as totalregindrecdnet,
	NULL as nonprsinglecontrecdgross,
	gp.grosspremiumindividual,
	NULL as netpremiumindividual,
	ra.representamount,
	sa.sumassured,
	fmt.totalcontdueamtreg,
	fmt.totalcontrecdamtreg,
	fmt.totalcontdueamt,
	fmt.totalcontrecdamt,
	NULL as targetmaturityvalue
FROM l1_tbl_Ctrt_Contract cc
LEFT JOIN 
policyInceptionDateDf pid
	ON cc.Ctrt_ContractPublicRef = pid.Ctrt_ContractPublicRef
LEFT JOIN financialMovementDf fm
	ON cc.Ctrt_ContractPublicRef = fm.Ctrt_ContractPublicRef
LEFT JOIN claRoleDf cr
	ON cc.Ctrt_ContractPublicRef = cr.Ctrt_ContractPublicRef
LEFT JOIN grossprmDf gp
	ON cc.Ctrt_ContractPublicRef = gp.Ctrt_ContractPublicRef
LEFT JOIN repamtDf ra
	ON cc.Ctrt_ContractPublicRef = ra.Ctrt_ContractPublicRef
LEFT JOIN sumAssuredDf sa
	ON cc.Ctrt_ContractPublicRef = sa.Ctrt_ContractPublicRef
LEFT JOIN finMovTypeDf fmt
	ON cc.Ctrt_ContractPublicRef = fmt.Ctrt_ContractPublicRef
WHERE cc.eudlcurrentind = 'Y'""").distinct

aggregateDf.createOrReplaceTempView("aggregateDf")


val aggregate2Df =
sqlContext.sql("""
select 
cc.policynumber,
cc.subaccountnumber,
cc.portfolioid,
cc.lastname,
cc.firstname,
cc.birthdate,
cc.livingstatus,
cc.policytermstartdate,
cc.policyinceptiondate,
cc.totalcurrentpensionvalue,
cc.totalvalueofpensioncontributions,
cc.currentproductvalue,
cc.mostrecentregularemployercontribution,
cc.mostrecentregularemployeecontribution,
cc.mostrecentregulardirectcontribution,
cc.mostrecentregularcontributiondatereceived,
cc.totalreginddue,
cc.totalregindrecdgross,
cc.totalregindrecdnet,
cc.nonprsinglecontrecdgross,
cc.grosspremiumindividual,
cc.netpremiumindividual,
cc.representamount,
cc.sumassured,
cc.totalcontdueamtreg,
cc.totalcontrecdamtreg,
cc.totalcontdueamt,
cc.totalcontrecdamt,
NULL as targetmaturityvalue,
appDateDf.appentereddate,
NULL as remainingelements,
NULL as deferredsumassured,
NULL as investmentamount,
ls.la1smoker,
ls.la2smoker,
NULL as selectedretirementage,
NULL as accountstatus,
pp.policystatus,
pp.policystatusdate,
pp.productname,
pp.producttype,
acc.accounttype,
"0" as productversion,
datesDf.enddate,
datesDf.maturitydate,
datesDf.reviewdate,
NULL as schemename,
NULL as schemereferencenumber,
NULL as leaverscheme,
NULL as paycentrename,
NULL as datejoinedemployer,
freqDf.expectedcontributionfrequency,
NULL as expectedemployercontributiontype,
NULL as expectedemployercontribution,
NULL as expectedmembercontributiontype,
NULL as expectedmembercontribution,
NULL as expectedavccontributiontype,
NULL as expectedavccontribution,
NULL as expectedpersonalcontribution,
NULL as expectedpersonalcontfrequency,
NULL as nextexpectedpersonalcontdate,
NULL as expectedpaymentout,
NULL as expectedpaymentoutfrequency,
NULL as nextexpectedpaymentoutdate,
NULL as expectedpaymentsoutstartdate,
NULL as pensionablesalary,
NULL as concurrentschemeindicator,
NULL as laprindicator,
NULL as wipindicator,
'1' as policyriskonlyind,
NULL as polqualindnotcal,
NULL as unitgrowth,
NULL as ipppercent,
t.trusttype
from aggregateDf cc
left join appDateDf 
on cc.policynumber = appDateDf.Ctrt_ContractPublicRef
left join lasmokerDf ls
on cc.policynumber = ls.Ctrt_ContractPublicRef
left join policyProductDf pp
on cc.policynumber = pp.Ctrt_ContractPublicRef
left join accountTypeDf acc
on cc.policynumber = acc.Ctrt_ContractPublicRef
left join datesDf 
on cc.policynumber = datesDf.Ctrt_ContractPublicRef
left join freqDf
on cc.policynumber = freqDf.Ctrt_ContractPublicRef
left join trusttypeDf t
on cc.policynumber = t.Ctrt_ContractPublicRef""").distinct

aggregate2Df.createOrReplaceTempView("aggregate2Df")

val aggregate3Df =
sqlContext.sql(f"""
select  
cc.policynumber,
cc.subaccountnumber,
cc.portfolioid,
cc.lastname,
cc.firstname,
cc.birthdate,
cc.livingstatus,
cc.policytermstartdate,
cc.policyinceptiondate,
cc.totalcurrentpensionvalue,
cc.totalvalueofpensioncontributions,
cc.currentproductvalue,
cc.mostrecentregularemployercontribution,
cc.mostrecentregularemployeecontribution,
cc.mostrecentregulardirectcontribution,
cc.mostrecentregularcontributiondatereceived,
cc.totalreginddue,
cc.totalregindrecdgross,
cc.totalregindrecdnet,
cc.nonprsinglecontrecdgross,
cc.grosspremiumindividual,
cc.netpremiumindividual,
cc.representamount,
cc.sumassured,
cc.totalcontdueamtreg,
cc.totalcontrecdamtreg,
cc.totalcontdueamt,
cc.totalcontrecdamt,
cc.targetmaturityvalue,
cc.appentereddate,
cc.remainingelements,
cc.deferredsumassured,
cc.investmentamount,
cc.la1smoker,
cc.la2smoker,
cc.selectedretirementage,
cc.accountstatus,
cc.policystatus,
cc.policystatusdate,
cc.productname,
cc.producttype,
cc.accounttype,
cc.productversion,
cc.enddate,
cc.maturitydate,
cc.reviewdate,
cc.schemename,
cc.schemereferencenumber,
cc.leaverscheme,
cc.paycentrename,
cc.datejoinedemployer,
cc.expectedcontributionfrequency,
cc.expectedemployercontributiontype,
cc.expectedemployercontribution,
cc.expectedmembercontributiontype,
cc.expectedmembercontribution,
cc.expectedavccontributiontype,
cc.expectedavccontribution,
cc.expectedpersonalcontribution,
cc.expectedpersonalcontfrequency,
cc.nextexpectedpersonalcontdate,
cc.expectedpaymentout,
cc.expectedpaymentoutfrequency,
cc.nextexpectedpaymentoutdate,
cc.expectedpaymentsoutstartdate,
cc.pensionablesalary,
cc.concurrentschemeindicator,
cc.laprindicator,
cc.wipindicator,
cc.policyriskonlyind,
cc.polqualindnotcal,
cc.unitgrowth,
cc.ipppercent,
cc.trusttype,
collectionDayDf.collectionday,
noteDf.policymessages,
NULL as linkedpolicytransfertype,
NULL as linkedpolicynumber,
NULL as fund_code,
NULL as fund_name,
NULL as fund_units,
NULL as latest_fund_price,
NULL as latest_fund_price_date,
NULL as fund_value,
NULL as isincode,
NULL as fundallocation,
NULL as fundprotectedrightsind,
NULL as policyridercodes,
NULL as policyridercodedesc,
NULL as subscriptionsintaxyear,
NULL as arrangementtype,
NULL as pensionadayfundvalue,
dp.deferredperiodla1,
dp.deferredperiodla2,
wdp.wopdeferredperiodla1,
wdp.wopdeferredperiodla2,
decIntRateDf.decreasinginterestrate,
indexDf.indexationdeferrals,
policyBasisDf.policybasis,
"$sourceName" as eudlsource,
"$batchId" as eudlbatchid,
CURRENT_TIMESTAMP () as eudlloaddate,
"$loadedBy" as eudlloadedby
from aggregate2Df cc
left join collectionDayDf 
on cc.policynumber = collectionDayDf.Ctrt_ContractPublicRef
left join noteDf 
on cc.policynumber = noteDf.Ctrt_ContractPublicRef
left join deferredperiodDf dp
on cc.policynumber = dp.Ctrt_ContractPublicRef
left join wopdeferredperiodDf wdp 
on cc.policynumber = wdp.Ctrt_ContractPublicRef
left join decIntRateDf
on cc.policynumber = decIntRateDf.Ctrt_ContractPublicRef
left join indexDf
on cc.policynumber = indexDf.Ctrt_ContractPublicRef
left join policyBasisDf
on cc.policynumber = policyBasisDf.Ctrt_ContractPublicRef""").distinct


    aggregate3Df.createOrReplaceTempView("aggregate3Df")
    
    logger.info(this.getClass.getName() + ": ***Loading the target table***")
    aggregate3Df.write.mode(SaveMode.Overwrite).insertInto(tgtTbl)
    
    val endTime = Utilities.getCurrentTimestamp()

    logger.info(this.getClass.getName() + ": ***Consumption View for SSG-PolicyDetails is Completed at : " + endTime + "***")
    sqlContext.stop()
    
  }
}