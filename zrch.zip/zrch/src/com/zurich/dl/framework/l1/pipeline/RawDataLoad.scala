package com.zurich.dl.framework.l1.pipeline

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import grizzled.slf4j.Logger
import org.apache.spark.SparkException
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.Constructor

import com.zurich.dl.generic.utils.Constants._
import com.zurich.dl.generic.utils.RawAvroConfig
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }

/**
 * The RawDataLoad program implements an application
 * that loads the files from staging to raw layer
 * with the help of a yaml configuration file
 *
 * It takes the source name, configuration file path
 * and batch id as arguments
 */

object RawDataLoad {

  val logger = Logger("CustomLogger")
  val sqlContext = SparkSession.builder()
    .appName("Raw-Data-Load")
    .enableHiveSupport()
    .getOrCreate()

  sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
  sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
  sqlContext.conf.set("spark.eventLog.enabled", "true")
  sqlContext.conf.set("spark.app.id", "Logs")
  sqlContext.conf.set("spark.io.compression.codec", "snappy")
  sqlContext.conf.set("spark.rdd.compress", "true")
  sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false")

  val fs = FileSystem.get(new Configuration())
  var errorDesc = ""
  var fileStatus = ""
  var fileName = ""
  var run_date = ""
  var present = ""
  var fileMvStatus = ""
  var successInd = -1

  /** Attunity Columns& Audit Columns List */

  val attunityChangeOper = ATTUNITYCOLUMNS(5)
  val attunityTimestamp = ATTUNITYCOLUMNS(6)
  val auditMd5Value = AUDITCOLUMNS(0)
  val auditEffStartDt = AUDITCOLUMNS(1)
  val auditEffEndDt = AUDITCOLUMNS(2)
  val auditChangeFlag = AUDITCOLUMNS(3)
  val auditBatchId = AUDITCOLUMNS(6)
  val auditCurrentInd = AUDITCOLUMNS(7)
  val auditLoadDate = AUDITCOLUMNS(4)
  val loadedBy = AUDITCOLUMNS(5)
  val sourceFileName = AUDITCOLUMNS(8)

  def main(args: Array[String]) {

    if (args.length != 5) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <Yaml path> <source name> <Batch id> <DataBase Name> <header flag>")
      System.exit(1)
    }

    val yamlPath = args(0)
    val sourceName = args(1)
    val batchId = args(2)

    /** Load YAML FILE */
    val ios = fs.open(new Path(yamlPath))
    logger.info(this.getClass.getName() + ": *** After YAML initialisation ***")
    val yaml = new Yaml(new Constructor((classOf[RawAvroConfig])))
    val obj = yaml.load(ios).asInstanceOf[RawAvroConfig]
    logger.info(this.getClass.getName() + ": " + obj.rawSource)

    /** Read parameters from the YAML file */
    val inputPath = obj.getRawSource().get(sourceName).staginDir
    logger.info(this.getClass.getName() + ": ***staging_Dir " + inputPath + "***")

    val avroRawTable = obj.getRawSource().get(sourceName).rawLayerTbl
    logger.info(this.getClass.getName() + ": ***Raw_Layer_Tbl " + avroRawTable + "***")

    val delimiter = obj.getRawSource().get(sourceName).fileDelimiter
    logger.info(this.getClass.getName() + ": ***Raw Table - " + avroRawTable + " File_Delimiter " + delimiter + "***")

    logger.info(this.getClass.getName() + ": ***Raw table : " + avroRawTable + ", batch ID is = " + batchId + "***")
    
    val dbName = args(3)

    val headerPresence = args(4)

    /** Use the database */
    sqlContext.sql(f"use $dbName")

    val file_status = fs.listStatus(new Path(inputPath))
    val file_name_list = file_status.map { s => s.getPath }

    sqlContext.sql(f"""truncate table $avroRawTable""")

    file_name_list.foreach { x =>
      {

        /** For each file, derive the file name and path */
        val file_name = x.toString().substring(x.toString().lastIndexOf("/") + 1)
        val file_path = x.toString().substring(0, x.toString().lastIndexOf("/"))

        fileName = file_name
        run_date = getCurrentTimestamp()

        /** Load the file into table */
       // println(f"*******************************$file_name*********************************************")
        logger.info(this.getClass.getName() + ": ***Raw Table - " + avroRawTable + " File Name : " + fileName + "***")
        
        logger.info(this.getClass.getName() + ": ***Raw Table - " + avroRawTable + " In Univocity***")
       
        successInd = readCsvCommons(x.toString(), delimiter, avroRawTable, "Univocity", fileName, batchId, run_date, headerPresence)
        if (successInd == 1) {
          logger.info(this.getClass.getName() + ": ***Raw Table - " + avroRawTable + " In Commons***")
          successInd = readCsvCommons(x.toString(), delimiter, avroRawTable, "commons", fileName, batchId, run_date, headerPresence)
        }

        /** Make an entry in audit table */
        logger.info(this.getClass.getName() + ": ***Raw Table - " + avroRawTable + " Making an entry in the audit file load master table.***")
        insertInAuditFileStatus(batchId, avroRawTable, fileName, run_date, fileStatus, errorDesc)
        if (successInd > 0) {
          System.exit(successInd)
        }
      }
    }
    sqlContext.stop()
  }

  val ISOFormatGeneration: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss")

  def getCurrentTimestamp(): String = {
    val now: DateTime = new org.joda.time.DateTime()
    ISOFormatGeneration.print(now) // return
  }

  def insertInAuditFileStatus(batchId: String, rawTbl: String, fileName: String, run_date: String, fileStatus: String, errorDesc: String) = {
    val errorDsc = errorDesc.replaceAll("\"", """\\"""")
    val statusDf = sqlContext.sql(f"""select "$batchId" as batch_id ,"$rawTbl" as raw_table_name, "$fileName" as source_file_name,"$run_date" as file_load_date,"$fileStatus" as file_load_status,"$errorDsc" as remarks """)
    statusDf.write.mode(SaveMode.Append).insertInto(AUDIT_FILE_STATUS_TBL)
  }

  def readCsvCommons(path: String, delimiter: String, avroRawTable: String, parser: String, fileName: String, batchId: String, run_date: String, headerPresence: String): Int = {
    try {
      val rawTblSchema = sqlContext.table(avroRawTable).drop(f"$auditBatchId", f"$auditLoadDate", f"$sourceFileName").schema
      val rawDf = sqlContext.read.format("com.databricks.spark.csv")
        .option("delimiter", delimiter)
        .option("header", headerPresence)
        .option("parserLib", parser)
        .option("mode", "FAILFAST")
        .schema(rawTblSchema)
        .option("multiLine", true)
        .option("quote", "\"")
        .load(path)
       
      logger.info(this.getClass.getName() + ": ***Loading the raw table  - " + avroRawTable + "***")
      rawDf.withColumn(f"$auditBatchId", lit(batchId)).withColumn(f"$auditLoadDate", lit(run_date)).withColumn(f"$sourceFileName", lit(fileName)).write.mode(SaveMode.Append).format("avro").insertInto(avroRawTable)
      logger.info(this.getClass.getName() + ": Loading the raw table  - " + avroRawTable)
     // errorDesc = ""
      fileStatus = "LOADED"
      logger.info(this.getClass.getName() + ": ***File status for table - " + avroRawTable + " : " + fileStatus + "***")
      return 0
    } catch {
      case xe: IllegalArgumentException => return 1 // return
      case xe: NullPointerException     => return 1 // return
      case xe: SparkException => try { throw xe.getCause }
      catch {
        case xe: RuntimeException =>
          logger.info("RUNTIME EXCEPTION : " + xe.getMessage.substring(0, 100))
          errorDesc = xe.getMessage.substring(0, 100)
          fileStatus = "FAILED"
          return 1
        case xe: InvalidInputException =>
          logger.info("INVALID INPUT EXCEPTION : " + xe.getMessage.substring(0, 100))
          errorDesc = xe.getMessage.substring(0, 100)
          fileStatus = "FAILED"
          return 1
        case xe: Exception =>
          logger.info("EXCEPTION : " + xe.getMessage.substring(0, 100))
          errorDesc = xe.getMessage.substring(0, 100) 
          fileStatus = "FAILED"
          return 1
      }
    }
  }
}


