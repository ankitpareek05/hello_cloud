package com.zurich.dl.framework.l1.pipeline

import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.Constructor
import com.zurich.dl.generic.utils.Config
import grizzled.slf4j.Logger
import org.apache.spark.sql.DataFrame
import scala.collection.JavaConverters._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SaveMode
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import com.zurich.dl.generic.utils.Utilities
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.joda.time.DateTime
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader

import java.util.Calendar
import java.text.SimpleDateFormat

/**
 * The Class ApplicationDataLoad.
 */
object ApplicationDataLoad {

  def main(args: Array[String]) {

    val logger = Logger("CustomLogger")

    logger.info(this.getClass.getName() + ": *** Initializing Spark Session ***")

    val sqlContext = SparkSession.builder()
      .appName("Application-Data-Load")
      .enableHiveSupport()
      .getOrCreate()

    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    import sqlContext.implicits._
    sqlContext.conf.set("hive.exec.dynamic.partition", "true");
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
    sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");

    if (args.length != 10) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <source-name> <config-file path><Batch_ID><DataBase Name><sub_job_id><batch_start_date><LoadedBy><auditJobIdFull><auditJobIdRaw><auditCOBDate>")
      System.exit(1)
    }

    val sourceName = args(0)
    logger.info(this.getClass.getName() + ": ***Logging Started for source, " + sourceName + " DQ Check utility running ***")

    /** Load YAML FILE. */
    logger.info(this.getClass.getName() + ": ***Loading yaml file***")
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val ios = fs.open(new Path(args(1)))
    logger.info(this.getClass.getName() + ": ***After YAML initialisation***")
    val yaml = new Yaml(new Constructor((classOf[Config])))
    val obj = yaml.load(ios).asInstanceOf[Config]
    logger.debug(obj.toString())
    logger.debug(obj.getSource_name())

    /** Get Table Names. */
    val srcTbl = obj.getSource_name().get(sourceName).raw_layer_tbl.trim()
    val tgtTbl = obj.getSource_name().get(sourceName).l1_tbl.trim()
    val tgtErrTbl = obj.getSource_name().get(sourceName).l1_err_tbl.trim()

    logger.info(this.getClass.getName() + ": *** Application Load started for " + tgtTbl + "***")

    /** Audit job ids data. ***/
    val auditJobIdFull = args(7)
    val auditJobIdRaw = args(8)
    val auditCOBDate = args(9)

    val nullCheckFields = obj.getSource_name().get(sourceName).getNull_check_fields()
    logger.debug("null_check_fields" + nullCheckFields)

    val primaryKeyList = obj.getSource_name().get(sourceName).getPrimary_key()
    logger.debug("primarykey" + primaryKeyList)

    val refCheckMap = obj.getSource_name().get(sourceName).getReference_check()
    logger.debug("ref_check" + refCheckMap)

    val dateFieldsMap = obj.getSource_name().get(sourceName).getDate_fields()
    val loadDate = Utilities.getCurrentTimestamp()

    /** Use the database */
    sqlContext.sql("use " + args(3))

    val dbName = args(3).trim()

    /** Audit Columns List. */
    val auditMd5Value = AUDITCOLUMNS(0)
    val auditEffStartDt = AUDITCOLUMNS(1)
    val auditEffEndDt = AUDITCOLUMNS(2)
    val auditChangeFlag = AUDITCOLUMNS(3)
    val auditLoadDate = AUDITCOLUMNS(4)
    val loadedBy = AUDITCOLUMNS(5)
    val auditBatchId = AUDITCOLUMNS(6)
    val auditCurrentInd = AUDITCOLUMNS(7)
    val auditSourceFileName = AUDITCOLUMNS(8)

    val eudlloadedby = args(6)

    val inputDf = sqlContext.sql(f"""select * from $srcTbl """)
    var validRecordsDF: DataFrame = inputDf

    val errorDescCol = "error_description"
    var errorDf: DataFrame = inputDf.limit(0)
    var errorRecordsDF: DataFrame = errorDf.withColumn(errorDescCol, lit(""))

    /**
     *  Call Not Null utility for Primary key and Not Null fields check
     *  and insert error records in the error table with appropriate description
     */
    if (nullCheckFields.size() != 0) {
      val notNullCheckDFList: List[DataFrame] = Utilities.validateNotNull(sqlContext, inputDf, nullCheckFields.asScala.toList)

      val notNullErrorDF = notNullCheckDFList(1).withColumn(errorDescCol, lit("violated not null constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Not Null checks for Primary Key and Not Null fields***")
      validRecordsDF = notNullCheckDFList(0);
      errorRecordsDF = errorRecordsDF.union(notNullErrorDF);
    }

    /**
     * Call Reference check utility and insert error
     *  records in the error table with appropriate description
     */
    if (!(refCheckMap.isEmpty())) {
      val refCheckDFList: List[DataFrame] = Utilities.validateReferentialIntegrity(sqlContext, refCheckMap, validRecordsDF, primaryKeyList.asScala.toList)

      val refCheckErrorDF = refCheckDFList(1).withColumn(errorDescCol, lit("violated reference check constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Reference checks***")
      validRecordsDF = refCheckDFList(0)
      errorRecordsDF = errorRecordsDF.union(refCheckErrorDF)
    }

    /**
     * Call Date format check utility and insert error
     *  records in the error table with appropriate description
     */
    if (!(dateFieldsMap.isEmpty())) {
      val dateCheckDFList: List[DataFrame] = Utilities.validateDateFormat(sqlContext, sqlContext, validRecordsDF, dateFieldsMap.asScala)
      val dateCheckErrorDF = dateCheckDFList(1).withColumn(errorDescCol, lit("violated date check constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Date format checks***")
      validRecordsDF = dateCheckDFList(0);
      errorRecordsDF = errorRecordsDF.union(dateCheckErrorDF)
    }

    val batchId: String = args(2).toString()
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + ", batch ID is = " + batchId)

    val trgtTblErr = sqlContext.table(tgtErrTbl)
    val trgtTblErrSc = trgtTblErr.columns
    val trgtTbl = sqlContext.table(tgtTbl)
    val trgtTblSc = trgtTbl.columns
    val subJobId = args(4)
    val batchStartDate = args(5)

    /** Checksum should be generated on the data columns by excluding audit columns. */
    val actualIncData = validRecordsDF.drop(f"$auditLoadDate", f"$auditBatchId", f"$auditSourceFileName")
    actualIncData.createOrReplaceTempView("actualIncData")

    /** Generating checksum on data columns. */
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Generating checksum on data columns***")
    val actualIncDataHash = sqlContext.sql("""SELECT *, md5(CONCAT_WS(',', *)) AS eudlmd5value FROM actualIncData""")

    /** Need to add source file name back to data frame as it was removed to calculate checksum. */
    val postDQcheckDF = actualIncDataHash.as("df1").join(validRecordsDF.as("df2"), primaryKeyList.asScala.toList)
      .select($"df1.*", $"df2.$auditSourceFileName")
      .withColumn(f"$loadedBy", lit(eudlloadedby))
      .withColumn(f"$auditEffStartDt", lit(loadDate).cast("timestamp"))
      .withColumn(f"$auditEffEndDt", lit(""))
      .withColumn(f"$loadedBy", lit(eudlloadedby))
      .withColumn(f"$auditCurrentInd", lit("Y"))
      .withColumn(f"$auditChangeFlag", lit("Y"))
      .withColumn(f"$auditLoadDate", lit(loadDate))
      .withColumn(f"$auditBatchId", lit(batchId)).select(trgtTblSc.head, trgtTblSc.tail: _*)

    errorRecordsDF = errorRecordsDF.withColumn(f"$auditMd5Value", lit(null))
      .withColumn(f"$auditEffStartDt", lit(loadDate).cast("timestamp"))
      .withColumn(f"$auditEffEndDt", lit(""))
      .withColumn(f"$auditChangeFlag", lit("N"))
      .drop(f"$auditLoadDate")
      .withColumn(f"$auditLoadDate", lit(loadDate))
      .withColumn(f"$loadedBy", lit(eudlloadedby))

    logger.info(this.getClass.getName() + ": ***Loading L1 Error table : " + tgtErrTbl + "***")  
    errorRecordsDF.select(trgtTblErrSc.head, trgtTblErrSc.tail: _*).write.mode(SaveMode.Append).insertInto(tgtErrTbl)

    /** Fetches all the data from existing L1 table with current indicator as 'Y'.  */
    val existingDatadf = sqlContext.sql(f"""select * from $tgtTbl where $auditCurrentInd="Y"""")

     /**
     * Apply is always an append only file.
     * So there won't be any data in eudlcurrentind="N".
     */
    if (sourceName.equalsIgnoreCase("Apply")) {

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Appending apply data***")
      
      postDQcheckDF.distinct().write.mode(SaveMode.Append).insertInto(tgtTbl)

    } else {

      /** This returns a list of dataframe with both Y and N records separately, to write it to the L1 table. */
     
      val finalDf = Utilities.performCDCForFullLoads(sqlContext, batchId, existingDatadf, postDQcheckDF, primaryKeyList.asScala.toList, loadDate)
      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Implemented the CDC functionality***")
      
      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Writing the data to target table***")
      
      /** Load  inactive Records(eudlcurrentind="N"). */
      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Loading inactive records to 'N' partition***")
      finalDf(1).write.mode(SaveMode.Append).insertInto(tgtTbl)

      /** Load all active Records(eudlcurrentind="Y"). */
      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Loading active records to 'Y' partition***")
      finalDf(0).write.mode(SaveMode.Overwrite).insertInto(tgtTbl)
    }

    val subJobEndDate = Utilities.getCurrentTimestamp()

    /** Make an entry in audit table. */
    val loadType = "APPLICATIONDATA"

    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Making an entry to the audit table***")
    Utilities.insertInAudit(sqlContext, dbName, srcTbl, tgtTbl, primaryKeyList.asScala.toList, auditJobIdFull, subJobId, auditJobIdRaw, loadDate, batchStartDate, subJobEndDate, eudlloadedby, loadType, auditCOBDate, batchId)

    sqlContext.stop();
  }

}
