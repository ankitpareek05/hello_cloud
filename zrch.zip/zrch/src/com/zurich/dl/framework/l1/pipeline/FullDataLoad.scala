package com.zurich.dl.framework.l1.pipeline

import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.Constructor
import com.zurich.dl.generic.utils.Config
import grizzled.slf4j.Logger
import org.apache.spark.sql.DataFrame
import scala.collection.JavaConverters._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.SaveMode
import com.zurich.dl.generic.utils.Utilities
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.spark.serializer.KryoSerializer
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.joda.time.DateTime
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader

/**
 * The FullLoadPipeline program implements an application
 * that loads the manual/ reference files from raw layer to
 * L1 layer and performs the validations for Null values/
 * Null values on primary key column, referential integrity
 * check and Date field format check for all the sources,
 * with the help of a yaml configuration file
 *
 * It takes the source name, source input table name,
 * L1 table name, L1 error table name, configuration file
 * path, batch id and database name,subJobId as arguments
 */

object FullDataLoad {

  def main(args: Array[String]) {

    val logger = Logger("CustomLogger")

    /** Check  if correct number of arguments are passed or not */

    if (args.length != 10) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <source-name>  <config-file path> <Batch_ID><DataBase Name><SubJobId><BatchStartDate><loaded by><auditJobIdFull><auditJobIdRaw><auditCobDate>")
      System.exit(1)
    }
    
    /** Assign Input parameters to values */

    val sourceName = args(0)

    val batchId: String = args(2).toString()
    val dbName = args(3)
    val subJobId = args(4)
    val batchStartDate = args(5)
    val loadedBy = args(6)

    val sqlContext = SparkSession.builder()
      .appName("Full-Data-Load")
      .enableHiveSupport()
      .getOrCreate()

    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    import sqlContext.implicits._
    sqlContext.conf.set("hive.exec.dynamic.partition", "true");
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
    sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");

    logger.info(this.getClass.getName() + ": ***Logging Started for source, "+ sourceName + " DQ Check utility running ***")

    /** Load YAML FILE */
    logger.info(this.getClass.getName() + ": ***Loading YAML file***")
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val ios = fs.open(new Path(args(1)))
    logger.info(this.getClass.getName() + ": ***After YAML initialisation***")
    val yaml = new Yaml(new Constructor((classOf[Config])))
    val obj = yaml.load(ios).asInstanceOf[Config]
    logger.debug(obj.getSource_name())

    val srcTbl = obj.getSource_name().get(sourceName).raw_layer_tbl.trim()
    val tgtTbl = obj.getSource_name().get(sourceName).l1_tbl.trim()
    val tgtErrTbl = obj.getSource_name().get(sourceName).l1_err_tbl.trim()
    
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + ", batch ID is = " + batchId + "***")

    val auditJobIdFull = args(7)
    val auditJobIdRaw = args(8)
    val auditCOBDate = args(9)

    logger.info(this.getClass.getName() + ": ***Starting L1 table full load : " + tgtTbl + "***")
    
    /** Get the list of Not Null Attributes */
    val nullCheckFields = obj.getSource_name().get(sourceName).null_check_fields
    logger.debug("null_check_fields" + nullCheckFields)

    /** Get the list of Primary Key Attributes */
    val primaryKeyList = obj.getSource_name().get(sourceName).primary_key
    logger.debug("primarykey" + primaryKeyList)

    /** Get the list of Foriegn Key Attributes */
    val refCheckMap = obj.getSource_name().get(sourceName).reference_check
    logger.debug("ref_check" + refCheckMap)

    /** Get the list of Date Attributes */
    val dateFieldsMap = obj.getSource_name().get(sourceName).date_fields

    val loadDate = Utilities.getCurrentTimestamp()

    sqlContext.sql("use " + args(3))

    /** Truncate the L1 table before it is loaded */
    sqlContext.sql(f"""truncate table $tgtTbl""")

    /** Create a data frame with the input table records */
    
    val inputDF_initial = sqlContext.sql(f"""select * from $srcTbl""")

    val inputDF = inputDF_initial

    val error_description_col_name = "error_description"

    var validRecordsDF: DataFrame = inputDF;
    var errorRecordsDF: DataFrame = inputDF.withColumn(error_description_col_name, lit("")) limit (0);

    /**
     *  Call Not Null utility for Primary key and Not Null fields check
     *  and insert error records in the error table with appropriate description
     */
    if (nullCheckFields.size() != 0) {
      val notNullCheckDFList: List[DataFrame] = Utilities.validateNotNull(sqlContext, inputDF, nullCheckFields.asScala.toList)

      val notNullErrorDF = notNullCheckDFList(1).withColumn(error_description_col_name, lit("violated primary key constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Not Null checks for Primary Key and Not Null fields***")
      validRecordsDF = notNullCheckDFList(0)

      errorRecordsDF = notNullErrorDF
    }

    /**
     * Call Reference check utility and insert error
     *  records in the error table with appropriate description
     */
    if (!(refCheckMap.isEmpty())) {
      val refCheckDFList: List[DataFrame] = Utilities.validateReferentialIntegrity(sqlContext, refCheckMap, validRecordsDF, primaryKeyList.asScala.toList)

      val refCheckErrorDF = refCheckDFList(1).withColumn(error_description_col_name, lit("violated reference check constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Reference checks***")
      validRecordsDF = refCheckDFList(0)

      errorRecordsDF = errorRecordsDF.union(refCheckErrorDF)
    }

    /**
     * Call Date format check utility and insert error
     *  records in the error table with appropriate description
     */
    if (!(dateFieldsMap.isEmpty())) {

      val dateCheckDFList: List[DataFrame] = Utilities.validateDateFormat(sqlContext, sqlContext, validRecordsDF, dateFieldsMap.asScala)

      val dateCheckErrorDF = dateCheckDFList(1).withColumn(error_description_col_name, lit("violated date check constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Date format checks***")
      validRecordsDF = dateCheckDFList(0)

      errorRecordsDF = errorRecordsDF.union(dateCheckErrorDF)
    }

    /**Add Audit Columns to Valid,Error records Dataframe */

    val auditMd5Value = AUDITCOLUMNS(0)
    val auditEffStartDt = AUDITCOLUMNS(1)
    val auditEffEndDt = AUDITCOLUMNS(2)
    val auditChangeFlag = AUDITCOLUMNS(3)
    val auditLoadDate = AUDITCOLUMNS(4)
    val auditLoadedBy = AUDITCOLUMNS(5)
    val auditBatchId = AUDITCOLUMNS(6)
    val auditCurrentInd = AUDITCOLUMNS(7)

    validRecordsDF = validRecordsDF.withColumn(f"$auditMd5Value", lit(null))
      .withColumn(f"$auditCurrentInd", lit("Y"))
      .withColumn(f"$auditEffStartDt", lit(loadDate))
      .withColumn(f"$auditEffEndDt", lit("9999-12-31"))
      .withColumn(f"$auditChangeFlag", lit("I"))
      .withColumn(f"$auditLoadDate", lit(loadDate))
      .withColumn(f"$auditLoadedBy", lit(loadedBy))
      .withColumn(f"$auditBatchId", lit(batchId))

    errorRecordsDF = errorRecordsDF.withColumn(f"$auditMd5Value", lit(null))
      .withColumn(f"$auditCurrentInd", lit("Y"))
      .withColumn(f"$auditEffStartDt", lit(loadDate))
      .withColumn(f"$auditEffEndDt", lit("9999-12-31"))
      .withColumn(f"$auditChangeFlag", lit("I")) // As it is full load all records are considered as Inserts
      .withColumn(f"$auditLoadDate", lit(loadDate))
      .withColumn(f"$auditLoadedBy", lit(loadedBy))
      .withColumn(f"$auditBatchId", lit(batchId))

    /** Load Target table (L1) with all valid Records */
      
    logger.info(this.getClass.getName() + ": ***Loading L1 table : " + tgtTbl + "***")  
    val trgtTblSc = sqlContext.table(tgtTbl).columns
    validRecordsDF.select(trgtTblSc.head, trgtTblSc.tail: _*).write.mode(SaveMode.Overwrite).format("orc").insertInto(tgtTbl)

    /** Load Error table (L1_ERR) with all error Records */

    logger.info(this.getClass.getName() + ": ***Loading L1 Error table : " + tgtErrTbl + "***")
    val trgtTblErrSc = sqlContext.table(tgtErrTbl).columns
    errorRecordsDF.select(trgtTblErrSc.head, trgtTblErrSc.tail: _*).write.mode(SaveMode.Append).insertInto(tgtErrTbl)

    /** Fetch Current Timestamp as sub Job end timestamp */
    val subJobEndDate = Utilities.getCurrentTimestamp()

    /** Make an entry in audit table */
    val loadType = "FULL"
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Making an entry in the audit temp table***")
    Utilities.insertInAudit(sqlContext, dbName, srcTbl, tgtTbl, primaryKeyList.asScala.toList, auditJobIdFull, subJobId, auditJobIdRaw, loadDate, batchStartDate, subJobEndDate, loadedBy, loadType, auditCOBDate, batchId)
    sqlContext.stop();
  }

}
