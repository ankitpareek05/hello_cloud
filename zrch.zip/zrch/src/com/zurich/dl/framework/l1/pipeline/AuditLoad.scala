package com.zurich.dl.framework.l1.pipeline
import com.zurich.dl.generic.utils.Config
import com.zurich.dl.generic.utils.Constants._
import grizzled.slf4j.Logger
import org.apache.spark.sql.DataFrame
import scala.collection.JavaConverters._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.SaveMode
import com.zurich.dl.generic.utils.Utilities._
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import org.apache.spark.serializer.KryoSerializer
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.joda.time.DateTime
import org.apache.spark.sql.SparkSession

/**
 * This will load the audit data from audit temp table to main table
 * It takes the audit temp table and audit table from Constants
 */

object AuditLoad {

  def main(args: Array[String]) {

    val logger = Logger("CustomeLogger")

    val sqlContext = SparkSession.builder()
      .appName("Audit-Data-Load")
      .enableHiveSupport()
      .getOrCreate()

    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    import sqlContext.implicits._
    sqlContext.conf.set("hive.exec.dynamic.partition", "true");
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");

    if (args.length != 2) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <audit temp Database-name> <audit Database-name>")
      System.exit(1)
    }

    logger.info(this.getClass.getName() + ":  ***Logging Started for Audit Table, Audit Table Load Started***")

    val auditTempDb = args(0)
    val auditDb = args(1)
    val auditTblTmp = AUDIT_TBL_TMP
    val auditTbl = AUDIT_TBL

    /** Use the database */
    sqlContext.sql(f"""use $auditTempDb""")

    val auditTmp = sqlContext.sql(f"""Select aud_batch_id,aud_cob_date,aud_job_id,aud_job_start_timestamp,aud_sub_job_id,aud_sub_job_log_path,aud_sub_job_start_timestamp,aud_sub_job_end_timestamp,aud_sub_job_run_status,aud_sub_job_source_rowcount,aud_sub_job_target_rowcount,aud_updatedby,aud_update_date from $auditTblTmp""")

    /** Batch End Date */
    val end_date = getCurrentTimestamp()
    logger.info(this.getClass.getName() + ": ***Getting Job(Batch) End Time " + end_date + "***")
   
    /** Batch Job Status */
    val jobStatus = sqlContext.sql(f"""Select MIN(aud_sub_job_run_status) from $auditTblTmp""").head.getString(0)
    logger.info(this.getClass.getName() + ": ***Getting Job Status " + jobStatus + "***")
    
    val auditStatus = auditTmp.withColumn("aud_job_run_status", lit(jobStatus)).withColumn("aud_job_end_timestamp", lit(end_date))

    /** Copying data from audit tmp to audit main table */
    val audit = auditStatus.select("aud_batch_id", "aud_cob_date", "aud_job_id", "aud_job_run_status", "aud_job_start_timestamp", "aud_job_end_timestamp", "aud_sub_job_id", "aud_sub_job_log_path", "aud_sub_job_start_timestamp", "aud_sub_job_end_timestamp", "aud_sub_job_run_status", "aud_sub_job_source_rowcount", "aud_sub_job_target_rowcount", "aud_updatedby", "aud_update_date")
    
    logger.info(this.getClass.getName() + ": ***Loading "+auditTbl+" Table***")

    audit.write.mode(SaveMode.Append).insertInto(auditDb + "." + auditTbl)

    sqlContext.stop();
  }
}
