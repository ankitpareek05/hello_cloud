package com.zurich.dl.framework.l1.pipeline

import org.yaml.snakeyaml.Yaml
import org.yaml.snakeyaml.constructor.Constructor
import com.zurich.dl.generic.utils.Config
import grizzled.slf4j.Logger
import org.apache.spark.sql.DataFrame
import scala.collection.JavaConverters._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SaveMode
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.Path
import com.zurich.dl.generic.utils.Utilities
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import org.joda.time.format.DateTimeFormat
import org.joda.time.format.DateTimeFormatter
import org.joda.time.DateTime
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader

/**
 * The IncrementalDataLoad program implements an application
 * that loads the manual/ reference files from rawcdc layer to
 * L1 layer and performs the validations for Null values/
 * Null values on primary key column, referential integrity
 * check and Date field format check for all the sources,
 * with the help of a yaml configuration file.
 *
 * It mainly performs the change data capture logic based on the attunity flags.
 */
object IncrementalDataLoad {

  val logger = Logger("CustomLogger")
  val sqlContext = SparkSession.builder()
    .appName("Incremental-Data-Load")
    .enableHiveSupport()
    .getOrCreate()

  sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
  sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
  sqlContext.conf.set("spark.eventLog.enabled", "true")
  sqlContext.conf.set("spark.app.id", "Logs")
  sqlContext.conf.set("spark.io.compression.codec", "snappy")
  sqlContext.conf.set("spark.rdd.compress", "true")

  import sqlContext.implicits._
  sqlContext.conf.set("hive.exec.dynamic.partition", "true");
  sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
  sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");

  def main(args: Array[String]) {

    if (args.length != 10) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <source-name>  <config-file path><Batch_ID><DataBase Name><sub_job_id><batch_start_date><LoadedBy><auditJobIdCDC><auditJobIdRaw><auditCobDate>")
      System.exit(1)
    }

    val sourceName = args(0)
    logger.info(this.getClass.getName() + ": ***Logging Started for source, " + sourceName + " DQ Check utility running***")

    /** load YAML FILE */
    logger.info(this.getClass.getName() + ": ***Loading YAML file***")
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val ios = fs.open(new Path(args(1)))
    logger.info(this.getClass.getName() + ": ***After YAML initialisation***")
    val yaml = new Yaml(new Constructor((classOf[Config])))
    val obj = yaml.load(ios).asInstanceOf[Config]
    logger.debug(obj.toString())
    logger.debug(obj.getSource_name())
    
    val batchId: String = args(2).toString()

    /** Get Table Names */
    val srcTbl = obj.getSource_name().get(sourceName).raw_layer_cdc_tbl.trim()
    val tgtTbl = obj.getSource_name().get(sourceName).l1_tbl.trim()
    val tgtErrTbl = obj.getSource_name().get(sourceName).l1_err_tbl.trim()
    
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + ", batch ID is = " + batchId + "***")
    
    logger.info(this.getClass.getName() + ": ***Starting L1 table CDC loads : " + tgtTbl + "***")

    val auditJobIdCDC = args(7)
    val auditJobIdRaw = args(8)
    val auditCOBDate = args(9)

    val nullCheckFields = obj.getSource_name().get(sourceName).getNull_check_fields()
    logger.debug("null_check_fields" + nullCheckFields)

    val primaryKeyList = obj.getSource_name().get(sourceName).getPrimary_key()
    logger.debug("primarykey" + primaryKeyList)

    val refCheckMap = obj.getSource_name().get(sourceName).getReference_check()
    logger.debug("ref_check" + refCheckMap)

    val dateFieldsMap = obj.getSource_name().get(sourceName).getDate_fields()
    val loadDate = Utilities.getCurrentTimestamp()
    
    /** Use the database */
    sqlContext.sql("use " + args(3))

    val dbName = args(3).trim()

    /** Attunity Columns& Audit Columns List */

    val attunityChangeOper = ATTUNITYCOLUMNS(5)
    val attunityTimestamp = ATTUNITYCOLUMNS(6)
    val auditMd5Value = AUDITCOLUMNS(0)
    val auditEffStartDt = AUDITCOLUMNS(1)
    val auditEffEndDt = AUDITCOLUMNS(2)
    val auditChangeFlag = AUDITCOLUMNS(3)
    val auditBatchId = AUDITCOLUMNS(6)
    val auditCurrentInd = AUDITCOLUMNS(7)
    val auditLoadDate = AUDITCOLUMNS(4)
    val loadedBy = AUDITCOLUMNS(5)
    val eudlloadedby = args(6)

    val inputDf_list: List[DataFrame] = handleChangeFlag(srcTbl, primaryKeyList.asScala.toList, attunityChangeOper)
    val inputDf = inputDf_list(0)
    val errorDescCol = "error_description"
    var validRecordsDF: DataFrame = inputDf
    var errorRecordsDF: DataFrame = inputDf_list(1).withColumn(errorDescCol, lit(""))

    /**
     *  Call Not Null utility for Primary key and Not Null fields check
     *  and insert error records in the error table with appropriate description
     */
    if (nullCheckFields.size() != 0) {
      val notNullCheckDFList: List[DataFrame] = Utilities.validateNotNull(sqlContext, inputDf, nullCheckFields.asScala.toList)

      val notNullErrorDF = notNullCheckDFList(1).withColumn(errorDescCol, lit("violated not null constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Not Null checks for Primary Key and Not Null fields***")
      validRecordsDF = notNullCheckDFList(0);
      errorRecordsDF = errorRecordsDF.union(notNullErrorDF);
    }

    /**
     * Call Reference check utility and insert error
     *  records in the error table with appropriate description
     */
    if (!(refCheckMap.isEmpty())) {
      val refCheckDFList: List[DataFrame] = Utilities.validateReferentialIntegrity(sqlContext, refCheckMap, validRecordsDF, primaryKeyList.asScala.toList)

      val refCheckErrorDF = refCheckDFList(1).withColumn(errorDescCol, lit("violated reference check constraint"))

      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Reference checks***")
      validRecordsDF = refCheckDFList(0)
      errorRecordsDF = errorRecordsDF.union(refCheckErrorDF)
    }

    /**
     * Call Date format check utility and insert error
     *  records in the error table with appropriate description
     */
    if (!(dateFieldsMap.isEmpty())) {
      val dateCheckDFList: List[DataFrame] = Utilities.validateDateFormat(sqlContext, sqlContext, validRecordsDF, dateFieldsMap.asScala)
      val dateCheckErrorDF = dateCheckDFList(1).withColumn(errorDescCol, lit("violated date check constraint"))
      
      logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Date format checks***")
      validRecordsDF = dateCheckDFList(0);
      errorRecordsDF = errorRecordsDF.union(dateCheckErrorDF)
    }

    /** Adding the extra audit columns values relevant to both valid and error records respectively */
    validRecordsDF = validRecordsDF.withColumn(f"$auditMd5Value", lit(null))
      .withColumn(f"$loadedBy", lit(eudlloadedby))
      .drop(f"$auditLoadDate").withColumn(f"$auditLoadDate", lit(loadDate))

    errorRecordsDF = errorRecordsDF.withColumn(f"$auditMd5Value", lit(null))
      .withColumn(f"$auditEffStartDt", unix_timestamp($"$attunityTimestamp", "yyyy/MM/dd HH:mm:ss").cast("timestamp"))
      .withColumn(f"$auditEffEndDt", lit(""))
      .withColumn(f"$auditChangeFlag", $"$attunityChangeOper")
      .drop(f"$auditLoadDate")
      .withColumn(f"$auditLoadDate", lit(loadDate))
      .withColumn(f"$loadedBy", lit(eudlloadedby))
      .drop(f"$attunityTimestamp", f"$attunityChangeOper")

    val postDQcheckDF = validRecordsDF
    val trgtTblErr = sqlContext.table(tgtErrTbl)
    val trgtTblErrSc = trgtTblErr.columns
    val trgtTbl = sqlContext.table(tgtTbl)
    val trgtTblSc = trgtTbl.columns
    val subJobId = args(4)
    val batchStartDate = args(5)

    logger.info(this.getClass.getName() + ": ***L1 Error table : " + tgtErrTbl + " Loading data into the Error table***")
    errorRecordsDF.select(trgtTblErrSc.head, trgtTblErrSc.tail: _*).write.mode(SaveMode.Append).insertInto(tgtErrTbl)

    /** Fetches all the data from existing L1 table with current indicator as 'Y'  */
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Fetching data from L1 table from 'Y' partition***")
    val existingDatadf = sqlContext.sql(f"""select * from $tgtTbl where $auditCurrentInd="Y"""")

    /** This retuns a list of dataframe with both Y and N records separately, to write it to the L1 table */
    val finalDf = Utilities.performCDC(sqlContext, batchId, existingDatadf, postDQcheckDF, primaryKeyList.asScala.toList)
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Implemented the CDC functionality***")
    
    /** Load  inactive Records(eudlcurrentind="N") */
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Loading data into the 'N' partition***")
    finalDf(1).write.mode(SaveMode.Append).insertInto(tgtTbl)

    /** Load all active Records(eudlcurrentind="Y") */
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Loading data into the 'Y' partition***")
    finalDf(0).write.mode(SaveMode.Overwrite).insertInto(tgtTbl)

    val subJobEndDate = Utilities.getCurrentTimestamp()

    /** Make an entry in audit table */
    val loadType = "Incremental"

    Utilities.insertInAudit(sqlContext, dbName, srcTbl, tgtTbl, primaryKeyList.asScala.toList, auditJobIdCDC, subJobId, auditJobIdRaw, loadDate, batchStartDate, subJobEndDate, eudlloadedby, loadType, auditCOBDate, batchId)
    logger.info(this.getClass.getName() + ": ***L1 table : " + tgtTbl + " Added an entry in the audit temp table***")
    
    sqlContext.stop();
  }

  /**
   * This method takes the latest records from the raw table, drops the irreleveant header columns and 
   *    gives a dataframe only with flags as 'I', 'U' and 'D'.
	 * */
  def handleChangeFlag(rawtable: String, primaryKeyList: List[String], header_change_oper: String): List[DataFrame] =
    {
      logger.info(this.getClass.getName() + ": ***Fetching records from " + rawtable + "with attunity flags as 'I','U' & 'D'***")
      val inputDf_initial = sqlContext.sql(f"""select * from $rawtable where $header_change_oper IN ('I','U','D')""")
      
      /** Get Records with invalid Primary Key*/
      val cond = primaryKeyList.map(x => x + " IS NULL" + " OR " + x + "=\"\"").mkString(" OR ")

      var errorDf_initial = inputDf_initial.filter(cond).toDF()

      /** If there are no records in Raw table, exit with success */
      if (inputDf_initial.count().toInt == 0) {
        sqlContext.stop()
        System.exit(0);
      }
      
      logger.info(this.getClass.getName() + ":  ***Fetching the records from " + rawtable + "based on latest timestamp***")
      val maxHeaderSeq = inputDf_initial.groupBy(primaryKeyList.head, primaryKeyList.tail: _*).agg(max("header_change_seq").alias("header_change_seq"))

      var latestRecordsDf = inputDf_initial.as("A1").join(broadcast(maxHeaderSeq), maxHeaderSeq.columns).select($"A1.*")

      var inputDf: DataFrame = latestRecordsDf.limit(0)
      var errorDf: DataFrame = errorDf_initial.limit(0)

      logger.info(this.getClass.getName() + ":  ***Dropping irrelevant attunity columns from " + rawtable + "to load the L1 table***")
      for (i <- 0 to ATTUNITYCOLUMNS.length - 3) {
        inputDf = latestRecordsDf.drop(ATTUNITYCOLUMNS(i))
        errorDf = errorDf_initial.drop(ATTUNITYCOLUMNS(i))
        latestRecordsDf = inputDf
        errorDf_initial = errorDf
      }
      List(inputDf, errorDf)
    }
}
