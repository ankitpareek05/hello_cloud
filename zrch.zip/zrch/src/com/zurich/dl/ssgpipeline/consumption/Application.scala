package com.zurich.dl.ssgpipeline.consumption

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import grizzled.slf4j.Logger
import org.apache.spark.SparkException
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader
import org.apache.spark.sql.SaveMode
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }
import com.zurich.dl.generic.utils.Utilities

object Application {

  def main(args: Array[String]): Unit = {

    val logger = Logger("CustomLogger")

    if (args.length != 6) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <SSG pipeline Database Name><Target Table><property file path><Batch_ID><LoadedBy><SSG database name>")
      System.exit(1)
    }

    logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
    
    val startTime = Utilities.getCurrentTimestamp()
     
    logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")

    val sqlContext = SparkSession.builder()
      .appName("Application")
      .enableHiveSupport()
      .getOrCreate()

    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    import sqlContext.implicits._
    sqlContext.conf.set("hive.exec.dynamic.partition", "true");
    sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
    sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");

    /**Load Property File */
    logger.info(this.getClass.getName() + ": ***Reading Property file***")
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val propertyFilePath = fs.open(new Path(args(2)))
    val propConfReader = new InputStreamReader(propertyFilePath)
    val propConf = ConfigFactory.parseReader(propConfReader)

    /**Audit Column Names */
    val auditLoadDateCol = AUDITCOLUMNS(4)
    val auditLoadedByCol = AUDITCOLUMNS(5)
    val auditSourceCol = AUDITCOLUMNS(9)

    /**Audit Column Data */
    val loadedBy = args(4)
    val sourceName = SRC_PIPELINE
    val loadDate = Utilities.getCurrentTimestamp()

    /**Set database */
    sqlContext.sql("use " + args(0))

    /**Get the Consumption View Temp table Schema */
    val tgtTbl = args(1)
    val trgtTblSc = sqlContext.table(tgtTbl).columns

    /**Get the Customer match DB name */
    val consumptionViewDb = args(1).split('.')
    
    /**Get Reference table DB name */
    val systemRefTypeDB = args(5)

    /**Create the data frames for loading the Consumption View Temp table */
    logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")

    val policyNumberDf = sqlContext.sql(propConf.getString("query_policy_number"))
    policyNumberDf.createOrReplaceTempView("policyNumberDf")

    val applicationNumberDf = sqlContext.sql(propConf.getString("query_application_number"))
    applicationNumberDf.createOrReplaceTempView("applicationNumberDf")

    val productTypeDf = sqlContext.sql(propConf.getString("query_product_type").replaceAll("\\bREFERENCE_DB", systemRefTypeDB))
    productTypeDf.createOrReplaceTempView("productTypeDf")

    val applicationStatusDf = sqlContext.sql(propConf.getString("query_application_status"))
    applicationStatusDf.createOrReplaceTempView("applicationStatusDf")

    val customerMatchDf = sqlContext.sql(propConf.getString("query_customer_match").replaceAll("\\bCONSUMPTION_VIEW_DB", consumptionViewDb(0))).distinct()
    customerMatchDf.createOrReplaceTempView("customerMatchDf")

    val medicalColsDf = sqlContext.sql(propConf.getString("query_medical_cols"))
    medicalColsDf.createOrReplaceTempView("medicalColsDf")

    logger.info(this.getClass.getName() + ": ***Creating Final Dataframe***")
    val targetDf = sqlContext.sql(propConf.getString("query_target_view"))
      .withColumn(auditSourceCol, lit(sourceName))
      .withColumn(auditLoadDateCol, lit(loadDate))
      .withColumn(auditLoadedByCol, lit(loadedBy))
      .select(trgtTblSc.head, trgtTblSc.tail: _*)

    logger.info(this.getClass.getName() + ": ***Loading the target table***")
    targetDf.write.mode(SaveMode.Overwrite).insertInto(tgtTbl)
    val endTime = Utilities.getCurrentTimestamp()

    logger.info(this.getClass.getName() + ": ***Consumption View for Application is Completed at : " + endTime + "***")
    sqlContext.stop()

  }
}