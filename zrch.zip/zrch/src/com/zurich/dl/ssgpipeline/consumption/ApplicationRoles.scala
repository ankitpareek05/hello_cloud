package com.zurich.dl.ssgpipeline.consumption

import org.apache.spark.sql.SparkSession
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
import grizzled.slf4j.Logger
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader
import com.zurich.dl.generic.utils.Utilities
import com.zurich.dl.generic.utils.Constants._
import org.apache.spark.sql.types.StringType

/**
 * The Class ApplicationRoles.
 */
object ApplicationRoles {

  def main(args: Array[String]) {

    val logger = Logger("CustomLogger")

    if (args.length != 6) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <SSG pipeline Database Name><Target Table><property file path><Batch_ID><LoadedBy><SSG database name>")
      System.exit(1)
    }

    logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
    val startTime = Utilities.getCurrentTimestamp()
     
    logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")

    val sqlContext = SparkSession.builder()
      .appName("ApplicationRoles")
      .enableHiveSupport()
      .getOrCreate()

    sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
    sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
    sqlContext.conf.set("spark.eventLog.enabled", "true")
    sqlContext.conf.set("spark.app.id", "Logs")
    sqlContext.conf.set("spark.io.compression.codec", "snappy")
    sqlContext.conf.set("spark.rdd.compress", "true")

    val tgtTbl = args(1)
    val consumptionViewDb = args(1).split('.')

    val batchId = args(3)
    val loadedBy = args(4)
    val loadDate = Utilities.getCurrentTimestamp()
    val sourceName = SRC_PIPELINE

    /** Audit columns. */
    val auditLoadDate = AUDITCOLUMNS(4)
    val auditLoadedBy = AUDITCOLUMNS(5)
    val auditBatchId = AUDITCOLUMNS(6)
    val auditSourceCol = AUDITCOLUMNS(9)

    /** Reading the property file having queries. */
    logger.info(this.getClass.getName() + ": ***Reading Property file***")
    
    val conf = new Configuration()
    val fs = FileSystem.get(conf);
    val propertyFilePath = fs.open(new Path(args(2)))
    val propConfReader = new InputStreamReader(propertyFilePath)
    val propConf = ConfigFactory.parseReader(propConfReader)
    val query1 = propConf.getString("query_1").replaceAll("\\bCONSUMPTION_VIEW_DB", consumptionViewDb(0))
    val query2 = propConf.getString("query_2")
    val query3 = propConf.getString("query_3")

    /** Use the database. */
    sqlContext.sql("use " + args(0))
    val trgtTblSc = sqlContext.table(tgtTbl).columns

    logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")
    /** Deriving the policy list from clients and its details. */
    
    val clientDetailsDF = sqlContext.sql(f"""$query1""")
    clientDetailsDF.createOrReplaceTempView("clientDetailsDF")

    /** Deriving the party type column. */
    val policyDetailsDF = sqlContext.sql(f"""$query2""")
    policyDetailsDF.createOrReplaceTempView("policyDetailsDF")

    logger.info(this.getClass.getName() + ": ***Loading the target table***")
    
    /** Inserting into application roles. */
    sqlContext.sql(f"""$query3""")
      .withColumn("sourceproductsystem", lit(sourceName))
      .withColumn("businessitemtype", lit(APPLICATION))
      .withColumn(f"$auditBatchId", lit(batchId))
      .withColumn(f"$auditLoadDate", lit(loadDate).cast("timestamp"))
      .withColumn(f"$auditSourceCol", lit(sourceName))
      .withColumn(f"$auditLoadedBy", lit(loadedBy))
      .select(trgtTblSc.head, trgtTblSc.tail: _*).write.mode(SaveMode.Overwrite).insertInto(tgtTbl)

    val endTime = Utilities.getCurrentTimestamp()

    logger.info(this.getClass.getName() + ": ***Consumption View for Application-Requirements is Completed at : " + endTime + "***")
    sqlContext.stop()
  }

}
    