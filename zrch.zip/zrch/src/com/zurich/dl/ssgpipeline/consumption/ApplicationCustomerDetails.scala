package com.zurich.dl.ssgpipeline.consumption

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.hadoop.mapred.InvalidInputException
import com.zurich.dl.generic.utils.Utilities
import grizzled.slf4j.Logger
import org.apache.spark.SparkException
import com.zurich.dl.generic.utils.Constants._
import com.zurich.dl.generic.utils.RawAvroConfig
import org.apache.spark.sql.SparkSession
import com.typesafe.config.ConfigFactory
import java.io.InputStreamReader
import org.apache.spark.sql.SaveMode
import org.apache.spark.serializer.KryoSerializer
import org.apache.spark.sql.functions.{ udf, lit, col, broadcast }

/**
 * The Class ApplicationCustomerDetails.
 */
object ApplicationCustomerDetails {
  
  def main(args: Array[String]) {
    
      val logger = Logger("CustomLogger")
     
      if (args.length != 6) {
      logger.error("Invalid number of arguments passed")
      logger.error("Arguments Usage: <SSG pipeline Database Name><Target Table><property file path><Batch_ID><LoadedBy><SSG database name>")
      System.exit(1)
    }

     
     logger.info(this.getClass.getName() + ": ***Initializing Spark Session***")
        
     val startTime = Utilities.getCurrentTimestamp()
     
     logger.info (this.getClass.getName() + ": ***Application started at : " + startTime + "***")
     
     val sqlContext = SparkSession.builder()
                                  .appName("ApplicationCustomerDetails")
                                  .enableHiveSupport()
                                  .getOrCreate()
    
     sqlContext.conf.set("spark.serializer", classOf[KryoSerializer].getName)
     sqlContext.conf.set("spark.sql.tungsten.enabled", "true")
     sqlContext.conf.set("spark.eventLog.enabled", "true")
     sqlContext.conf.set("spark.app.id", "Logs")
     sqlContext.conf.set("spark.io.compression.codec", "snappy")
     sqlContext.conf.set("spark.rdd.compress", "true")

     import sqlContext.implicits._
     sqlContext.conf.set("hive.exec.dynamic.partition", "true");
     sqlContext.conf.set("hive.exec.dynamic.partition.mode", "nonstrict");
     sqlContext.conf.set("spark.sql.hive.convertMetastoreOrc", "false");
    
     /** Load Property File */
     logger.info(this.getClass.getName() + ": ***Reading Property file***")
     val conf = new Configuration()
     val fs = FileSystem.get(conf);
     val propertyFilePath = fs.open(new Path(args(2)))   
     val propConfReader = new InputStreamReader(propertyFilePath)
     val propConf = ConfigFactory.parseReader(propConfReader)
     
     val consumptionViewDb = args(1).split('.')
    
    /** Read the queries from the property file */
     val query1 =  propConf.getString("query_1").replaceAll("\\bCONSUMPTION_VIEW_DB", consumptionViewDb(0))
     val query2 =  propConf.getString("query_2")
     val query3 =  propConf.getString("query_3")
    
     val joinkeys=propConf.getString("join_key_list")
     val joinkeyList=joinkeys.split(",").toList
    
     /** Audit Column Names */
     val auditBatchIdCol = AUDITCOLUMNS(6)
     val auditLoadDateCol = AUDITCOLUMNS(4)
     val auditLoadedByCol = AUDITCOLUMNS(5)
     val auditSourceCol = AUDITCOLUMNS(9)
   
     /***Audit Column Data ***/ 
     val batchId =args(3)
     val loadedBy=args(4)
     val sourceName=SRC_PIPELINE
     val loadDate = Utilities.getCurrentTimestamp()
   
     val tgtTbl=args(1)
    
     /** Use the database. */
     sqlContext.sql("use "+args(0)) 
     
     val trgtTblSc = sqlContext.table(tgtTbl).columns
     
     logger.info(this.getClass.getName() + ": ***Creating dataframes for Temp Tables***")
     val DfCustomerMatchId=sqlContext.sql(query1)
     val DfPersonDetails=sqlContext.sql(query2)
     val DfGeneralDetails=sqlContext.sql(query3)
    
     val clientNumber=List(joinkeyList(0))
     val policyNumber=List(joinkeyList(1))
    
     logger.info(this.getClass.getName() + ": ***Creating Final Dataframe**")
     val finalDf = DfCustomerMatchId.join(broadcast(DfPersonDetails),clientNumber,"left").drop(DfPersonDetails(joinkeyList(0))).drop(DfPersonDetails(joinkeyList(1)))
                                    .join(broadcast(DfGeneralDetails),joinkeyList,"left").drop(DfGeneralDetails(joinkeyList(0))).drop(DfGeneralDetails(joinkeyList(1)))
                                    .drop(DfCustomerMatchId(joinkeyList(0)))
                                    .withColumn(auditBatchIdCol,lit(batchId))
                                    .withColumn(auditLoadDateCol,lit(loadDate))
                                    .withColumn(auditLoadedByCol,lit(loadedBy))
                                    .withColumn(auditSourceCol,lit(sourceName))
                                    .select(trgtTblSc.head, trgtTblSc.tail: _*)
     
     logger.info(this.getClass.getName() + ": ***Loading the target table***")                               
     finalDf.write.mode(SaveMode.Overwrite).insertInto(tgtTbl)

     val endTime = Utilities.getCurrentTimestamp()

     logger.info(this.getClass.getName() + ": ***Consumption View for Application-CustomerDetails is Completed at : " + endTime + "***")
     sqlContext.stop()
  }
}