import common.utils.Logging as l
import preprocessing.PreprocessingConstants as ppc
import pyspark.sql.functions as f
import common.utils.CommonUtils as  cu
import time


def rule_add_batch_id(source_df, rule):
    l.log.info("Adding Process_id core key")

    try:
        detail_action_dict = cu.get_map_from_string(rule)

        if detail_action_dict.get("col_name", "NA") != "NA":

            if detail_action_dict.get("col_value", "NA").upper() == "NA":
                value = str(int(round(time.time() * 1000)))
            else:
                value = detail_action_dict.get("col_value", "NA")

            updated_df = source_df.withColumn(detail_action_dict.get("col_name"), f.lit(value))

        else:
            updated_df = source_df.withColumn(ppc.DEFAULT_BATCH_ID_COL_NAME,
                                               f.lit(str(int(round(time.time() * 1000)))))
        l.log.info("PROCESS_ID core key is added")
        updated_df.show()
        return updated_df

    except Exception as e:
        l.log.warn("Error while adding PROCESS_ID core key. Please verify the config file")
    return source_df


def rule_add_process_datetime(source_df, rule):
    l.log.info("Adding Process_id core key")

    try:
        detail_action_dict = cu.get_map_from_string(rule)

        if detail_action_dict.get("col_name", "NA") != "NA":

            if detail_action_dict.get("col_value", "NA").upper() == "NA":
                value = str(int(round(time.time() * 1000)))
            else:
                value = detail_action_dict.get("col_value", "NA")

            updated_df = source_df.withColumn(detail_action_dict.get("col_name"), f.lit(value))

        else:
            updated_df = source_df.withColumn(ppc.DEFAULT_BATCH_ID_COL_NAME,
                                               f.lit(str(int(round(time.time() * 1000)))))
        l.log.info("PROCESS_ID core key is added")
        updated_df.show()
        return updated_df

    except Exception as e:
        l.log.warn("Error while adding PROCESS_ID core key. Please verify the config file")
    return source_df


def rule_add_created_by(source_df, rule):
    l.log.info("Adding CREATED_BY core key")

    try:
        detail_action_dict = cu.get_map_from_string(rule)

        if detail_action_dict.get("col_name", "NA") != "NA":

            if detail_action_dict.get("col_value", "NA").upper() == "NA":
                value = str(int(round(time.time() * 1000)))
            else:
                value = detail_action_dict.get("col_value", "NA")

            updated_df = source_df.withColumn(detail_action_dict.get("col_name"), f.lit(value))

        else:
            updated_df = source_df.withColumn(ppc.DEFAULT_BATCH_ID_COL_NAME,
                                               f.lit(str(int(round(time.time() * 1000)))))
        l.log.info("CREATED_BY core key is added")
        updated_df.show()
        return updated_df

    except Exception as e:
        l.log.warn("Error while adding CREATED_BY core key. Please verify the config file")
    return source_df
