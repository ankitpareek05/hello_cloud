from common.utils import GlobalVariables as gv
import preprocessing.PreprocessingRules as ppr


def process_core_key_rules(input_df, config_data):

    rule_action = dict((k, v) for k, v in config_data.items() if k.__contains__("rule"))
    print(rule_action)

    if rule_action is not None:
        add_batch_id = config_data.get(gv.layer_name+"_core_key_rule_add_batch_id_core_key", "NA")
        add_process_data = config_data.get(gv.layer_name+"_core_key_rule_add_process_date_core_key", "NA")
        add_created_by = config_data.get(gv.layer_name+"_core_key_rule_add_created_by_core_key", "NA")
        # rule_value is key for other dict
        for rule in rule_action:
            rule_value = rule_action.get(rule)

            if rule_value == add_batch_id:
                print(rule_value)
                updated_df = ppr.rule_add_batch_id(input_df, rule_value)
                input_df = updated_df
            elif rule_value == add_process_data:
                print(rule_value)
                updated_df = ppr.rule_add_process_datetime(input_df, rule_value)
                input_df = updated_df
            elif rule_value == add_created_by:
                print(rule_value)
                updated_df = ppr.rule_add_created_by(input_df, rule_value)
                input_df = updated_df
        return updated_df
    else:
        print("------returning input df---------")
        return input_df
