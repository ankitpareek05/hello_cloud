from common.utils.Logging import *
from common.utils import CommonUtils as cu
from common.utils import CommonConstants as cc
from common.utils import GlobalVariables as gv
from preprocessing.impl import PreprocessingImpl as ppl
import sys



def main(args):


    if len(args) < 4:
        log.error("Invalid number of arguments passed")
        sys.exit(1)

    config_path = args[1]
    file_name = args[2]
    layer_name = args[3]
    source_name = args[4]


    #Below are the run-time arguments to be deleted
    #config_path = r"C:\Users\neejha\Desktop\_Python_ACI\datalake_python\configFiles\Preprocessing_conf.csv"
    #file_name = "ACCOUNT"
    #layer_name = "L0"
    #source_name = "SFDC"

    gv.layer_name = layer_name.lower()
    log.info("Layer Name: " + gv.layer_name)

    gv.source_name = source_name.lower()
    log.info("Source Name: " + gv.source_name)

    gv.file_name = file_name.lower()
    log.info("File Name: " + gv.file_name)

    log.info("\n############# Pre Processing Driver #############")
    log.info(" Parsing Config Data")

    config_data = cu.parse_config_file(config_path, file_name, source_name, layer_name)
    filter_config_dict = dict((k, v) for k, v in config_data.items() if k.startswith(layer_name.lower()))

    bucket_name = gv.root_path
    log.info("Bucket Name: " + bucket_name)

    layer_name_with_action = gv.layer_name + "_source"
    input_key = layer_name_with_action + "_input_details"
    log.info("Reading Input File")

    df = cu.read_input_file(filter_config_dict, input_key, bucket_name)

    #   Calling the Preprocessing Impl
    final_df = ppl.process_core_key_rules(df, config_data)
    final_df.show()
    # writing data to output file
    output_key = layer_name_with_action + "_output_details"

    try:
        cu.write_output_file(final_df, config_data, bucket_name, output_key)
    except:
        log.info("Error occured while writing the Dataframe")


if __name__ == "__main__":
    main(sys.argv)