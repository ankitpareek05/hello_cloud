from common.utils import Logging as l
from common.utils import CommonUtils as cu
from matchmerge.utils import MatchMergeConstants as mmc
from matchmerge.impl import MatchProcessImpl as mpl
import sys


def try_convert(row):
    try:
        return str(row[0]), str(row[1])
    except Exception as e:
        l.log.exception(e)
        l.log.error("ERROR: INVALID CONFIGURATION")


def get_match_rules(match_rule_df):
    try:
        match = ((match_rule_df.rdd.map(lambda row: row["ATTRIBUTES-MATCH_TYPE"].split(",")))
                 .map(lambda x: list(map(lambda value: value.split("-"), x)))).collect()

        match_2 = match_rule_df.rdd.map(lambda row: row["RULE_ID"]).collect()

        match_3 = match_rule_df.rdd.map(lambda row: row["RULE_STATUS"]).collect()

        match_4 = match_rule_df.rdd.map(lambda row: row["RULE_TYPE"]).collect()

        match_rules = []

        for i in range(len(match)):
            rules = [match_2[i], match[i], match_3[i], match_4[i]]
            match_rules.append(rules)

        return match_rules

    except Exception as e:
        l.log.exception(e)
        l.log.error("ERROR: INVALID CONFIGURATION")


def main(args):
    # match_conf_file = args[1]
    # match_rule_file = args[2]

    match_conf_file = "C:\\Users\\anpareek\\Documents\\SparkWorkSpace\\DataLake_Python\\datalake_python\\configFiles\\MatchConf"
    match_rule_file = "C:\\Users\\anpareek\\Documents\\SparkWorkSpace\\DataLake_Python\\datalake_python\\configFiles\\MatchRule"

    l.log.info("Reading match conf")

    # Read the Match configuration into a dataframe

    match_conf_df = cu.read_from_delimited_file(match_conf_file, "false", "=")

    # Convert the dataframe into a key value pair
    match_conf_df.show(100,500)
    print(":: ", match_conf_df.rdd.collect())
    match_conf_dict = match_conf_df.rdd.map(lambda row: try_convert(row)).collectAsMap()
    print(">>match_conf_dict: ", match_conf_dict)

    l.log.info("Reading match rule")

    match_rule_df = cu.read_from_delimited_file(match_rule_file, "True", ":")
    match_rules = get_match_rules(match_rule_df)
    print("-------------------------------match_rules-------------------------------")
    print(match_rules)

    l.log.info("Reading input data frame")
    input_df = cu.read_from_csv_file(match_conf_dict[mmc.INPUT_PATH], "true")
    print("-------------------------------input_df-------------------------------")
    input_df.show()

    # input_df.show()

    l.log.info("Calling perform_match method")

    mpl.perform_match(input_df, match_rules, match_conf_dict[mmc.DATA_ROWID_OBJECT],
                      match_conf_dict[mmc.MATCH_OUTPUT_PATH])


if __name__ == "__main__":
    main(sys.argv)
