import re
import datetime
import urllib.request  # to open URL
import urllib.parse


def main():
    str_ip = "('l_subpremise', '#131')$('l_premise', None)$('l_street_number', '28')$('l_route', 'Atlantic Avenue')$('l_locality', 'Boston')$('s_administrative_area_level_2', 'Suffolk County')$('s_administrative_area_level_1', 'MA')$('s_country', 'US')$('l_postal_code', '02110')$('l_postal_code_suffix', None)$('formatted_address', '28 Atlantic Ave #131, Boston, MA 02110, USA')$('partial_match', None)$('latitude', 42.3633432)$('longitude', -71.05006689999999)$('error_message', None)$('status', 'OK')"

    x = get_value_for_string_address(str_ip, "l_route")
    print(">>>: ", x)

    # url = "https://www.wikipedia.org/"
    # resp = urllib.request.urlopen(url)
    # print("resp type: ", type(resp))
    # # to see what you can do with response
    # dir(resp)
    #
    # # check if the request was successfull
    # resp.code()
    # # 200 - ok
    # # 400 - bad request
    # # 403 - forbidden
    # # 404 - not found
    # resp.length()
    # resp.peek()  # utf-8
    # data = resp.read()  # type <bytes>
    # html = data.decode("UTF-8")  # str type
    #
    # params = {"v": "EuC-yVzHhMI", "t": "5m56s"}
    # querystring = urllib.parse.urlencode(params)  # v=EuC-yVzHhMI&t=5m56s
    # url = "https://www.youtube.com/watch" + "?" + querystring
    # resp = urllib.request.urlopen(url)
    # resp.isClosed()  # FALSE: checks if connection closed or opened
    # resp.code()  # 200


def get_value_for_string_address(input_str, index_col_name):
    input_str_list = input_str.strip().split("$")
    for input_str_list_indx in range(len(input_str_list)):
        if input_str_list[input_str_list_indx].find(index_col_name) != -1:
            input_str_list[input_str_list_indx] = input_str_list[input_str_list_indx].replace("(", "")
            input_str_list[input_str_list_indx] = input_str_list[input_str_list_indx].replace(")", "")
            input_str_list[input_str_list_indx] = input_str_list[input_str_list_indx].replace("'", "")
            internal_input_str_list = input_str_list[input_str_list_indx].strip().split(",")
            return internal_input_str_list[1]




def get_value_for_str1(str1, indx_col):
    str1 = str1.replace("{", "")
    str1 = str1.replace("}", "")
    lis = str1.split(",")
    for lis_indx in range(len(lis)):
        if lis[lis_indx].find(indx_col) != -1:
            ilis = lis[lis_indx].split("=")
            return ilis[1]


def val_rule_datevalidate(col_value, format):
    if str(format).strip() == "yyyy-MM-dd":
        # day_f, month_f, year_f = format.split('-')
        day_f, month_f, year_f = "%Y", "%m", "%d"
        format = day_f + "-" + month_f + "-" + year_f

    try:
        datetime.datetime.strptime(col_value, format)
        print("valid:", datetime.datetime.strptime(col_value, format))
    except ValueError:
        print("Incorrect data format, should be YYYY-MM-DD")
        print(">>valid:", datetime.datetime.strptime(col_value, format))


def val_rule_isnumeric_withexpression(col, expression):
    try:
        print("col: ", col)
        print("expression: ", expression)
        if str(col).strip() == "":
            print("---if---")
            return "null is NaN"
        elif re.match("-{0,1}[0-9]+\\.{0,1}[0-9]*", str(col)):
            print("---elif---")
            out = ""
            if str(expression).startswith("leq"):
                out = float(col) <= float(str(expression).replace("leq", "").strip())
            elif str(expression).startswith("geq"):
                out = float(col) >= float(str(expression).replace("geq", "").strip())
            elif str(expression).startswith("eq"):
                out = float(col) == float(str(expression).replace("eq", "").strip())
            elif str(expression).startswith("lt"):
                out = float(col) < float(str(expression).replace("lt", "").strip())
            elif str(expression).startswith("gt"):
                out = float(col) > float(str(expression).replace("gt", "").strip())
            print(out)
            ret = "Numeric and " + str(expression) + " is " + str(out)
            print(">>>ret: ", ret)
            return ret
        else:
            print("---else---")
            return "Non-Numeric"
    except ValueError:
        print("Incorrect expression or col")


if __name__ == '__main__':
    main()
