from common.utils.Logging import *
from common.utils import GlobalVariables as gv
from common.utils import CommonUtils as cu
import sys


def set_env_variables(src_name, layer_name, config_df):
    """
    A function to set the environment variable
    :param src_name: Source Name to be process
    :param layer_name: Layer Name to be process
    :param config_df: Config Dataframe
    :return: None. A global variable will be set.
    """
    file_name = "ALL"

    # Set Root Path
    try:
        root_path_df = config_df.filter((config_df["TYPE"] == "ENV") & (config_df["FILE_NAME"] == file_name.strip()) &
                                        (config_df["SOURCE_NAME"] == src_name.strip())
                                        & (config_df["ACTION"] == "ROOT_PATH"))
        root_path = root_path_df.select(config_df["VALUE"]).head()["VALUE"]
        gv.root_path = root_path
        log.info("Setting root path as - " + root_path)
    except Exception as e:
        log.erorr("Mandatory Action <ROOT_PATH> not found")
        log.error(e)
        sys.exit(1)

    # Set Process Time column Name
    try:
        process_time_col_name_df = config_df.filter(
            (config_df["TYPE"] == "ENV") & (config_df["FILE_NAME"] == file_name.strip()) &
            (config_df["SOURCE_NAME"] == src_name.strip())
            & (config_df["ACTION"] == "CORE_KEY") & (config_df["KEY"] == "PROCESS_TIME_COL_NAME"))
        process_time_col_name = process_time_col_name_df.select(config_df["VALUE"]).head()["VALUE"]
        process_time_col_name = cu.get_map_from_string(process_time_col_name).get("col_name")
        gv.process_time_col_name = str(process_time_col_name)
        log.info(f'Setting Process Time column Name as - {gv.process_time_col_name}')
    except Exception as e:
        log.warn(f'Action - <PROCESS_TIME_COL_NAME> not found, hence setting default as {gv.process_time_col_name}')

    # Set Created By column Name
    try:
        created_by_col_name_df = config_df.filter(
            (config_df["TYPE"] == "ENV") & (config_df["FILE_NAME"] == file_name.strip()) &
            (config_df["SOURCE_NAME"] == src_name.strip()) & (config_df["ACTION"] == "CORE_KEY") &
            (config_df["KEY"] == "CREATED_BY_COL_NAME"))
        created_by_col_name = created_by_col_name_df.select(config_df["VALUE"]).head()["VALUE"]
        created_by_col_name = cu.get_map_from_string(created_by_col_name).get("col_name")
        gv.created_by_col_name = str(created_by_col_name)
        log.info(f'Setting Process Time column Name as - {gv.created_by_col_name}')
    except Exception as e:
        log.warn(f'Action - <CREATED_BY_COL_NAME> not found, hence setting default as {gv.created_by_col_name}')

    # Set Created By column Value
    try:
        created_by_col_value_df = config_df.filter(
            (config_df["TYPE"] == "ENV") & (config_df["FILE_NAME"] == file_name.strip()) &
            (config_df["SOURCE_NAME"] == src_name.strip()) & (config_df["ACTION"] == "CORE_KEY") &
            (config_df["KEY"] == "CREATED_BY_USER_NAME"))
        created_by_col_value = created_by_col_value_df.select(config_df["VALUE"]).head()["VALUE"]
        created_by_col_value = cu.get_map_from_string(created_by_col_value).get("col_name")
        gv.created_by_col_value = str(created_by_col_value)
        log.info(f'Setting Process Time column Name as - {gv.created_by_col_value}')
    except Exception as e:
        log.warn(f'Action - <CREATED_BY_USER_NAME> not found, hence setting default as {gv.created_by_col_value}')

    # Set Quality Rating Column Name
    try:
        quality_rating_col_name_df = config_df.filter(
            (config_df["TYPE"] == "ENV") & (config_df["FILE_NAME"] == file_name.strip()) &
            (config_df["SOURCE_NAME"] == src_name.strip()) & (config_df["ACTION"] == "CORE_KEY") &
            (config_df["KEY"] == "QUALITY_RATING_COL_NAME"))
        quality_rating_col_name = quality_rating_col_name_df.select(config_df["VALUE"]).head()["VALUE"]
        quality_rating_col_name = cu.get_map_from_string(quality_rating_col_name).get("col_name")
        gv.quality_rating_col_name = str(quality_rating_col_name)
        log.info(f'Setting Process Time column Name as - {gv.quality_rating_col_name}')
    except Exception as e:
        log.warn(f'Action - <QUALITY_RATING_COL_NAME> not found, hence setting default as {gv.quality_rating_col_name}')

    # set Batch Id Column Name
    try:
        batch_id_col_name_df = config_df.filter(
            (config_df["TYPE"] == "ENV") & (config_df["FILE_NAME"] == file_name.strip()) &
            (config_df["SOURCE_NAME"] == src_name.strip()) & (config_df["ACTION"] == "CORE_KEY") &
            (config_df["KEY"] == "BATCH_ID_COL_NAME"))
        batch_id_col_name = batch_id_col_name_df.select(config_df["VALUE"]).head()["VALUE"]
        batch_id_col_name = cu.get_map_from_string(batch_id_col_name).get("col_name")
        gv.batch_id_col_name = str(batch_id_col_name)
        log.info(f'Setting Process Time column Name as - {gv.batch_id_col_name}')
    except Exception as e:
        log.warn(f'Action - <BATCH_ID_COL_NAME> not found, hence setting default as {gv.batch_id_col_name}')
