from pyspark.sql import SparkSession
from functools import lru_cache
from common.utils import Logging as L


@lru_cache(maxsize=None)
def get_spark_session():
    L.log.info("Getting Spark Session")
    spark = SparkSession.builder \
        .appName("DataLake") \
        .master("local[*]") \
        .config("spark.sql.tungsten.enabled", "true") \
        .config("spark.io.compression.codec", "snappy") \
        .enableHiveSupport() \
        .config("spark.rdd.compress", "true")\
        .getOrCreate()

    return spark
