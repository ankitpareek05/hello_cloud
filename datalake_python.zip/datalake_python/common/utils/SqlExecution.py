import pyspark
from pyspark.sql import SQLContext
from common.utils.InitiateSparkSession import get_spark_session
from common.utils.Logging import *
from common.utils import CommonUtils as cu

from common.utils import GlobalVariables as gv

spark = get_spark_session()

log.info("In Common utils")


def sql_runner(config_data, bucket_name, layer_name_with_action):
    expected_input_details_dict = {k: v for k, v in config_data.items() if k.find("input_details") != -1}
    expected_input_details = [(K, v) for K, v in expected_input_details_dict.items()]

    for i in range(len(expected_input_details)):
        key = layer_name_with_action + "_input_details" + str(i)
        input_df = cu.read_input_file(config_data, key, bucket_name)

    expected_sql_quries_dict = {k: v for k, v in config_data.items() if k.find("sql_query") != -1}
    expected_sql_quries = [(K, v) for K, v in expected_sql_quries_dict.items()]

    # create empty data frame
    final_df = ""

    for i in range(len(expected_sql_quries)):
        sql_key = layer_name_with_action + "_sql_query" + str(i)
        output_key = layer_name_with_action + "_output_details" + str(i)

        output_details = config_data.get(output_key) or "NA"

        sql_query_details = cu.get_details_map(config_data, sql_key)

        sql_query = sql_query_details.get("sql")
        sql_type = sql_query_details.get("type")

        log.info(f'Running Query - {sql_type}')

        df = spark.sql(sql_query)
        df.persist(pyspark.StorageLevel.MEMORY_AND_DISK_SER)

        if output_details != "NA":
            cu.write_output_file(df, config_data, bucket_name, output_key)
        if i == len(expected_sql_quries):
            final_df = df

    SQLContext.clearCache
    return final_df


def sql_runner_ui(config_data, bucket_name, layer_name_with_action):
    expected_input_details_dict = {k: v for k, v in config_data.items() if k.find("input_details") != -1}
    expected_input_details = [(K, v) for K, v in expected_input_details_dict.items()]

    for i in range(len(expected_input_details)):
        key = layer_name_with_action + "_input_details" + str(i)
        input_df = cu.read_input_file(config_data, key, bucket_name)

    expected_sql_quries_dict = {k: v for k, v in config_data.items() if k.find("sql_query") != -1}
    expected_sql_quries = [(K, v) for K, v in expected_sql_quries_dict.items()]

    # create empty data frame
    final_df = ""

    for i in range(len(expected_sql_quries)):
        sql_key = layer_name_with_action + "_sql_query" + str(i)
        output_key = layer_name_with_action + "_output_details" + str(i)

        output_details = config_data.get(output_key) or "NA"

        sql_query_details = cu.get_details_map(config_data, sql_key)

        sql_query = sql_query_details.get("sql")
        sql_type = sql_query_details.get("type")

        # log.info("Running Query - ", sql_type)

        df = spark.sql(sql_query)
        df.persist(pyspark.StorageLevel.MEMORY_AND_DISK_SER)

        if output_details != "NA":
            cu.write_output_file(df, config_data, bucket_name, output_key)
        if i == len(expected_sql_quries):
            final_df = df

    SQLContext.clearCache
    return final_df


if __name__ == '__main__':
    # config_data = {
    #     'l0_source_input_details': 'path=\\Desktop\\Neelam_ACI\\Sources\\Contact|| file_format = csv || header=true || sep=NA || table_name=NA',
    #     'l0_source_output_details': 'path=\\Desktop\\Neelam_ACI\\Targets\\Contact_small_phone.csv || file_format = csv || mode=overwrite || header= true || sep=NA ||save_as_Table=false || table_name=NA',
    #     'l0_source_column_name': 'PHONE = Phone || COUNTRY = Country', 'l0_source_format': 'phone_format = E164',
    #     'l0_source_schema': 'dl_source_name || source_desc || dl_created_by || dl_process_time || src_create_ts || src_update_ts',
    #     'l0_source_sql_query': 'dl_source_name || source_desc || dl_created_by || dl_process_time || src_create_ts || src_update_ts'}
    #
    # bucket_name = "C:\\Users\\bdurgaprasad"
    # layer_name_with_action = "l0_source"

    # Below are the run-time arguments to be deleted
    config_path = r"C:\Users\bdurgaprasad\aci_American_Century_Investments\pyspark\datalake_python\configFiles\EntityModel_Sql_Config.csv"
    file_name = "CONTACT"
    layer_name = "L0"
    source_name = "SFDC"

    gv.layer_name = layer_name.lower()
    log.info("Layer Name: " + gv.layer_name)

    gv.source_name = source_name.lower()
    log.info("Source Name: " + gv.source_name)

    gv.file_name = file_name.lower()
    log.info("File Name: " + gv.file_name)

    log.info("\n############# Data Quality Driver #############")

    config_data = cu.parse_config_file(config_path, file_name, source_name, layer_name)
    filter_config_dict = dict((k, v) for k, v in config_data.items() if k.startswith(layer_name.lower()))

    bucket_name = gv.root_path
    log.info("Bucket Name: " + bucket_name)

    layer_name_with_action = gv.layer_name + "_source"
    input_key = layer_name_with_action + "_input_details"
    log.info("Reading Input File")

    # print("--------------------------------------------------")
    # print(config_data)
    # print(bucket_name)
    # print(layer_name_with_action)

    sql_runner(config_data, bucket_name, layer_name_with_action)
