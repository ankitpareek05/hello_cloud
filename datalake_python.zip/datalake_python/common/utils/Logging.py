from pyspark import SparkContext

sc = SparkContext()
logger = sc._jvm.org.apache.log4j
logger.LogManager.getLogger(__name__).setLevel(logger.Level.INFO)
log = logger.LogManager.getLogger(__name__)
