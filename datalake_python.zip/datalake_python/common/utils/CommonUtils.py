import pyspark.sql.functions as F
from pyspark.sql import SQLContext
import os.path
import timeit
from common.utils.InitiateSparkSession import get_spark_session
from common.utils.Logging import *
from common.utils import EnvironmentVariables
from common.utils import CommonConstants
from itertools import chain
from pyspark.sql.types import *
import sys

spark = get_spark_session()
sc = spark.sparkContext

log.info("In Common utils")

def concat(type):
    def concat_(*args):
        return list(chain.from_iterable((arg if arg else [] for arg in args)))
    return F.udf(concat_, ArrayType(type))


def read_from_csv_file(input_path, header_val, prefix=""):
    log.info("Reading CSV file onto DataFrame")
    """
    A function used to read data from CSV
    :param input_path: Input file path
    :param header_val: Header Value - true|false
    :return: DataFrame
    """

    if input_path != "":
        log.info(f'Reading data from path - {input_path}')
        df = spark.read \
            .option("header", header_val) \
            .option("inferSchema", "false") \
            .option("ignoreLeadingWhiteSpace", "true") \
            .option("ignoreTrailingWhiteSpace", "true") \
            .option("escape", "\"") \
            .option("quote", "\"") \
            .option("multiLine", "true") \
            .option("nullValue", "") \
            .option("nullValue", "null") \
            .option("nullValue", "NULL") \
            .option("nullValue", " ") \
            .csv(input_path) \
            .repartition(calculate_size_and_repartition(input_path))

        if prefix == "":
            return df
        else:
            main_column_with_prefix = list(map(lambda cols: F.col(cols).alias("%s%s" % (prefix, cols)), df.columns))
            df = df.select(*main_column_with_prefix)
            return df
    else:
        log.info("Path cannot be Empty. Exiting the process...")
        sys.exit(1)
        return


def read_from_delimited_file(input_path, header_val, delimiter, prefix=""):
    log.info("----------------Reading from delimiter------------------")
    """
    A function used to read data from delimited file
    :param input_path: Input file path
    :param header_val: Header Value - true|false
    :return: DataFrame
    """

    if input_path != "":
        log.info(f'Reading data from path - {input_path}')
        df = spark.read \
            .option("header", header_val) \
            .option("inferSchema", "true") \
            .option("delimiter", delimiter) \
            .option("ignoreLeadingWhiteSpace", "true") \
            .option("ignoreTrailingWhiteSpace", "true") \
            .option("escape", "\"") \
            .option("quote", "\"") \
            .option("multiLine", "true") \
            .option("nullValue", "") \
            .option("nullValue", "null") \
            .option("nullValue", "NULL") \
            .option("nullValue", " ") \
            .csv(input_path) \
            .repartition(calculate_size_and_repartition(input_path))
        if prefix == "":
            return df
        else:
            main_column_with_prefix = list(map(lambda cols: F.col(cols).alias("%s%s" % (prefix, cols)), df.columns))
            df = df.select(*main_column_with_prefix)
            return df
    else:
        log.info("Path cannot be Empty. Exiting the process...")
        sys.exit(1)
        return


def read_from_parquet_file(input_path, header_val, prefix=""):
    log.info("----------------Reading Parquet file as a DataFrame------------------")
    """
    A function used to read data from parquet file
    :param input_path: Input file path
    :param header_val: Header Value - true|false
    :return: DataFrame
    """

    if input_path != "":
        log.info(f'Reading data from path - {input_path}')
        df = spark.read \
            .option("header", header_val) \
            .option("inferSchema", "true") \
            .option("ignoreLeadingWhiteSpace", "true") \
            .option("ignoreTrailingWhiteSpace", "true") \
            .option("escape", "\"") \
            .option("quote", "\"") \
            .option("multiLine", "true") \
            .option("nullValue", "") \
            .option("nullValue", "null") \
            .option("nullValue", "NULL") \
            .option("nullValue", " ") \
            .parquet(input_path) \
            .repartition(calculate_size_and_repartition(input_path))

        if prefix == "":
            return df
        else:
            main_column_with_prefix = list(map(lambda cols: F.col(cols).alias("%s%s" % (prefix, cols)), df.columns))
            df = df.select(*main_column_with_prefix)
            return df
    else:
        log.info("Path cannot be Empty. Exiting the process...")
        sys.exit(1)
        return


def read_from_json_file(input_path, header_val):
    log.info("----------------Reading from json------------------")
    """
    A function used to read data from json file
    :param input_path: Input file path
    :param header_val: Header Value - true|false
    :return: DataFrame
    """
    df = spark.read \
        .option("header", header_val) \
        .option("inferSchema", "true") \
        .option("ignoreLeadingWhiteSpace", "true") \
        .option("ignoreTrailingWhiteSpace", "true") \
        .option("escape", "\"") \
        .option("quote", "\"") \
        .option("multiLine", "true") \
        .option("nullValue", "") \
        .option("nullValue", "null") \
        .option("nullValue", "NULL") \
        .option("nullValue", " ") \
        .json(input_path)
    return df


def read_from_table(table_name, prefix=""):
    log.info("----------------Reading from Table------------------")
    log.info("Reading Data From Table as a DataFrame")
    df = spark.sql("select * from {}".format(table_name))
    if prefix == "":
        return df
    else:
        main_column_with_prefix = list(map(lambda cols: F.col(cols).alias("%s%s" % (prefix, cols)), df.columns))
        df = df.select(*main_column_with_prefix)
        return df


def parse_config_file(config_path, file_name, src_name, layer_name):
    log.info("----------------Reading config file------------------")
    """
    A function to parse the config file and return the data in Key->Value pair
    :param config_path: Input path for Config file
    :param file_name: File name to be process
    :param src_name: Source name to be process
    :param layer_name: Layer name of processing
    :return: Dictionary of Key Value Pair
    """
    log.info("Parsing Config file into key value pair")
    read_config_as_df = read_from_csv_file(config_path, "true").na.fill("NA")
    read_config_as_df.show(100, False)
    log.info("Setting Environment Variables")
    EnvironmentVariables.set_env_variables(src_name, layer_name, read_config_as_df)
    read_config_as_df = read_config_as_df.filter((read_config_as_df["LAYER"] == layer_name.strip().upper())
                                                 & (read_config_as_df["FILE_NAME"] == file_name.strip().upper()) & (
                                                         read_config_as_df[
                                                             "SOURCE_NAME"] == src_name.strip().upper()))
    read_config_as_df = read_config_as_df.withColumn("KEYS", F.concat(read_config_as_df["LAYER"],
                                                                      F.lit("_"), read_config_as_df["ACTION"],
                                                                      F.lit("_"), read_config_as_df["KEY"])) \
        .withColumn("VALUE", read_config_as_df["VALUE"])

    config_rdd = read_config_as_df.select("KEYS", "VALUE").rdd.map(lambda x: (x[0].lower(), x[1])).collectAsMap()
    print(config_rdd)
    return config_rdd


def get_details_map(config_data, key):
    """
    A function to get the details from the key
    :param config_data: Key-Value config pair
    :param key: Key from which details to be extracted
    :return: Dictionay of Key-Value
    """
    try:
        log.info("Getting Details from - " + key)

        detail_data = config_data.get(key).strip().split("||")
        detail_data_dict = []
        for x in detail_data:
            data = x.split("=")
            key, value = data[0], "=".join(data[1:])
            detail_data_dict.append((key.strip(), value.strip()))

        return dict(detail_data_dict)

    except Exception as e:
        log.erorr("Error occured in get_details_map")
        log.error(e)


def get_map_from_string(input_string):
    """
    A function to get the details from the key
    :param: String
    """
    log.info("Getting Details from - " + input_string)
    detail_data = input_string.split("||")
    detail_data_dict = []
    for x in detail_data:
        data = x.split("=")
        key, value = data[0], "=".join(data[1:])
        detail_data_dict.append((key.strip(), value.strip()))

    return dict(detail_data_dict)


def replace_new_line(df):
    log.info("Replacing New Line Character from the String columns with Blank")
    df.createOrReplaceTempView("ABC")
    spark.udf.register("NewLine", replace_new_line_udf)
    schema = [F.col(x) for x in df.columns]
    sql = []
    sql = list(map(lambda fields: sql + "NewLine(" + fields.name + ") as " + fields.name
    if fields.dataType.equals(StringType()) else sql + fields.name), schema)

    sql_query = "SELECT " + ", ".join(sql) + " FROM ABC"
    df = spark.sql(sql_query)

    return df


def replace_new_line_udf(cols):
    if cols is not None:
        return cols.replaceAll("\n", " ").replaceAll("\r", " ")
    else:
        return cols


def read_lookup(file_name):
    log.info("-------------Reading lookup -----------------")
    df_lookup = read_from_csv_file(file_name, "true")
    lookup_dict = df_lookup.select("KEYS", "VALUES").rdd.map(lambda x: (x[0].strip(), x[1].strip())).collectAsMap()
    return lookup_dict


def write_to_csv(output_df, output_path, save_mode):
    log.info("-------------Writing data to csv--------------")
    print(output_path)
    output_df.coalesce(1).write.format("csv") \
        .option("header", "true") \
        .option("sep", ",") \
        .mode(save_mode) \
        .save(output_path)


def write_to_csv_partition(output_df, output_path, save_mode, partition):
    log.info("-----------------Writing data to csv-----------------")
    print(output_path)
    output_df.coalesce(1).write.partitionBy(partition).format("csv") \
        .option("header", "true") \
        .option("sep", ",") \
        .mode(save_mode) \
        .save(output_path)


def write_to_delimiter(output_df, output_path, delimiter, save_mode):
    log.info("---------- Writing data to delimited file -----------------")
    print(output_path)
    output_df.coalesce(1).write.format("csv") \
        .option("header", "true") \
        .option("sep", delimiter) \
        .mode(save_mode) \
        .save(output_path)


def write_to_s3(output_df, output_path, write_mode):
    log.info("---------- Writing data to S3 -----------------")
    output_df.coalesce(4).write \
        .format("com.databricks.spark.csv") \
        .option("header", "true") \
        .option("nullValue", "N/A") \
        .option("fileType", "csv") \
        .option("accessKey", CommonConstants.S3_ACCESS_KEY) \
        .option("secretKey", CommonConstants.S3_SECRET_ACCESS_KEY) \
        .mode(write_mode) \
        .save(output_path)


def write_to_parquet(output_df, output_path, write_mode, header):
    log.info("---------------Writing DataFrame in Parquet format--------------")
    output_df.write.format("parquet") \
        .option("header", header) \
        .option("nullValue", "") \
        .option("nullValue", None) \
        .option("nullValue", "NULL") \
        .mode(write_mode) \
        .save(output_path)


def save_to_table(output_df, output_path, table_name):
    log.info("-------------Writing DataFrame to table----------------------")

    output_df.write.format("csv") \
        .option("nullValue", "") \
        .option("nullValue", None) \
        .option("nullValue", "NULL") \
        .option("path", output_path) \
        .saveAsTable(table_name)


def is_file_exists(file_path):
    print(file_path)
    if os.path.isdir(file_path) and os.path.exists(file_path):
        return True
    if os.path.isdir(file_path):
        for each_path in os.listdir(file_path):
            if os.path.exists(file_path + each_path):
                return "True"
            else:
                return "False"
    elif os.path.exists(file_path):
        print("path exists")
        return True
    else:
        print("Directory/Path not exist")
        return False


def is_hdfs_file_exist(file_path):
    URI = sc._gateway.jvm.java.net.URI
    Path = sc._gateway.jvm.org.apache.hadoop.fs.Path
    FileSystem = sc._gateway.jvm.org.apache.hadoop.fs.FileSystem
    Configuration = sc._gateway.jvm.org.apache.hadoop.conf.Configuration

    fs = FileSystem.get(URI("hdfs://localhost:8020"), Configuration())
    status = fs.is_dir(file_path)

    if status:
        file_list = fs.listStatus(Path(file_path))
        file_exist = fs.exists(file_list.getPath())
        return file_exist
    else:
        file_exist = fs.exists(file_path)
        return file_exist


def read_input_file(config_data, input_key, bucket_name):
    """
    @summary A function to read the tables
    based on File formmat.
    @param Config file, layer name and bucket name
    @return Dataframe
    """

    log.info("Reading input Data file ")

    input_details_map = get_details_map(config_data, input_key)
    input_file_path = bucket_name + input_details_map.get("path")

    log.info("Input Data file path =" + input_file_path)

    input_file_format = input_details_map.get("file_format").lower().strip()
    log.info("Input data file format =" + input_file_format)

    input_file_header = input_details_map.get("header", "true")
    log.info("Header required to read the input file =" + input_file_header)

    input_file_seprator = input_details_map.get("sep", "NA")
    log.info("Input file delimiter =" + input_file_seprator)

    input_file_table_name = input_details_map.get("table_name")
    log.info("Input file Table name =" + input_file_table_name)

    input_file_prefix = input_details_map.get("prefix", "")
    log.info("Input file Prefix =" + input_file_prefix)

    input_file_view_name = input_details_map.get("view_name", "")
    log.info("Input file View Name =" + input_file_view_name)

    if input_file_format == "csv":
        input_df = read_from_csv_file(input_file_path, input_file_header)

    elif input_file_format == "parquet":
        input_df = read_from_parquet_file(input_file_path, input_file_header)

    elif input_file_format == "delimited":
        input_df = read_from_delimited_file(input_file_path, input_file_header, input_file_seprator)

    elif input_file_format == "json":
        input_df = read_from_json_file(input_file_path, input_file_header)

    elif input_file_format == "table":
        input_df = read_from_table(input_file_table_name)

    else:
        log.info("")

    if input_file_view_name != "":
        print("Creating Temp View - ", input_file_view_name)
        input_df.createOrReplaceTempView(input_file_view_name)
        # SQLContext.cacheTable(input_file_view_name)

    return input_df


def write_output_file(final_df, config_data, bucket_name, output_key):
    """
    @summary A function to write the based on
    file format.
    @param Config file, layer name and bucket name
    @return Dataframe
    """

    log.info("Writing output file ")

    output_details_map = get_details_map(config_data, output_key)

    output_file_path = bucket_name + output_details_map.get("path")
    output_file_format = output_details_map.get("file_format", "parquet").lower()
    output_file_save_mode = output_details_map.get("mode", "overwrite")
    output_file_header = output_details_map.get("header", "true")
    output_file_separator = output_details_map.get("sep", ",")
    output_file_saveAsTable = output_details_map.get("save_as_table", "false")
    output_file_table_name = output_details_map.get("table_name", "")

    if output_file_format == "csv":
        write_to_csv(final_df, output_file_path, output_file_save_mode)

    elif output_file_format == "parquet":
        write_to_parquet(final_df, output_file_path, output_file_save_mode, output_file_header)

    elif output_file_format == "delimited":
        write_to_delimiter(final_df, output_file_path, output_file_separator, output_file_save_mode)

    elif output_file_format == "table" and output_file_saveAsTable == "true":
        save_to_table(final_df, output_file_path, output_file_table_name)

    else:
        # log.info("No file format mentioned in the config file")
        print("file_format is not specified in config file. Hence, writing in PARQUET format by Default")
        write_to_parquet(final_df, output_file_path, output_file_save_mode, output_file_header)


def calculate_size_and_repartition(path):
    blockSize = 128
    Path = sc._gateway.jvm.org.apache.hadoop.fs.Path
    FileSystem = sc._gateway.jvm.org.apache.hadoop.fs.FileSystem
    Configuration = sc._gateway.jvm.org.apache.hadoop.conf.Configuration
    fs = FileSystem.get(Configuration())
    size_mb = fs.getContentSummary(Path(path)).getLength() / 1024 / 1024
    if size_mb > blockSize:
        return int(size_mb / blockSize)
    else:
        return 1
