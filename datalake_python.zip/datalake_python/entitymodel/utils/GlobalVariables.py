
class GlobalVariables:
    rootPath = "C:/Users/pvedanabhatla/Desktop/"
    fileName = ""
    layerName = "l0"
    sourceId = ""
    sourceName = ""
    moduleName = ""
    debugFlag = "false"
    processTimeColName = "dl_process_time"
    createdByUserName = "Deloitte"
    createdByColName = "dl_created_by"
    qualityRatingColName = "dl_quality_rating"