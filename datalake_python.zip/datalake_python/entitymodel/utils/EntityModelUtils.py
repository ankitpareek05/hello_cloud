from pyspark.sql.types import StringType
from datetime import datetime
from common.utils import Logging as logger
from common.utils import CommonUtils as cu
from common.utils.InitiateSparkSession import get_spark_session
import pyspark.sql.functions as F
import time
from pyspark.sql.functions import udf

spark = get_spark_session()

def parseConfigFile(configPath, fileName, srcName, layerName):
    readConfigAsDf = cu.read_from_csv_file(configPath, "true").na.fill("NA")
    readConfigAsDf = readConfigAsDf.filter((readConfigAsDf["LAYER"] == layerName.strip().upper()) &
                      (readConfigAsDf["FILE_NAME"] == fileName.strip().upper()) &
                      (readConfigAsDf["SOURCE_NAME"] == srcName.strip().upper()))
    readConfigAsDf = readConfigAsDf.withColumn("KEYS", F.concat(readConfigAsDf["LAYER"], F.lit("_"),
                                                                readConfigAsDf["ACTION"], F.lit("_"),
                                                                readConfigAsDf["KEY"])).withColumn("VALUE",
                                                                                                   readConfigAsDf["VALUE"])
    config_rdd = readConfigAsDf.select("KEYS", "VALUE").rdd.map(lambda x: (x[0].lower(), x[1].lower())).collectAsMap()
    logger.log.info("In parseConfigFile of EntityModelUtils")
    return config_rdd

def getProcessTime():
    return str(datetime.now())

def getAutoIncrementSeq(currentTimestamp, yarnId, monoIncrId):
    yarnIdSeq = ""
    if("_" in yarnId):
        yarnIdSeq = yarnId.split("_")[2]
    elif("-" in yarnId):
        yarnIdSeq = yarnId.split("-")[1]
    finalSeq = str(currentTimestamp) + str(yarnIdSeq) + str(monoIncrId)
    return finalSeq

getcurrentTimestampUDF = udf(lambda : str(int(round(time.time() * 1000))))
getAutoIncrementSeqUDF = udf(lambda currentTimestamp, yarnId, monoIncrId : getAutoIncrementSeq(currentTimestamp, yarnId, monoIncrId))

def getUniqueId(df,colName):
    yarnId = spark.sparkContext.applicationId
    df1 = df.withColumn("curr_timestamp", getcurrentTimestampUDF())
    df1 = df1.withColumn("mono_incr_id", F.monotonically_increasing_id())
    df2 = df1.withColumn(colName, getAutoIncrementSeqUDF(F.col("curr_timestamp"), F.lit(yarnId), F.col("mono_incr_id")))
    finalDF = df2.drop(F.col("curr_timestamp")).drop(F.col("mono_incr_id"))
    logger.log.info("In getUniqueId of EntityModelUtils")
    return finalDF

def createMeasureNameValue(inputDF, measureNameCol, measureValueCol, measureCols):
    tagValueColsList = []
    measureCols = ["company_name"]
    measureNameCol = "key_name"
    measureValueCol = "key_value"

    for c in measureCols:
        tagValueColsList.append(F.struct(F.lit(c).alias(measureNameCol), F.col(c).cast(StringType()).alias(measureValueCol)))
    tagValueCols = F.explode(F.array(*tagValueColsList))

    measureColumn = [F.col(column) for column in measureCols]

    initialCols = [F.col(x) for x in list(set([column for column in inputDF.columns]).
                                          difference(set(measureCols)))]

    modifiedCols = initialCols + [F.col("_kvs." + measureNameCol), F.col("_kvs." + measureValueCol)]
    modifiedCols1 = initialCols + [tagValueCols.alias("_kvs")]
    modifiedDF = inputDF.select(*modifiedCols1).select(*modifiedCols)

    logger.log.info("In createMeasureNameValue of EntityModelUtils")

    return modifiedDF
