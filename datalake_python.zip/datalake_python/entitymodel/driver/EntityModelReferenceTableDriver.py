from common.utils.InitiateSparkSession import get_spark_session
from entitymodel.utils.GlobalVariables import GlobalVariables as gv
from entitymodel.utils import EntityModelUtils
from entitymodel.impl import EntityModelImpl
import sys
from common.utils.Logging import *

spark = get_spark_session()


def main(args):
    if len(args) < 5:
        log.error("Invalid number of arguments passed")
        sys.exit(1)

    config_path = args[1]
    file_name = args[2]
    layer_name = args[3]
    source_name = args[4]


    #config_path = r"C:\Users\pvedanabhatla\datalake_python\configFiles\EntityModel_config.csv"
    #file_name = "CONTACT"
    #layer_name = "L0"
    #source_name = "SFDC"
    module = "ALL"

    parsedData = EntityModelUtils.parseConfigFile(config_path, file_name, source_name, layer_name)
    configData = {k: v for k, v in parsedData.items() if k.startswith(layer_name.lower()) == True}

    gv.fileName = file_name.lower()
    gv.sourceName = source_name.lower()
    gv.layerName = layer_name.lower()

    bucketName = gv.rootPath
    layerNm = gv.layerName
    debugFlag = gv.debugFlag

    EntityModelImpl.generateReferenceTables(configData)

if __name__ == "__main__":
    main(sys.argv)