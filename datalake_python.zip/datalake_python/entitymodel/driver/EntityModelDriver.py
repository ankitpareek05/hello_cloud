from common.utils.InitiateSparkSession import get_spark_session
from common.utils import GlobalVariables as gv
from common.utils import CommonUtils as cu
from entitymodel.utils import EntityModelUtils
from entitymodel.impl import EntityModelImpl
import sys
from common.utils.Logging import *

spark = get_spark_session()


def main(args):
    if len(args) < 5:
        log.error("Invalid number of arguments passed")
        sys.exit(1)

    config_path = args[1]
    file_name = args[2]
    layer_name = args[3]
    source_name = args[4]

    # Below are the argumemts, to be deleted or commented at run-time
    # config_path = r"C:\Users\pvedanabhatla\datalake_python\configFiles\EntityModel_config.csv"
    # file_name = "CONTACT"
    # layer_name = "L0"
    # source_name = "SFDC"

    module = "ALL"

    parsedData = EntityModelUtils.parseConfigFile(config_path, file_name, source_name, layer_name)
    configData = {k: v for k, v in parsedData.items() if k.startswith(layer_name.lower()) == True}

    gv.file_name = file_name.lower()
    gv.source_name = source_name.lower()
    gv.layer_name = layer_name.lower()

    bucketName = gv.root_path
    layerNm = gv.layer_name
    debugFlag = gv.debug_flag

    inputDetailsMap = dict([(i.split("=")[0].strip(), i.split("=")[1].strip()) for i in
                            configData.get(layerNm + "_party_model_input_details").strip().lower().split('||')])

    inputFilePath = bucketName + inputDetailsMap.get("path")
    inputFileFormat = inputDetailsMap.get("file_format", "parquet")
    inputFileHeader = inputDetailsMap.get("header", "true")
    inputFileSeparator = inputDetailsMap.get("sep", "NA")
    inputFileTableName = inputDetailsMap.get("table_name", "NA")
    inputFilePrefix = inputDetailsMap.get("prefix", "NA")

    # Switch case in Python

    def csv():
        return cu.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)

    def parquet():
        return cu.read_from_parquet_file(inputFilePath, inputFileHeader)

    def delimited():
        return cu.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader, )

    def table():
        return cu.read_from_table(inputFileTableName)

    # map the inputs to the function blocks

    fileType = {"csv": csv,
                "parquet": parquet,
                "delimited": delimited,
                "table": table
                }

    inputDF = fileType[inputFileFormat]()
    EntityModelImpl.generateDimensionTables(inputDF, configData)
    EntityModelImpl.generateFactTables(inputDF, configData)
    EntityModelImpl.generateRelationTables(inputDF, configData)


if __name__ == "__main__":
    main(sys.argv)
