from entitymodel.utils import EntityModelUtils
from entitymodel.utils.GlobalVariables import GlobalVariables
from common.utils import CommonUtils, Logging, CommonConstants
from common.utils.Logging import *

from pyspark.sql import DataFrame
import pyspark.sql.functions as fun


class ReferenceTables:
    bucketName = GlobalVariables.rootPath
    debugFlag = GlobalVariables.debugFlag

    def sourceType(referenceNameWithLayer: str, referenceConfigData: dict()):

        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")


        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        sourceSchema = list(map(lambda x: x.strip().lower(), referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic

        if inputFileFormat == "csv":
            sourceDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            sourceDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            sourceDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                          inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        sourceDF = sourceDF.selectExpr(*mappingString)

        # Adding core columns
        sourceDF = sourceDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
        .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        sourceDF = sourceDF.selectExpr(*sourceSchema)

        # Saving the Data
        if outputFileSaveAsTable.lower() == "true":
            CommonUtils.saveToTable(sourceDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat == "csv":
                CommonUtils.write_to_csv(sourceDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(sourceDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(sourceDF, outputFilePath, outputFileHeader, outputFileWriteMode)

    def partyType(referenceNameWithLayer: str, referenceConfigData: dict()):
        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")

        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        partyTypeSchema = list(map(lambda x: x.strip().lower(),
                            referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(),
                             referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic

        if inputFileFormat == "csv":
            partyTypeDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            partyTypeDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            partyTypeDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                         inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(
            map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        partyTypeDF = partyTypeDF.selectExpr(*mappingString)

        # Adding core columns
        partyTypeDF = partyTypeDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
        .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        partyTypeDF = partyTypeDF.selectExpr(*partyTypeSchema)

        # Saving the Data
        if outputFileSaveAsTable.lower() == "true":
            CommonUtils.saveToTable(partyTypeDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat == "csv":
                CommonUtils.write_to_csv(partyTypeDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(partyTypeDF, outputFilePath, outputFileHeader,
                                                             outputFileSeparator, outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(partyTypeDF, outputFilePath, outputFileHeader, outputFileWriteMode)

    def nameType(referenceNameWithLayer: str, referenceConfigData: dict()):
        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")

        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        nameTypeSchema = list(map(lambda x: x.strip().lower(),
                               referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(),
                             referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic
        if inputFileFormat == "csv":
            nameTypeDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            nameTypeDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            nameTypeDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                          inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(
            map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        nameTypeDF = nameTypeDF.selectExpr(*mappingString)

        # Adding core columns
        nameTypeDF = nameTypeDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
        .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        nameTypeDF = nameTypeDF.selectExpr(*nameTypeSchema)

        # Saving the Data
        if outputFileSaveAsTable.lower() == "true":
            CommonUtils.saveToTable(nameTypeDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat == "csv":
                CommonUtils.write_to_csv(nameTypeDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(nameTypeDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(nameTypeDF, outputFilePath, outputFileHeader, outputFileWriteMode)

    def identifierType(referenceNameWithLayer: str, referenceConfigData: dict()):
        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")

        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        identifierTypeSchema = list(map(lambda x: x.strip().lower(),
                              referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(),
                             referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic
        if inputFileFormat == "csv":
            identifierTypeDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            identifierTypeDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            identifierTypeDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                           inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(
            map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        identifierTypeDF = identifierTypeDF.selectExpr(*mappingString)

        # Adding core columns
        identifierTypeDF = identifierTypeDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
        .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        identifierTypeDF = identifierTypeDF.selectExpr(*identifierTypeSchema)

        # Saving the Data
        if outputFileSaveAsTable.lower() == "true":
            CommonUtils.saveToTable(identifierTypeDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat  == "csv":
                CommonUtils.write_to_csv(identifierTypeDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(identifierTypeDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(identifierTypeDF, outputFilePath, outputFileHeader, outputFileWriteMode)

    def addressType(referenceNameWithLayer: str, referenceConfigData: dict()):
        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")

        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        addressTypeSchema = list(map(lambda x: x.strip().lower(),
                                    referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(),
                             referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic
        if inputFileFormat == "csv":
            addressTypeDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            addressTypeDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            addressTypeDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                                 inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(
            map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        addressTypeDF = addressTypeDF.selectExpr(*mappingString)

        # Adding core columns
        addressTypeDF = addressTypeDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
        .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        addressTypeDF = addressTypeDF.selectExpr(*addressTypeSchema)

        # Saving the Data
        if  outputFileSaveAsTable.lower() == "true":
            CommonUtils.saveToTable(addressTypeDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat == "csv":
                CommonUtils.write_to_csv(addressTypeDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(addressTypeDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(addressTypeDF, outputFilePath, outputFileHeader, outputFileWriteMode)

    def phoneType(referenceNameWithLayer: str, referenceConfigData: dict()):
        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")

        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        phoneTypeSchema = list(map(lambda x: x.strip().lower(),
                                 referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(),
                             referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic
        if inputFileFormat == "csv":
            phoneTypeDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            phoneTypeDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            phoneTypeDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                              inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(
            map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        phoneTypeDF = phoneTypeDF.selectExpr(*mappingString)

        # Adding core columns
        phoneTypeDF = phoneTypeDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
        .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        phoneTypeDF = phoneTypeDF.selectExpr(*phoneTypeSchema)

        # Saving the Data
        if outputFileSaveAsTable.lower()  == "true":
            CommonUtils.saveToTable(phoneTypeDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat == "csv":
                CommonUtils.write_to_csv(phoneTypeDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(phoneTypeDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(phoneTypeDF, outputFilePath, outputFileHeader, outputFileWriteMode)

    def emailType(referenceNameWithLayer: str, referenceConfigData: dict()):
        inputDetailsMap = dict()
        for data in referenceConfigData.get(referenceNameWithLayer + "_input_details").strip().lower().split("||"):
            inputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        inputFilePath = ReferenceTables.bucketName + inputDetailsMap.get("path")
        inputFileFormat = inputDetailsMap.get("file_format", "parquet")
        inputFileHeader = inputDetailsMap.get("header", "true")
        inputFileSeparator = inputDetailsMap.get("sep", "NA")
        inputFilePrefix = inputDetailsMap.get("prefix", "")

        outputDetailsMap = dict()

        for data in referenceConfigData.get(referenceNameWithLayer + "_output_details").strip().lower().split("||"):
            outputDetailsMap[data.split("=")[0].strip()] = data.split("=")[1].strip()

        outputFilePath = ReferenceTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        emailTypeSchema = list(map(lambda x: x.strip().lower(),
                               referenceConfigData.get(referenceNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(),
                             referenceConfigData.get(referenceNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        # Start of Logic
        if inputFileFormat == "csv":
            emailTypeDF = CommonUtils.read_from_csv_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "parquet":
            emailTypeDF = CommonUtils.read_from_parquet_file(inputFilePath, inputFileHeader, inputFilePrefix)
        elif inputFileFormat == "delimited":
            emailTypeDF = CommonUtils.read_from_delimited_file(inputFilePath, inputFileSeparator, inputFileHeader,
                                                            inputFilePrefix)

        # Mapping the columns with schema
        mappingString = list(
            map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        emailTypeDF = emailTypeDF.selectExpr(*mappingString)

        # Adding core columns
        emailTypeDF = emailTypeDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
            .withColumn(createdByColName, fun.lit(createdByUserName))

        # Selecting the schema
        emailTypeDF = emailTypeDF.selectExpr(*emailTypeSchema)

        # Saving the Data
        if outputFileSaveAsTable.lower() == "true":
            CommonUtils.saveToTable(emailTypeDF, outputFilePath, outputFileWriteMode, outputFileTableName)
        else:
            if outputFileFormat == "csv":
                CommonUtils.write_to_csv(emailTypeDF, outputFilePath, outputFileWriteMode)
            elif outputFileFormat == "delimited":
                CommonUtils.write_to_delimiter(emailTypeDF, outputFilePath, outputFileHeader, outputFileSeparator,
                                             outputFileWriteMode)
            elif outputFileFormat == "parquet":
                CommonUtils.write_to_parquet(emailTypeDF, outputFilePath, outputFileHeader, outputFileWriteMode)