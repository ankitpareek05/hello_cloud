# from com.datalake.entitymodel.utils import EntityModelUtils, GlobalVariables
from entitymodel.utils import EntityModelUtils
from entitymodel.utils.GlobalVariables import GlobalVariables
from common.utils import CommonUtils, Logging
from common.utils.Logging import *
from pyspark.sql import DataFrame
import pyspark.sql.functions as fun
from pyspark.sql.types import StringType
from pyspark.storagelevel import StorageLevel as s


class DimensionTables:
    bucketName = GlobalVariables.rootPath

    def partyDim(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData):
        log.info(">>>>>>>>>> Running Party Dimension - ")

        partyDF = preProcessedDF
        # Getting Party Dim details
        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")

        partyDimFilePath = DimensionTables.bucketName + dimensionDetailMap.get("path")
        partyDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        partyDimFileHeader = dimensionDetailMap.get("header", "true")
        partyDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        partyDimTableName = dimensionDetailMap.get("table_name", "NA")
        partyDimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Party Join Condition Details
        partyDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        partyDimJoinType = partyDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        partyDimJoinCondition = partyDimJoinDetailsMap.get("join_condition", "NA").strip().lower() # todo
        partyDimJoinCondition = "(pre_unique_id = dim_src_legacy_id and lower(pre_file_type) = dim_party_type)"

        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = DimensionTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        partySchema = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))
        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()

        expectedDefaultCol = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        # Start of Logic

        # Checking if Party Dimension already exists
        fileExist = CommonUtils.is_file_exists(partyDimFilePath.replace("*", ""))
        if fileExist:
            log.info("Existing Party_dim found, de-duplicating the data ")

            def getExistingDF(partyDimFileFormat:str):

                if partyDimFileFormat == "csv":
                    return CommonUtils.read_from_csv_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
                elif partyDimFileFormat == "parquet":
                    return CommonUtils.read_from_parquet_file(partyDimFilePath, partyDimFileHeader)
                elif partyDimFileFormat == "delimited":
                    return CommonUtils.read_from_delimited_file(partyDimFilePath, partyDimFileSeparator, partyDimFileHeader)
                elif partyDimFileFormat == "table":
                    return CommonUtils.read_from_table(partyDimTableName)

            existingPartyDF = getExistingDF(partyDimFileFormat)
            partyDF = partyDF.join(existingPartyDF, fun.expr(partyDimJoinCondition), partyDimJoinType)

        else:
            log.info("No Existing Party Dimension Found !! Hence loading complete data")

        # Mapping the columns with schema
        mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        partyDF = partyDF.selectExpr(*mappingString)
        partyDF = EntityModelUtils.getUniqueId(partyDF, uniqueIdColName)

        partyDF.persist(s.MEMORY_AND_DISK_SER)

        # Adding core columns
        partyDF = partyDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
            .withColumn(createdByColName, fun.lit(createdByUserName))

        # Adding Column with default value
        if len(expectedDefaultCol) != 0:
            for i in range(1, len(expectedDefaultCol) + 1):
                defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + str(i))

                colName = defaultColConfig.get("col_name").strip()
                colValue = defaultColConfig.get("col_value").strip()

                partyDF = partyDF.withColumn(colName, fun.lit(colValue))

        # Getting columns names missing from Schema
        missingColumns = list(set(partySchema).difference(partyDF.columns))

        # Setting missing columns value to blank
        for col in missingColumns:
            partyDF = partyDF.withColumn(col, fun.lit("").cast(StringType()))

        # Selecting the schema
        partyDF = partyDF.selectExpr(*partySchema)

        # Saving the Data
        if(partyDF.head() is not None) :
            if (outputFileSaveAsTable.lower() == "true"):
                CommonUtils.save_to_table(partyDF, outputFilePath, outputFileWriteMode, outputFileTableName)
            else:
                if outputFileFormat ==  "csv":
                    CommonUtils.write_to_csv(partyDF, outputFilePath, outputFileWriteMode)
                elif outputFileFormat == "delimited":
                    CommonUtils.write_to_delimiter(partyDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                elif outputFileFormat == "parquet" :
                    CommonUtils.write_to_parquet(partyDF, outputFilePath, outputFileHeader, outputFileWriteMode)
        else:
            log.info("No New Record Found !!!")

    def addressDim(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):
        log.info(">>>>>>>>>> Running Address Dimension - ")

        addressDF = preProcessedDF

        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")

        addressDimFilePath = DimensionTables.bucketName + dimensionDetailMap.get("path")
        addressDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        addressDimFileHeader = dimensionDetailMap.get("header", "true")
        addressDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        addressDimTableName = dimensionDetailMap.get("table_name", "NA")
        addressDimPrefix = dimensionDetailMap.get("prefix", "")

        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = DimensionTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        # Getting Party Join Condition Details
        addressDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        addressDimJoinType = addressDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        addressDimJoinCondition = addressDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        addressSchema  = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))

        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName
        qualityRatingColName = GlobalVariables.qualityRatingColName

        expectedDefaultCol = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()

        # Start of Logic
        # Checking if Dimension already exists
        fileExist = CommonUtils.is_file_exists(addressDimFilePath.replace("*", ""))

        def getExistingAddressDF(addressDimFileFormat:str):
            if addressDimFileFormat == "csv":
                return CommonUtils.read_from_csv_file(addressDimFilePath, addressDimFileHeader, addressDimPrefix)
            elif addressDimFileFormat == "parquet":
                return CommonUtils.read_from_parquet_file(addressDimFilePath, addressDimFileHeader, addressDimPrefix)
            elif addressDimFileFormat == "delimited":
                return CommonUtils.read_from_delimited_file(addressDimFilePath, addressDimFileSeparator,
                                                              addressDimFileHeader, addressDimPrefix)
            elif addressDimFileFormat == "table":
                return CommonUtils.read_from_table(addressDimTableName, addressDimPrefix)

        if fileExist:
            log.info("Existing Address Dimension found, de-duplicating the data ")
            existingAddressDF = getExistingAddressDF(addressDimFileFormat)
            addressDF = addressDF.join(existingAddressDF, fun.expr(addressDimJoinCondition), addressDimJoinType)

        # Mapping the columns with schema
        mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        addressDF = addressDF.selectExpr(*mappingString)

        # Adding unique Id to the Dim
        addressDF = EntityModelUtils.getUniqueId(addressDF, uniqueIdColName)

        addressDF.persist(s.MEMORY_AND_DISK_SER)

        # Adding core columns

        addressDF = addressDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
        .withColumn(createdByColName, fun.lit(createdByUserName)) \
        .withColumn(qualityRatingColName, fun.lit(0))

        # Adding Column with default value
        if len(expectedDefaultCol) != 0:
            for i in range(1, len(expectedDefaultCol) + 1):
                defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + str(i))

                colName = defaultColConfig.get("col_name").strip()
                colValue = defaultColConfig.get("col_value").strip()

                addressDF = addressDF.withColumn(colName, fun.lit(colValue))

        # Getting columns names missing from Schema
        missingColumns = list(set(addressSchema).difference(addressDF.columns))

        # Setting missing columns value to blank
        for col in missingColumns:
            addressDF = addressDF.withColumn(col, fun.lit("").cast(StringType()))

        # Selecting the schema
        addressDF = addressDF.selectExpr(*addressSchema)

        # Saving the Data

        if  addressDF.head() is not None:
            if outputFileSaveAsTable.lower() == "true":
                CommonUtils.save_to_table(addressDF, outputFilePath, outputFileWriteMode, outputFileTableName)
            else:
                if outputFileFormat == "csv" :
                    CommonUtils.write_to_csv(addressDF, outputFilePath, outputFileWriteMode)
                elif outputFileFormat == "delimited":
                    CommonUtils.write_to_delimiter(addressDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                elif outputFileFormat == "parquet" :
                    CommonUtils.write_to_parquet(addressDF, outputFilePath, outputFileHeader, outputFileWriteMode)

        else:
            log.info("No New Record Found !!!")

    def phoneDim(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):
        log.info(">>>>>>>>>> Running Phone Dimension - ")
        phoneDF = preProcessedDF

        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")

        phoneDimFilePath = DimensionTables.bucketName + dimensionDetailMap.get("path")
        phoneDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        phoneDimFileHeader = dimensionDetailMap.get("header", "true")
        phoneDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        phoneDimTableName = dimensionDetailMap.get("table_name", "NA")
        phoneDimPrefix = dimensionDetailMap.get("prefix", "")

        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = DimensionTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        # Getting Party Join Condition Details
        phoneDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        phoneDimJoinType = phoneDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        phoneDimJoinCondition = phoneDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        phoneSchema = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName
        qualityRatingColName = GlobalVariables.qualityRatingColName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()
        expectedDefaultCol = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        # Start of Logic
        #  Checking if Party Dimension already exists
        fileExist = CommonUtils.is_file_exists(phoneDimFilePath.replace("*", ""))

        def getExistingPhoneDF(phoneDimFileFormat):
            if phoneDimFileFormat == "csv":
                return CommonUtils.read_from_csv_file(phoneDimFilePath, phoneDimFileHeader, phoneDimPrefix)
            elif phoneDimFileFormat ==  "parquet":
                return CommonUtils.read_from_parquet_file(phoneDimFilePath, phoneDimFileHeader, phoneDimPrefix)
            elif phoneDimFileFormat == "delimited":
                return CommonUtils.read_from_delimited_file(phoneDimFilePath, phoneDimFileSeparator,
                                                              phoneDimFileHeader, phoneDimPrefix)
            elif phoneDimFileFormat == "table" :
                return CommonUtils.read_from_table(phoneDimTableName, phoneDimPrefix)

        if fileExist:
            log.info("Existing Party_dim found, de-duplicating the data ")
            existingPhoneDF = getExistingPhoneDF(phoneDimFileFormat)
            phoneDF = phoneDF.join(existingPhoneDF, fun.expr(phoneDimJoinCondition), phoneDimJoinType)

        # Mapping the columns with schema
        mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        phoneDF = phoneDF.selectExpr(*mappingString)

        # Adding unique Id to the Dim
        phoneDF = EntityModelUtils.getUniqueId(phoneDF, uniqueIdColName)
        phoneDF.persist(s.MEMORY_AND_DISK_SER)

        # Adding core columns
        phoneDF = phoneDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
        .withColumn(createdByColName, fun.lit(createdByUserName))\
        .withColumn(qualityRatingColName, fun.lit(0))

        # Adding Column with default value
        if len(expectedDefaultCol) != 0:
            for i in  range( 1,  len(expectedDefaultCol) + 1):
                defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + str(i))

                colName = defaultColConfig.get("col_name").strip()
                colValue = defaultColConfig.get("col_value").strip()

                phoneDF = phoneDF.withColumn(colName, fun.lit(colValue))

        # Getting columns names missing from Schema
        missingColumns = list(set(phoneSchema).difference(phoneDF.columns))


        # Setting missing columns value to blank
        for col in missingColumns:
            phoneDF = phoneDF.withColumn(col, fun.lit("").cast(StringType()))

        # Selecting the schema
        phoneDF = phoneDF.selectExpr(*phoneSchema)

        # Saving the Data

        if phoneDF.head() is not None:
           if outputFileSaveAsTable.lower() == "true":
                CommonUtils.save_to_table(phoneDF, outputFilePath, outputFileWriteMode, outputFileTableName)
           else:
                if outputFileFormat == "csv" :
                     CommonUtils.write_to_csv(phoneDF, outputFilePath, outputFileWriteMode)
                elif outputFileFormat == "delimited":
                     CommonUtils.write_to_delimiter(phoneDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                elif outputFileFormat == "parquet" :
                     CommonUtils.write_to_parquet(phoneDF, outputFilePath, outputFileHeader, outputFileWriteMode)
        else:
            log.info("No New Record Found !!!")

    def emailDim(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):
        log.info(">>>>>>>>>> Running Email Dimension - ")
        emailDF = preProcessedDF

        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")

        emailDimFilePath = DimensionTables.bucketName + dimensionDetailMap.get("path")
        emailDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        emailDimFileHeader = dimensionDetailMap.get("header", "true")
        emailDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        emailDimTableName = dimensionDetailMap.get("table_name", "NA")
        emailDimPrefix = dimensionDetailMap.get("prefix", "")

        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = DimensionTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        # Getting Party Join Condition Details
        emailDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        emailDimJoinType = emailDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        emailDimJoinCondition = emailDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        emailSchema = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName
        qualityRatingColName = GlobalVariables.qualityRatingColName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()
        expectedDefaultCol = list(
            filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))


        # Start of Logic
        # Checking if Party Dimension already exists
        fileExist = CommonUtils.is_file_exists(emailDimFilePath.replace("*", ""))

        def getExistingPhoneDF(emailDimFileFormat):
            if emailDimFileFormat == "csv":
                return CommonUtils.read_from_csv_file(emailDimFilePath, emailDimFileHeader, emailDimPrefix)
            elif emailDimFileFormat ==  "parquet":
                return CommonUtils.read_from_parquet_file(emailDimFilePath, emailDimFileHeader, emailDimPrefix)
            elif emailDimFileFormat == "delimited":
                return CommonUtils.read_from_delimited_file(emailDimFilePath, emailDimFileSeparator, emailDimFileHeader,
                                                  emailDimPrefix)
            elif emailDimFileFormat == "table" :
                return CommonUtils.read_from_table(emailDimTableName, emailDimPrefix)

        if fileExist:
            log.info("Existing Party_dim found, de-duplicating the data ")

            existingEmailDF = getExistingPhoneDF(emailDimFileFormat)
            emailDF = emailDF.join(existingEmailDF, fun.expr(emailDimJoinCondition), emailDimJoinType)

        # Mapping the columns with schema
        mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

        emailDF = emailDF.selectExpr(*mappingString)

        # Adding unique Id to the Dim
        emailDF = EntityModelUtils.getUniqueId(emailDF, uniqueIdColName)
        emailDF.persist(s.MEMORY_AND_DISK_SER)

        # Adding core columns
        emailDF = emailDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
        .withColumn(createdByColName, fun.lit(createdByUserName)) \
        .withColumn(qualityRatingColName, fun.lit(0))

        # Adding Column with default value
        if len(expectedDefaultCol) != 0:
            for i in range(1 ,len(expectedDefaultCol) + 1):
                defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + i)

                colName = defaultColConfig.get("col_name").strip()
                colValue = defaultColConfig.get("col_value").strip()

                emailDF = emailDF.withColumn(colName, fun.lit(colValue))

        # Getting columns names missing from Schema
        missingColumns = list(set(emailSchema).difference(emailDF.columns))


        # Setting missing columns value to blank
        for col in missingColumns:
            emailDF = emailDF.withColumn(col, fun.lit("").cast(StringType()))

        # Selecting the schema
        emailDF = emailDF.selectExpr(*emailSchema)

        # Saving the Data

        if  emailDF.head() is not None:
            if outputFileSaveAsTable.lower() == "true":
                CommonUtils.save_to_table(emailDF, outputFilePath, outputFileWriteMode, outputFileTableName)
            else:
                if outputFileFormat == "csv":
                    CommonUtils.write_to_csv(emailDF, outputFilePath, outputFileHeader, outputFileWriteMode)
                elif outputFileFormat ==  "delimited":
                    CommonUtils.write_to_delimiter(emailDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                elif outputFileFormat == "parquet":
                    CommonUtils.write_to_parquet(emailDF, outputFilePath, outputFileHeader, outputFileWriteMode)

        else:
            log.info("No New Record Found !!!")

    def partyNameDim(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):
        log.info(">>>>>>>>>> Running Party Name Dimension - ")

        partyNameDF = preProcessedDF

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")
        partyDimFilePath = DimensionTables.bucketName + dimensionDetailMap.get("path")
        partyDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        partyDimFileHeader = dimensionDetailMap.get("header", "true")
        partyDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        partyDimTableName = dimensionDetailMap.get("table_name", "NA")
        partyDimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Party Join Condition Details
        partyDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        partyDimJoinType = partyDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        partyDimJoinCondition = partyDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = DimensionTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        partyNameSchema = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()

        expectedDefaultCol = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        # Start of Logic
        try:
            log.info("Reading data from Party_dim to fetch party_id")

            def getExistingPartyDF(partyDimFileFormat):

                if partyDimFileFormat == "csv":
                    return CommonUtils.read_from_csv_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
                elif partyDimFileFormat ==  "parquet":
                    return CommonUtils.read_from_parquet_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
                elif partyDimFileFormat == "delimited":
                    return CommonUtils.read_from_delimited_file(partyDimFilePath, partyDimFileSeparator,
                                                                  partyDimFileHeader)
                elif partyDimFileFormat == "table":
                    return CommonUtils.read_from_table(partyDimTableName)

            existingPartyDF = getExistingPartyDF(partyDimFileFormat)


            partyNameDF = partyNameDF.join(existingPartyDF, fun.expr(partyDimJoinCondition), partyDimJoinType)

            # Mapping the columns with schema
            mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

            partyNameDF = partyNameDF.selectExpr(*mappingString)

            partyNameDF = EntityModelUtils.getUniqueId(partyNameDF, uniqueIdColName)

            partyNameDF.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            partyNameDF = partyNameDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol) + 1):
                    defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    partyNameDF = partyNameDF.withColumn(colName, fun.lit(colValue))

            # Getting columns names missing from Schema
            missingColumns = list(set(partyNameSchema).difference(partyNameDF.columns))

            # Setting missing columns value to blank
            for col in missingColumns:
                partyNameDF = partyNameDF.withColumn(col, fun.lit("").cast(StringType()))

            # Selecting the schema
            partyNameDF = partyNameDF.selectExpr(*partyNameSchema)

            # Saving  the Data

            if partyNameDF.head() is not None:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.save_to_table(partyNameDF, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(partyNameDF, outputFilePath, outputFileWriteMode)
                    elif outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(partyNameDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                    elif outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(partyNameDF, outputFilePath, outputFileHeader, outputFileWriteMode)
            else:
                log.info(" No New Record Found")

        except Exception as e:
            raise e

    def identifierDim(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):
        log.info(">>>>>>>>>> Running Identifier Dimension - ")

        identifierDF = preProcessedDF

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")
        partyDimFilePath = DimensionTables.bucketName + dimensionDetailMap.get("path")
        partyDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        partyDimFileHeader = dimensionDetailMap.get("header", "true")
        partyDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        partyDimTableName = dimensionDetailMap.get("table_name", "NA")
        partyDimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Party Join Condition Details
        partyDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        partyDimJoinType = partyDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        partyDimJoinCondition = partyDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = DimensionTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        partyNameSchema = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()

        expectedDefaultCol = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        # Start of Logic
        try:
            log.info("Reading data from Party_dim to fetch party_id")

            def getExistingPartyDF(partyDimFileFormat):
                if partyDimFileFormat == "csv":
                    return CommonUtils.read_from_csv_file(partyDimFilePath, partyDimFileHeader)
                elif partyDimFileFormat == "parquet":
                    return CommonUtils.read_from_parquet_file(partyDimFilePath, partyDimFileHeader)
                elif partyDimFileFormat == "delimited":
                    return CommonUtils.read_from_delimited_file(partyDimFilePath, partyDimFileSeparator,
                                                                  partyDimFileHeader)
                elif partyDimFileFormat == "table":
                    return CommonUtils.read_from_table(partyDimTableName)

            existingPartyDF = getExistingPartyDF(partyDimFileFormat)
            identifierDF = identifierDF.join(existingPartyDF, fun.expr(partyDimJoinCondition), partyDimJoinType)

            # Mapping the columns with schema
            mappingString = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

            identifierDF = identifierDF.selectExpr(*mappingString)

            identifierDF = EntityModelUtils.getUniqueId(identifierDF, uniqueIdColName)

            identifierDF.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            identifierDF = identifierDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol) + 1):
                    defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + i)

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    identifierDF = identifierDF.withColumn(colName, fun.lit(colValue))

            # Getting columns names missing from Schema
            missingColumns = list(set(partyNameSchema).difference(identifierDF.columns))

            # Setting missing columns value to blank
            for col in missingColumns:
                identifierDF = identifierDF.withColumn(col, fun.lit("").cast(StringType()))

            # Selecting the schema
            identifierDF = identifierDF.selectExpr(*partyNameSchema)

            # Saving the Data

            if identifierDF.head() is not None:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.save_to_table(identifierDF, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(identifierDF, outputFilePath, outputFileHeader, outputFileWriteMode)
                    elif outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(identifierDF, outputFilePath, outputFileHeader,
                                                             outputFileSeparator, outputFileWriteMode)
                    elif outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(identifierDF, outputFilePath, outputFileHeader,
                                                     outputFileWriteMode)
            else:
                log.info(" No New Record Found")

        except Exception as e:
            raise  e