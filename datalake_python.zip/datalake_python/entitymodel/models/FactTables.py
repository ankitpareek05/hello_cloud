from entitymodel.utils import EntityModelUtils
from entitymodel.utils.GlobalVariables import GlobalVariables
from common.utils import CommonUtils, Logging, CommonConstants
from common.utils.Logging import *

from pyspark.sql import DataFrame
import pyspark.sql.functions as fun
from pyspark.sql.types import StringType
from pyspark.storagelevel import StorageLevel as s

class FactTables:
    bucketName = GlobalVariables.rootPath

    def accountFact(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):

        # dimConfigData.foreach(println)
        accountFactDF = preProcessedDF

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")
        partyDimFilePath = FactTables.bucketName + dimensionDetailMap.get("path")
        partyDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        partyDimFileHeader = dimensionDetailMap.get("header", "true")
        partyDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        partyDimTableName = dimensionDetailMap.get("table_name", "NA")
        partyDimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Party Join Condition Details
        partyDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        partyDimJoinType = partyDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        partyDimJoinCondition = partyDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = FactTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        accountFactSchema = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        measureValueColDetails = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_key_value_col_name")
        measureNameCol = measureValueColDetails.get("key_col_name", CommonConstants.DL_MEASURE_NAME)
        measureValueCol = measureValueColDetails.get("value_col_name", CommonConstants.DL_MEASURE_VALUE)
        measureTagValueCols = list(map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_key_value_cols").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()

        expectedDefaultCol  = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        #  Start of Logic

        try:
            log.info("Reading data from Party_dim to fetch party_id")

            def getExistingPartyDF(partyDimFileFormat):
                if partyDimFileFormat == "csv":
                    return CommonUtils.read_from_csv_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
                elif partyDimFileFormat == "parquet":
                    return CommonUtils.read_from_parquet_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
                elif partyDimFileFormat == "delimited":
                    return CommonUtils.read_from_delimited_file(partyDimFilePath, partyDimFileSeparator,
                                                                  partyDimFileHeader, partyDimPrefix)
                elif partyDimFileFormat == "table":
                    return CommonUtils.read_from_table(partyDimTableName, partyDimPrefix)

            existingPartyDF = getExistingPartyDF(partyDimFileFormat)

            accountFactDF = accountFactDF.join(existingPartyDF, fun.expr(partyDimJoinCondition), partyDimJoinType)

            accountFactDF = EntityModelUtils.getUniqueId(accountFactDF, uniqueIdColName)

            accountFactDF.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            accountFactDF = accountFactDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol) + 1):
                    defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    accountFactDF = accountFactDF.withColumn(colName, fun.lit(colValue))

            # Renaming the cols for Tag - Value
            for cols in measureTagValueCols:
                oldCol, newCol = cols.split("::")[0], cols.split("::")[1]
                accountFactDF = accountFactDF.withColumnRenamed(oldCol, newCol)

            tagValueCols = list(map(lambda x: x.split("::")[1], measureTagValueCols))
            accountFactDF = EntityModelUtils.createMeasureNameValue(accountFactDF, measureNameCol, measureValueCol,
                                                                    tagValueCols)

            # Mapping the columns with schema
            mappingString  = list(map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

            accountFactDF = accountFactDF.selectExpr(*mappingString)

            # Getting columns names missing from Schema
            # $$$$$
            missingColumns = list(set(accountFactSchema).difference(accountFactDF.columns))

            # Getting missing columns value to blank

            for col in missingColumns:
                accountFactDF = accountFactDF.withColumn(col, fun.lit("").cast(StringType()))

            #Selecting  the schema
            accountFactDF = accountFactDF.selectExpr(*accountFactSchema)

            # Saving the Data
            if accountFactDF.head() is not None:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.saveToTable(accountFactDF, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(accountFactDF, outputFilePath, outputFileWriteMode)
                    if outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(accountFactDF, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                    if outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(accountFactDF, outputFilePath, outputFileHeader, outputFileWriteMode)
            else:
                log.info(" No New Record Found")
        except Exception as e:
            raise e

    def contactFact(preProcessedDF: DataFrame, dimNameWithLayer: str, dimConfigData: dict()):
        # dimConfigData.foreach(println)
        contactFactDF = preProcessedDF

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_input_details")
        partyDimFilePath = FactTables.bucketName + dimensionDetailMap.get("path")
        partyDimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        partyDimFileHeader = dimensionDetailMap.get("header", "true")
        partyDimFileSeparator = dimensionDetailMap.get("sep", "NA")
        partyDimTableName = dimensionDetailMap.get("table_name", "NA")
        partyDimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Party Join Condition Details
        partyDimJoinDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_dim_join_condition")
        partyDimJoinType = partyDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        partyDimJoinCondition = partyDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_output_details")

        outputFilePath = FactTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        accountFactSchema = list(
            map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_schema").split("||")))
        mappingColumn = list(
            map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_mapping_column").split("||")))

        measureValueColDetails = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_key_value_col_name")
        measureNameCol = measureValueColDetails.get("key_col_name", CommonConstants.DL_MEASURE_NAME)
        measureValueCol = measureValueColDetails.get("value_col_name", CommonConstants.DL_MEASURE_VALUE)
        measureTagValueCols = list(
            map(lambda x: x.strip().lower(), dimConfigData.get(dimNameWithLayer + "_key_value_cols").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = dimConfigData.get(dimNameWithLayer + "_unique_id_col_name").strip().lower()

        expectedDefaultCol = list(filter(lambda x: (dimNameWithLayer + "_default_col_value") in x, dimConfigData.keys()))

        #  Start of Logic
        try:
            log.info("Reading data from Party_dim to fetch party_id")

            if partyDimFileFormat == "csv":
                existingPartyDF = CommonUtils.read_from_csv_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
            elif partyDimFileFormat == "parquet":
                existingPartyDF = CommonUtils.read_from_parquet_file(partyDimFilePath, partyDimFileHeader, partyDimPrefix)
            elif partyDimFileFormat == "delimited":
                existingPartyDF = CommonUtils.read_from_delimited_file(partyDimFilePath, partyDimFileSeparator,
                                                              partyDimFileHeader, partyDimPrefix)
            elif partyDimFileFormat == "table":
                existingPartyDF = CommonUtils.read_from_table(partyDimTableName, partyDimPrefix)

            contactFactDF = contactFactDF.join(existingPartyDF, fun.expr(partyDimJoinCondition), partyDimJoinType)

            contactFactDF = EntityModelUtils.getUniqueId(contactFactDF, uniqueIdColName)

            contactFactDF.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            contactFactDF = contactFactDF.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
            .withColumn(createdByColName, fun.lit(createdByUserName))

            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol)):
                    defaultColConfig = CommonUtils.get_details_map(dimConfigData, dimNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    contactFactDF = contactFactDF.withColumn(colName, fun.lit(colValue))

            # Renaming the cols for Tag - Value
            for cols in measureTagValueCols:
                oldCol, newCol = cols.split("::")[0], cols.split("::")[1]
                contactFactDF = contactFactDF.withColumnRenamed(oldCol, newCol)


            tagValueCols = list(map(lambda x: x.split("::")[1], measureTagValueCols))
            contactFactDF = EntityModelUtils.createMeasureNameValue(contactFactDF, measureNameCol, measureValueCol,
                                                                    tagValueCols)

            # Mapping the columns with schema
            mappingString = list(
                map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

            contactFactDF = contactFactDF.selectExpr(*mappingString)

            # Getting columns names missing from Schema
            # $$$$$
            missingColumns = list(set(accountFactSchema).difference(contactFactDF.columns))

            # Getting missing columns value to blank

            for col in missingColumns:
                contactFactDF = contactFactDF.withColumn(col, fun.lit("").cast(StringType()))

            # Selecting  the schema
            contactFactDF = contactFactDF.selectExpr(*accountFactSchema)

            # Saving the Data

            if  contactFactDF.head() is not None:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.saveToTable(contactFactDF, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(contactFactDF, outputFilePath, outputFileWriteMode)
                    if outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(contactFactDF, outputFilePath, outputFileHeader,
                                                       outputFileSeparator, outputFileWriteMode)
                    if outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(contactFactDF, outputFilePath, outputFileHeader,
                                                     outputFileWriteMode)
            else:
                log.info(" No New Record Found")
        except Exception as e:
            raise e