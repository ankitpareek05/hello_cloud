from entitymodel.utils import EntityModelUtils
from entitymodel.utils.GlobalVariables import GlobalVariables
from common.utils import CommonUtils, Logging, CommonConstants
from common.utils.Logging import *

from pyspark.sql import DataFrame
import pyspark.sql.functions as fun
from pyspark.sql.types import StringType
from pyspark.storagelevel import StorageLevel as s


class RelationTables:
    bucketName = GlobalVariables.rootPath

    def partyAddressRel(preProcessedDF: DataFrame, relNameWithLayer: str,  relConfigData: dict()):

        partyAddressRel = preProcessedDF

        # Getting Reference Dim(Party) Details
        referenceDimDetailMap = CommonUtils.get_details_map(relConfigData,
                                                          relNameWithLayer + "_reference_dim_input_details")
        referenceDimFilePath = RelationTables.bucketName + referenceDimDetailMap.get("path")
        referenceDimFileFormat = referenceDimDetailMap.get("file_format", "parquet")
        referenceDimFileHeader = referenceDimDetailMap.get("header", "true")
        referenceDimFileSeparator = referenceDimDetailMap.get("sep", "NA")
        referenceDimTableName = referenceDimDetailMap.get("table_name", "NA")
        referenceDimPrefix = referenceDimDetailMap.get("prefix", "")

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_input_details")
        dimFilePath = RelationTables.bucketName + dimensionDetailMap.get("path")
        dimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        dimFileHeader = dimensionDetailMap.get("header", "true")
        dimFileSeparator = dimensionDetailMap.get("sep", "NA")
        dimTableName = dimensionDetailMap.get("table_name", "NA")
        dimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Reference Dim Join Condition Details
        referenceDimJoinDetailsMap = CommonUtils.get_details_map(relConfigData,
                                                               relNameWithLayer + "_reference_dim_join_condition")
        referenceDimJoinType = referenceDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        referenceDimJoinCondition = referenceDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Dimension Join Condition Details
        dimJoinDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_join_condition")
        dimJoinType = dimJoinDetailsMap.get("join_type", "NA").strip().lower()
        dimJoinCondition = dimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_output_details")

        outputFilePath = RelationTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        relationSchema =   list(map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_schema").split("||")))
        mappingColumn = list(
            map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = relConfigData.get(relNameWithLayer + "_unique_id_col_name").strip().lower()
        expectedDefaultCol  = list(filter(lambda x:  (relNameWithLayer + "_default_col_value") in x, relConfigData.keys()))

        # Start of Logic
        try:
            log.info("Reading data from Dimension to fetch dimension_id")

            if dimFileFormat == "csv":
                existingAddressDF = CommonUtils.read_from_csv_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "parquet":
                existingAddressDF = CommonUtils.read_from_parquet_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat =="delimited":
                existingAddressDF = CommonUtils.read_from_delimited_file(dimFilePath, dimFileSeparator, dimFileHeader, dimPrefix)
            elif dimFileFormat == "table":
                existingAddressDF = CommonUtils.read_from_table(dimTableName, dimPrefix)

            log.info("Reading data from Reference dim to get Reference_id")
            if referenceDimFileFormat == "csv":
                existingReferenceDF = CommonUtils.read_from_csv_file(referenceDimFilePath, referenceDimFileHeader, referenceDimPrefix)
            elif referenceDimFileFormat == "parquet":
                existingReferenceDF = CommonUtils.read_from_parquet_file(referenceDimFilePath, referenceDimFileHeader, referenceDimPrefix)
            elif referenceDimFileFormat == "delimited":
                existingReferenceDF = CommonUtils.read_from_delimited_file(referenceDimFilePath, referenceDimFileSeparator,
                                                              referenceDimFileHeader, referenceDimPrefix)
            elif referenceDimFileFormat == "table":
                existingReferenceDF = CommonUtils.read_from_table(referenceDimTableName, referenceDimPrefix)

            partyAddressRel = partyAddressRel \
            .join(existingReferenceDF, fun.expr(referenceDimJoinCondition), referenceDimJoinType) \
            .join(existingAddressDF, fun.expr(dimJoinCondition), dimJoinType)

            # Mapping the columns with schema
            mappingString = list(map(lambda cols: cols.split("::")[0].strip()+ " as " + cols.split("::")[1].strip(), mappingColumn))

            partyAddressRel = partyAddressRel.selectExpr(*mappingString)

            partyAddressRel = EntityModelUtils.getUniqueId(partyAddressRel, uniqueIdColName)

            partyAddressRel.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            partyAddressRel = partyAddressRel.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime()))\
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in  range(1, len(expectedDefaultCol)):
                    defaultColConfig = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    partyAddressRel = partyAddressRel.withColumn(colName, fun.lit(colValue))


            # Getting columns names missing from Schema
            missingColumns = list(set(relationSchema).difference(partyAddressRel.columns))

            # Setting missing columns value to blank

            for col in missingColumns:
                partyAddressRel = partyAddressRel.withColumn(col, fun.lit("").cast(StringType()))

            # Selecting the schema
            partyAddressRel = partyAddressRel.selectExpr(*relationSchema)

            # Saving the vData

            if partyAddressRel.head() is not None:
                if outputFileSaveAsTable == "true":
                    CommonUtils.save_to_table(partyAddressRel, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(partyAddressRel, outputFilePath, outputFileWriteMode)
                    elif outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(partyAddressRel, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                    elif outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(partyAddressRel, outputFilePath, outputFileHeader, outputFileWriteMode)

            else:
                log.info(" No New Record Found")

        except Exception as e:
            raise e

    def partyPhoneRel(preProcessedDF: DataFrame, relNameWithLayer: str, relConfigData: dict()):
        partyPhoneRel = preProcessedDF

        # Getting Reference Dim(Party) Details
        referenceDimDetailMap = CommonUtils.get_details_map(relConfigData,
                                                          relNameWithLayer + "_reference_dim_input_details")
        referenceDimFilePath = RelationTables.bucketName + referenceDimDetailMap.get("path")
        referenceDimFileFormat = referenceDimDetailMap.get("file_format", "parquet")
        referenceDimFileHeader = referenceDimDetailMap.get("header", "true")
        referenceDimFileSeparator = referenceDimDetailMap.get("sep", "NA")
        referenceDimTableName = referenceDimDetailMap.get("table_name", "NA")
        referenceDimPrefix = referenceDimDetailMap.get("prefix", "")

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_input_details")
        dimFilePath = RelationTables.bucketName + dimensionDetailMap.get("path")
        dimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        dimFileHeader = dimensionDetailMap.get("header", "true")
        dimFileSeparator = dimensionDetailMap.get("sep", "NA")
        dimTableName = dimensionDetailMap.get("table_name", "NA")
        dimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Reference Dim Join Condition Details
        referenceDimJoinDetailsMap = CommonUtils.get_details_map(relConfigData,
                                                               relNameWithLayer + "_reference_dim_join_condition")
        referenceDimJoinType = referenceDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        referenceDimJoinCondition = referenceDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Dimension Join Condition Details
        dimJoinDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_join_condition")
        dimJoinType = dimJoinDetailsMap.get("join_type", "NA").strip().lower()
        dimJoinCondition = dimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_output_details")

        outputFilePath = RelationTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        relationSchema =   list(map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_schema").split("||")))
        mappingColumn = list(
            map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = relConfigData.get(relNameWithLayer + "_unique_id_col_name").strip().lower()
        expectedDefaultCol  = list(filter(lambda x:  (relNameWithLayer + "_default_col_value") in x, relConfigData.keys()))

        # Start of Logic

        try:
            log.info("Reading data from Dimension to fetch dimension_id")

            if dimFileFormat == "csv":
                existingPhoneDF = CommonUtils.read_from_csv_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "parquet":
                existingPhoneDF = CommonUtils.read_from_parquet_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "delimited":
                existingPhoneDF = CommonUtils.read_from_delimited_file(dimFilePath, dimFileSeparator, dimFileHeader,
                                                                      dimPrefix)
            elif dimFileFormat == "table":
                existingPhoneDF = CommonUtils.read_from_table(dimTableName, dimPrefix)

            log.info("Reading data from Reference dim to get Reference_id")

            if referenceDimFileFormat == "csv":
                existingReferenceDF = CommonUtils.read_from_csv_file(referenceDimFilePath, referenceDimFileHeader,
                                                                  referenceDimPrefix)
            elif referenceDimFileFormat == "parquet":
                existingReferenceDF = CommonUtils.read_from_parquet_file(referenceDimFilePath, referenceDimFileHeader,
                                                                      referenceDimPrefix)
            elif referenceDimFileFormat == "delimited":
                existingReferenceDF = CommonUtils.read_from_delimited_file(referenceDimFilePath, referenceDimFileSeparator,
                                                                        referenceDimFileHeader, referenceDimPrefix)
            elif referenceDimFileFormat == "table":
                existingReferenceDF = CommonUtils.read_from_table(referenceDimTableName, referenceDimPrefix)

            partyPhoneRel = partyPhoneRel \
            .join(existingReferenceDF, fun.expr(referenceDimJoinCondition), referenceDimJoinType)\
            .join(existingPhoneDF, fun.expr(dimJoinCondition), dimJoinType)

            # Mapping the columns with schema
            mappingString = list(map(lambda cols: cols.split("::")[0].strip()+ " as " + cols.split("::")[1].strip(), mappingColumn))

            partyPhoneRel = partyPhoneRel.selectExpr(*mappingString)

            partyPhoneRel = EntityModelUtils.getUniqueId(partyPhoneRel, uniqueIdColName)

            partyPhoneRel.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            partyPhoneRel = partyPhoneRel.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol)):
                    defaultColConfig = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    partyPhoneRel = partyPhoneRel.withColumn(colName, fun.lit(colValue))

            # Getting columns names missing from Schema
            missingColumns = list(set(relationSchema).difference(partyPhoneRel.columns))

            # Setting missing columns value to blank
            for col in missingColumns:
                partyPhoneRel = partyPhoneRel.withColumn(col, fun.lit("").cast(StringType()))

            # Selecting the schema
            partyPhoneRel = partyPhoneRel.selectExpr(*relationSchema)

            # Saving the Data
            if partyPhoneRel.head() is not None:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.save_to_table(partyPhoneRel, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat ==  "csv":
                        CommonUtils.write_to_csv(partyPhoneRel, outputFilePath, outputFileWriteMode)
                    elif outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(partyPhoneRel, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                    elif outputFileFormat ==  "parquet":
                        CommonUtils.write_to_parquet(partyPhoneRel, outputFilePath, outputFileHeader, outputFileWriteMode)
            else:
                log.info(" No New Record Found")

        except Exception as e:
            raise e

    def partyEmailRel(preProcessedDF: DataFrame, relNameWithLayer: str, relConfigData: dict()):
        partyEmailRel = preProcessedDF

        # Getting Reference Dim(Party) Details
        referenceDimDetailMap = CommonUtils.get_details_map(relConfigData,
                                                          relNameWithLayer + "_reference_dim_input_details")
        referenceDimFilePath = RelationTables.bucketName + referenceDimDetailMap.get("path")
        referenceDimFileFormat = referenceDimDetailMap.get("file_format", "parquet")
        referenceDimFileHeader = referenceDimDetailMap.get("header", "true")
        referenceDimFileSeparator = referenceDimDetailMap.get("sep", "NA")
        referenceDimTableName = referenceDimDetailMap.get("table_name", "NA")
        referenceDimPrefix = referenceDimDetailMap.get("prefix", "")

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_input_details")
        dimFilePath = RelationTables.bucketName + dimensionDetailMap.get("path")
        dimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        dimFileHeader = dimensionDetailMap.get("header", "true")
        dimFileSeparator = dimensionDetailMap.get("sep", "NA")
        dimTableName = dimensionDetailMap.get("table_name", "NA")
        dimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Reference Dim Join Condition Details
        referenceDimJoinDetailsMap = CommonUtils.get_details_map(relConfigData,
                                                               relNameWithLayer + "_reference_dim_join_condition")
        referenceDimJoinType = referenceDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        referenceDimJoinCondition = referenceDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Dimension Join Condition Details
        dimJoinDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_join_condition")
        dimJoinType = dimJoinDetailsMap.get("join_type", "NA").strip().lower()
        dimJoinCondition = dimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_output_details")

        outputFilePath = RelationTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        relationSchema =   list(map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_schema").split("||")))
        mappingColumn = list(
            map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = relConfigData.get(relNameWithLayer + "_unique_id_col_name").strip().lower()
        expectedDefaultCol  = list(filter(lambda x:  (relNameWithLayer + "_default_col_value") in x, relConfigData.keys()))

        # Start of Logic

        try:
            log.info("Reading data from Dimension to fetch dimension_id")

            if dimFileFormat == "csv":
                existingEmailDF = CommonUtils.read_from_csv_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "parquet":
                existingEmailDF = CommonUtils.read_from_parquet_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "delimited":
                existingEmailDF = CommonUtils.read_from_delimited_file(dimFilePath, dimFileSeparator, dimFileHeader,
                                                                    dimPrefix)
            elif dimFileFormat == "table":
                existingEmailDF = CommonUtils.read_from_table(dimTableName, dimPrefix)

            log.info("Reading data from Reference dim to get Reference_id")

            if referenceDimFileFormat == "csv":
                existingReferenceDF = CommonUtils.read_from_csv_file(referenceDimFilePath, referenceDimFileHeader,
                                                                  referenceDimPrefix)
            elif referenceDimFileFormat == "parquet":
                existingReferenceDF = CommonUtils.read_from_parquet_file(referenceDimFilePath, referenceDimFileHeader,
                                                                      referenceDimPrefix)
            elif referenceDimFileFormat == "delimited":
                existingReferenceDF = CommonUtils.read_from_delimited_file(referenceDimFilePath, referenceDimFileSeparator,
                                                                        referenceDimFileHeader, referenceDimPrefix)
            elif referenceDimFileFormat == "table":
                existingReferenceDF = CommonUtils.read_from_table(referenceDimTableName, referenceDimPrefix)

            partyEmailRel = partyEmailRel \
                .join(existingReferenceDF, fun.expr(referenceDimJoinCondition), referenceDimJoinType) \
                .join(existingEmailDF, fun.expr(dimJoinCondition), dimJoinType)

            # Mapping the columns with schema
            mappingString = list(
                map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

            partyEmailRel = partyEmailRel.selectExpr(*mappingString)

            partyEmailRel = EntityModelUtils.getUniqueId(partyEmailRel, uniqueIdColName)

            partyEmailRel.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            partyEmailRel = partyEmailRel.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol)):
                    defaultColConfig = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    partyEmailRel = partyEmailRel.withColumn(colName, fun.lit(colValue))

            # Getting columns names missing from Schema
            missingColumns = list(set(relationSchema).difference(partyEmailRel.columns))

            # Setting missing columns value to blank
            for col in missingColumns:
                partyEmailRel = partyEmailRel.withColumn(col, fun.lit("").cast(StringType()))

            #Selecting the schema
            partyEmailRel = partyEmailRel.selectExpr(*relationSchema)

            # Saving the Data

            if partyEmailRel.head() is not None> 0:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.save_to_table(partyEmailRel, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(partyEmailRel, outputFilePath, outputFileWriteMode)
                    elif outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(partyEmailRel, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                    elif outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(partyEmailRel, outputFilePath, outputFileHeader, outputFileWriteMode)
            else:
                log.info(" No New Record Found")

        except Exception as e:
            raise e

    def partyPartyRel(preProcessedDF: DataFrame, relNameWithLayer: str, relConfigData: dict()):
        partyPartyRel = preProcessedDF

        # Getting Reference Dim(Party) Details
        referenceDimDetailMap = CommonUtils.get_details_map(relConfigData,
                                                          relNameWithLayer + "_reference_dim_input_details")
        referenceDimFilePath = RelationTables.bucketName + referenceDimDetailMap.get("path")
        referenceDimFileFormat = referenceDimDetailMap.get("file_format", "parquet")
        referenceDimFileHeader = referenceDimDetailMap.get("header", "true")
        referenceDimFileSeparator = referenceDimDetailMap.get("sep", "NA")
        referenceDimTableName = referenceDimDetailMap.get("table_name", "NA")
        referenceDimPrefix = referenceDimDetailMap.get("prefix", "")

        # Getting Dim Details
        dimensionDetailMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_input_details")
        dimFilePath = RelationTables.bucketName + dimensionDetailMap.get("path")
        dimFileFormat = dimensionDetailMap.get("file_format", "parquet")
        dimFileHeader = dimensionDetailMap.get("header", "true")
        dimFileSeparator = dimensionDetailMap.get("sep", "NA")
        dimTableName = dimensionDetailMap.get("table_name", "NA")
        dimPrefix = dimensionDetailMap.get("prefix", "")

        # Getting Reference Dim Join Condition Details
        referenceDimJoinDetailsMap = CommonUtils.get_details_map(relConfigData,
                                                               relNameWithLayer + "_reference_dim_join_condition")
        referenceDimJoinType = referenceDimJoinDetailsMap.get("join_type", "NA").strip().lower()
        referenceDimJoinCondition = referenceDimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Dimension Join Condition Details
        dimJoinDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_dim_join_condition")
        dimJoinType = dimJoinDetailsMap.get("join_type", "NA").strip().lower()
        dimJoinCondition = dimJoinDetailsMap.get("join_condition", "NA").strip().lower()

        # Getting Output Details
        outputDetailsMap = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_output_details")

        outputFilePath = RelationTables.bucketName + outputDetailsMap.get("path")
        outputFileFormat = outputDetailsMap.get("file_format", "parquet")
        outputFileWriteMode = outputDetailsMap.get("mode", "append")
        outputFileHeader = outputDetailsMap.get("header", "true")
        outputFileSeparator = outputDetailsMap.get("sep", "NA")
        outputFileSaveAsTable = outputDetailsMap.get("save_as_table", "false")
        outputFileTableName = outputDetailsMap.get("table_name", "")

        relationSchema =   list(map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_schema").split("||")))
        mappingColumn = list(
            map(lambda x: x.strip().lower(), relConfigData.get(relNameWithLayer + "_mapping_column").split("||")))

        processTimeColName = GlobalVariables.processTimeColName
        createdByColName = GlobalVariables.createdByColName
        createdByUserName = GlobalVariables.createdByUserName

        uniqueIdColName = relConfigData.get(relNameWithLayer + "_unique_id_col_name").strip().lower()
        expectedDefaultCol  = list(filter(lambda x:  (relNameWithLayer + "_default_col_value") in x, relConfigData.keys()))

        # Start of Logic

        try:
            log.info("Reading data from Dimension to fetch dimension_id")

            if dimFileFormat == "csv":
                existingEmailDF = CommonUtils.read_from_csv_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "parquet":
                existingEmailDF = CommonUtils.read_from_parquet_file(dimFilePath, dimFileHeader, dimPrefix)
            elif dimFileFormat == "delimited":
                existingEmailDF = CommonUtils.read_from_delimited_file(dimFilePath, dimFileSeparator, dimFileHeader,
                                                                    dimPrefix)
            elif dimFileFormat == "table":
                existingEmailDF = CommonUtils.read_from_table(dimTableName, dimPrefix)

            log.info("Reading data from Reference dim to get Reference_id")

            if referenceDimFileFormat == "csv":
                existingReferenceDF = CommonUtils.read_from_csv_file(referenceDimFilePath, referenceDimFileHeader,
                                                                  referenceDimPrefix)
            elif referenceDimFileFormat == "parquet":
                existingReferenceDF = CommonUtils.read_from_parquet_file(referenceDimFilePath, referenceDimFileHeader,
                                                                      referenceDimPrefix)
            elif referenceDimFileFormat == "delimited":
                existingReferenceDF = CommonUtils.read_from_delimited_file(referenceDimFilePath, referenceDimFileSeparator,
                                                                        referenceDimFileHeader, referenceDimPrefix)
            elif referenceDimFileFormat == "table":
                existingReferenceDF = CommonUtils.read_from_table(referenceDimTableName, referenceDimPrefix)

            partyPartyRel = partyPartyRel \
            .join(existingReferenceDF, fun.expr(referenceDimJoinCondition), referenceDimJoinType) \
            .join(existingEmailDF, fun.expr(dimJoinCondition), dimJoinType)

            # Mapping the columns with schema
            mappingString = list(
                map(lambda cols: cols.split("::")[0].strip() + " as " + cols.split("::")[1].strip(), mappingColumn))

            partyPartyRel = partyPartyRel.selectExpr(*mappingString)

            partyPartyRel = EntityModelUtils.getUniqueId(partyPartyRel, uniqueIdColName)

            partyPartyRel.persist(s.MEMORY_AND_DISK_SER)

            # Adding core columns
            partyPartyRel = partyPartyRel.withColumn(processTimeColName, fun.lit(EntityModelUtils.getProcessTime())) \
            .withColumn(createdByColName, fun.lit(createdByUserName))

            # Adding Column with default value
            if len(expectedDefaultCol) != 0:
                for i in range(1, len(expectedDefaultCol)):
                    defaultColConfig = CommonUtils.get_details_map(relConfigData, relNameWithLayer + "_default_col_value" + str(i))

                    colName = defaultColConfig.get("col_name").strip()
                    colValue = defaultColConfig.get("col_value").strip()

                    partyPartyRel = partyPartyRel.withColumn(colName, fun.lit(colValue))

            # Getting columns names missing from Schema
            missingColumns = list(set(relationSchema).difference(partyPartyRel.columns))

            # Setting missing columns value to blank
            for col in missingColumns:
                partyPartyRel = partyPartyRel.withColumn(col, fun.lit("").cast(StringType()))

            #Selecting the schema
            partyPartyRel = partyPartyRel.selectExpr(*relationSchema)

            # Saving the Data

            if partyPartyRel.head() is not None:
                if outputFileSaveAsTable.lower() == "true":
                    CommonUtils.save_to_table(partyPartyRel, outputFilePath, outputFileWriteMode, outputFileTableName)
                else:
                    if outputFileFormat == "csv":
                        CommonUtils.write_to_csv(partyPartyRel, outputFilePath, outputFileWriteMode)
                    elif outputFileFormat == "delimited":
                        CommonUtils.write_to_delimiter(partyPartyRel, outputFilePath, outputFileHeader, outputFileSeparator, outputFileWriteMode)
                    elif outputFileFormat == "parquet":
                        CommonUtils.write_to_parquet(partyPartyRel, outputFilePath, outputFileHeader, outputFileWriteMode)

            else:
                log.info(" No New Record Found")

        except Exception as e:
            raise e