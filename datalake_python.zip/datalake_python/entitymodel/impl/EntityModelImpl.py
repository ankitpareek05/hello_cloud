from entitymodel.utils.GlobalVariables import GlobalVariables as gv
from common.utils.InitiateSparkSession import get_spark_session
from common.utils import Logging as logger
from pyspark.sql import DataFrame
from entitymodel.models.DimensionTables import DimensionTables
from entitymodel.models.ReferenceTables import ReferenceTables
from entitymodel.models.FactTables import FactTables
from entitymodel.models.RelationTables import RelationTables



spark = get_spark_session()

def generateReferenceTables(inputConfigData):
    layerName = gv.layerName
    expectedReferences = [reference.strip().lower() for reference in
                          inputConfigData.get((layerName + "_reference_tables_list"), "NA").split("||")]
    if not expectedReferences[0].lower() == "na":
        for referenceName in expectedReferences:
            referenceNameWithLayer = layerName + "_" + referenceName
            referenceConfigData = {k:v for k,v in inputConfigData.items() if k.lower().startswith(referenceNameWithLayer)}
            logger.log.info("Running Reference for : " + referenceNameWithLayer)
            if referenceName == "source":
                ReferenceTables.sourceType(referenceNameWithLayer, referenceConfigData)
            elif referenceName == "party_type":
                ReferenceTables.partyType(referenceNameWithLayer, referenceConfigData)
            elif referenceName == "name_type":
                ReferenceTables.nameType(referenceNameWithLayer, referenceConfigData)
            elif referenceName == "identifier_type":
                ReferenceTables.identifierType(referenceNameWithLayer, referenceConfigData)
            elif referenceName == "address_type":
                ReferenceTables.addressType(referenceNameWithLayer, referenceConfigData)
            elif referenceName == "phone_type":
                ReferenceTables.phoneType(referenceNameWithLayer, referenceConfigData)
            elif referenceName == "email_type":
                ReferenceTables.emailType(referenceNameWithLayer, referenceConfigData)
    else:
        logger.log.info("No Reference Table List Available")

def generateDimensionTables(preProcessedDF, inputConfigData):
    layerName = gv.layerName
    expectedDimensions = [dimension.strip().lower() for dimension in
                          inputConfigData.get((layerName + "_dimension_tables_list"), "NA").split("||")]
    if not expectedDimensions[0].lower() == "na":
        for dimName in expectedDimensions:
            dimNameLayer = layerName + "_" + dimName
            logger.log.info("\nRunning Dimension for : " + dimNameLayer)
            dimConfigData = {k:v for k,v in inputConfigData.items() if k.lower().startswith(dimNameLayer)}
            if dimName == "party_dim":
                DimensionTables.partyDim(preProcessedDF, dimNameLayer, dimConfigData)
            elif dimName == "party_name_dim":
                DimensionTables.partyNameDim(preProcessedDF, dimNameLayer, dimConfigData)
            elif dimName.startswith("address_dim"):
                DimensionTables.addressDim(preProcessedDF, dimNameLayer, dimConfigData)
            elif dimName.startswith("phone_dim"):
                DimensionTables.phoneDim(preProcessedDF, dimNameLayer, dimConfigData)
            elif dimName.startswith("email_dim"):
                DimensionTables.emailDim(preProcessedDF, dimNameLayer, dimConfigData)
            elif dimName == "url_dim":
                DimensionTables.partyDim(preProcessedDF, dimNameLayer, dimConfigData)
            elif dimName.startsWith("identifier_dim"):
                DimensionTables.identifierDim(preProcessedDF, dimNameLayer,dimConfigData)
            else:
                logger.log.info("No match found for : " + dimNameLayer)
    else:
        logger.log.info("No DIM List Available ")

def generateFactTables(preProcessedDF, inputConfigData):
    layerName = gv.layerName
    expectedFacts = [fact.strip().lower() for fact in
                     inputConfigData.get((layerName + "_fact_tables_list"), "NA").split("||")]

    if not expectedFacts[0].lower() == "na":
        for factName in expectedFacts:
            factNameLayer = layerName + "_" + factName
            logger.log.info("Running Facts for : " + factNameLayer)
            factConfigData = {k: v for k, v in inputConfigData.items() if k.lower().startswith(factNameLayer)}
            if factName.startswith("account_fact"):
                FactTables.accountFact(preProcessedDF, factNameLayer,factConfigData)
            elif factName.startswith("contact_fact"):
                FactTables.contactFact(preProcessedDF, factNameLayer,factConfigData)
            else:
                logger.log.info("No match found for : " + factNameLayer)
    else:
        logger.log.info("No Facts List Available ")

def generateRelationTables(preProcessedDF, inputConfigData):
    layerName = gv.layerName
    expectedRelations = [relation.strip().lower() for relation in inputConfigData.get((layerName + "_relation_tables_list"), "NA").split("||")]
    if not expectedRelations[0].lower() == "na":
        for relName in expectedRelations:
            relNameLayer = layerName + "_" + relName
            logger.log.info("Running Relations for : " + relNameLayer)
            relConfigData = {k:v for k,v in inputConfigData.items() if k.lower().startswith(relNameLayer)}
            if relName == "party_party_rel":
                RelationTables.partyPartyRel(preProcessedDF, relNameLayer, relConfigData)
            elif relName.startswith("party_address_rel"):
                RelationTables.partyAddressRel(preProcessedDF, relNameLayer, relConfigData)
            elif relName.startswith("party_phone_rel"):
                RelationTables.partyPhoneRel(preProcessedDF, relNameLayer,relConfigData)
            elif relName.startswith("party_email_rel"):
                RelationTables.partyEmailRel(preProcessedDF, relNameLayer,relConfigData)
            elif relName.startswith("party_url_rel"):
                RelationTables.partyEmailRel(preProcessedDF, relNameLayer,relConfigData)
            else:
                logger.log.info("No match found for : " + relNameLayer)
    else:
        logger.log.info("No Relation List Available ")
