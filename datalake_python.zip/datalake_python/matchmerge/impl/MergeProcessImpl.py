import sys

from pyspark.sql.types import StringType

import common.utils.CommonUtils as cu
import pyspark.sql.functions as f
from pyspark.storagelevel import StorageLevel
from common.utils.InitiateSparkSession import get_spark_session
from pyspark.sql.window import Window
from functools import reduce
from datetime import date
from common.utils import Logging as l
from matchmerge.utils import MatchMergeConstants as mmc

spark = get_spark_session()

def inArray(col1,col2):
    col3=col1+col2
    return col3

spark.udf.register("inArray",inArray)


def join_and_cascade(path, match_df3, dimension, dim_out_bkp):
    l.log.info("Running Join and cascade for " + dimension)

    dim_df = cu.read_from_csv_file(path + "\\*.csv", "true")
    dim_col = "dl_" + dimension.replace("_DIM", "").lower() + "_unique_id"
    dim_df_schema = [f.col(x) for x in dim_df.columns]
    l.log.info(dim_df_schema)
    dim_df.persist(StorageLevel.MEMORY_AND_DISK)
    dim_df.show()
    dim_df2 = dim_df.withColumn("period", f.concat_ws("-", f.lit(date.today().month), f.lit(date.today().year)))
    dim_df2.show()
    cu.write_to_csv_partition(dim_df2, dim_out_bkp + "/" + dimension, "overwrite", "period")
    temp_dim_df = dim_df.join(match_df3, (f.col(dim_col) == f.col("UNIQUE_ID_m")),
                              "left_outer").filter(f.col("UNIQUE_ID_m").isNull()).select(dim_df_schema)
    # temp_dim_df.show()

    temp_dim_df2 = dim_df.join(match_df3, (f.col(dim_col) == f.col("UNIQUE_ID_m"))) \
        .withColumn("party_unique_id", f.col("unique_id_matched")).select(dim_df_schema)

    # temp_dim_df2.show()

    dim_cascade_df = temp_dim_df.union(temp_dim_df2). \
        withColumn("period", f.concat_ws("-", f.lit(date.today().month), f.lit(date.today().year))) \
        # orderBy(f.col("UNIQUE_ID_m")). \

    # dim_cascade_df.show()
    cu.write_to_csv_partition(dim_cascade_df, dim_out_bkp + "/" + dimension + "_cascade", "overwrite", "period")


def read_dimensions_df(dim_out, match_df3, dim_out_bkp):
    dimensions = ('PARTY_DIM', 'ADDRESS_DIM', 'PHONE_DIM', 'PARTY_NAME_DIM', 'EMAIL_DIM', 'IDENTIFIER_DIM')

    for each in dimensions:
        path = dim_out + "dl_stg_" + each.lower()
        path_exist = cu.is_file_exists(path)

        if path_exist:
            l.log.info("file_exist for " + each)
            join_and_cascade(path, match_df3, each, dim_out_bkp)
        else:
            l.log.info("no file for dimension " + each.lower())


def perform_merge(trust_df, match_df, input_df_renamed, match_conf_dict):
    l.log.info("Launching merge job")

    # Find the output paths used in the merge process from the match configuration file

    dim_out = match_conf_dict[mmc.DIM_OUTPUT]
    gold_path = match_conf_dict[mmc.GOLDEN_OUTPUT_PATH]
    dim_out_bkp = match_conf_dict[mmc.DIM_OUTPUT_BKP]
    merge_output = match_conf_dict[mmc.MERGE_OUTPUT]

    # Create the list of match columns from the trust configuration

    l.log.info("Reading the match columns from trust configuration")
    match_col = trust_df.select("attribute_name").distinct().collect()
    match_columns = [x.attribute_name for x in match_col]
    print(">>match_columns: ", match_columns)

    # Group match_df with unique_id_matched in order to form a dataframe
    # containing unique_id and unique_id_matched

    print("##########################matchdf############")
    match_df.show()
    print("##########################matchdf############")
    l.log.info("Creating match_df_grouped")
    match_df.printSchema()
    match_df_grouped = match_df.groupBy("unique_id_matched").agg(f.collect_list("unique_id").alias("combine_id"))\
         .withColumn("unique_id_matched", f.array("unique_id_matched")) \
        .withColumn("sam",inArray(f.col("unique_id_matched"),f.col("combine_id")))



       # .   withColumn("merge_columns", f.array(f.concat_ws(',',f.col("unique_id_matched")[0], f.col("combine_id")[0])))\
       #  .withColumn("unique_id", f.explode(f.col("merge_columns"))) \
       #  .withColumn("unique_id_matched", f.explode(f.col("unique_id_matched"))) \
       #  .select("unique_id", "unique_id_matched")

    match_df_grouped.show()
    match_df_grouped.printSchema()

    print("----match_df_grouped----")
    match_df_grouped.show()

    l.log.info("Creating merge_df")

    merge_df = input_df_renamed.join(match_df_grouped, "unique_id").withColumn("row_num", f.row_number().over
    (Window.orderBy(f.col("unique_id_matched")).partitionBy(f.col("unique_id_matched"))))

    print("----merge_df----")
    merge_df.show()

    merge_df = merge_df.filter(f.col("row_num") == 1)

    print("----merge_df row_num=1----")
    merge_df.show()

    l.log.info("Creating final_merge_df")

    final_merge_df = merge_df.filter(f.col("row_num") == 1).select("unique_id", "src_sys_code")

    print("----final_merge_df----")
    final_merge_df.show()

    merge_trust_join_df = merge_df.select("unique_id", "unique_id_matched", "src_sys_code").join(trust_df,
                                                                                                 "src_sys_code") \
        .withColumn("dense_rank", f.dense_rank().over
    (Window.orderBy(f.col("trust_score").desc()).partitionBy("unique_id_matched"))).orderBy("attribute_name")

    print("----merge_trust_join_df----")
    merge_trust_join_df.show()

    l.log.info("Creating merge_trust_filter_df")

    merge_trust_filter_df = merge_trust_join_df.filter((f.col("dense_rank") == 1) | ((f.col("dense_rank") == 2) &
                                                                                     (f.col(
                                                                                         "attribute_name") == "PRIMARY_TELEPHONE") &
                                                                                     (f.col("unique_id_matched") == 2))) \
        .orderBy(f.col("unique_id_matched"))

    print("----merge_trust_filter_df----")
    merge_trust_filter_df.show()

    l.log.info("Performing group by using unique_id_matched")

    merge_trust_grouped_df = merge_trust_filter_df.groupBy("unique_id_matched").pivot("attribute_name").agg(
        f.max("src_sys_code"))
    print("----merge_trust_grouped_df----")
    merge_trust_grouped_df.show()

    merge_trust_renamed_df = merge_trust_grouped_df.select(
        [f.col(x).alias(x + "_m") for x in merge_trust_grouped_df.columns])
    print("----merge_trust_renamed_df----")
    merge_trust_renamed_df.show(2000)

    # Populate list_df with the join between merge_df and merge_trust_renamed_df

    list_df = []
    for attribute in match_columns:
        list_df.append(merge_df.join(merge_trust_renamed_df, (f.col("src_sys_code") == f.col(attribute + "_m")) & (
                    f.col("unique_id_matched") == f.col(
                "unique_id_matched_m"))).select("unique_id_matched", attribute).withColumnRenamed("unique_id_matched",
                                                                                                  "unique_id"))

    list_df_with_unique_id = reduce(lambda df1, df2: df1.join(df2, ["unique_id"]), list_df)

    print("----list_df_with_unique_id----")
    list_df_with_unique_id.show(1000)

    # Find matching rows between final_merge_df and list_df_with_unique_id

    l.log.info("Creating final_merge_list_df_join")

    final_merge_list_df_join = final_merge_df.join(list_df_with_unique_id, "unique_id")
    print("----final_merge_list_df_join----")
    final_merge_list_df_join.show()

    # final_merge_list_df_join.persist(StorageLevel.MEMORY_AND_DISK)

    schema = [f.col(x) for x in final_merge_list_df_join.columns]

    match_df_renamed = match_df.withColumnRenamed("UNIQUE_ID", "UNIQUE_ID_m")
    print("----match_df_renamed----")
    match_df_renamed.show()

    l.log.info("Creating golden_df")

    golden_df = input_df_renamed.join(match_df_renamed, ((f.col("UNIQUE_ID") == f.col("UNIQUE_ID_m")) |
                                                         (f.col("UNIQUE_ID") == f.col("unique_id_matched"))),
                                      "left_outer"). \
        filter(f.col("UNIQUE_ID_m").isNull()).select(schema).union(final_merge_list_df_join.select(schema)). \
        orderBy(f.col("UNIQUE_ID")).withColumn("period", f.concat_ws("-", f.lit(date.today().month),
                                                                     f.lit(date.today().year)))

    golden_df = golden_df.select("UNIQUE_ID").withColumnRenamed("UNIQUE_ID", "UNIQUE_ID_GOLD")

    golden_df_final = input_df_renamed.join(golden_df, f.col("UNIQUE_ID") == f.col("UNIQUE_ID_GOLD")).drop(
        "UNIQUE_ID_GOLD")

    print("----golden_df_final----")
    golden_df_final.show()

    cu.write_to_csv(golden_df_final, gold_path, "overwrite")
    cu.write_to_csv(final_merge_list_df_join, merge_output, "overwrite")

    # Enable below code based on whether it is required to update dimension tables

    # read_dimensions_df(dim_out, match_df3, dim_out_bkp)
