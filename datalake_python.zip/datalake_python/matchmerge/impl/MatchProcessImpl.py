import common.utils.CommonUtils as cu
from common.utils.InitiateSparkSession import get_spark_session
from common.utils import Logging as l
import pyspark.sql.functions as F

spark = get_spark_session()


def perform_match(input_df, rules, p_key, output_path):
    response = ""
    # Execute all ACTIVE match rules
    try:
        print(">>rules: ", rules)
        if rules is not None:
            for each in rules:
                if "ACTIVE" in each:
                    print("-------------------------------each ACTIVE rule-------------------------------\n", each)
                    input_df.createOrReplaceTempView("df1")
                    input_df.createOrReplaceTempView("df2")

                    rule_name = each[0]
                    rule_type = each[3]

                    # condition = " AND ".join(map(lambda x: "soundex(c1." + x[0] + ") = soundex(c2." + x[0] + ")"
                    condition = " AND ".join(map(
                        lambda x: "(soundex(c1." + x[0] + ") = soundex(c2." + x[0] + ")" + " OR levenshtein(c1." + x[
                            0] + ", c2." + x[0] + ") < 5) "
                        if x[1] == "FUZZY" else ("c1." + x[0] + " = c2." + x[0] if x[1] == "EXACT" else None), each[1]))

                    print("-------------------------------condition-------------------------------")
                    print(condition)

                    condition = '(soundex(c1.company_name) = soundex(c2.company_name) OR levenshtein(c1.company_name, c2.company_name) < 5) AND ' \
                                '(soundex(c1.street_address) = soundex(c2.street_address) OR levenshtein(c1.street_address, c2.street_address) < 5) AND ' \
                                'c1.city = c2.city AND c1.state = c2.state'

                    query = "SELECT c1." + p_key + " AS UNIQUE_ID,  c2." + p_key + " AS UNIQUE_ID_MATCHED,'" \
                            + rule_name + "' AS MATCH_RULE, '" + rule_type + "' AS MATCH_TYPE FROM df1 " \
                                                                             "c1 JOIN"" df2 c2 ON " \
                            + condition + " WHERE c1." + p_key + " > c2." + p_key

                    print("-------------------------------query-------------------------------")
                    print(query)

                    l.log.info(query)
                    f_df = spark.sql(query)

                    f_df.show()

                    f_df2 = f_df.groupBy("unique_id").agg(F.min("unique_id_matched").alias("unique_id_matched")). \
                        orderBy("unique_id_matched")

                    f_df3 = f_df2.withColumn("match_rule", F.lit(rule_name)).withColumn("match_type", F.lit(rule_type))

                    cu.write_to_csv(f_df3, output_path, "append")

        return response

    except Exception as e:
        l.log.info(e)
        return response
