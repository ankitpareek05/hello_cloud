from common.utils import CommonUtils as cu
from common.utils.Logging import *
from matchmerge.utils import MatchMergeConstants as mmc
from matchmerge.impl import MergeProcessImpl as mpl
import pyspark.sql.functions as f
import sys


def try_convert(row):
    try:
        return str(row[0]), str(row[1])
    except Exception as e:
        log.exception(e)
        log.error("ERROR: INVALID CONFIGURATION")


def main(args):

    # match_conf_file = args[1]

    log.info("Reading match conf")

    #Read the Match configuration into a dataframe

    match_conf_file = "C:\\Users\\anpareek\\Documents\\SparkWorkSpace\\DataLake_Python\\datalake_python\\configFiles\\MatchConf"

    match_conf_df = cu.read_from_delimited_file(match_conf_file, "false", "=")

    #Convert the dataframe into a key value pair
    match_conf_df.show(100,500)
    print(":: ", match_conf_df.rdd.collect())
    # match_conf_dict = match_conf_df.rdd.map(lambda row: try_convert(row)).collectAsMap()
    match_conf_dict = match_conf_df.rdd.map(lambda row: (str(row[0]), str(row[1]))).collectAsMap()
    print(">>match_conf_dict: ", match_conf_dict)

    log.info("Reading input data frame in the Merge Job")
    input_df = cu.read_from_csv_file(match_conf_dict[mmc.INPUT_PATH], "true")

    #Input dataframe's primary key column to be converted to unique_id and
    #source column to be converted to src_sys_code

    input_df_renamed = input_df.withColumnRenamed(match_conf_dict[mmc.DATA_ROWID_OBJECT], "unique_id").\
        withColumnRenamed(match_conf_dict[mmc.SRC_SYS_CODE], "src_sys_code")

    input_df_renamed = input_df_renamed.select([f.col(c).cast("string") for c in input_df_renamed.columns])
    input_df_renamed.show(10, 500)

    log.info("Reading trust data frame")
    trust_df = cu.read_from_csv_file(match_conf_dict[mmc.TRUST_PATH], "true")

    trust_df.show()

    log.info("Reading match output data frame")
    match_output_df = cu.read_from_csv_file(match_conf_dict[mmc.MATCH_OUTPUT_PATH], "true")

    match_output_df.show()

    log.info("Calling perform_merge")

    mpl.perform_merge(trust_df, match_output_df, input_df_renamed, match_conf_dict)


if __name__ == "__main__":
    main(sys.argv)
