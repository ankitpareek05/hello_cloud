""" Data Profiling
This Module is the Driver Program for Data Profiling.
Data profiling contains twenty generic rules through which
can get the insight of source data.
 @Example: Null, not null etc.
"""
import argparse
from common.utils import GlobalVariables as gv
from common.utils import Logging,CommonConstants,CommonUtils
from common.utils.Logging import log
from common.utils import CommonUtils as cu
from dataprofiling.impl import DataProfilingRuleProcessImpl as dpImpl
import sys


def main(args):

    if len(args) < 5:
        log.error("Invalid number of arguments passed")
        sys.exit(1)

    config_path = args[1]
    file_name = args[2]
    layer_name = args[3]
    source_name = args[4]

    # input_path = r"C:\Users\anpareek\Documents\SparkWorkSpace\Datalake_pythonV1\datalake_python\configFiles\DataProfiling_Config.csv"
    # file_name = "ACCOUNT"
    # layer_name = "BRONZE"
    # source_name = "SFDC"

    gv.layer_name = layer_name.lower()
    log.info("Layer Name: " + gv.layer_name)

    gv.source_name = source_name.lower()
    log.info("Source Name: " + gv.source_name)

    gv.file_name = file_name.lower()
    log.info("File Name: " + gv.file_name)

    log.info("\n############# Data Profiling Driver #############")

    config_data = cu.parse_config_file(config_path, file_name, source_name, layer_name)
    filter_config_dict = dict((k, v) for k, v in config_data.items() if k.startswith(layer_name.lower()))

    bucket_name = gv.root_path
    log.info("Bucket Name: " + bucket_name)

    layer_name_with_action = gv.layer_name + "_source"
    input_key = layer_name_with_action + "_input_details"
    log.info("Reading Input File")

    log.info("Calling read function based on config file parameters")

    source_file_df=CommonUtils.read_input_file(config_data,input_key,bucket_name)

    log.info("Processing with data profiling process ")
    final_df=dpImpl.process_data_profiling_rules(config_data,source_file_df,layer_name_with_action)

    output_key = layer_name_with_action + "_output_details"
    log.info("Key related to output details= "+output_key)

    CommonUtils.write_output_file(final_df, config_data, bucket_name, output_key)

    log.info("Data Profiling process completed")

if __name__ == "__main__":
    main(sys.argv)







