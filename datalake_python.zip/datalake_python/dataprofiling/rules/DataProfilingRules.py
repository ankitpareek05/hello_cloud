from common.utils.InitiateSparkSession import get_spark_session
from dataprofiling.utils import RulesConstants
from pyspark.sql import functions as dffunc
from decimal import *
from pyspark.sql import Row
from common.utils.Logging import log
import sys
import itertools
spark = get_spark_session()

"""
Function to take the list of tupples
and return second element of tuple
"""
def takeSecond(elem):
    return elem[1]

"""
     Get Null Count Details from DataFrame
     :arg
     original DataFrame
     :return
      List of Row containing Data Profiling Result
             #Int = '' is considered as null
             #String = null|NULL is considered as null
"""
def get_null_count_details(inputDf,record_count):

    seq_null=[(RulesConstants.DATAPROFILING_NULL_COUNT,-1)]
    seq_percentage_null=[(RulesConstants.DATAPROFILING_PERCENTAGE_NULL,-1)]
    seq_notnull=[(RulesConstants.DATAPROFILING_NOTNULL_COUNT,-1)]
    seq_percentage_notnull=[(RulesConstants.DATAPROFILING_PERCENTAGE_NOTNULL,-1)]

    columns=zip_with_index(inputDf.columns)

    data_operation=[]
    log.info("Creating SQL expression to get the null/not_noll counts and percentage")
    for cols in columns:

        data_operation.append([((dffunc.sum(dffunc.when(dffunc.isnull(dffunc.col(cols[0])), 1).otherwise(0)) / record_count) * 100).alias("Percentage"+ cols[0]),
                               (dffunc.sum(dffunc.when(dffunc.isnull(dffunc.col(cols[0])), 1).otherwise(0)).alias("count" + cols[0])),
                               (((dffunc.sum(dffunc.when(dffunc.col(cols[0]).isNotNull(), 1).otherwise(0)) / record_count) * 100).alias("Percentage_not" + cols[0])),
                               (dffunc.sum(dffunc.when(dffunc.col(cols[0]).isNotNull(), 1).otherwise(0)).alias("count_not" + cols[0]))])


    log.info("Flatting the SQL expressi and storing into single list")
    joined_list=list(itertools.chain(*data_operation))

    log.info("Expression is= "+str(joined_list))

    log.info("Performing SQL expression on Source data")
    df1= inputDf.agg(*joined_list)

    log.info("Fetching First record and converting into Row")
    data =df1.first()

    for cols in columns:
        is_null = data["count" + cols[0]]
        is_not_null = str(data["count_not" + cols[0]])

        percentage_null = str(round(Decimal(data["Percentage"+ cols[0]]),2)) + "%"
        percentage_not_null = str(round(Decimal(data["Percentage_not" + cols[0]]), 2)) + "%"

        seq_null = seq_null + [(is_null, cols[1])]
        seq_percentage_null = seq_percentage_null + [(percentage_null, cols[1])]
        seq_notnull = seq_notnull + [(is_not_null, cols[1])]
        seq_percentage_notnull = seq_percentage_notnull + [(percentage_not_null, cols[1])]

    print(seq_percentage_null)


    seq_null.sort(key=takeSecond) #[('Null_Count', -1), ('0', 0), ('1', 1), ('1', 2), ('1', 3)]
    log.info("Sorting List as per the Column")
    seq_percentage_null.sort(key=takeSecond)
    seq_notnull.sort(key=takeSecond)
    seq_percentage_notnull.sort(key=takeSecond)

    list_row=[]

    list_row.append([str(x[0]) for x in seq_null])
    list_row.append([str(x[0]) for x in seq_percentage_null])
    list_row.append([str(x[0]) for x in seq_notnull])
    list_row.append( [str(x[0]) for x in seq_percentage_notnull])

    return list_row


"""
Method to tag the columns 
with its index and store it 
in list
:return 
List of tupples

"""
def zip_with_index(col):
    col_with_index=[]
    for i in col:
        col_with_index.append((i,col.index(i)))
    return col_with_index

def filter_numeric_field(val):
    if((str(val[0].dataType) == "IntegerType") or (str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") ):
        return val

def filter_data_type(val):
    if((str(val[0].dataType) == "IntegerType") or (str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType")
    or (str(val[0].dataType) == "BooleanType") or (str(val[0].dataType) == "TimestampType")):
        return val

def filter_all_data_type(val):
    if((str(val[0].dataType) == "IntegerType") or (str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType")
    or (str(val[0].dataType) == "BooleanType") or (str(val[0].dataType) == "TimestampType") or (str(val[0].dataType) == "StringType")):
        return val


def get_distinct_count_detail(inputDf,record_count):

    seq_distinct=[(RulesConstants.DATAPROFILING_DISTINCT_COUNT,-1)]
    seq_percentage_distinct=[(RulesConstants.DATAPROFILING_PERCENTAGE_DISTINCT,-1)]
    zipped_columns = zip_with_index(inputDf.columns)

    inputDf.createOrReplaceTempView("data")

    data_operation=[]
    data_operation1 = []

    for cols in zipped_columns:
        data_operation.append(dffunc.countDistinct(cols[0]).alias("Distinct"+cols[0]))

    for cols in zipped_columns:
        data_operation1.append("count(distinct("+cols[0]+")) as Distinct"+cols[0])


    flatten_list=data_operation1
    sql_expr= "select "+ ",".join(flatten_list)+" from data"
    data1=spark.sql(sql_expr)

    data=data1.first()

    for cols in zipped_columns:
        distinct_count = data["Distinct" + cols[0]]
        distinct_percentage=str(round(Decimal(((int(distinct_count)/record_count)*100)),2))+"%"
        seq_distinct = seq_distinct + [(distinct_count, cols[1])]
        seq_percentage_distinct=seq_percentage_distinct+[(distinct_percentage,cols[1])]


    seq_distinct.sort(key=takeSecond)
    seq_percentage_distinct.sort(key=takeSecond)

    list_row = []
    list_row.append([x[0] for x in seq_distinct])
    list_row.append([x[0] for x in seq_percentage_distinct])


    return list_row

def get_data_type(input_df,record_count):

    seq_data_type=[(RulesConstants.DATAPROFILING_DATATYPE,-1)]
    zipped_columns = zip_with_index(input_df.schema.fields)

    for col in zipped_columns:
        seq_data_type=seq_data_type+[(str(col[0].dataType),col[1])]


    seq_data_type.sort(key=takeSecond)

    list_row = []
    list_row.append([x[0] for x in seq_data_type])

    return list_row


def get_record_count(input_df,record_count):
    
    seq_reocrd_count=[(RulesConstants.DATAPROFILING_RECORD_COUNT,-1)]

    zipped_columns=zip_with_index(input_df.columns)

    for cols in zipped_columns:
        seq_reocrd_count=seq_reocrd_count+[(record_count,cols[1])]

    seq_reocrd_count.sort(key=takeSecond)

    list_row=[]
    list_row.append([x[0] for x in seq_reocrd_count])

    return list_row


def get_blank_count_details(input_df,record_count):

    seq_blank_count=[(RulesConstants.DATAPROFILING_BLANK_COUNT,-1)]
    seq_blank_percentage_count=[(RulesConstants.DATAPROFILING_PERCENTAGE_BLANK,-1)]

    zipped_columns=zip_with_index(input_df.columns)

    data_operation=[]
    for cols in zipped_columns:
        data_operation.append([dffunc.sum(dffunc.when(dffunc.trim(dffunc.col(cols[0]))== dffunc.lit(""),1).otherwise(0)).alias("Blank"+cols[0]),
         ((dffunc.sum(dffunc.when(dffunc.trim(dffunc.col(cols[0]))==dffunc.lit(""),1).otherwise(0)) / record_count)*100).alias("Percentage_Blank"+cols[0])])

    joined_list = list(itertools.chain(*data_operation))

    data=input_df.agg(*joined_list)

    data_first=data.first()

    for cols in zipped_columns:
        is_blank=str(data_first["Blank"+cols[0]])
        is_percentage_blank = str(round(Decimal(data_first["Percentage_Blank" + cols[0]]), 2)) + "%"
        seq_blank_count=seq_blank_count+[(is_blank,cols[1])]
        seq_blank_percentage_count = seq_blank_percentage_count + [(is_percentage_blank, cols[1])]

    seq_blank_count.sort(key=takeSecond)
    seq_blank_percentage_count.sort(key=takeSecond)

    list_row=[]

    list_row.append([x[0] for x in seq_blank_count])
    list_row.append([x[0] for x in seq_blank_percentage_count])
    return list_row



def get_zero_count_details(input_df,record_count):

    seq_zero_count=[(RulesConstants.DATAPROFILING_ZERO_COUNT,-1)]
    seq_percentage_zero=[(RulesConstants.DATAPROFILING_PERCENTAGE_ZERO,-1)]

    zipped_column=zip_with_index(input_df.columns)
    zipped_schema=zip_with_index(input_df.schema.fields)

    filter_zipped_column=list(filter(filter_numeric_field,zipped_schema))

    data_operation=[]

    for val in filter_zipped_column:
        data_operation.append([dffunc.sum(dffunc.when((dffunc.col(val[0].name)== 0) | (dffunc.col(val[0].name) ==0.0), 1).otherwise(0)).alias("Zero"+val[0].name),
                               ((dffunc.sum(dffunc.when((dffunc.col(val[0].name) == 0) | (dffunc.col(val[0].name) == 0.0),1).otherwise(0)) / record_count ) * 100 ).alias("Percentage_zero"+val[0].name)
                               ])


    flatten_list=list(itertools.chain(*data_operation))

    data_first= Row()
    if flatten_list:
        data=input_df.agg(*flatten_list)
        data_first=data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) =="DoubleType") or (str(val[0].dataType) =="IntegerType")  or (str(val[0].dataType) =="LongType")  or (str(val[0].dataType) =="FloatType")) :

            is_zero=str(data_first["Zero"+str(val[0].name)])
            is_percentage_zero = str(round(Decimal(data_first["Percentage_zero"+str(val[0].name)]), 2)) + "%"
            seq_zero_count=seq_zero_count+[(is_zero,val[1])]
            seq_percentage_zero=seq_percentage_zero+[(is_percentage_zero,val[1])]

        else:
            seq_zero_count=seq_zero_count+[(RulesConstants.DATAPROFILING_NOTAPPLICABLE,val[1])]
            seq_percentage_zero = seq_percentage_zero + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]


    seq_zero_count.sort(key=takeSecond)
    seq_percentage_zero.sort(key=takeSecond)

    row_list=[]
    row_list.append([x[0] for x in seq_zero_count])
    row_list.append([x[0] for x in seq_percentage_zero])

    return row_list


def get_max_value(input_df, record_count):
    seq_max_value = [(RulesConstants.DATAPROFILING_MAXIMUM_VALUE, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_data_type, zipped_schema))

    data_operation = []

    for val in filter_zipped_column:
        data_operation.append([dffunc.max(dffunc.col(val[0].name)).alias("Max_Value" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or (
                str(val[0].dataType) == "TimestampType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") or (
                        str(val[0].dataType) == "BooleanType")):

            max_value = str(data_first["Max_Value" + str(val[0].name)])
            seq_max_value = seq_max_value + [(max_value, val[1])]
        else:
            seq_max_value = seq_max_value + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]


    seq_max_value.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_max_value])
    return row_list

def get_min_value(input_df, record_count):
    seq_min_value = [(RulesConstants.DATAPROFILING_MINIMUM_VALUE, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_data_type, zipped_schema))

    data_operation = []

    for val in filter_zipped_column:
        data_operation.append([dffunc.min(dffunc.col(val[0].name)).alias("Min_Value" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or (
                str(val[0].dataType) == "TimestampType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") or (
                        str(val[0].dataType) == "BooleanType")):

            min_value = str(data_first["Min_Value" + str(val[0].name)])
            seq_min_value = seq_min_value + [(min_value, val[1])]
        else:
            seq_min_value = seq_min_value + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]


    seq_min_value.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_min_value])
    return row_list


def get_max_length(input_df, record_count):
    seq_max_length = [(RulesConstants.DATAPROFILING_MAXIMUM_LENGTH, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_all_data_type, zipped_schema))

    data_operation = []

    for val in filter_zipped_column:
        data_operation.append([dffunc.max(dffunc.length(dffunc.col(val[0].name))).alias("Max_Length" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or (
                str(val[0].dataType) == "TimestampType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") or (
                        str(val[0].dataType) == "BooleanType") or (str(val[0].dataType) == "StringType")):

            max_length = str(data_first["Max_Length" + str(val[0].name)])
            if max_length:
                seq_max_length = seq_max_length + [(str(max_length), val[1])]
            elif ((max_length is None) or (len(max_length)==0)):
                seq_max_length = seq_max_length + [("0", val[1])]

        else:
            seq_max_length = seq_max_length + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]

    seq_max_length.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_max_length])
    return row_list


def get_min_length(input_df, record_count):
    seq_min_length = [(RulesConstants.DATAPROFILING_MINIMUM_LENGTH, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_all_data_type, zipped_schema))
    data_operation = []

    for val in filter_zipped_column:
        data_operation.append([dffunc.min(dffunc.length(dffunc.col(val[0].name))).alias("Min_Length" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or (
                str(val[0].dataType) == "TimestampType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") or (
                        str(val[0].dataType) == "BooleanType") or (str(val[0].dataType) == "StringType")):

            min_length = str(data_first["Min_Length" + str(val[0].name)])
            if min_length:
                seq_min_length = seq_min_length + [(str(min_length), val[1])]
            elif ((min_length is None) or (len(min_length)==0)):
                seq_min_length = seq_min_length + [("0", val[1])]

        else:
            seq_min_length = seq_min_length + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]

    seq_min_length.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_min_length])
    return row_list


def get_mean_length(input_df, record_count):
    seq_mean_length = [(RulesConstants.DATAPROFILING_MEAN_LENGTH, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_all_data_type, zipped_schema))
    data_operation = []

    for val in filter_zipped_column:
        data_operation.append([dffunc.avg(dffunc.length(dffunc.col(val[0].name))).alias("Mean_Length" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or (
                str(val[0].dataType) == "TimestampType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") or (
                        str(val[0].dataType) == "BooleanType") or (str(val[0].dataType) == "StringType")):

            mean_length = str(data_first["Mean_Length" + str(val[0].name)])
            if mean_length:
                seq_mean_length = seq_mean_length + [(str(mean_length), val[1])]
            elif ((mean_length is None) or (len(mean_length)==0)):
                seq_mean_length = seq_mean_length + [("0", val[1])]

        else:
            seq_mean_length = seq_mean_length + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]

    seq_mean_length.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_mean_length])
    return row_list


def get_mean_value(input_df, record_count):
    seq_mean_value = [(RulesConstants.DATAPROFILING_MEAN_Value, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_numeric_field, zipped_schema))
    data_operation = []


    for val in filter_zipped_column:
        data_operation.append([dffunc.avg(dffunc.when(dffunc.col(val[0].name).isNull(),0).otherwise(dffunc.col(val[0].name))).alias("Mean_Value" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") ):

            #mean_value = str(data_first["Mean_Value" + str(val[0].name)])
            mean_value = str(round(Decimal(data_first["Mean_Value" + str(val[0].name)]), 2))
            seq_mean_value = seq_mean_value + [(str(mean_value), val[1])]

        else:
            seq_mean_value = seq_mean_value + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]

    seq_mean_value.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_mean_value])
    return row_list


def get_variance(input_df, record_count):
    seq_varience = [(RulesConstants.DATAPROFILING_VARIANCE, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_numeric_field, zipped_schema))

    data_operation = []


    for val in filter_zipped_column:
        data_operation.append([dffunc.variance(dffunc.when(dffunc.col(val[0].name).isNull(),0).otherwise(dffunc.col(val[0].name))).alias("variance" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") ):

            #variance = str(data_first["variance" + str(val[0].name)])
            variance = str(round(Decimal(data_first["variance" + str(val[0].name)]), 2))
            seq_varience = seq_varience + [(str(variance), val[1])]

        else:
            seq_varience = seq_varience + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]

    seq_varience.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_varience])
    return row_list


def get_standard_deviation(input_df, record_count):
    seq_std_dev = [(RulesConstants.DATAPROFILING_STDDEV, -1)]
    zipped_schema = zip_with_index(input_df.schema.fields)

    filter_zipped_column = list(filter(filter_numeric_field, zipped_schema))

    data_operation = []


    for val in filter_zipped_column:
        data_operation.append([dffunc.stddev(dffunc.when(dffunc.col(val[0].name).isNull(),0).otherwise(dffunc.col(val[0].name))).alias("stddev" + val[0].name)])

    flatten_list = list(itertools.chain(*data_operation))

    data_first = Row()
    if flatten_list:
        data = input_df.agg(*flatten_list)
        data_first = data.first()
    else:
        data_first

    for val in zipped_schema:
        if ((str(val[0].dataType) == "DoubleType") or (str(val[0].dataType) == "IntegerType") or
                (str(val[0].dataType) == "LongType") or (str(val[0].dataType) == "FloatType") ):

            #stddev = str(data_first["stddev" + str(val[0].name)])

            stddev = str(round(Decimal(data_first["stddev" + str(val[0].name)]), 2))
            seq_std_dev = seq_std_dev + [(str(stddev), val[1])]

        else:
            seq_std_dev = seq_std_dev + [(RulesConstants.DATAPROFILING_NOTAPPLICABLE, val[1])]


    seq_std_dev.sort(key=takeSecond)
    row_list = []

    row_list.append([x[0] for x in seq_std_dev])
    return row_list