import itertools

from pyspark.sql.types import StructField, StringType, StructType
from common.utils.Logging import log
from common.utils.InitiateSparkSession import get_spark_session
from dataprofiling.utils import RulesConstants as rc
from dataprofiling.rules import DataProfilingRules as dpr
from pyspark import StorageLevel
spark = get_spark_session()
def process_data_profiling_rules(config_data,input_df,layer_name_with_action):

    log.info("Data profiling rules execution started")

    rules=config_data.get(layer_name_with_action+"_rules")

    input_df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    record_count=input_df.count()

    if (rules=="ALL"):
        rules= rc.RULES
        log.info("List of rules that will be called= "+str(rules))
    else:
        rules=rules.split("||")
        log.info("List of rules that will be called= "+str(rules))

    list_row = []
    for rule in rules:
        list_row.append(call_dataprofiling_rules(rule,input_df,record_count))


    log.info("Flatting the Data and storing in required format ")
    combined_data=[]
    for arr in list_row:
        for inner in arr:
            combined_data.append(inner)

    log.info("Creating output file schema")
    summary = [StructField(rc.COL_DATAPROFILING_RULE, StringType(), True)]
    new_schema = list(map(lambda x: StructField(x, StringType(), True), input_df.columns))
    combined_schema = StructType(summary + new_schema)

    final_df = spark.createDataFrame(spark.sparkContext.parallelize(combined_data), combined_schema)
    final_df.show()
    return final_df



def call_dataprofiling_rules(rule_name,input_df,record_count):

    log.info("Rule is being called= "+ rule_name)
    rule_name=rule_name.strip()

    if(rule_name==rc.RULES_BLANK_CHECK):
        return dpr.get_blank_count_details(input_df, record_count)
    elif(rule_name==rc.RULES_DATA_TYPE):
        return dpr.get_data_type(input_df, record_count)
    elif(rule_name==rc.RULES_DISTINCT_VALUE):
        return dpr.get_distinct_count_detail(input_df, record_count)
    elif(rule_name==rc.RULES_MAX_LENGTH):
        return dpr.get_max_length(input_df, record_count)
    elif(rule_name==rc.RULES_MEAN_LENGTH):
        return dpr.get_mean_length(input_df, record_count)
    elif(rule_name==rc.RULES_MEAN_VALUE):
        return dpr.get_mean_value(input_df, record_count)
    elif(rule_name==rc.RULES_MAX_VALUE):
        return dpr.get_max_value(input_df, record_count)
    elif(rule_name==rc.RULES_MIN_VALUE):
        return dpr.get_min_value(input_df, record_count)
    elif(rule_name==rc.RULES_MIN_LENGTH):
        return dpr.get_min_length(input_df, record_count)
    elif(rule_name==rc.RULES_STDDEV):
        return dpr.get_standard_deviation(input_df, record_count)
    elif(rule_name==rc.RULES_VARIANCE):
        return dpr.get_variance(input_df, record_count)
    elif(rule_name==rc.RULES_ZERO_CHECK):
        return dpr.get_zero_count_details(input_df,record_count)
    elif(rule_name==rc.RULES_NULL_CHECK):
         return dpr.get_null_count_details(input_df,record_count)
    elif(rule_name==rc.RULES_RECORD_COUNT):
        return dpr.get_record_count(input_df,record_count)
    else:
        log.info("Rule name is not matched")





