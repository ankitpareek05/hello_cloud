from common.utils import Logging as l, GlobalVariables as gv, CommonUtils as cu
import re
from common.utils.InitiateSparkSession import get_spark_session

spark = get_spark_session()


def create_expr_rule(config_data):
    """
    A function to dynamically create the expression rule
    :param config_data: Dictionary of key-value pair
    :return: List of expression
    """
    rule_config_data = {}
    expr_rule = []
    regex_expr = gv.layer_name + "|_standardization_|_validation_|_cleansing_"

    # Getting all the keys with Cleansing, Validation and Standardization Rule
    for k in config_data.keys():
        if (("_std_" in k) | ("_cln_" in k) | ("_val_" in k)) & ("rule" in k):
            key = re.sub("\\d$", "", re.sub(regex_expr, "", k))
            rule_config_data[key] = config_data.get(k)

    #  Generating List of Expression
    for k in rule_config_data.keys():
        details_map = cu.get_details_map(rule_config_data, k)
        expr = details_map.get("expr", "NA")
        src_col = details_map.get("src_col_name", "NA")
        tgt_col = details_map.get("tgt_col_name", "NA")

        if ")" in k:
            if expr != "NA":
                expr_rule.append(expr)
            else:
                split_key = k.split(")", 1)
                if len(split_key) == 1:
                    a = split_key[0] + "(" + src_col + "))" + " as " + tgt_col
                    expr_rule.append(a)
                else:
                    a = split_key[0] + "(" + src_col + "))" + split_key[1] + " as " + tgt_col
                    expr_rule.append(a)
        else:
            if expr != "NA":
                expr_rule.append(expr)
            else:
                a = k + "(" + src_col + ")" + " as " + tgt_col
                expr_rule.append(a)

    return expr_rule
