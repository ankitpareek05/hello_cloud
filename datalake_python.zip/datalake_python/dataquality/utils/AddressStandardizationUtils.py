from common.utils import Logging as l
import requests
import time


def convert_address_for_url(str1, invalid_chars):
    address = str1
    for invalid_char in invalid_chars:
        if address.find(invalid_char):
            address = address.replace(invalid_char, " ")

    address_parts = address.strip().split(",")
    sb = ""
    for i in range(len(address_parts)):
        child_address = address_parts[i].strip().split(" ")
        if len(child_address) > 1:
            for j in range(len(child_address)):
                sb = sb + str(child_address[j]).strip() + "+"
            sb = sb[:-1]  # Delete training "+"
        else:
            sb = sb + address_parts[i].strip()
        if address_parts[i].strip() != "":
            sb = sb + ",+"
    if len(sb) > 2:
        sb = sb[:-2]
    return str(sb)


def get_suggested_addresses(address, google_api_uri, google_api_key, google_api_delay):
    if address.strip() == "":
        address = ""

    invalid_chars = ["\n", "<", ">", "#", "%", "{", "}", "|", "\\", "^", "[", "]", "`", "~", ";", "/", "?",
                     ":", "@", "&", "=", "+", "$"]
    formatted_address = convert_address_for_url(address, invalid_chars)

    google_api_uri = google_api_uri.format(formatted_address)
    time.sleep(google_api_delay / 100)
    geocode_url = google_api_uri + "&key={}".format(google_api_key)
    address_results = requests.get(geocode_url)
    address_results = address_results.json()  # address_results is dict type

    # if there's no results or an error, return empty results.
    if len(address_results['results']) == 0:
        output = {
            "l_subpremise": None,
            "l_premise": None,
            "l_street_number": None,
            "l_route": None,
            # "l_neighborhood": None,
            "l_locality": None,
            "s_administrative_area_level_2": None,
            "s_administrative_area_level_1": None,
            "s_country": None,
            "l_postal_code": None,
            "l_postal_code_suffix": None,

            "formatted_address": None,
            "partial_match": None,
            "latitude": None,
            "longitude": None,
            "error_message": None,

            # "accuracy": None,
            # "google_place_id": None,
            # "type": None,
            # "postcode": None,
            # "short_name": None,
            # "long_name": None
        }
    else:
        answer = address_results['results'][0]
        output = {
            "l_subpremise": answer['address_components'][0].get('long_name'),
            "l_premise": None,  # "l_premise": answer['address_components'][#].get('long_name'),
            "l_street_number": answer['address_components'][1].get('long_name'),
            "l_route": answer['address_components'][2].get('long_name'),
            # "l_neighborhood": answer['address_components'][3].get('long_name'),
            "l_locality": answer['address_components'][4].get('long_name'),
            "s_administrative_area_level_2": answer['address_components'][5].get('short_name'),
            "s_administrative_area_level_1": answer['address_components'][6].get('short_name'),
            "s_country": answer['address_components'][7].get('short_name'),
            "l_postal_code": answer['address_components'][8].get('long_name'),
            "l_postal_code_suffix": None,  # "l_postal_code_suffix": answer['address_components'][#].get('long_name'),

            "formatted_address": answer.get('formatted_address'),
            "partial_match": answer.get("partial_match"),
            "latitude": answer.get('geometry').get('location').get('lat'),
            "longitude": answer.get('geometry').get('location').get('lng'),
            "error_message": answer.get('error_message'),

            # "accuracy": answer.get('geometry').get('location_type'),
            # "google_place_id": answer.get("place_id"),
            # "type": answer.get('types')[0],
            # "postcode": ",".join([x['long_name'] for x in answer.get('address_components')
            # if 'postal_code' in x.get('types')]),
            # "short_name": answer['address_components'][0].get('short_name'),
            # "long_name": answer['address_components'][0].get('long_name')

        }
    # Append some other details:
    output['status'] = address_results.get('status')
    output = [(K, v) for K, v in output.items()]
    # output is list type
    return output


def get_address_from_google_api_udf(address, google_api_url, google_api_key, google_api_delay):
    formatted_address_list = get_suggested_addresses(address, google_api_url, google_api_key, google_api_delay)
    output = []

    if formatted_address_list == "" or len(formatted_address_list) == 0:
        l.log.info("Formatted Address is NULL")
    else:
        if len(formatted_address_list) > 0:
            for i in range(len(formatted_address_list)):
                output.append(formatted_address_list[i][1])

    return output
