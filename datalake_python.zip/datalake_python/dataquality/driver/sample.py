import argparse
from common.utils import Logging as l
from common.utils import CommonUtils as cu
from common.utils import GlobalVariables as gv
from dataquality.impl import DataQualityRuleProcessImpl as dq
from common.utils.InitiateSparkSession import get_spark_session
import sys

spark = get_spark_session()

name=r"C:\Users\anpareek\Documents\SparkWorkSpace\DataLake_Python\datalake_python\configFiles\DataQuality_Config_Std.csv"
df=cu.read_input_file(name,"true")
df.show()