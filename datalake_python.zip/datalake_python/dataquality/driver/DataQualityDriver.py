""" Data Quality
This Module is the Driver Program for Data Quality.
Data Quality contains Cleansing Rules, Standardization Rules, and Validation Rules.
"""
import sys
from common.utils.Logging import *
from common.utils import CommonUtils as cu
from common.utils import GlobalVariables as gv
from common.utils import CommonConstants as cc
from dataquality.impl import DataQualityRuleProcessImpl as dq


def main(args):
    usage = "Arguments Usage: [Input-config path] [File Name] [Source Name] [Layer Name] [DebugFlag]-<optional><TRUE|FALSE>-Default-'false'"

    if len(args) < 5:
        log.error("Invalid number of arguments passed")
        log.error(usage)
        sys.exit(1)

    config_path = args[1]
    file_name = args[2]
    layer_name = args[3]
    source_name = args[4]

    # Below are the run-time arguments to be deleted
    # config_path = r"C:\Users\bdurgaprasad\aci_American_Century_Investments\pyspark\datalake_python\configFiles\DataQuality_Config_Std.csv"
    # file_name = "ACCOUNT"
    # layer_name = "L0"
    # source_name = "SFDC"

    if len(args) == 6:
        print("Debug Level is set to TRUE: ", args[5])
    else:
        log.info("Debug Level is set to FALSE")
        gv.debug_flag = "false"

    gv.layer_name = layer_name.lower()
    log.info("Layer Name: " + gv.layer_name)

    gv.source_name = source_name.lower()
    log.info("Source Name: " + gv.source_name)

    gv.file_name = file_name.lower()
    log.info("File Name: " + gv.file_name)

    log.info("\n############# Data Quality Driver #############")

    config_data = cu.parse_config_file(config_path, file_name, source_name, layer_name)
    filter_config_dict = dict((k, v) for k, v in config_data.items() if k.startswith(layer_name.lower()))

    bucket_name = gv.root_path
    log.info("Bucket Name: " + bucket_name)

    # layer_name_with_action = gv.layer_name + "_source"
    layer_name_with_action = gv.layer_name + "_" + cc.DATA_QUALITY
    input_key = layer_name_with_action + "_input_details"
    log.info("Reading Input File")

    # Read the File
    df = cu.read_input_file(filter_config_dict, input_key, bucket_name)

    # Calling the Data Quality Rules
    final_df = dq.process_data_quality_rules(df, config_data)

    # Write the File
    output_key = layer_name_with_action + "_output_details"

    try:
        cu.write_output_file(final_df, config_data, bucket_name, output_key)
    except:
        log.info("Error occured while processing DataQuality Rules or while writing the Dataframe")


if __name__ == "__main__":
    main(sys.argv)
