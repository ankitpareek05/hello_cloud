from common.utils import Logging as l, GlobalVariables as gv, CommonUtils as cu
from common.utils.InitiateSparkSession import get_spark_session
from dataquality.udfs import udfRegister
from dataquality.utils.DataQualityUtils import create_expr_rule
from dataquality.utils import AddressStandardizationUtils
from dataquality.udfs import PhoneStandardizationUDF
from pyspark.sql import functions as f
import pyspark.storagelevel as str_lvl
import time
from common.utils import CommonConstants as cc
from pyspark.sql.functions import current_timestamp
from pyspark.sql.types import ArrayType, StringType, MapType

spark = get_spark_session()


def process_data_quality_rules(input_df, config_data):
    """
    A function to Process Data Quality Rule
    :param input_df: Input DataFrame
    :param config_data: Dictionary of key-value pair
    :return: Final DataFrame
    """
    l.log.info("\n########## Data Quality Rule process Engine ##########")

    # Register the UDF
    udfRegister.process_udf_register()

    # Create Dynamic SQL for the rules
    expr_rule_list = create_expr_rule(config_data)
    input_df_column = input_df.columns

    all_columns = input_df_column + expr_rule_list
    expr_rule = "select " + ", ".join(x for x in all_columns) + " from inputDF"
    l.log.info("\nThe Expression is - " + expr_rule)
    input_df.createOrReplaceTempView("inputDF")

    # Uncomment below line when udf register is completed.
    final_df = spark.sql(expr_rule)
    return final_df


def process_address_standardization(input_df, input_config_data):
    layer_name_with_action = gv.layer_name + "_" + cc.ADDRESS_STD
    is_call_to_google_api = input_config_data.get(layer_name_with_action + "_call_to_google_api") or "FALSE"

    # empty dataframe
    std_add_df = ""

    if is_call_to_google_api.lower() != "false":
        l.log.info(
            "Call to Google API parameter set to True in Config file. Hence calling Google API for Standardization")
        google_api_url = input_config_data.get(layer_name_with_action + "_google_api_url") or "NA"
        google_api_key = input_config_data.get(layer_name_with_action + "_google_api_key") or "NA"
        google_api_delay = int(input_config_data.get(layer_name_with_action + "_google_api_delay") or "10")
        concatenate_address_col_details = cu.get_details_map(input_config_data,
                                                             layer_name_with_action + "_concatenate_address_cols")
        src_concatenate_cols = concatenate_address_col_details.get("src_col_name")
        tgt_col_names = concatenate_address_col_details.get("tgt_col_name")
        col_list = src_concatenate_cols.split("#")
        col_list = list(map(lambda x: x.strip(), col_list))
        std_add_df = input_df.withColumn(tgt_col_names, f.concat_ws(" ", *col_list))

        get_address_from_google_api_udf_decl = f.udf(AddressStandardizationUtils.get_address_from_google_api_udf,
                                                     ArrayType(StringType()))

        std_add_df = std_add_df.withColumn("standardize_add",
                                           get_address_from_google_api_udf_decl(std_add_df["concatenate_address"],
                                                                                f.lit(google_api_url),
                                                                                f.lit(google_api_key),
                                                                                f.lit(google_api_delay))) \
            .withColumn("partial_match_std", f.col("standardize_add")[11]) \
            .withColumn("formattedAddress_std", f.col("standardize_add")[10]) \
            .withColumn("status_std", f.col("standardize_add")[15]) \
            .withColumn("error_message_std", f.col("standardize_add")[14]) \
            .withColumn("streetNumber_std", f.col("standardize_add")[2]) \
            .withColumn("route_std", f.col("standardize_add")[3]) \
            .withColumn("locality_std", f.col("standardize_add")[4]) \
            .withColumn("administrative_area_level_2_std", f.col("standardize_add")[5]) \
            .withColumn("administrative_area_level_1_std", f.col("standardize_add")[6]) \
            .withColumn("country_std", f.col("standardize_add")[7]) \
            .withColumn("postal_code_std", f.col("standardize_add")[8]) \
            .withColumn("latitude_std", f.col("standardize_add")[12]) \
            .withColumn("longitude_std", f.col("standardize_add")[13]) \
            .withColumn("sub_premise_std", f.col("standardize_add")[0]) \
            .withColumn("premise_std", f.col("standardize_add")[1]) \
            .withColumn("dl_quality_rating",
                        f.when(f.col("error_message_std") != "", "-1").when(f.col("partial_match_std") == "true",
                                                                            "1").otherwise("2")) \
            .withColumn("dl_process_time", current_timestamp()) \
            .drop(f.col("standardize_add"))

        # std_add_df.persist(str_lvl.MEMORY_AND_DISK_SER_2)

        # print(">>>>>>>>>>final dataframe<<<<<<<<<<<")
        # std_add_df = std_add_df
        # std_add_df.show(30, 500)
        # std_add_df.printSchema()

    return std_add_df


# test code for phone
def process_phone_standardization(input_df, input_config_data):
    layer_name_with_action = gv.layer_name + "_" + cc.PHONE_STD
    is_call_to_google_api = input_config_data.get(layer_name_with_action + "_call_to_google_api") or "FALSE"

    # empty dataframe
    std_phone_df = ""  # empty df

    if is_call_to_google_api.lower() != "false":
        phone_col = str(input_config_data.get(layer_name_with_action + "_phone_col"))
        country_col = str(input_config_data.get(layer_name_with_action + "_country_col"))
        phone_format = str(input_config_data.get(layer_name_with_action + "_phone_format"))
        std_phone_df = input_df.filter(f.length(input_df["country"]) == 2)

        get_phone_number_details_udf = f.udf(PhoneStandardizationUDF.get_phone_number_details,
                                             MapType(StringType(), StringType()))

        std_phone_df = std_phone_df \
            .withColumn("phoneValidity",
                        get_phone_number_details_udf(std_phone_df[phone_col], std_phone_df[country_col],
                                                     f.lit(phone_format))) \
            .withColumn("validity", f.col("phoneValidity")["Valid"]) \
            .withColumn("country_code", f.col("phoneValidity")["countryCode"]) \
            .withColumn("national_number", f.col("phoneValidity")["nationalNumber"]) \
            .withColumn("phone_format", f.col("phoneValidity")["phoneFormat"]) \
            .withColumn("error", f.col("phoneValidity")["error"]) \
            .drop(f.col("phoneValidity"))

    return std_phone_df
