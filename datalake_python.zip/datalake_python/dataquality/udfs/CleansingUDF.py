import re


def cln_upper_case(column):
    """
    Convert to upper case
    :param column: column(String) from dataframe
    :return: column values in upper case
    """
    return column.upper()


def cln_lower_case(column):
    """
    Convert to lower case
    :param column: column(String) from dataframe
    :return: column values in lower case
    """
    return column.lower()


def cln_trim(column):
    """
    Trim the unwanted spaces
    :param column: column from dataframe
    :return:  column values with Trimmed spaces
    """
    return column.strip()


def cln_initial_cap(column):
    """
    Capitalize the first letter of Value
    :param column: column from dataframe
    :return:Capitalize column values
    """
    return column.capitalize()


def cln_split_name(column):
    """
    spilt the firstname ,middlename, surname with "|"
    :param column: column from dataframe
    :return: firstname ,middlename, surname with "|"
    """
    suffixes = ["I", "II", "III", "IV", "V", "SENIOR", "JUNIOR", "JR", "SR", "PHD", "APR", "RPH", "PE", "MD", "DMD",
                "CME", "ESQ", "ESQUIRE", "i", "ii", "iii", "iv", "v", "JR.", "SR.", "PHD.", "LTD.", "APR.", "RPH.",
                "PE.", "MD.", "DMD.", "CME.", "ESQ.", "ESQUIRE.", "INC.", "J.D.", "TECH.", "PUB.", "ORG.", "PVT.",
                "CO.", "2ND", "3RD"]

    column_array = column.strip().split()

    f_name, m_name, l_name, suffix = "", "", "", ""

    if len(column_array) == 0:
        return f_name + "|" + m_name + "|" + l_name + "|" + suffix

    if len(column_array) == 1:
        f_name = column_array[0]
        return f_name + "|" + m_name + "|" + l_name + "|" + suffix

    if len(column_array) == 2:
        f_name = column_array[0]
        l_name = column_array[1]
        return f_name + "|" + m_name + "|" + l_name + "|" + suffix

    if len(column_array) == 3:
        f_name = column_array[0]
        m_name = column_array[1]
        l_name = column_array[2]
        return f_name + "|" + m_name + "|" + l_name + "|" + suffix

    if len(column_array) == 4:
        f_name = column_array[0]
        m_name = column_array[1]
        l_name = column_array[2]
        suffix = column_array[3]
        return f_name + "|" + m_name + "|" + l_name + "|" + suffix


def cln_camel_case(column):
    """
    To convert the value in CamelCase
    :param column: column from dataframe
    :return: Values in CamelCase
    """
    return ' '.join(list(map(lambda x: x.capitalize(), column.lower().split())))


def cln_replace_new_line(column):
    """
    Replace  \n from  value
    :param column: column from dataframe
    :return: value with replaced newline character
    """
    return column.replace("\n", " ")


def cln_remove_lead_zero(column):
    """
    To remove the leading zero from value
    :param column: column from dataframe
    :return: values without leading zeros
    """
    return str(column).lstrip("0")


def cln_add_leading_zero(column):
    """
    Prepend Zero to single digit
    :param column: column from dataframe
    :return: values in double digit
    """
    if len(str(column)) == 1:
        return "0" + str(column)
    else:
        return str(column)


def cln_replace_hypen_underscr_with_space(column):
    """
    Replace hyphen and  underscore with space in value
    :param column: column from dataframe
    :return: values with hypen and underscore replace with space
    """
    return re.sub(r'[-_]+', " ", column)


def cln_replace_slash_with_space(column):
    """
    Replace '/' (Slash) from value
    :param column:column from dataframe
    :return:values with / replaced with space
    """
    return column.replace("/", " ")


def cln_remove_slash(column):
    """
    Remove "/" from value
    :param column: column from dataframe
    :return: values without /
    """
    return re.sub(r'[\/\\]+', "", column)


def cln_replace_period_with_space(column):
    """
    Replace '.' (period) with space from value
    :param column: column from dataframe
    :return: values with space
    """
    return column.replace(".", " ")


def cln_remove_period(column):
    """
    Remove period from values
    :param column: column from dataframe
    :return: values without period
    """
    return column.replace(".", "")


def cln_remove_non_numeric(column):
    """
    Remove all the non-numeric(alphabets and wildcards characters) from value
    :param column: column from dataframe
    :return: numeric values
    """
    return re.sub(r'\D', "", column)


def cln_remove_non_alphabetic(column):
    """
    Remove numeric and wildcard symbols
    :param column: column from dataframe
    :return: string
    """
    return re.sub(r'[^A-Za-z]+', "", column)


def cln_special_char_removal(column):
    """
    Removes all wild card characters
    :param column: column from dataframe
    :return: values with integers and alphabets
    """
    return re.sub('[^A-Za-z0-9]+', "", column)


def cln_add_parenthesis_start_end(column):
    """
    Adding parenthesis at the  start and end of the value
    :param column:column from dataframe
    :return: values with parenthesis
    """
    return "(" + column + ")"


def cln_remove_parenthesis(column):
    """
    Remove parenthesis from value
    :param column:column from dataframe
    :return: values without parenthesis
    """
    return column.replace("(", "").replace(")", "")


def cln_sub_str(column, start_pos, end_pos):
    """
    To perform substring operation on value
    :param column: column from dataframe
    :param start_pos: starting index of column
    :param end_pos: ending index of column
    :return: substring
    """
    return column[start_pos:end_pos]


def cln_concat(first_string, second_string):
    """
    To concatenate input value with any value (concat "Deloitte" with "-" )
    :param first_string: column
    :param second_string: other string to concat with
    :return: combined string
    """
    return first_string+second_string


def cln_concat_any_value(column, sep):
    """
    To concatenate multiple values with specific delimiter
    :param column: column from dataframe
    :param sep: any delimiter
    :return:all values with delimiter seprated
    """
    array = [x for x in column]
    #column_array = column.strip().split()
    #print(column_array)
    return sep.join(array)


def cln_replace_punctuation_with_space(column):
    """
    Replace punctuation with space in values
    :param column: column from dataframe
    :return: values without punctuation
    """
    return re.sub(r'[.!\\?,;:_\-\[\](){}/]+', " ", column)


def cln_remove_punctuation(column):
    """
    Remove punctuation from values
    :param column: column from dataframe
    :return: values without punctuation
    """
    return re.sub(r'[.!\\?,;:_\-\[\](){}/]+', "", column)


def cln_remove_period_paranthesis(column):
    """
    Remove period and parenthesis from values
    :param column: column from dataframe
    :return: values without parenthesis and period
    """
    return re.sub(r'[.()]+', "", column)


































