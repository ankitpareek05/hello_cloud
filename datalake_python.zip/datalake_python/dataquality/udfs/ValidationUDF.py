import re
import datetime


def val_is_numeric(column):
    """
    Numeric value check
    :param column: dataframe column
    :return: "Numeric Value" if string is numeric else "Non-Numeric value"
    """
    if re.match("[0-9]+\\.*[0-9]*", str(column)):
        return "Numeric Value"
    else:
        return "Non-Numeric value"


def val_email_validation(column):
    """
    Validates Email
    :param column: dataframe column
    :return: "Valid Email" if email is valid else "Invalid Email"
    """
    regex = "^[A-Za-z0-9._!%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$"
    if re.match(regex, column):
        return "Valid Email"
    else:
        return "Invalid Email"


def val_url_validation(column):
    """
    Url Validation
    :param column: dataframe column
    :return: "valid URL" if url is valid else "Invalid Email"
    """
    regex = re.compile(
        r'^(?:http|ftp)s?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)

    if re.match(regex, column):
        return "Valid URL"
    else:
        return "Invalid URL"


def val_negative_number(column):
    """
    Checks a negative number
    :param column: dataframe column
    :return: negative, zero or non-negative number
    """
    if int(column) is not None:
        if int(column) < 0:
            return "Negative Number:" + str(column)
        elif int(column) == 0:
            return "Number is zero :" + str(column)
        else:
            return "Positive number :" + str(column)
    else:
        return "Null Value"


def val_positive_number(column):
    """
    checks a positive number
    :param column:dataframe column
    :return: positive, zero, non-positive
    """

    if int(column) is not None:
        if int(column) > 0:
            return "Positive Number:" + str(column)
        elif int(column) == 0:
            return "Number is zero :" + str(column)
        else:
            return "Negative number :" + str(column)
    else:
        return "Null Value"


def val_date_validation(column):
    date_format = '%Y-%m-%d'
    try:
        datetime.datetime.strptime(column, date_format)
        return "Date is Valid"
    except ValueError:
        print("Incorrect data format, should be YYYY-MM-DD")


def val_rule_isnumeric_withexpression(col, expression):
    try:
        if str(col).strip() == "":
            return "null is NaN"
        elif re.match("-{0,1}[0-9]+\\.{0,1}[0-9]*", str(col)):
            out = ""
            if str(expression).startswith("leq"):
                out = float(col) <= float(str(expression).replace("leq", "").strip())
            elif str(expression).startswith("geq"):
                out = float(col) >= float(str(expression).replace("geq", "").strip())
            elif str(expression).startswith("eq"):
                out = float(col) == float(str(expression).replace("eq", "").strip())
            elif str(expression).startswith("lt"):
                out = float(col) < float(str(expression).replace("lt", "").strip())
            elif str(expression).startswith("gt"):
                out = float(col) > float(str(expression).replace("gt", "").strip())
            print(out)
            ret = "Numeric and " + str(expression) + " is " + str(out)
            return ret
        else:
            return "Non-Numeric"
    except ValueError:
        # raise ValueError("Incorrect expression or col")
        print("Incorrect expression or col")


def val_rule_datevalidate(col_value, format1):
    if str(format1).strip() == "yyyy-MM-dd":
        # day_f, month_f, year_f = format.split('-')
        day_f, month_f, year_f = "%Y", "%m", "%d"
        format1 = day_f + "-" + month_f + "-" + year_f
    try:
        datetime.datetime.strptime(col_value, format1)
        return "Valid"
    except ValueError:
        # raise ValueError("Incorrect data format, should be YYYY-MM-DD")
        print("Incorrect data format, should be:", format1)
        return "Invalid"
