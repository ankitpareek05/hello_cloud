import phonenumbers
import phonenumbers.phonenumberutil
from common.utils.Logging import *
from common.utils.InitiateSparkSession import get_spark_session

spark = get_spark_session()


def get_phone_number_details(phone_column, country_column, phone_format):
    """
    Standardize phonenumbers in default format after validation
    :param phone_column: list having phone_number
     :param country_column: country_code
    :param phone_format: Standardize format
    :return: dataframe
    """

    dict_of_data = {"Valid": "False", "countryCode": "NA", "nationalNumber": "NA",
                    "phoneFormat": "NA", "error": "NA"}

    is_valid = ""

    if country_column is not None and len(country_column) == 2:
        phone_parse = phonenumbers.parse(phone_column)
        try:
            is_valid = phonenumbers.is_valid_number(phone_parse)
            dict_of_data["Valid"] = str(is_valid)
        except Exception as e:
            log.error(str(e))
            dict_of_data["Valid"] = str(is_valid)

        try:
            dict_of_data["countryCode"] = str(phone_parse.country_code)
        except Exception as e:
            log.error(str(e))
            dict_of_data["countryCode"] = "0"

        try:
            dict_of_data["nationalNumber"] = str(phone_parse.national_number)
        except Exception as e:
            log.error(str(e))
            dict_of_data["nationalNumber"] = ""

        try:
            if dict_of_data["Valid"].lower() == "true":
                if phone_format.upper() == "NATIONAL":
                    dict_of_data["phoneFormat"] = phonenumbers. \
                        format_number(phone_parse, phonenumbers.PhoneNumberFormat.NATIONAL)
                elif phone_format.upper() == "INTERNATIONAL":
                    dict_of_data["phoneFormat"] = phonenumbers. \
                        format_number(phone_parse, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
                elif phone_format.upper() == "E164":
                    dict_of_data["phoneFormat"] = phonenumbers. \
                        format_number(phone_parse, phonenumbers.PhoneNumberFormat.E164)
                else:
                    dict_of_data["phoneFormat"] = ""
        except Exception as e:
            log.error(str(e))
            dict_of_data["phoneFormat"] = ""

        try:
            dict_of_data["error"] = str(phonenumbers.is_possible_number_with_reason(phone_parse))

        except Exception as e:
            log.error(str(e))
            dict_of_data["error"] = "NOT A VALID NUMBER"

    else:
        dict_of_data = {"Valid": "false", "countryCode": "NA", "nationalNumber": "NA", "phoneFormat": "NA",
                        "error": "Error : Country code should be of length 2"}

    # Append some other details:
    dict_of_data['phone_column'] = phone_column

    return dict_of_data
