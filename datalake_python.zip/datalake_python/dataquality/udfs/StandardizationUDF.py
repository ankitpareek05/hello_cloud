from common.utils.InitiateSparkSession import get_spark_session
from common.utils import CommonUtils as cu
from common.utils import GlobalVariables as gv
from common.utils import CommonConstants
spark = get_spark_session()
sc = spark.sparkContext


gv.lookup_map = cu.read_lookup(CommonConstants.LOOKUP_FILE)


def std_url_http_removal(column):
    """
    Removes http:// and https:// from URLs
    :param column: dataframe column
    :return: values without http:// and https://
    """
    if column.startswith("https://") or column.startswith("http://"):
        return column.replace("https://", "").replace("http://", "")


def std_substitute(column, old_string, new_string):
    """
    Replaces old_string with new_string in column
    :param column: dataframe column
    :param old_string: string to replace
    :param new_string: string to replace with old string
    :return: new values
    """
    return column.replace(old_string, new_string)


def std_currency_code(column):
    return gv.lookup_map.get(column, "NA")





