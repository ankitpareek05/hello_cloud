from common.utils.InitiateSparkSession import get_spark_session
from dataquality.udfs import CleansingUDF, StandardizationUDF, ValidationUDF
spark = get_spark_session()


def process_udf_register():
    spark.udf.register("std_rule_url_http_removal", StandardizationUDF.std_url_http_removal)
    spark.udf.register("std_rule_substitute", StandardizationUDF.std_substitute)
    spark.udf.register("std_rule_currency_code", StandardizationUDF.std_currency_code)

    spark.udf.register("val_rule_is_numeric", ValidationUDF.val_is_numeric)
    spark.udf.register("val_rule_email_validation", ValidationUDF.val_email_validation)
    spark.udf.register("val_rule_url_validation", ValidationUDF.val_url_validation)
    spark.udf.register("val_rule_Negative_Number", ValidationUDF.val_negative_number)
    spark.udf.register("val_rule_Positive_Number", ValidationUDF.val_positive_number)
    spark.udf.register("val_rule_isnumeric_withexpression", ValidationUDF.val_rule_isnumeric_withexpression)
    spark.udf.register("val_rule_datevalidate", ValidationUDF.val_rule_datevalidate)

    spark.udf.register("cln_rule_lower_case", CleansingUDF.cln_lower_case)
    spark.udf.register("cln_rule_upper_case", CleansingUDF.cln_upper_case)
    spark.udf.register("cln_rule_trim_case", CleansingUDF.cln_trim)
    spark.udf.register("cln_rule_initial_cap", CleansingUDF.cln_initial_cap)
    spark.udf.register("cln_rule_split_name", CleansingUDF.cln_split_name)
    spark.udf.register("cln_rule_camel_case", CleansingUDF.cln_camel_case)

    spark.udf.register("cln_rule_replace_newline", CleansingUDF.cln_replace_new_line)
    spark.udf.register("cln_rule_remove_leading_zero", CleansingUDF.cln_remove_lead_zero)
    spark.udf.register("cln_rule_add_leading_zero", CleansingUDF.cln_add_leading_zero)

    spark.udf.register("cln_rule_replace_hyphen_underscore_with_space", CleansingUDF.cln_replace_hypen_underscr_with_space)
    spark.udf.register("cln_rule_replace_slash_with_space", CleansingUDF.cln_replace_slash_with_space)
    spark.udf.register("cln_rule_remove_slash", CleansingUDF.cln_remove_slash)

    spark.udf.register("cln_rule_replace_period_with_space", CleansingUDF.cln_replace_period_with_space)
    spark.udf.register("cln_rule_remove_period", CleansingUDF.cln_remove_period)

    spark.udf.register("cln_rule_remove_non_number", CleansingUDF.cln_remove_non_numeric)
    spark.udf.register("cln_rule_remove_non_alphabetic", CleansingUDF.cln_remove_non_alphabetic)
    spark.udf.register("cln_rule_special_character_removal", CleansingUDF.cln_special_char_removal)

    spark.udf.register("cln_rule_add_parenthesis_start_end", CleansingUDF.cln_add_parenthesis_start_end)
    spark.udf.register("cln_rule_remove_parenthesis", CleansingUDF.cln_remove_parenthesis)

    spark.udf.register("cln_rule_substring", CleansingUDF.cln_sub_str)
    spark.udf.register("cln_rule_concatenate_any_value", CleansingUDF.cln_concat_any_value)
    spark.udf.register("cln_rule_concatenate", CleansingUDF.cln_concat)

    spark.udf.register("cln_rule_punctuation_with_space", CleansingUDF.cln_replace_punctuation_with_space)
    spark.udf.register("cln_rule_remove_punctuation", CleansingUDF.cln_remove_punctuation)
    spark.udf.register("cln_rule_rmv_period_and_parenthesis", CleansingUDF.cln_remove_period_paranthesis)





