import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.SparkSession
import java.util.Date
import org.apache.spark.sql.functions._

import org.apache.spark.sql.SaveMode

import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.functions.when
import scala.math.BigDecimal
import java.text.DecimalFormat

object OM {
  
  def main(args: Array[String]) {
       
  Logger.getLogger("org").setLevel(Level.OFF)
  
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var DateFinal = new ListBuffer[String]()
  var usageList = new ListBuffer[String]()
  var paymentList = new ListBuffer[String]()
  var TenureList = new ListBuffer[String]()
  var DisputeList = new ListBuffer[String]()
  var arpuList = new ListBuffer[String]()
  var serviceOrdersList  = new ListBuffer[String]()
     
   val sparkConf = new SparkConf().setMaster("local[4]").setAppName("hbase sql")
   val sc = new SparkContext(sparkConf)
   val spark1 = SparkSession.builder().config(sc.getConf).getOrCreate()
   val sqlContext = spark1.sqlContext
       
 
    import spark1.implicits._
    
    def f1(number: Double)={ 
      "%.2f".format(number).toDouble
    }
    val udfFunc = udf(f1 _)   
    
     def getCountPercent(df: DataFrame): DataFrame = {
  df.withColumn("SUM", sum("count").over() )
    .withColumn("fraction", col("count") / sum("count").over())
    .withColumn("Percent", col("fraction") * 100 )
    .withColumn("number", udfFunc(col("Percent")))
    .drop("Percent")
    .drop("fraction")
}  
   
 
 
   val headerCSV  = spark1.sqlContext.read.format("CSV").option("header","true").option("delimiter", """|""").load("C:\\Users\\ayushgup\\Downloads\\Header3.csv")

   val columns = headerCSV.columns
  
        
      val data =   spark1.sqlContext.read.format("CSV").option("delimiter", """|""").load("C:/Users/ayushgup/Downloads/home_data_usage_2018122723_1372673.csv").toDF(columns:_*)



   for (coll <- columns.toList) {

      if (coll.contains("Date")) {

        for (datesss <- data.select(coll).collect()) {
          dateList += datesss.toString().slice(1, 8)
       

        }
        
  var dateFinalDF = dateList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)   
            
  for (date <- dateFinalDF.collect()){
     fileList += coll + "," + date
    }

      } else if (coll.contains("Usage")) {
    
    val   r =     data.select(coll).withColumn(coll, when(col(coll) <= 1026 , "<=1gb").when(col(coll) > 1026 && col(coll) < 5130 , "1-5gb")
                  .when(col(coll) > 5130 && col(coll) < 10260 , "5-10gb")
                  .when(col(coll) > 10260 && col(coll) < 20520 , "10-20gb")
                  .when(col(coll) > 20520 , ">20gb")
                  .otherwise(0)).toDF()
        
             for(usagee <-data.select(coll).where(col(coll)<=1026).collect()){        
                  
                
                 
                  usageList += "<=1gb"  
                
            
                 } 
             for(usagee <-data.select(coll).where(col(coll)>1026).where(col(coll)<5130).collect()){        
                  
                
                 
                  usageList += "1-5gb"   
               
            
                 } 
              for(usagee <-data.select(coll).where(col(coll)>5130).where(col(coll)<10260).collect()){        
                  
                
                 
                  usageList += "5-10gb"   
               
            
                 }
              for(usagee <-data.select(coll).where(col(coll)>10260).where(col(coll)<20520).collect()){        
                  
                
                 
                  usageList += "10-20gb"   
               
            
                 }
               for(usagee <-data.select(coll).where(col(coll)>20520).collect()){        
                  
                
                 
                  usageList += ">20gb"   
               
            
                 }

   //    var usageFinalDF = usageList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)    
              var usageFinalDF = r.groupBy(coll).count.transform(getCountPercent)           

       for (u <- usageFinalDF.collect()){
             fileList += coll + "," + u
      }
                         
      } else if (coll.contains("PaymentAmount")) {
                   
              for(usagee <-data.select(coll).where(col(coll)>1700).collect()){        
                  
                
                 
                  paymentList += "1700-1900"  
                
            
                 } 
              for(usagee <-data.select(coll).where(col(coll)>1500).where(col(coll)<1700).collect()){        
                  
                
                 
                  paymentList += "1500-1700"   
               
            
                 } 
                 
              for(usagee <-data.select(coll).where(col(coll)>1700).where(col(coll)<1900).collect()){        
                  
                
                 
                  paymentList += "1700-1900"   
               
            
                 } 
              for(usagee <-data.select(coll).where(col(coll)>1900).where(col(coll)<2000).collect()){        
                  
                
                 
                  paymentList += "1900-2000"   
               
            
                 } 

              for(usagee <-data.select(coll).where(col(coll)>2000).collect()){        
                  
                
                 
                  paymentList += ">2000"   
               
            
                 } 

                 
      var paymentFinalDF = paymentList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)    
                          
      for (u <- paymentFinalDF.collect()){
             fileList += coll + "," + u
      }
                 
       } else if (coll.contains("accountTenure")) {
             
                 for(usagee <-data.select(coll).where(col(coll)>1000000).where(col(coll)<5000000).collect()){        
                  
                
                 
                  TenureList += "1-5m"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>5000000).where(col(coll)<11000000).collect()){        
                  
                
                 
                  TenureList += "5-11m"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1200000).where(col(coll)<23000000).collect()){        
                  
                
                 
                  TenureList += "12-23m"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>2400000).where(col(coll)<35000000).collect()){        
                  
                
                 
                  TenureList += "24-35m"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>3600000).collect()){        
                  
                
                 
                  TenureList += ">36m"   
               
            
                 } 
       var TenureFinalDF = TenureList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)    
                       
       for (u <- TenureFinalDF.collect()){
           fileList += coll + "," + u
      }
      
      } else if (coll.equals("arpu")) {
          
             
                 for(usagee <-data.select(coll).where(col(coll)<1500).collect()){        
                  
                
                 
                  arpuList += "1-1500"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1500).where(col(coll)<1700).collect()){        
                  
                
                 
                  arpuList += "1500-1700"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1700).where(col(coll)<1900).collect()){        
                  
                
                 
                  arpuList += "1700-1900"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1900).where(col(coll)<2000).collect()){        
                  
                
                 
                 arpuList += "1900-2000"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>2000).collect()){        
                  
                
                 
                  arpuList += ">2000"   
               
            
                 } 
      var arpuFinalDF = arpuList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)    
                       

      for (u <-arpuFinalDF.collect()){
          fileList += coll + "," + u
      }
                  
      }  else if (coll.equals("DisputeAmount")|| coll.equals("ticketsAmount")) {
              
                 for(usagee <-data.select(coll).where(col(coll)===0).collect()){        
                  
                
                 
                  DisputeList += "0"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>0).collect()){        
                  
                
                 
                  DisputeList += ">0"  
                
            
                 } 
                 
      var DisputeFinalDF = DisputeList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)    
                       

      for (u <-DisputeFinalDF.collect()){
           fileList += coll + "," + u
      }
                 
                 
       }else if (coll.equals("serviceOrdersCreatedLast90Days")) {
              
                 for(usagee <-data.select(coll).where(col(coll)===0).collect()){        
                  
                
                 
                  serviceOrdersList += "0"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)===1).collect()){        
                  
                
                 
                  serviceOrdersList += "1"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)===2).collect()){        
                  
                
                 
                  serviceOrdersList += "2"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)===3).collect()){        
                  
                
                 
                  serviceOrdersList += "3"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>3).collect()){        
                  
                
                 
                  serviceOrdersList += ">3"  
                
            
                 } 
                 
      var  serviceOrdersFinalDF = serviceOrdersList.toList.toDF(coll).groupBy(coll).count.transform(getCountPercent)    
                       

      for (u <-serviceOrdersFinalDF.collect()){
           fileList += coll + "," + u
      }
       } else {
     

        import spark1.implicits._
          
        val actData1 = data.select(coll).toDF(coll).groupBy(coll).count().transform(getCountPercent) 
        
        
        for (actData <- actData1.collect()) {

          fileList += coll + "," + actData

        }

      }
    }
   
    val f = fileList.toList
    for (flist <- f) {

      println(flist.replaceAll("[\\[\\]]", ""))

    }
    
   
  }

      
  
}