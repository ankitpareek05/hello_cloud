import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.SparkSession
import java.util.Date


import org.apache.spark.sql.SaveMode

import scala.collection.mutable.ListBuffer


object SparkSQL {
  
  var fileList: List[String] = null
  var fileList1 = new ListBuffer[String]()
  case class Person(billingAccountID:Int, subscriberID:String, serviceType:String, dataUsageTotalMB:Double, startTime:String, endTime:String)
  
  var ColumnsList = "billingAccountID "
  ColumnsList = ColumnsList.concat("subscriberID ").concat("serviceType ").concat("dataUsageTotalMB ").concat("startTime ").concat("endTime ")
  def mapper(line:String): Person = {
    val fields = line.split('|')  
    
   
    
    
    val person:Person = Person(fields(0).toInt, fields(1), fields(2), fields(3).toDouble, fields(4).toString(), fields(5).toString())
    return person
  }
  
  def main(args: Array[String]) {
        Logger.getLogger("org").setLevel(Level.OFF)
        
        
        val sparkConf = new SparkConf().setMaster("local[4]").setAppName("hbase sql")
    val sc = new SparkContext(sparkConf)
    val spark1 = SparkSession.builder().config(sc.getConf).getOrCreate()
        
         // Use new SparkSession interface in Spark 2.0
    val spark = SparkSession
      .builder
      .appName("SparkSQL")
      .master("local[*]")
      //.config("spark.sql.warehouse.dir", "file:///C:/temp") // Necessary to work around a Windows bug in Spark 2.0.0; omit if you're not on Windows.
      .getOrCreate()
    
    val lines = spark1.sparkContext.textFile("C:/Users/ayushgup/Downloads/home_data_usage_2018122723_1372672.csv")
 
    val people = lines.map(mapper)
    
    // Infer the schema, and register the DataSet as a table.
    import spark.implicits._
    val schemaPeople = people.toDS
    
    //schemaPeople.printSchema()
    
    schemaPeople.createOrReplaceTempView("people")
    
    // SQL can be run over DataFrames that have been registered as a table
    //val teenagers = spark.sql("SELECT * FROM people WHERE dataUsageTotalMB >= 1300")
    
    //schemaPeople.map(x => (x(0),x(3)))
    
  //val agg = schemaPeople.groupBy("*").count()
  
  //agg.foreach(println)
  //agg.collect().distinct.foreach(println)
  
    for (col <-ColumnsList.split(" ")){
      
      
       if (col.contains("Time"))
    {
    
         
         val ndskad = schemaPeople.select(col).withColumnRenamed("%%Time","NewTime")
         
         
         for ( datesss <- ndskad)
           fileList1 +=  datesss.toString().slice(1, 8)
        
      
            
    }
      //val data = rowData.toDF
   //print(col + " ")
    //schemaPeople.select(col).groupBy(col).count().collect().foreach(println)
      if (col.contains("datausage")) {
        
        val dataUs = "1000"
        for (csv <- schemaPeople.groupBy(col).count())
           
    {
      
      fileList1 += col + "," + csv
      println(fileList1)
      
    }
      }
      else{
    
    for (csv <- schemaPeople.groupBy(col).count())
      
    {
      //if (!col.contains("Time"))
     // fileList = List(col + "," + csv)
      fileList1 += col + "," + csv
   //   println(fileList)
      
      
    }
      }
    }
        val f = fileList1
        for (flist  <- f) {
          println(flist.replaceAll("[\\[\\]]", ""))
        
        }
        
     // fileList.toDF.write.mode(SaveMode.Overwrite).text("C:/Users/sandeeki/Desktop/file/Final.txt")
      
      //fileList1.toDF.write.format("csv").save("C:\\PLDT\\SparkTask\\Export\\Final.csv")
      
      
      //write.mode(SaveMode.Overwrite).csv(outpath)
        
        
    //val results = teenagers.collect()
    
    //results.foreach(println)
    
    spark.stop()
    
  }
  
}
