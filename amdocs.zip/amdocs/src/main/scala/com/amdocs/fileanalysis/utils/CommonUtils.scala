package com.amdocs.fileanalysis.utils

import scala.io.Source

import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType

import com.amdocs.fileanalysis.traits.defaultValue
import com.amdocs.fileanalysis.udf.udfDefination

object CommonUtils extends defaultValue {

  val sqlContext = SparkInitialization.getSqlContext()
  val sparkContext = SparkInitialization.sparkContext
  val sparkSession = SparkInitialization.getSparkSession()

  def readPropertyFile(propertyFilePath: String, headerName: Array[String]) {
    val source = Source.fromFile(propertyFilePath)
    for (line <- source.getLines()) {

      if (line.contains("app_schema_path")) {

        ymlFilePath = line.split(":").last.mkString.trim().toLowerCase()

      } else if (line.contains("data_path")) {
        csvFilePath = line.split(":").last.mkString.trim().toLowerCase()
      } else if (line.contains("delimiter")) {
        delimiter = line.split(":").last.mkString.trim().toLowerCase()
      } else if (line.contains("count_range_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        count_range_column = dummyList.mkString(",")
        println(count_range_column)

        GlobalVariables.setCountRangeColumn(count_range_column)
      } else if (line.contains("usage_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        usage_column = dummyList.mkString(",")
        println(usage_column)
        GlobalVariables.setUsage_Column(usage_column)
      } else if (line.contains("date_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        date_column = dummyList.mkString(",")
        println(date_column)
        GlobalVariables.setDateColumn(date_column)
      } else if (line.contains("millioncount_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        if (!dummyList.isEmpty) {
          millioncount_column = dummyList.mkString(",")
        } else {
          millioncount_column = "NA"
        }

        println(millioncount_column)

        GlobalVariables.setMillionCountColumn(millioncount_column)
      } else if (line.contains("zero_morethanzero_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        if (!dummyList.isEmpty) {
          zero_morethanzero_column = dummyList.mkString(",")
        } else
          zero_morethanzero_column = "NA"
        println(zero_morethanzero_column)
        GlobalVariables.setZeroMoreThanZeroColumn(zero_morethanzero_column)
      } else if (line.contains("serviceOrders_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        if (!dummyList.isEmpty)
          serviceOrders_column = dummyList.mkString(",")
        else
          serviceOrders_column = "NA"
        println(serviceOrders_column)
        GlobalVariables.setServiceOrdersColumn(serviceOrders_column)
      } else if (line.contains("empty_null_column")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        if (!dummyList.isEmpty)
          empty_null_column = dummyList.mkString(",")
        else
          empty_null_column = "NA"
        println(empty_null_column)
        GlobalVariables.setEmptyNullColumn(empty_null_column)
      } else if (line.contains("simple_columns")) {
        val col1 = line.split(":").last.mkString.trim().toLowerCase()
        var dummyList: List[String] = List()
        col1.trim().split(",").map { x =>
          if (headerName.contains(x)) {
            dummyList = dummyList :+ x
          }
        }
        if (!dummyList.isEmpty)
          simple_columns = dummyList.mkString(",")
        else
          simple_columns = "NA"
        println(simple_columns)
        GlobalVariables.setSimpleColumns(simple_columns)

      }
    }

    println(ymlFilePath)
    source.close()

  }

  def readFromDelimiterFile(inputFile: String, delimiter: String, headerVal: String): DataFrame = {

    val mainDF = sparkSession.read
      .option("inferSchema", "false")
      .option("sep", delimiter)
      .option("header", headerVal)
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .csv(inputFile)
    mainDF
  }

  def getDfwithModifiedValue(df: DataFrame): DataFrame = {
    //date_column,count_range_column,usage_column,millioncount_column,zero_morethanzero_column,serviceOrders_column,empty_null_column,simple_columns
    var updatedDf = df
    if (!date_column.trim().equalsIgnoreCase("")) {

      val arrDate = date_column.trim().toLowerCase().split(",")
      arrDate.map { col =>
        updatedDf = updatedDf.withColumn(col, updatedDf(col).substr(1, 7))
      }

    }
    println(count_range_column)
    if (!count_range_column.trim().equalsIgnoreCase("NA")) {
      val arrCountRangeColumn = count_range_column.trim().toLowerCase().split(",")
      arrCountRangeColumn.map { col =>
        updatedDf = updatedDf.withColumn(col, when(updatedDf(col) <= 1500, "1-1500")
          .when(updatedDf(col) > 1500 && updatedDf(col) < 1700, "1500-1700")
          .when(updatedDf(col) > 1700 && updatedDf(col) < 1900, "1700-1900")
          .when(updatedDf(col) > 1900 && updatedDf(col) < 2000, "1900-2000")
          .when(updatedDf(col) > 2000, ">2000")
          .otherwise(0))

      }
    }

    if (!usage_column.trim().toLowerCase().equalsIgnoreCase("NA")) {
      val arrUsageColumn = usage_column.trim().split(",")
      arrUsageColumn.map { col =>
        updatedDf = updatedDf.withColumn(col, when(updatedDf(col) <= 1026, "<=1gb")
          .when(updatedDf(col) > 1026 && updatedDf(col) < 5130, "1-5gb")
          .when(updatedDf(col) > 5130 && updatedDf(col) < 10260, "5-10gb")
          .when(updatedDf(col) > 10260 && updatedDf(col) < 20520, "10-20gb")
          .when(updatedDf(col) > 20520, ">20gb")
          .otherwise(0))

      }
    }
    println(millioncount_column)
    if (!millioncount_column.trim().equalsIgnoreCase("NA")) {
      val arrMillionCount = millioncount_column.trim().toLowerCase().split(",")
      arrMillionCount.map { col =>
        updatedDf = updatedDf.withColumn(col, when(updatedDf(col) <= 1026, "<=1gb")
          .when(updatedDf(col) > 1026 && updatedDf(col) < 5130, "1-5gb")
          .when(updatedDf(col) > 5130 && updatedDf(col) < 10260, "5-10gb")
          .when(updatedDf(col) > 10260 && updatedDf(col) < 20520, "10-20gb")
          .when(updatedDf(col) > 20520, ">20gb")
          .otherwise(0))

      }
    }

    if (!zero_morethanzero_column.trim().equalsIgnoreCase("NA")) {
      val arrZeroColumn = zero_morethanzero_column.trim().toLowerCase().split(",")
      arrZeroColumn.map { col =>
        updatedDf = updatedDf.withColumn(col, when(updatedDf(col) === 0, "0").when(updatedDf(col) > 0, ">0")
          .otherwise(1))
      }
    }

    if (!serviceOrders_column.trim().equalsIgnoreCase("NA")) {
      val arrServiceOrder = serviceOrders_column.trim().toLowerCase().split(",")
      arrServiceOrder.map { col =>
        updatedDf = updatedDf.withColumn(col, when(updatedDf(col) === 0, "0").when(updatedDf(col) === 1, "1")
          .when(updatedDf(col) === 2, "2")
          .when(updatedDf(col) === 3, "3")
          .when(updatedDf(col) > 3, ">3"))

      }
    }

    if (!empty_null_column.trim().equalsIgnoreCase("NA")) {
      val arrNullColumn = empty_null_column.trim().toLowerCase().split(",")
      arrNullColumn.map { col =>
        updatedDf = updatedDf.withColumn(col, when(updatedDf(col) === 0, "empty, n/a").otherwise(1))
      }
    }

    if (!simple_columns.trim().equalsIgnoreCase("NA")) {
      updatedDf
    }

    updatedDf
  }

  def createMeasureNameValue(inputDF: DataFrame, measureNameCol: String, measureValueCol: String, measureCols: List[String]): DataFrame = {

    val tagValueCols = explode(array(
      measureCols.map(c => {
        struct(lit(c).alias(measureNameCol), col(c).cast(StringType).alias(measureValueCol))
      }): _*))
    val measureColumn = measureCols.map(col(_)).toArray
    val initialCols = inputDF.columns.map(col(_)).diff(measureColumn)

    val modifiedDF = inputDF.select(initialCols :+ tagValueCols.alias("_kvs"): _*)
      .select(initialCols ++ Seq(col("_kvs." + measureNameCol), col("_kvs." + measureValueCol)): _*)

    modifiedDF
  }

  def getDfWithFractionValue(df: DataFrame, recordCount: Long): DataFrame = {

    var fractionDf = df
    fractionDf.groupBy("attribute_name", "attribute_Value").count
      .withColumn("recordCount", lit(recordCount))
      .withColumn("percentage", udfDefination.udfFunc(col("count") / col("recordCount") * 100))

  }

}