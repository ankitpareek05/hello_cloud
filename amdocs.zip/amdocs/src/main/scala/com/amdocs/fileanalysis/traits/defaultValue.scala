package com.amdocs.fileanalysis.traits

import scala.collection.mutable.ListBuffer

trait defaultValue {
  var metaData: String = null
  var ColumnsList = new ListBuffer[String]()
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var fileL = new ListBuffer[String]()
  var ymlFilePath: String = ""
  var csvFilePath: String = ""
  var delimiter: String = ""
  var count_range_column: String = ""
  var usage_column: String = ""
  var date_column: String = ""
  var millioncount_column: String = ""
  var zero_morethanzero_column: String = ""
  var serviceOrders_column: String = ""
  var empty_null_column: String = ""
  var simple_columns: String = ""
}