package com.amdocs.fileanalysis.utils

object GlobalVariables {
  private var ymlFilePath: String = ""
  private var csvFilePath: String = ""
  private var delimiter: String = ""
  private var count_range_column: String = ""
  private var usage_column: String = ""
  private var date_column: String = ""
  private var millioncount_column: String = ""
  private var zero_morethanzero_column: String = ""
  private var serviceOrders_column: String = ""
  private var empty_null_column: String = ""
  private var simple_columns: String = ""
  private var repartitionNum = 4

  def getDateColumn = date_column
  def setDateColumn(value: String): Unit = date_column = value

  def getUsage_Column = usage_column
  def setUsage_Column(value: String): Unit = usage_column = value

  def getCountRangeColumn = count_range_column
  def setCountRangeColumn(value: String): Unit = count_range_column = value

  def getMillionCountColumn = millioncount_column
  def setMillionCountColumn(value: String): Unit = millioncount_column = value

  def getServiceOrdersColumn = serviceOrders_column
  def setServiceOrdersColumn(value: String): Unit = serviceOrders_column = value

  def getZeroMoreThanZeroColumn = zero_morethanzero_column
  def setZeroMoreThanZeroColumn(value: String): Unit = zero_morethanzero_column = value

  def getEmptyNullColumn = empty_null_column
  def setEmptyNullColumn(value: String): Unit = empty_null_column = value

  def getSimpleColumns = simple_columns
  def setSimpleColumns(value: String): Unit = simple_columns = value

  //setter
  def setRepartitionNum(value: Int): Unit = {

    repartitionNum = value
  }

  //getter
  def getRepartitionNum = repartitionNum

}