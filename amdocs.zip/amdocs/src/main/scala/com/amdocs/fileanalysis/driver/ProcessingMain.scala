package com.amdocs.fileanalysis.driver

import org.apache.spark.storage.StorageLevel

import com.amdocs.fileanalysis.utils.CommonUtils
import com.amdocs.fileanalysis.utils.GlobalVariables
import org.apache.spark.sql.functions._

object ProcessingMain {

  def main(args: Array[String]) {

    //val propertypath: String=args(1)
    val propertyFilePath: String = "C:\\Adrive\\NuveenInvestment\\workspace\\amdocs\\src\\main\\resources\\properties.yml"
    val sourceFilePath = "C:\\Adrive\\NuveenInvestment\\workspace\\amdocs\\src\\main\\resources\\home_data_usage_2018122723_1372673.csv"
    val headerFilePath = "C:\\Adrive\\NuveenInvestment\\workspace\\amdocs\\src\\main\\resources\\Header5.csv"

    // Reading Source file
    var headerDf = CommonUtils.readFromDelimiterFile(headerFilePath, "|", "true")
    val headerName = headerDf.columns.map(x => x.toLowerCase())
    val repartitionNum = GlobalVariables.getRepartitionNum
    var mainDF = CommonUtils.readFromDelimiterFile(sourceFilePath, "|", "true").toDF(headerName: _*).repartition(repartitionNum)
    val recordCount = mainDF.count()


    // Reading property file and storing into variables
    CommonUtils.readPropertyFile(propertyFilePath, headerName)
    mainDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    //mainDF.show()

    mainDF = CommonUtils.getDfwithModifiedValue(mainDF)
    //mainDF.show(200)
    mainDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    mainDF = CommonUtils.createMeasureNameValue(mainDF, "attribute_name", "attribute_Value", headerName.toList)
    //mainDF.show()
    mainDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    mainDF = CommonUtils.getDfWithFractionValue(mainDF, recordCount)
    //mainDF=mainDF.withColumnRenamed(existingName, newName)
    mainDF.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
   // mainDF.show()

    mainDF = mainDF.withColumnRenamed("attribute_name", "Attribute_Name")
      .withColumnRenamed("attribute_Value", "Attribute_Value")
      .withColumnRenamed("count", "Attribute_Count")
      .withColumnRenamed("recordCount", "Attribute_Total_Count")
      .withColumnRenamed("percentage", "Attribute_Percentage")
      
      mainDF=mainDF.sort(asc("Attribute_Name"))
      mainDF.show()
      //mainDF.orderBy("Attribute_Name")
    

  }
}