package com.amdocs.fileanalysis.utils

object CommonConstant {
  

}