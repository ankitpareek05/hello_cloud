package com.amdocs.fileanalysis.utils

import org.apache.spark.sql.SparkSession
import org.apache.log4j.Level
import org.apache.spark.serializer.KryoSerializer
import org.apache.log4j.Logger
import org.apache.spark.sql.SQLContext
import org.apache.spark.SparkContext

object SparkInitialization {
  
   Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("org.apache.spark.SparkContext").setLevel(Level.WARN)

  private val sparkSession = SparkSession.builder
    .appName("FileAnalysis")
    .config("spark.serializer", classOf[KryoSerializer].getName)
    .config("spark.sql.tungsten.enabled", "true")
    .config("spark.io.compression.codec", "snappy")
    .config("spark.rdd.compress", "true")
    .master("local[*]")
    //    .config("spark.executor.instances", "2")
    //    .config("spark.executor.cores", "1")
    .getOrCreate()
    
    val sqlContext= sparkSession.sqlContext
    
    val sparkContext=sparkSession.sparkContext
    
    sparkContext.getConf.getAll.toList.map(x => {
    println("===> " + x._1 + " -> " + x._2)
  })
  
   val executorNum = sparkContext.getConf.getOption("spark.executor.instances").getOrElse("NA")

  val executorCore = sparkContext.getConf.getOption("spark.executor.cores").getOrElse("NA")


  if (!executorNum.equalsIgnoreCase("NA") && !executorCore.equalsIgnoreCase("NA")) {
    val repartitionNum = (4 * executorNum.toInt * executorCore.toInt).toInt
    GlobalVariables.setRepartitionNum(repartitionNum)
  }

  
  
  
  def getSqlContext():SQLContext={
     return this.sqlContext
   }
   
   def getSparkContext():SparkContext={
     return this.sparkContext
   }
  
   def getSparkSession():SparkSession={
     return this.sparkSession
   }
}