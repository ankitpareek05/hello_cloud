package com.amdocs.fileanalysis.udf
import org.apache.spark.sql.functions._

object udfDefination {
      def f1(number: Double) = {
      "%.3f".format(number).toString()+" %"
    }
    val udfFunc = udf(f1 _)
    
}