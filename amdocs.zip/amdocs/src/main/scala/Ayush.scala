import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.SparkSession
import java.util.Date
import org.apache.spark.sql.functions._

import org.apache.spark.sql.SaveMode

import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.functions.when
import scala.math.BigDecimal
import java.text.DecimalFormat

object Ayush {
  
  def main(args: Array[String]) {
        Logger.getLogger("org").setLevel(Level.OFF)
  
       
  
  
 
  // var ColumnsList = new ListBuffer[String]()
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var DateFinal = new ListBuffer[String]()
  var DateColumn: String = ""
  var UsageColumn: String = ""
   var usageList = new ListBuffer[String]()
    var PaymentColumn: String = ""
   var paymentList = new ListBuffer[String]()
   var actualData = new ListBuffer[String]()
  var ccl = new ListBuffer[String]()

        
         val sparkConf = new SparkConf().setMaster("local[4]").setAppName("hbase sql")
    val sc = new SparkContext(sparkConf)
    val spark1 = SparkSession.builder().config(sc.getConf).getOrCreate()
        val sqlContext = spark1.sqlContext
       
 
    import spark1.implicits._
 
 
  val headerCSV  = spark1.sqlContext.read.format("CSV").option("header","true").option("delimiter", """|""").load("C:\\Users\\ayushgup\\Downloads\\Header3.csv")

  val ColumnsList = headerCSV.columns
  
        
      val data =   spark1.sqlContext.read.format("CSV").option("delimiter", """|""").load("C:/Users/ayushgup/Downloads/home_data_usage_2018122723_1372673.csv").toDF(ColumnsList:_*)

 
   for (coll <- ColumnsList) {

      if (coll.contains("Date")) {

        DateColumn = coll
         ccl += DateColumn
        for (datesss <- data.select(coll).collect()) {
          dateList += datesss.toString().slice(1, 8)
          

        }

      } else if (coll.contains("Usage")) {

        UsageColumn = coll
           ccl += UsageColumn
             
                 for(usagee <-data.select(coll).where(col(coll)<=1000).collect()){        
                  
                
                 
                  usageList += "<=1gb"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1000).where(col(coll)<5000).collect()){        
                  
                
                 
                  usageList += "1-5gb"   
               
            
                 } 
                 
      
      } else if (coll.contains("PaymentAmount")) {
                 PaymentColumn = coll
           ccl += PaymentColumn
             
                 for(usagee <-data.select(coll).where(col(coll)>1700).collect()){        
                  
                
                 
                  paymentList += "1700-1900"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1500).where(col(coll)<1700).collect()){        
                  
                
                 
                  paymentList += "1500-1700"   
               
            
                 } 
       
      } else {
       

        import spark1.implicits._
        
        var actaulDataDf = data.select(coll).toDF(coll)
     ccl += coll
        for (actData <- actaulDataDf.collect()) {

          fileList += "" + actData

        }

      }
    }

    val dateFinal = dateList.toList
    val usageFinal = usageList.toList
    val paymentFinal = paymentList.toList
    
    import spark1.implicits._
   
   def f1(number: Double)={ 
      "%.2f".format(number).toDouble
    }
val udfFunc = udf(f1 _)

   
    var dateFinalDF = dateFinal.toDF(DateColumn).groupBy(DateColumn).count()
    for (date <- dateFinalDF.collect()){
      fileList += "" + date
      }

     var usageFinalDF = usageFinal.toDF(UsageColumn).groupBy(UsageColumn).count()
     for (usage <- usageFinalDF.collect()){
      fileList += "" + usage
      }
     
     var paymentFinalDF = paymentFinal.toDF(PaymentColumn).groupBy(PaymentColumn).count()
     for (payment <- paymentFinalDF.collect()){
      fileList += "" + payment
      } 
  
    println("Final list is getting printed")
   
    val f = fileList.toList
    for (colum <- ColumnsList)
    {
     var piio = f.toDF(colum).groupBy(colum).count().withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).drop("fraction")
    
     for (dsgad <- piio.collect())
     
     actualData += colum + "," + dsgad
    }
    
     for (flist <- actualData.toList) {

      println(flist.replaceAll("[\\[\\]]", ""))

    }
    

  }

    

  
}

