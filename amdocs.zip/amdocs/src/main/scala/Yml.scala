import scala.io.Source
import org.apache.spark._
import org.apache.spark.sql.hive.HiveContext
import scala.util.control.Breaks._
import org.apache.log4j._
import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import scala.collection.mutable.ArrayBuffer

import org.apache.spark.sql.functions.when
import scala.math.BigDecimal

import org.apache.spark.SparkContext._
import org.apache.spark.sql._

import java.util.Date
import org.apache.spark.Partitioner._
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.{DataFrame, Row, SQLContext, DataFrameReader}
import java.sql.{Connection, DriverManager, ResultSet, Timestamp}
import scala.collection._
import org.apache.spark.sql.functions.when

trait init {
  var metaData: String = null
  var ColumnsList = new ListBuffer[String]()
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var fileL = new ListBuffer[String]()
  var ymlFilePath: String = ""
  var csvFilePath: String = ""
  var delimiter: String = ""
  var count_range_column: String = ""
  var usage_column: String = ""
  var date_column: String = ""
  var millioncount_column: String = ""
  var zero_morethanzero_column: String = ""
  var serviceOrders_column: String = ""
  var empty_null_column: String = ""
  var simple_columns: String = ""
}

object Yml extends init {

  
  def main(args: Array[String]) {

    val sparkConf = new SparkConf().setAppName("HiveStore")  //.set("spark.dynamicAllocation.enabled","true").set("SPARK_EXECUTOR_MEMORY", "3g")
    val sc = new SparkContext(sparkConf)
    val spark1 = SparkSession.builder().config(sc.getConf).enableHiveSupport().getOrCreate()

    import spark1.implicits._

    def f1(number: Double) = {
      "%.2f".format(number).toDouble
    }
    val udfFunc = udf(f1 _)

    def getCountPercent(df: DataFrame): DataFrame = {
      df.withColumn("SUM", sum("count").over())
        .withColumn("fraction", col("count") / sum("count").over())
        .withColumn("Percent", col("fraction") * 100)
        .withColumn("number", udfFunc(col("Percent")))
        .drop("Percent")
        .drop("fraction")
    }
    
     def occurenceCount(df: DataFrame,column: String)    
    {
      
     var usageFinalDF = df.groupBy(column).count.transform(getCountPercent)           

       for (value <- usageFinalDF.collect()){
             fileList += column + "~" + value.mkString("~")
      }
    }

    Logger.getLogger("org").setLevel(Level.OFF)
   
    

    val column: String = null
    val dataType: String = null

    val propertypath: String = "/var/tmp/spark/properties.yml"

   

    getProperty(propertypath)
    getMetaData(ymlFilePath)
    
    var fileName = csvFilePath.split("/").last
    var tableName = fileName.split(".csv").mkString

    
    import spark1.implicits._
    import spark1.sql
    
    //Creating a Hive External Table
    Logger.getLogger("org").info("Performing query : DROP TABLE IF EXISTS pontis_analyst." + tableName )
    sql("DROP TABLE IF EXISTS pontis_analyst." + tableName)
    println("Performing query :CREATE EXTERNAL TABLE IF NOT EXISTS pontis_analyst." + tableName + " (" + metaData + ") ROW FORMAT DELIMITED FIELDS TERMINATED BY '|' LOCATION '/user/bdauser/hiveValidation/" + tableName + "'" )
    sql("CREATE EXTERNAL TABLE IF NOT EXISTS pontis_analyst." + tableName + " (" + metaData + ") ROW FORMAT DELIMITED FIELDS TERMINATED BY '" + delimiter + "' LOCATION '/user/bdauser/hiveValidation/" + tableName + "'")
    println("Performing query :LOAD DATA LOCAL INPATH '" + csvFilePath + "' OVERWRITE INTO TABLE pontis_analyst." + tableName)
    sql("LOAD DATA LOCAL INPATH '" + csvFilePath + "' OVERWRITE INTO TABLE pontis_analyst." + tableName)
    println("data loaded")

    val rowData = sql("select * from pontis_analyst." + tableName)
     println("rowdata created" )
     import org.apache.spark.storage.StorageLevel._
    val data = rowData.toDF
     println("data created..")
    for (coll <- ColumnsList.toList) {
    println("inside for loop")
      if (date_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {
         println("date condition checked..")
        for (datesss <- data.select(coll).collect()) {
          dateList += datesss.toString().slice(1, 8)

        }

        var dateFinalDF = dateList.toList.toDF(coll)
        
        occurenceCount(dateFinalDF,coll)
        
      } else if (usage_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

        var condition = data.select(coll).withColumn(coll, when(col(coll) <= 1026, "<=1gb").when(col(coll) > 1026 && col(coll) < 5130, "1-5gb")
          .when(col(coll) > 5130 && col(coll) < 10260, "5-10gb")
          .when(col(coll) > 10260 && col(coll) < 20520, "10-20gb")
          .when(col(coll) > 20520, ">20gb")
          .otherwise(0)).toDF(coll)
         
          occurenceCount(condition,coll)

      } else if (count_range_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

        var condition = data.select(coll).withColumn(coll, when(col(coll) <= 1500, "1-1500").when(col(coll) > 1500 && col(coll) < 1700, "1500-1700")
          .when(col(coll) > 1700 && col(coll) < 1900, "1700-1900")
          .when(col(coll) > 1900 && col(coll) < 2000, "1900-2000")
          .when(col(coll) > 2000, ">2000")
          .otherwise(0)).toDF(coll)

        occurenceCount(condition,coll)

      } else if (millioncount_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

        var condition = data.select(coll).withColumn(coll, when(col(coll) > 1000000 && col(coll) < 5000000, "1-5m").when(col(coll) > 5000000 && col(coll) < 11000000, "5-11m")
          .when(col(coll) > 12000000 && col(coll) < 23000000, "12-23m")
          .when(col(coll) > 24000000 && col(coll) < 35000000, "24-35m")
          .when(col(coll) > 36000000, ">36m")
          .otherwise(0)).toDF(coll)

       occurenceCount(condition,coll)

      } else if (zero_morethanzero_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

        var condition = data.select(coll).withColumn(coll, when(col(coll) === 0, "0").when(col(coll) > 0, ">0")
          .otherwise(1)).toDF(coll)

       occurenceCount(condition,coll)

      } else if (serviceOrders_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

        var condition = data.select(coll).withColumn(coll, when(col(coll) === 0, "0").when(col(coll) === 1, "1")
          .when(col(coll) === 2, "2")
          .when(col(coll) === 3, "3")
          .when(col(coll) > 3, ">3"))
          .toDF(coll)

       occurenceCount(condition,coll)
      } else if (empty_null_column.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

        var condition = data.select(coll).withColumn(coll, when(col(coll) === 0, "empty, n/a").otherwise(1)).toDF(coll)

       occurenceCount(condition,coll)
      } else if (simple_columns.toLowerCase().trim().split(",").contains(coll.toLowerCase())) {

       val actData1 = data.select(coll).toDF(coll)
        
        occurenceCount(actData1,coll)

      } 
    }
    
    var finalList = fileList.toList
     println("loading calculated data into final list ")
    for (flist <- finalList) {

      fileL += flist.replaceAll("[\\[\\]]", "")

    }
    //Creating the Final List into a DataFrame
    
     println("Created the Final List ")
     println("creating DF")
   var finall = fileL.toDF()
   
   println("now DF is ready")
    var FinalDF: DataFrame = finall.selectExpr("split(value, '~')[0] as Attribute_Name", "split(value, '~')[1] as Attribute_Value","split(value, '~')[2] as Attribute_Count","split(value, '~')[3] as Attribute_Total_Count","split(value, '~')[4] as Attribute_Percentage");
 
//inserting data into Hive Distributed table
     Logger.getLogger("org").info("Performing query : inserting data into Hive Distributed table :- CREATE EXTERNAL TABLE IF NOT EXISTS pontis_analyst." + tableName + "_Distribution LOCATION '/user/bdauser/hiveValidation/" + tableName + "_Distribution' as select * from mytempTable")
   FinalDF.createOrReplaceTempView("mytempTable")

   println("View is created")
   
   sql("DROP TABLE IF EXISTS pontis_analyst." + tableName + "_Distribution")
   sql("CREATE EXTERNAL TABLE IF NOT EXISTS pontis_analyst." + tableName + "_Distribution LOCATION '/user/bdauser/hiveValidation/" + tableName + "_Distribution' as select * from mytempTable")
   
   sql("DROP table mytempTable")
//Completed inserting data into HIVE 
   spark1.stop()
  
  }

   
  
  //Get metaData from application.yml file
   
  
  def getMetaData(ymlFilePath: String) {
     Logger.getLogger("org").info("Get metaData from application.yml file")
    val source = Source.fromFile(ymlFilePath)

    breakable {
      for (line <- source.getLines()) {

        if ((line.contains("- name:")) && ((line.split(":").last.mkString == " fileName") || (line.split(":").last.mkString == " fileProperties") || (line.split(":").last.mkString == " filePropertiesHSUC") || (line.split(":").last.mkString == " filePropertiesMonthlyProf") || (line.split(":").last.mkString == " filePropertiesHomeProduct") || (line.split(":").last.mkString == " filePropertiesBillingSub")))
          break

        else {
          if (line.contains("- name:")) {

            var column = line.split(":").last.mkString
            ColumnsList += column.trim()

            if (metaData != null) {
              metaData = metaData.concat(",")
              metaData = metaData.concat(column + " ")

            } else {
              metaData = column

            }
            metaData = metaData.concat(" ")
          } else if (line.contains("type:")) {
            val dataType = line.split(":").last.mkString
            metaData = metaData.concat(dataType)
          }
        }
      }

    }
//Completed fetching metaData from application.yml file
     Logger.getLogger("org").info("Completed fetching metaData from application.yml file")
    
    source.close()

  }
  
   //Get metaData from application.yml file
  def getProperty(propertyFilePath: String) {
    val source = Source.fromFile(propertyFilePath)

    for (line <- source.getLines()) {

      if (line.contains("app_schema_path")) {

        ymlFilePath = line.split(":").last.mkString.trim()

      } else if (line.contains("data_path")) {
        csvFilePath = line.split(":").last.mkString.trim()
      } else if (line.contains("delimiter")) {
        delimiter = line.split(":").last.mkString.trim()
      } else if (line.contains("count_range_column")) {
        count_range_column = line.split(":").last.mkString.trim()
      } else if (line.contains("usage_column")) {
        usage_column = line.split(":").last.mkString.trim()
      } else if (line.contains("date_column")) {
        date_column = line.split(":").last.mkString.trim()
      } else if (line.contains("millioncount_column")) {
        millioncount_column = line.split(":").last.mkString.trim()
      } else if (line.contains("zero_morethanzero_column")) {
        zero_morethanzero_column = line.split(":").last.mkString.trim()
      } else if (line.contains("serviceOrders_column")) {
        serviceOrders_column = line.split(":").last.mkString.trim()
      } else if (line.contains("empty_null_column")) {
        empty_null_column = line.split(":").last.mkString.trim()
      } else if (line.contains("simple_columns")) {
        simple_columns = line.split(":").last.mkString.trim()
      } 
    }

    source.close()

  }
}
