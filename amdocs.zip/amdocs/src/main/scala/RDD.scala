
import scala.io.Source
import org.apache.spark._
import org.apache.spark.sql.hive.HiveContext
import scala.util.control.Breaks._
import org.apache.log4j._
import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.SparkSession



trait init2 {
  var metaData: String = null
  var ColumnsList = new ListBuffer[String]()
  var fileList  = new ListBuffer[String]()
  var dateList= new ListBuffer[String]()
  var DateColumn: String = null

}

object RDD extends init2 {
  
  
  val spark: SparkSession =  SparkSession.builder().getOrCreate()

  //main method for entry point
  def main(args: Array[String]) {
    
    Logger.getLogger("org").setLevel(Level.OFF)  

    val column: String = null
    val dataType: String = null

    val ymlFilePath: String = args(0)
    val csvFilePath: String = args(1)
    //println(csvFilePath)
    var fileName = csvFilePath.split("/").last
   var tableName = fileName.split(".csv").mkString
   //println(tableName.mkString)
   // fileName.foreach(println(_))
   
  

    getMetaData(ymlFilePath)

    // Create a Sql context with
    val sc = new SparkContext("local[*]", "HiveStore")

    // Read each line of my book into an RDD
    val sqlContext = new HiveContext(sc)

    //print("CREATE TABLE IF NOT EXISTS FileLoad (" + metaData + ") stored as orc tblproperties (\"orc.compress\"=\"NONE\")")
    //print("LOAD DATA LOCAL INPATH '" + csvFilePath + "' INTO TABLE FileLoad")
    sqlContext.sql("DROP TABLE IF EXISTS pontis_analyst." + tableName)
    sqlContext.sql("CREATE EXTERNAL TABLE IF NOT EXISTS pontis_analyst." + tableName + " (" + metaData + ") ROW FORMAT DELIMITED FIELDS TERMINATED BY '|' LOCATION '/user/bdauser/hiveValidation/" + tableName + "'")
    sqlContext.sql("LOAD DATA LOCAL INPATH '" + csvFilePath + "' OVERWRITE INTO TABLE pontis_analyst." + tableName)
    
    //println("Data loaded into table #########################################################################################")
    val rowData = sqlContext.sql("select * from pontis_analyst." + tableName)
    
    //println("Data fetched from table #########################################################################################")
    val data = rowData.toDF
    
//data.columns
    
  /*  for (rowData <- data){
         //println(rowData)
         //println(rowData.getClass)
         
         for (data <- rowData.toSeq)
         {
           //println(data)
         //println(data.getClass)
         
        
           
         }
         
         
    }*/
  
    
    //println("Data converted into DS #########################################################################################")
    //val DS = ColumnsList.split(" ").toList
    
    //DS.foreach(print)
    
  for (col <- ColumnsList.toList){
    
    //println("Entered into for loop #########################################################################################")
    
    if (col.contains("Date"))
    {
      
     
      val dateVal = data.select(col)
      
      for ( datesss <- dateVal)
        
      {
         dateList += datesss.toString().slice(1, 8)
    
      }
            
    }
    else if (col.contains("Usage"))
        {
            
              //var usage = data.select(col).filter("col < 10000")
              //println(usage)
          
        }
    else
    {
    
   for ( actData <- data.groupBy(col).count())
       
     {
      
      fileList += col + "," + actData
      //println(fileList)
    }
   
    }
  }
      val dateFinal = dateList.toList.toSeq
     import spark.implicits._
     
     var dateFinalDF = dateFinal.toDF(DateColumn)
     
     for ( actData <- dateFinalDF.groupBy(DateColumn).count())
       
     {
      
      fileList += DateColumn + "," + actData
      println(fileList)
    }
     
    
     val f = fileList.toList
        for (flist  <- f) {
        
         println(flist.replaceAll("[\\[\\]]", ""))
        
        }
    
    
      }

  //Get metaData from application.yml file
  def getMetaData(ymlFilePath: String) {
    val source = Source.fromFile(ymlFilePath)

    breakable {
      for (line <- source.getLines()) {

        if ((line.contains("- name:")) && ((line.split(":").last.mkString == " fileName") || (line.split(":").last.mkString == " fileProperties") || (line.split(":").last.mkString == " filePropertiesHSUC") || (line.split(":").last.mkString == " filePropertiesMonthlyProf") || (line.split(":").last.mkString == " filePropertiesHomeProduct") || (line.split(":").last.mkString == " filePropertiesBillingSub")))
          break

        else {
          if (line.contains("- name:")) {

            var column = line.split(":").last.mkString
            ColumnsList += column.trim()
            

            if (metaData != null ) {
              metaData = metaData.concat(",")
              metaData = metaData.concat(column + " ")
              
              
            } else {
              metaData = column
             
            }
            metaData = metaData.concat(" ")
          } else if (line.contains("type:")) {
            val dataType = line.split(":").last.mkString
            metaData = metaData.concat(dataType)
          }
        }
      }
      
    }
//print(metaData)
    //println(ColumnsList)
    //println(ColumnsList.getClass)
     println(fileList)
     
   
    source.close()
    
   
     
        
  }

}