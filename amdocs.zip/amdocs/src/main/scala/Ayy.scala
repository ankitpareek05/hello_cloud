import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.SparkSession
import java.util.Date
import org.apache.avro.Schema 
import org.apache.spark.sql.SaveMode

object Ayy extends App {

  val Spark = SparkSession.builder().appName("local[*]").getOrCreate()
  
  val sparkContext = Spark.sparkContext
  
  val sqlContext = Spark.sqlContext
  
  val df = Spark.sqlContext.read.json("C:/Users/ayushgup/Downloads/DB-_CDR06_b7b_41c262616b_4de3.json")

df.write.format("com.databricks.spark.avro").save("C:/Users/ayushgup/Downloads/DB.avro")
  
}