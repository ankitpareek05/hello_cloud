import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.SparkSession
import java.util.Date
import org.apache.spark.sql.functions._

import org.apache.spark.sql.SaveMode

import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.functions.when

object Ayush257 {
  
  def main(args: Array[String]) {
        Logger.getLogger("org").setLevel(Level.OFF)
  
       
  
  
 
   var ColumnsList = new ListBuffer[String]()
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var DateFinal = new ListBuffer[String]()
  var DateColumn: String = ""
  var UsageColumn: String = ""
   var usageList = new ListBuffer[String]()
  // var usageFinalDF =new ListBuffer[String]()

        
         val sparkConf = new SparkConf().setMaster("local[4]").setAppName("hbase sql")
    val sc = new SparkContext(sparkConf)
    val spark1 = SparkSession.builder().config(sc.getConf).getOrCreate()
        val sqlContext = spark1.sqlContext
       
  /*  val spark = SparkSession
      .builder
      .appName("SparkSQL")
      .master("local[*]")
      .enableHiveSupport()
      .getOrCreate() */
    import spark1.implicits._
  //  val lines = spark1.sparkContext.textFile("C:/Users/ayushgup/Downloads/home_data_usage_2018122723_1372672.csv").map(lines=>lines.split("""\|""")).toDF()  //.toString()
  //   val header = spark1.sparkContext.textFile("C:\\Users\\ayushgup\\Downloads\\Header.csv").map(lin=>lin.split("""\|""")).toDF()   //.toString()
 
  val headerCSV  = spark1.sqlContext.read.format("CSV").option("header","true").option("delimiter", """|""").load("C:\\Users\\ayushgup\\Downloads\\Header.csv")

  val columns = headerCSV.columns
  
        
      val data =   spark1.sqlContext.read.format("CSV").option("delimiter", """|""").load("C:/Users/ayushgup/Downloads/home_data_usage_2018122723_1372672.csv").toDF(columns:_*)
  
 // data.show()
  
 // data.select("startTime").show()
 for (coll <- columns.toList) {

      if (coll.contains("Time")) {

        DateColumn = coll

        for (datesss <- data.select(coll).collect()) {
          dateList += datesss.toString().slice(1, 8)
        //  println("Datelist as string" + dateList.toList.toString())

        }

      } else if (coll.contains("Usage")) {
                 UsageColumn = coll
                 data.select(coll).where(col(coll)<=1000)//.groupBy().count().toDF(UsageColumn).show()  //.withColumn("SUM", sum("count").over()  ).show()
             //    data.select(coll).where(col(coll)>1000).where(col(coll)<5000)     //.groupBy().count().show()
                 for(usagee <-data.select(coll).where(col(coll)<=1000).collect()){        //data.select(coll).collect()){
                  
                
                 
                  usageList += "<=1gb"  //.where(col(coll)>1000).groupBy(coll).count().withColumn("SUM", sum("count").over()  )
                //  println(usageList.toList)
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1000).where(col(coll)<5000).collect()){        
                  
                
                 
                  usageList += "1-5gb"   //usagee + "," +"1-5gb"  
                //  println(usageList.toList)
            
                 } 
                 
           //   println(usageList.toList)   
   //     println("usagejksfsdfsifhs f sfhshfhfhfiehfiwehfio")

      } else {
      //  println("Final elsebjbbvvivivhhiff i")

        import spark1.implicits._
          
        val actData1 = data.select(coll).toDF(coll).groupBy(coll).count().withColumn("SUM", sum("count").over()  ).withColumn("fraction1", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).drop("fraction1")
        
        
        for (actData <- actData1.collect()) {

          fileList += coll + "," + actData

        }

      }
    }

    val dateFinal = dateList.toList
    val usageFinal = usageList.toList
 
    import spark1.implicits._

    var dateFinalDF = dateFinal.toDF(DateColumn).groupBy(DateColumn).count  //.agg(sum("count").alias("count"))
 .withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).drop("fraction")  //.show()          //.count()
   // dateFinalDF.show()
   
var usageFinalDF = usageFinal.toDF(UsageColumn).groupBy(UsageColumn).count   //.where(col(UsageColumn)>1000).groupBy( UsageColumn).count().withColumn("SUM", sum("count").over()  ).show()
   .withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).drop("fraction")  

//.groupBy("usg").count().withColumn("SUM", sum("count").over()  )
 
    for (date <- dateFinalDF.collect()){
      fileList += DateColumn + "," + date
    }
      for (usage <- usageFinalDF.collect()){
      fileList += UsageColumn + "," + usage
      }
      
    //println(dateFinalDF.groupBy(DateColumn).count())
    val f = fileList.toList
    for (flist <- f) {

      println(flist.replaceAll("[\\[\\]]", ""))

    }
 def f1(number: Double)={ 
   // BigDecimal(((number))).setScale(2, BigDecimal.RoundingMode.HALF_UP).toDouble
      "%.2f".format(number).toDouble
    }
  }

      
  
}