
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.SparkSession
import java.util.Date
import org.apache.spark.sql.functions._

import org.apache.spark.sql.SaveMode

import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.functions.when
import scala.math.BigDecimal
import java.text.DecimalFormat

object New {
  
  def main(args: Array[String]) {
        Logger.getLogger("org").setLevel(Level.OFF)
  
       
  
  
 
   var ColumnsList = new ListBuffer[String]()
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var DateFinal = new ListBuffer[String]()
  var DateColumn: String = ""
  var UsageColumn: String  = ""
   var usageList = new ListBuffer[String]()
    var PaymentColumn: String = ""
   var paymentList = new ListBuffer[String]()
   var DisputeColumn: String = ""
 var TenureColumn: String  = ""
 var arpuColumn: String  = ""
 
     
         val sparkConf = new SparkConf().setMaster("local[4]").setAppName("hbase sql")
    val sc = new SparkContext(sparkConf)
    val spark1 = SparkSession.builder().config(sc.getConf).getOrCreate()
        val sqlContext = spark1.sqlContext
       
 
    import spark1.implicits._
  def f1(number: Double)={ 
      "%.2f".format(number).toDouble
    }
val udfFunc = udf(f1 _)   
 
 
  val headerCSV  = spark1.sqlContext.read.format("CSV").option("header","true").option("delimiter", """|""").load("C:\\Users\\ayushgup\\Downloads\\Header3.csv")

  val columns = headerCSV.columns
  
        
      val data =   spark1.sqlContext.read.format("CSV").option("delimiter", """|""").load("C:/Users/ayushgup/Downloads/home_data_usage_2018122723_1372673.csv").toDF(columns:_*)

data.createOrReplaceTempView("datatv") 


      
//data.select(data.columns.filter(_.contains("Usage")).map(data(_)) : _*)
 
//val rr= columns.filter(_.contains("Usage")).toList.toString

//data.select(rr).withColumn("New_usage", when(col(rr) <= 1000 , "<=1gb").when(col(rr) > 1000 && col("rr") < 5000 , "1-5gb").otherwise(0)).toDF().show()

 for (coll <- columns.toList) {

      if (coll.contains("Date")) {

        DateColumn = coll

        for (datesss <- data.select(coll).collect()) {
          dateList += datesss.toString().slice(1, 8)
       

        }

      } else if (coll.contains("Usage")) {
                 UsageColumn = coll
  val   r =     data.select(coll).withColumn("New_usage", when(col(coll) <= 1000 , "<=1gb").when(col(coll) > 1000 && col(coll) < 5000 , "1-5gb").otherwise(0)).toDF()
    
    data.join(r, coll).drop(coll)
    
    
    
    //.groupBy("New_usage").count   
  // .withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).drop("fraction").show()
             
                 for(usagee <-data.select(coll).where(col(coll)<=1000).collect()){        
                  
                
                 
                  usageList += "<=1gb"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1000).where(col(coll)<5000).collect()){        
                  
                
                 
                  usageList += "1-5gb"   
               
            
                 } 
                 
      
      } else if (coll.contains("PaymentAmount")) {
                 PaymentColumn = coll
           
             
                 for(usagee <-data.select(coll).where(col(coll)>1700).collect()){        
                  
                
                 
                  paymentList += "1700-1900"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1500).where(col(coll)<1700).collect()){        
                  
                
                 
                  paymentList += "1500-1700"   
               
            
                 } 
       } else if (coll.contains("accountTenure")) {
                 TenureColumn = coll
           
             
                 for(usagee <-data.select(coll).where(col(coll)>1000000).where(col(coll)<5000000).collect()){        
                  
                
                 
                  paymentList += "1-5m"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>5000000).where(col(coll)<11000000).collect()){        
                  
                
                 
                  paymentList += "5-11m"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1200000).where(col(coll)<23000000).collect()){        
                  
                
                 
                  paymentList += "12-23m"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>2400000).where(col(coll)<35000000).collect()){        
                  
                
                 
                  paymentList += "24-35m"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>3600000).collect()){        
                  
                
                 
                  paymentList += ">36m"   
               
            
                 } 
      
      } else if (coll.equals("arpu")) {
                 arpuColumn = coll
           
             
                 for(usagee <-data.select(coll).where(col(coll)<1500).collect()){        
                  
                
                 
                  paymentList += "1-1500"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1500).where(col(coll)<1700).collect()){        
                  
                
                 
                  paymentList += "1500-1700"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1700).where(col(coll)<1900).collect()){        
                  
                
                 
                  paymentList += "1700-1900"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>1900).where(col(coll)<2000).collect()){        
                  
                
                 
                  paymentList += "1900-2000"   
               
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>2000).collect()){        
                  
                
                 
                  paymentList += ">2000"   
               
            
                 } 
      }  else if (coll.equals("DisputeAmount")) {
                 DisputeColumn = coll
           
             
                 for(usagee <-data.select(coll).where(col(coll)===0).collect()){        
                  
                
                 
                  paymentList += "0"  
                
            
                 } 
                 for(usagee <-data.select(coll).where(col(coll)>0).collect()){        
                  
                
                 
                  paymentList += "0"  
                
            
                 } 
       } else {
     

        import spark1.implicits._
          
        val actData1 = data.select(coll).toDF(coll).groupBy(coll).count().withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).withColumn("number", udfFunc(col("Percent"))).drop("Percent").drop("fraction")  
        
        
        for (actData <- actData1.collect()) {

          fileList += coll + "," + actData

        }

      }
    }

    val dateFinal = dateList.toList
    val usageFinal = usageList.toList
    val paymentFinal = paymentList.toList
    
   
    
    data.show()
    import spark1.implicits._
     
    var dateFinalDF = dateFinal.toDF(DateColumn).groupBy(DateColumn).count  
 .withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).withColumn("number", udfFunc(col("Percent"))).drop("fraction")         
  
 
  
var usageFinalDF = usageFinal.toDF(UsageColumn).groupBy(UsageColumn).count   
   .withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).withColumn("number", udfFunc(col("Percent"))).drop("Percent").drop("fraction")  

var paymentFinalDF = paymentFinal.toDF(PaymentColumn).groupBy(PaymentColumn).count   
   .withColumn("SUM", sum("count").over()  ).withColumn("fraction", col("count") /  sum("count").over()).withColumn("Percent", col("fraction") * 100   ).withColumn("number", udfFunc(col("Percent"))).drop("Percent").drop("fraction")
    for (date <- dateFinalDF.collect()){
      fileList += DateColumn + "," + date
    }
      for (usage <- usageFinalDF.collect()){
      fileList += UsageColumn + "," + usage
      }
      
      for (payment <- paymentFinalDF.collect()){
      fileList += PaymentColumn + "," + payment
      } 
      
   
    val f = fileList.toList
    for (flist <- f) {

      println(flist.replaceAll("[\\[\\]]", ""))

    }
    
   
  }

      
  
}