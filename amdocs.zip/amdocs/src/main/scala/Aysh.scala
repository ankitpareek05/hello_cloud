

import scala.io.Source
import org.apache.spark._
import org.apache.spark.sql.hive.HiveContext
import scala.util.control.Breaks._
import org.apache.log4j._
import scala.collection.mutable.ListBuffer
import org.apache.spark.sql.SparkSession

trait init1 {
  var metaData: String = null
  var ColumnsList = new ListBuffer[String]()
  var fileList = new ListBuffer[String]()
  var dateList = new ListBuffer[String]()
  var DateFinal = new ListBuffer[String]()
  var DateColumn: String = ""

}

object Aysh extends init1 {

  //val sqlContext = spark.sqlContext
  //main method for entry point
  def main(args: Array[String]) {

    val sparkConf = new SparkConf().setAppName("HiveStore")
    val sc = new SparkContext(sparkConf)
    val spark1 = SparkSession.builder().config(sc.getConf).enableHiveSupport().getOrCreate()

    //val spark: SparkSession =  SparkSession.builder().appName("AppName").enableHiveSupport().getOrCreate()

    //val sc = spark.sparkContext

    Logger.getLogger("org").setLevel(Level.OFF)

    val column: String = null
    val dataType: String = null

    val ymlFilePath: String = args(0)
    val csvFilePath: String = args(1)
    //println(csvFilePath)
    var fileName = csvFilePath.split("/").last
    var tableName = fileName.split(".csv").mkString
    //println(tableName.mkString)
    // fileName.foreach(println(_))

    getMetaData(ymlFilePath)

    // Create a Sql context with
    //val sc = new SparkContext("local[*]", "HiveStore")

    // Read each line of my book into an RDD
    //val sqlContext = new HiveContext(sc)
    import spark1.implicits._
    import spark1.sql

    //print("CREATE TABLE IF NOT EXISTS FileLoad (" + metaData + ") stored as orc tblproperties (\"orc.compress\"=\"NONE\")")
    //print("LOAD DATA LOCAL INPATH '" + csvFilePath + "' INTO TABLE FileLoad")
    sql("DROP TABLE IF EXISTS pontis_analyst." + tableName)
    sql("CREATE EXTERNAL TABLE IF NOT EXISTS pontis_analyst." + tableName + " (" + metaData + ") ROW FORMAT DELIMITED FIELDS TERMINATED BY '|' LOCATION '/user/bdauser/hiveValidation/" + tableName + "'")
    sql("LOAD DATA LOCAL INPATH '" + csvFilePath + "' OVERWRITE INTO TABLE pontis_analyst." + tableName)

    
    val rowData = sql("select * from pontis_analyst." + tableName)

   
    //import spark1.implicits._
    val data = rowData.toDF

    for (col <- ColumnsList.toList) {

      if (col.contains("Date")) {

        DateColumn = col

        for (datesss <- data.select(col).collect()) {
          dateList += datesss.toString().slice(1, 8)
          //println("Datelist as string" + dateList.toList.toString())

        }

      } else if (col.contains("Usage")) {

        //var usage = data.select(col).filter($col < 10000)
        println("usagejksfsdfsifhs f sfhshfhfhfiehfiwehfio")

      } else {
        println("Final elsebjbbvvivivhhiff i")

        import spark1.implicits._

        for (actData <- data.select(col).toDF(col).groupBy(col).count().collect()) {

          fileList += col + "," + actData

        }

      }
    }

    val dateFinal = dateList.toList
    import spark1.implicits._

    var dateFinalDF = dateFinal.toDF(DateColumn).groupBy(DateColumn).count()

    for (data <- dateFinalDF.collect())
      fileList += DateColumn + "," + data

    //println(dateFinalDF.groupBy(DateColumn).count())
    val f = fileList.toList
    for (flist <- f) {

      println(flist.replaceAll("[\\[\\]]", ""))

    }

  }

  //Get metaData from application.yml file
  def getMetaData(ymlFilePath: String) {
    val source = Source.fromFile(ymlFilePath)

    breakable {
      for (line <- source.getLines()) {

        if ((line.contains("- name:")) && ((line.split(":").last.mkString == " fileName") || (line.split(":").last.mkString == " fileProperties") || (line.split(":").last.mkString == " filePropertiesHSUC") || (line.split(":").last.mkString == " filePropertiesMonthlyProf") || (line.split(":").last.mkString == " filePropertiesHomeProduct") || (line.split(":").last.mkString == " filePropertiesBillingSub")))
          break

        else {
          if (line.contains("- name:")) {

            var column = line.split(":").last.mkString
            ColumnsList += column.trim()
            println("columns name " + column.trim())

            if (metaData != null) {
              metaData = metaData.concat(",")
              metaData = metaData.concat(column + " ")

            } else {
              metaData = column

            }
            metaData = metaData.concat(" ")
          } else if (line.contains("type:")) {
            val dataType = line.split(":").last.mkString
            metaData = metaData.concat(dataType)
          }
        }
      }

    }

    source.close()

  }

}

