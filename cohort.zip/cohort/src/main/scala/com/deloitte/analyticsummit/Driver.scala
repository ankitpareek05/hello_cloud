package com.deloitte.analyticsummit
import java.time.temporal.ChronoUnit
import org.apache.spark.sql.functions._
import java.time.LocalDate
import org.apache.spark.sql.types.DecimalType


object Driver {
     val sparkSession = InitiateSparkContext.getSparkSession()
  def main(args: Array[String]){
    
    // read user table 
    
    var df1= CommonUtils.readFromCsvFile("src//main//resources//users.csv", "true", "false")
    df1= df1.na.fill("").toDF(df1.columns.map(_.toUpperCase()):_*)
    
     df1= df1.withColumn("TIMESTAMP", CommonUtils.udfstandardizeDateYYYYMMDD(df1("TIMESTAMP"), lit("yyyyMMdd"))).alias("users")
    // read activies table
    var df2= CommonUtils.readFromCsvFile("src//main//resources//activities.csv", "true", "false")
    df2= df2.na.fill("").toDF(df2.columns.map(_.toUpperCase()):_*)
    
    
    
    df2=df2.withColumn("TIMESTAMP", CommonUtils.udfstandardizeDateYYYYMMDD(df2("TIMESTAMP"), lit("yyyyMMdd"))).alias("activities")
   

    df2= df2.withColumn("MONTH",CommonUtils.udf_month_value(df2("TIMESTAMP")))
    
   // df2=df2.withColumn("month", CommonUtils.udf_month_between())
    df1.show()
    df2.show()
    
    val cohort_items=df1.withColumn("COHORT_MONTH",CommonUtils.udf_month_value(df1("TIMESTAMP"))).orderBy("COHORT_MONTH","ID")
    //cohort_items.show()
    
    var user_activities = df2.join(cohort_items,df2("USERID")===cohort_items("ID"),"left")
    .withColumn("MONTH_NUMBER", CommonUtils.udf_month_between(df2("TIMESTAMP"),cohort_items("TIMESTAMP")))
    user_activities=user_activities.select(user_activities("USERID"), user_activities("MONTH_NUMBER")).groupBy(user_activities("USERID"), user_activities("MONTH_NUMBER")).count()
    user_activities=user_activities.drop(user_activities("count"))
    user_activities.show()

    var cohort_size= cohort_items.groupBy(cohort_items("COHORT_MONTH")).agg(count(cohort_items("COHORT_MONTH")).alias("NUM_USERS"))
    cohort_size=cohort_size.select(cohort_size("COHORT_MONTH"),cohort_size("NUM_USERS"))
    
    //cohort_size.show()
    
    println ("user activites")
   // user_activities.show()
    
    println("Items")
    //cohort_items.show()
    
    
    var retention_table=user_activities.join(cohort_items,user_activities("USERID")===cohort_items("ID"),"left")
    
    .groupBy(cohort_items("COHORT_MONTH"),user_activities("MONTH_NUMBER"))
    .agg(count(cohort_items("COHORT_MONTH")).alias("NUM_USERS"))
    //retention_table=retention_table
   // retention_table.show()
    
    
    var final_table= retention_table.join(cohort_size,retention_table("COHORT_MONTH")===cohort_size("COHORT_MONTH")).filter(retention_table("COHORT_MONTH").isNotNull)//.orderBy("cohort_month","month_number")
    .withColumn("PERCENTAGE", retention_table("NUM_USERS")*100/cohort_size("NUM_USERS"))
    .select(retention_table("COHORT_MONTH"),cohort_size("NUM_USERS").alias("TOTAL_USERS"),retention_table("MONTH_NUMBER"),col("PERCENTAGE").cast(DecimalType(15,2)))
    final_table.show()
    //final_table=final_table.withColumn("PERCENTAGE", CommonUtils.udfFunc(col("PERCENTAGE1")))
    //.select(retention_table("COHORT_MONTH"),cohort_size("NUM_USERS").alias("TOTAL_USERS"),retention_table("MONTH_NUMBER"),col("PERCENTAGE"))
   
    final_table.printSchema()

    final_table.show()
    //.groupBy(col1, cols)
       
    
    
  }
  
}