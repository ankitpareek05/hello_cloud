package com.deloitte.analyticsummit

import java.net.URI
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Date
import java.time.format.DateTimeFormatter
import java.time.LocalDateTime

import scala.collection.Map
import scala.collection.mutable._

import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.storage.StorageLevel
import java.time.temporal.ChronoUnit
import java.time.LocalDate


/*
 * Common Utils for Utility functions
 * Developer: Ankit Pareek
 */

object CommonUtils {

  // Getting sparkSession object
  val sparkSession = InitiateSparkContext.getSparkSession()

  // Getting sparkContext object
  val sparkContext = InitiateSparkContext.getSparkContext()

  // Getting sqlContext object
  val sqlContext = InitiateSparkContext.getSqlContext()

  import sparkSession.implicits._

  /**
   * @input: array of column names
   * @return : array of columns
   */
 
  /**
   * Read data from file and convert it into DataFrame
   * @Input:inputfilePath,delimiter,Header=True/False
   * @return:Dataframe
   */

  def readFromCsvFile(inputFile: String, headerVal: String, inferSchema: String): DataFrame = {
    val sparkSession = InitiateSparkContext.getSparkSession()
    val dataFrame = sparkSession.read
      .option("header", headerVal)
      .option("inferSchema", inferSchema)
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL")
      .csv(inputFile)
    dataFrame
  }



  /**
   * Get current time stamp
   * Developer: Ankit Pareek
   */
  def getTimeStamp(): (String, Long) = {

    val unixTime: Long = System.currentTimeMillis
    val currentTimeStamp = new Timestamp(unixTime)
    (currentTimeStamp.toString(), unixTime)

  }

  /**
   * Add Source timeStamp to the dataframe
   * @return:Dataframe
   */
 
  def writeSFDCObjects(data: DataFrame, instance: String, userName: String, password: String, objectName: String) = {
    data.write.format("com.springml.spark.salesforce").
      //mode(SaveMode.Append).
      option("login", instance).
      option("username", userName).
      option("password", password).
      //option("datasetName", "Account").
      option("sfObject", objectName).
      option("version", "43.0")
      .option("ignoreLeadingWhiteSpace", "true")
      .option("ignoreTrailingWhiteSpace", "true")
      .option("escape", "\"")
      .option("multiLine", true)
      .option("nullValue", "")
      .option("nullValue", null)
      .option("nullValue", "NULL").
      save()

  }
  
   def udfstandardizeDateYYYYMMDD = udf { (dateColumn: String, format: String) =>
    {
      var dtCol = dateColumn
      var frmtlen = format.size
      if (dtCol.size < frmtlen) {
        val dtCol1 = dtCol.toInt
        dtCol = f"$dtCol1%08d"
      }
      val inputdateFormat = new SimpleDateFormat(format)
      val inputdate = inputdateFormat.parse(dateColumn)
      val dateFormatStr = "yyyy-MM-dd"

      val outputDateFormat = new SimpleDateFormat(dateFormatStr)
      val formattedDate = outputDateFormat.format(inputdate)
      formattedDate
    }
    

  }

       
    def month_between(date1:String,date2:String):Option[Long]={
          
      val date_1=Option(date1).getOrElse(return None)
      val date_2=Option(date2).getOrElse(return None)
      val s1= LocalDate.parse(date1)  
      val s2 = LocalDate.parse(date2)
      val c=ChronoUnit.MONTHS.between(s1, s2)
      Some(c)
    }
//= udf {(date1:String ,date2:String) =>
    
    val udf_month_between=udf[Option[Long],String, String](month_between)
    
    
def udf_month_value = udf {(date1:String) =>
      val s1 = LocalDate.parse(date1)      
      val d=s1.getMonthValue
      d
    }

  def f1(number: Double) = {
    "%.2".format(number).toString() + " %"
  }
  val udfFunc = udf(f1 _)

 

}