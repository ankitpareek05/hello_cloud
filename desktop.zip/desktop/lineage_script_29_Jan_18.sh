#!/bin/bash

nTables=0
target_db=""
target_table=""
tblPrCnt=0
level=0

main(){

 initialize $1

}

initialize(){
 
 directory_search="/home/hadoop/Nordea/"
 temp_dir="/home/hadoop/test_lineage/"
 target_dir="/home/hadoop/Developments/lineage/"
 target_file="$target_dir""lineage.csv"
 nTables=$(cat "$1" | wc -l)
 echo "TOTAL TABLES == $nTables" 
 
 while read -r line
 do

  if [[ "$line" != "NIL" ]]; then
   target_db=$(echo $line | awk -F"." '{print $1}')
   target_table=$(echo $line | awk -F"." '{print $2}')
   if [ -z "$target_table" ];then
     echo "TARGET TABLE CANNOT BE IDENTIFIED FOR $target_table"
     target_table=$(echo $line | awk -F"." '{print $1}')
   fi

   echo "DATABASE.TABLE == $target_db.$target_table"

   tblPrCnt=`expr $tblPrCnt + 1`
   generateQueries $directory_search $temp_dir $target_db $target_table
  fi

 done < "$1"
 

 newArray=()
 if [ ! -f "$target_file" ]
  then
    echo "LEVEL,TARGET_DB.TARGET_TABLE,SOURCE_DB.SOURCE_TABLE" >> $target_file
    cat $temp_dir"FINAL-MAP-LEVEL-$level""-SOURCE" >> $target_file
    newArray=($(cat $temp_dir"FINAL-MAP-LEVEL-$level""-SOURCE" | awk -F"," '{print $3}' | sort | uniq | xargs))
    printf "%s\n" "${newArray[@]}" > $temp_dir"target_table"  
  else
    cat $temp_dir"FINAL-MAP-LEVEL-$level""-SOURCE" >> $target_file
   parsed_tbl=($(tail -n +2 "$target_file" | awk -F"," '{print $2}' | sort | uniq | xargs))

    newTblsToParse=($(cat $temp_dir"FINAL-MAP-LEVEL-$level""-SOURCE" | awk -F"," '{print $3}' | sort | uniq | xargs))
    arrCnt=0
#    newArray=()
    for tbl in "${newTblsToParse[@]}"
    do
     checkExist=$(echo "${parsed_tbl[@]}" | grep -w "$tbl" | wc -l)
     if [ $checkExist == 0 ];then
        newArray+=("$tbl")
     fi
     arrCnt=`expr $arrCnt + 1`
    done
     printf "%s\n" "${newArray[@]}" > $temp_dir"target_table"

  fi

 level=`expr $level + 1`

 if [ ${#newArray[@]} -eq 0 ]; then
    echo "LINEAGE COMPLETED ...."
   exit 1
# else
#   initialize $temp_dir"target_table"
 fi

# initialize $temp_dir"target_table"

}


generateQueries(){

  checkExist=$(grep --exclude=*.dot -rnw "$directory_search" -e "$target_db.$target_table" | grep "$target_table.tbl" | wc -l)
  if [ $checkExist -eq 1 ]; then
   echo "$target_table EXISTS $checkExist AS TABLE"
   query_type="INSERT"
  else
   echo "$target_table EXISTS $checkExist AS VIEW"
   query_type="REPLACE"
  fi

  executeType $directory_search $temp_dir $target_db $target_table $query_type 
}


executeType(){

  if [[ "$query_type" == "REPLACE" ]];then
    echo "SEARCHING "$target_db.$target_table" FOR REPLACE"
    grep --exclude=*.dot -rnw "$directory_search" -e "$target_db.$target_table" | grep "$target_table.vw" > $temp_dir"$target_db.$target_table""-LIST"
  else
    echo "SEARCHING "$target_db.$target_table" FOR INSERT"
    grep --exclude=*.dot -rnw "$directory_search" -e "$target_db.$target_table" | grep "$query_type" > $temp_dir"$target_db.$target_table""-LIST"
  fi

 if [ ! -s $temp_dir"$target_db.$target_table""-LIST" ]; then
   echo "$temp_dir"$target_db.$target_table""-LIST" is EMPTY"
   echo "$level,$target_db.$target_table,NIL" >> $temp_dir"TEMP-MAP-$level""-SOURCE" 
 else

 declare -a tableList
 cntr=0
 while read -r line
 do

  fileName=$(echo $line | awk -F":" '{print $1}')
  lineNum=$(echo $line | awk -F":" '{print $2}')

  fname=`basename $fileName`

  if [[ ( "$fname" == *"_DELETE_"*".sql" ) || ( "$fname" == *"_HOLD.sql" ) || ( "$fname" == *"_hold.sql" ) || ( "$fname" == *"_D.sql" ) || ( "$fname" == *"_D.vw" ) || ( "$fname" == *"_HOLD.vw" ) ]];then
   echo "$fname IS DECOMISSIONED"
  else
   echo "$fname IS NOT"

  if [ "${fname##*.}" = "sql" ]; then
   tblExist=$(cat $fileName | sed -n "$lineNum,/;/p" | sed 's/*\//AAAAA/g' | sed 's/\/\*/AAAAA/g' | sed -r 's/(AAAAA)(.*AAAAA)//g' | sed '/AAAAA/,/AAAAA/d' | sed 's/--.*/ /g' | sed 's/\r//g' | sed ':a;N;$!ba;s/\n/ /g' | awk '{for (I=1;I<=NF;I++) if ($I == "JOIN" || $I == "FROM") {print $(I+1)};}' | tr '[:lower:]' '[:upper:]' | sort | uniq | grep -v "(" | sed 's/;//g' | sed 's/)//g' | wc -l)
  else
   tblExist=$(cat $fileName | sed 's/\r//g' | sed ':a;N;$!ba;s/\n/ /g' | awk '{for (I=1;I<=NF;I++) if ($I == "JOIN" || $I == "FROM") {print $(I+1)};}' | tr '[:lower:]' '[:upper:]' | sort | uniq | grep -v "(" | sed 's/;//g' | sed 's/)//g' | awk '/\./' | wc -l)
  fi

  if [[ $tblExist > 0 ]]; then
   if [ "${fname##*.}" = "sql" ]; then
     tableList=($(cat $fileName | sed -n "$lineNum,/;/p" | sed 's/*\//AAAAA/g' | sed 's/\/\*/AAAAA/g' | sed -r 's/(AAAAA)(.*AAAAA)//g' | sed '/AAAAA/,/AAAAA/d' | sed 's/--.*/ /g' | sed 's/\r//g' | sed ':a;N;$!ba;s/\n/ /g' | awk '{for (I=1;I<=NF;I++) if ($I == "JOIN" || $I == "FROM") {print $(I+1)};}' | tr '[:lower:]' '[:upper:]' | sort | uniq | grep -v "(" | sed 's/;//g' | sed 's/)//g'))
   else
     tableList=($(cat $fileName | sed 's/\r//g' | sed ':a;N;$!ba;s/\n/ /g' | awk '{for (I=1;I<=NF;I++) if ($I == "JOIN" || $I == "FROM") {print $(I+1)};}' | tr '[:lower:]' '[:upper:]' | sort | uniq | grep -v "(" | sed 's/;//g' | sed 's/)//g' | awk '/\./'))
   fi

  printf "%s\n" "${tableList[@]}" >> $temp_dir"TEST-LEVEL-$level""-SOURCE"

  for input in "${tableList[@]}"
  do
   echo "INSIDE LINEAGE === ""$target_db.$target_table,$input"
   if [ "$target_db.$target_table" != "$input" ]
   then
      echo "$level,$target_db.$target_table,$input" >> $temp_dir"TEMP-MAP-$level""-SOURCE"
   fi
  done  
  fi

 fi

  echo "=========================="
 done < $temp_dir"$target_db.$target_table""-LIST" 

fi

mv $temp_dir"$target_db.$target_table""-LIST" "$target_dir"
 

   sortTbls=$(cat $temp_dir"TEMP-MAP-$level""-SOURCE" | awk -F"," '{print $3}' | sort | uniq)
   sortMap=$(cat $temp_dir"TEMP-MAP-$level""-SOURCE" | sort | uniq)
   printf "%s\n" "${sortTbls[@]}" > $temp_dir"LEVEL-$level""-SOURCE"
   printf "%s\n" "${sortMap[@]}" > $temp_dir"FINAL-MAP-LEVEL-$level""-SOURCE"

}

main $1