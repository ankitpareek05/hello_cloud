'''
Created on Sep 13, 2018

@author: vishagrawal
'''
#!/usr/bin/python
#import xlrd 
import boto3
import sys

xl_path = r"/home/hadoop/ai_vishal/python/athena.xlsx"
sqlFileLocation = sys.argv[1]
databaseName = sys.argv[2]


def get_xl_content_in_list():
    list_of_xl_val = []
    book = xlrd.open_workbook(xl_path)
    first_sheet = book.sheet_by_index(0)
    no_of_rows = first_sheet.nrows
    no_of_cols = first_sheet.ncols
    print("Rows: %s, Columns : %s" % (no_of_rows, no_of_cols))
    for row in range(1, no_of_rows):
        
        database_name = first_sheet.cell_value(row, 0)
        table_name = first_sheet.cell_value(row, 1)
        source_name = first_sheet.cell_value(row, 2)
        file_name = first_sheet.cell_value(row, 3)
        query = first_sheet.cell_value(row, 4)
        list_of_xl_val.append([database_name , table_name, source_name, file_name, query ])
    return(list_of_xl_val) 

def getSQLQueries(sqlFileLocation):
    sqlFileList = open(sqlFileLocation, 'r').readlines()
    sqlFileListClean = [line.strip() for line in sqlFileList if not line.startswith('--') if line != '\n' if line!=""]
    return sqlFileListClean
	
	
# Function for starting athena query
def run_query(query, database, s3_output):
    client = boto3.client('athena')
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': database
            },
        ResultConfiguration={
            'OutputLocation': s3_output,
            }
        )
    print('Execution ID: ' + response['QueryExecutionId'])
    return response


querySet = getSQLQueries(sqlFileLocation)
s3_output = r"s3://ai-00688001-processing-dev/test/ai_vishal/athena/"

for query in querySet:
    if query!="":
        print("Executing query: %s" % query)
        res = run_query(query, databaseName, s3_output)
